const GameMessage = require('../../../Logic/Message/GameMessage')

class StartSpectateMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14104
    this.version = 0
    this.accountId = 0
  }

  decode () {
    this.accountId = this.readLong().toNumber()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = StartSpectateMessage
