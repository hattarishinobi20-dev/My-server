const GameMessage = require('../../../Logic/Message/GameMessage')

class StopSpectateMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14107
    this.version = 0
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = StopSpectateMessage
