const GameMessage = require('../../../Logic/Message/GameMessage')

class MatchmakeRequestMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14103
    this.version = 0
    this.characterInstanceId = 0
    this.eventSlot = 0
  }

  decode () {
    this.readVInt()
    this.characterInstanceId = this.readVInt()
    this.readVInt()
    this.eventSlot = this.readVInt()
    if (this.eventSlot > 3) this.eventSlot = 1
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = MatchmakeRequestMessage
