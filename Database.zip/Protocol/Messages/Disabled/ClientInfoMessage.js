const GameMessage = require('../../../Logic/Message/GameMessage')

class ClientInfoMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 10177
    this.version = 0
  }

  getServiceNodeType () {
    return 27
  }
}

module.exports = ClientInfoMessage
