const GameMessage = require('../../../Logic/Message/GameMessage')
const BitStream = require('../../../Titan/DataStream/BitStream')
const ClientInput = require('../../../Logic/Battle/Input/ClientInput')

class ClientInputMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 10555
    this.version = 0
    this.inputs = []
  }

  decode () {
    const stream = new BitStream(this.buffer, this.length)
    stream.readPositiveInt(14)
    stream.readPositiveInt(10)
    stream.readPositiveInt(13)
    stream.readPositiveInt(10)
    const count = stream.readPositiveInt(5)
    for (let i = 0; i < count; i++) {
      const input = new ClientInput()
      input.decode(stream)
      this.inputs.push(input)
    }
  }

  getServiceNodeType () {
    return 27
  }
}

module.exports = ClientInputMessage
