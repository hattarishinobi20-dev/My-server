const GameMessage = require('../../../Logic/Message/GameMessage')

class JoinableAllianceListMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24304
    this.version = 0
    this.joinableAlliances = []
  }

  encode () {
    this.writeVInt(this.joinableAlliances.length)
    for (const entry of this.joinableAlliances) {
      entry.encode(this)
    }
  }

  getServiceNodeType () {
    return 11
  }
}

module.exports = JoinableAllianceListMessage
