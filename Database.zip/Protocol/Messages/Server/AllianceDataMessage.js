const GameMessage = require('../../../Logic/Message/GameMessage')

class AllianceDataMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24301
    this.version = 0
    this.alliance = null
    this.isMyAlliance = false
  }

  encode () {
    this.writeBoolean(this.isMyAlliance)
    this.alliance.encode(this)
  }

  getServiceNodeType () {
    return 11
  }
}

module.exports = AllianceDataMessage
