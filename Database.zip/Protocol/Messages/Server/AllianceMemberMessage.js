const GameMessage = require('../../../Logic/Message/GameMessage')

class AllianceMemberMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24308
    this.version = 0
    this.avatarId = 0
    this.entry = null
  }

  encode () {
    this.writeLong(this.avatarId)
    this.entry.encode(this)
  }

  getServiceNodeType () {
    return 11
  }
}

module.exports = AllianceMemberMessage
