const GameMessage = require('../../../Logic/Message/GameMessage')

class AddFriendFailedMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 20112
    this.version = 0
    this.reason = 0
  }

  encode () {
    this.writeInt(this.reason)
  }

  getServiceNodeType () {
    return 3
  }
}

module.exports = AddFriendFailedMessage
