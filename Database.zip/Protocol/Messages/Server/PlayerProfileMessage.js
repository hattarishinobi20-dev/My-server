const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')
const GlobalId = require('../../../Logic/Data/Helper/GlobalId')
const AllianceRole = require('../../../Logic/Avatar/AllianceRole')

class PlayerProfileMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24113
    this.version = 0
    this.profile = null
    this.allianceHeader = null
    this.allianceRole = AllianceRole.None
  }

  encode () {
    this.profile.encode(this)
    if (this.writeBoolean(this.allianceHeader != null)) {
      this.allianceHeader.encode(this)
    }

    if (this.allianceRole > AllianceRole.None) {
      ByteStreamHelper.writeDataReference(this, GlobalId.createGlobalId(25, this.allianceRole))
    } else {
      this.writeVInt(0)
    }
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = PlayerProfileMessage
