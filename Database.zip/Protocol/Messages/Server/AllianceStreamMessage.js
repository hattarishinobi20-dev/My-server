const GameMessage = require('../../../Logic/Message/GameMessage')

class AllianceStreamMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24311
    this.version = 0
    this.entries = null
  }

  encode () {
    if (this.entries == null) {
      this.writeVInt(-1)
      return
    }

    this.writeVInt(this.entries.length)
    for (const entry of this.entries) {
      entry.encode(this)
    }
  }

  getServiceNodeType () {
    return 11
  }
}

module.exports = AllianceStreamMessage
