const GameMessage = require('../../../Logic/Message/GameMessage')

class AvailableServerCommandMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24111
    this.version = 0
    this.command = null
  }

  encode () {
    this.writeVInt(this.command.getCommandType())
    this.command.encode(this)
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = AvailableServerCommandMessage
