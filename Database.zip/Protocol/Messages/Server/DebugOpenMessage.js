const GameMessage = require('../../../Logic/Message/GameMessage')

class DebugOpenMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 20500
    this.version = 0
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = DebugOpenMessage
