const GameMessage = require('../../../Logic/Message/GameMessage')

class CreatePlayerMapResponseMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 22100
    this.version = 0
    this.map = null
  }

  encode () {
    this.writeVInt(0)
    if (this.writeBoolean(this.map != null)) {
      this.map.encode(this)
    }
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = CreatePlayerMapResponseMessage
