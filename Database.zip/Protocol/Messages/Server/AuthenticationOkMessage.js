const GameMessage = require('../../../Logic/Message/GameMessage')

class AuthenticationOkMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 20104
    this.version = 0
    this.accountId = 0
    this.passToken = null
    this.serverEnvironment = null
    this.major = 0
    this.minor = 0
    this.build = 0
  }

  encode () {
    this.writeLong(this.accountId)
    this.writeLong(this.accountId)
    this.writeString(this.passToken)
    this.writeString(null)
    this.writeString(null)
    this.writeInt(this.major)
    this.writeInt(this.build)
    this.writeInt(this.minor)
    this.writeString(this.serverEnvironment)
    this.writeInt(0)
    this.writeInt(0)
    this.writeInt(0)
    this.writeString('103121310241222')
    this.writeString('')
    this.writeString('')
    this.writeInt(0)
    this.writeString(null)
    this.writeString('BR')
    this.writeString(null)
    this.writeInt(2)
    this.writeString('')
    this.writeInt(2)
    this.writeString('https://game-assets.brawlstarsgame.com')
    this.writeString('http://a678dbc1c015a893c9fd-4e8cc3b1ad3a3c940c504815caefa967.r87.cf2.rackcdn.com')
    this.writeInt(2)
    this.writeString('https://raw.githubusercontent.com/IsaaSooBarr/Project-LaserScratch/main/Files/EventAssets/')
    this.writeString('https://24b999e6da07674e22b0-8209975788a0f2469e68e84405ae4fcf.ssl.cf2.rackcdn.com/event-assets')
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = AuthenticationOkMessage
