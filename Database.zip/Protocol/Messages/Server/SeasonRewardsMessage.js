const GameMessage = require('../../../Logic/Message/GameMessage')

const STAR_POINTS_TROPHIES_START = Object.freeze([550, 600, 650, 700, 750, 800, 850, 900, 950, 1000, 1050, 1100, 1150, 1200, 1250, 1300, 1350, 1400])
const STAR_POINTS_TROPHIES_END = Object.freeze([599, 649, 699, 749, 799, 849, 899, 949, 999, 1049, 1099, 1149, 1199, 1249, 1299, 1349, 1399, -1])
const STAR_POINTS_SEASON_REWARD_AMOUNT = Object.freeze([70, 120, 160, 200, 220, 240, 260, 280, 300, 320, 340, 360, 380, 400, 420, 440, 460, 480])
const STAR_POINTS_TROPHIES_IN_RESET = Object.freeze([525, 550, 600, 650, 700, 725, 750, 775, 800, 825, 850, 875, 900, 925, 950, 975, 1000, 1025])

class SeasonRewardsMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24123
    this.version = 0
    this.playersCount = 0
    this.lobbyData = null
  }

  encode () {
    this.writeVInt(1)
    this.writeVInt(STAR_POINTS_TROPHIES_START.length)
    for (let x = 0; x < STAR_POINTS_TROPHIES_START.length; x++) {
      this.writeVInt(STAR_POINTS_TROPHIES_START[x])
      this.writeVInt(STAR_POINTS_TROPHIES_END[x])
      this.writeVInt(STAR_POINTS_SEASON_REWARD_AMOUNT[x])
      this.writeVInt(STAR_POINTS_TROPHIES_IN_RESET[x])
      this.writeVInt(0)
      this.writeVInt(0)
    }
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = SeasonRewardsMessage
