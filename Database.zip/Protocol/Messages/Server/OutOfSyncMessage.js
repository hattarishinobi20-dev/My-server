const GameMessage = require('../../../Logic/Message/GameMessage')

class OutOfSyncMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24104
    this.version = 0
  }

  encode () {
    this.writeVInt(0)
    this.writeVInt(0)
    this.writeVInt(0)
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = OutOfSyncMessage
