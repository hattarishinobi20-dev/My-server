const GameMessage = require('../../../Logic/Message/GameMessage')

class FriendListUpdateMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 20106
    this.version = 0
    this.entry = null
  }

  encode () {
    this.writeBoolean(true)
    this.entry.encode(this)
  }

  getServiceNodeType () {
    return 3
  }
}

module.exports = FriendListUpdateMessage
