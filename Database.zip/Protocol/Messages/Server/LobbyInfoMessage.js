const GameMessage = require('../../../Logic/Message/GameMessage')

class LobbyInfoMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 23457
    this.version = 0
    this.playersCount = 0
    this.lobbyData = null
  }

  encode () {
    this.writeVInt(this.playersCount)
    this.writeString(this.lobbyData)
    this.writeVInt(0)
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = LobbyInfoMessage
