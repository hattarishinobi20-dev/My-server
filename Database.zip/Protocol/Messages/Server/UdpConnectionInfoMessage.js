const GameMessage = require('../../../Logic/Message/GameMessage')

class UdpConnectionInfoMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24112
    this.version = 0
    this.serverPort = 0
    this.serverAddress = null
    this.sessionId = 0
  }

  encode () {
    this.writeVInt(this.serverPort)
    this.writeString(this.serverAddress)
    this.writeInt(10)
    this.writeLong(this.sessionId)
    this.writeShort(0)
    this.writeInt(0)
  }

  getServiceNodeType () {
    return 27
  }
}

module.exports = UdpConnectionInfoMessage
