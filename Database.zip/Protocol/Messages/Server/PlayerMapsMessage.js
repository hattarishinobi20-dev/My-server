const GameMessage = require('../../../Logic/Message/GameMessage')

class PlayerMapsMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 22102
    this.version = 0
    this.maps = []
  }

  encode () {
    this.writeVInt(this.maps.length)
    for (const map of this.maps) {
      map.encode(this)
    }
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = PlayerMapsMessage
