const GameMessage = require('../../../Logic/Message/GameMessage')

class MatchMakingStatusMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 20405
    this.version = 0
    this.seconds = 0
    this.found = 0
    this.max = 0
    this.showTips = false
  }

  encode () {
    this.writeInt(this.seconds)
    this.writeInt(this.found)
    this.writeInt(this.max)
    this.writeInt(0)
    this.writeInt(0)
    this.writeBoolean(this.showTips)
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = MatchMakingStatusMessage
