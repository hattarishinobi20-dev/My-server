const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')

class UpdatePlayerMapResponseMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 22103
    this.version = 0
    this.mapId = 0
    this.errorCode = 0
  }

  encode () {
    this.writeVInt(this.errorCode)
    ByteStreamHelper.encodeLogicLong(this, this.mapId)
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = UpdatePlayerMapResponseMessage
