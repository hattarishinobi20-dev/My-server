const GameMessage = require('../../../Logic/Message/GameMessage')

class AllianceResponseMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24333
    this.version = 0
    this.responseType = 0
  }

  encode () {
    this.writeVInt(this.responseType)
  }

  getServiceNodeType () {
    return 11
  }
}

module.exports = AllianceResponseMessage
