const GameMessage = require('../../../Logic/Message/GameMessage')

class OwnHomeDataMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24101
    this.version = 0
    this.home = null
    this.avatar = null
  }

  encode () {
    this.writeVInt(0)
    this.writeVInt(0)
    this.home.encode(this)
    this.avatar.encode(this)
    this.writeVInt(0)
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = OwnHomeDataMessage
