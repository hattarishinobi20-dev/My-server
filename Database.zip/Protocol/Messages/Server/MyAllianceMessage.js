const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')
const GlobalId = require('../../../Logic/Data/Helper/GlobalId')

class MyAllianceMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24399
    this.version = 0
    this.onlineMembers = 0
    this.role = 0
    this.allianceHeader = null
  }

  encode () {
    this.writeVInt(this.onlineMembers)
    if (this.writeBoolean(this.allianceHeader != null)) {
      ByteStreamHelper.writeDataReference(this, GlobalId.createGlobalId(25, this.role))
      this.allianceHeader.encode(this)
    }
  }

  getServiceNodeType () {
    return 11
  }
}

module.exports = MyAllianceMessage
