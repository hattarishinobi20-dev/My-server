const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamStreamMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24131
    this.version = 0
    this.teamId = 0
    this.entries = []
  }

  encode () {
    this.writeVLong(this.teamId)
    this.writeVInt(this.entries.length)
    for (const entry of this.entries) {
      entry.encode(this)
    }
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamStreamMessage
