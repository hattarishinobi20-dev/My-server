const GameMessage = require('../../../Logic/Message/GameMessage')

class CreateAccountOkMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 26007
    this.version = 0
    this.accountId = 0
    this.passToken = null
  }

  encode () {
    this.writeStringReference(this.passToken)
    this.writeLong(this.accountId)
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = CreateAccountOkMessage
