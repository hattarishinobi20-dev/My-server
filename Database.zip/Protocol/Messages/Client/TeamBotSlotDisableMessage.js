const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamBotSlotDisableMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14373
    this.version = 0
    this.botSlot = 0
    this.disable = false
  }

  decode () {
    this.botSlot = this.readInt()
    this.disable = this.readBoolean()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamBotSlotDisableMessage
