const GameMessage = require('../../../Logic/Message/GameMessage')

class LeaveAllianceMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14308
    this.version = 0
  }

  getServiceNodeType () {
    return 11
  }
}

module.exports = LeaveAllianceMessage
