const GameMessage = require('../../../Logic/Message/GameMessage')

class ChronosEventSeenMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14166
    this.version = 0
    this.unknown = 0
  }

  decode () {
    this.unknown = this.readVInt()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = ChronosEventSeenMessage
