const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamClearInviteMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14367
    this.version = 0
    this.slot = 0
  }

  decode () {
    this.slot = this.readVInt()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamClearInviteMessage
