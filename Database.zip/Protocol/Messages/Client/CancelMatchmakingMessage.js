const GameMessage = require('../../../Logic/Message/GameMessage')

class CancelMatchmakingMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14106
    this.version = 0
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = CancelMatchmakingMessage
