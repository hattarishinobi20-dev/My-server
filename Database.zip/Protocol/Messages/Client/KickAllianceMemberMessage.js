const GameMessage = require('../../../Logic/Message/GameMessage')

class KickAllianceMemberMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14307
    this.version = 0
    this.accountId = 0
  }

  decode () {
    this.accountId = this.readLong().toNumber()
  }

  getServiceNodeType () {
    return 11
  }
}

module.exports = KickAllianceMemberMessage
