const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamSetEventMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14362
    this.version = 0
    this.eventSlot = 0
  }

  decode () {
    this.readVInt()
    this.eventSlot = this.readVInt()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamSetEventMessage
