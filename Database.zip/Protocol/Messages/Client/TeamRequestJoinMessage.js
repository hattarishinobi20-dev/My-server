const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamRequestJoinMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14881
    this.version = 0
    this.unk = 0
    this.teamId = 0
  }

  decode () {
    this.unk = this.readLong().toNumber()
    this.teamId = this.readLong().toNumber()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamRequestJoinMessage
