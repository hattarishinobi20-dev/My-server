const GameMessage = require('../../../Logic/Message/GameMessage')

class RequestServerStatus extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 19999
    this.version = 0
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = RequestServerStatus
