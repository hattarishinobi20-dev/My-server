const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')

class DeletePlayerMapMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 12101
    this.version = 0
    this.mapId = 0
  }

  decode () {
    this.mapId = ByteStreamHelper.decodeLogicLong(this).getLowerInt()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = DeletePlayerMapMessage
