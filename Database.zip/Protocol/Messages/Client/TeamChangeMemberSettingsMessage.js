const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')

class TeamChangeMemberSettingsMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14354
    this.version = 0
    this.characterId = 0
    this.skinId = 0
  }

  decode () {
    this.characterId = ByteStreamHelper.readDataReference(this)
    this.skinId = ByteStreamHelper.readDataReference(this)
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamChangeMemberSettingsMessage
