const GameMessage = require('../../../Logic/Message/GameMessage')

class KeepAliveMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 10108
    this.version = 0
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = KeepAliveMessage
