const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamChatMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14359
    this.version = 0
    this.message = null
  }

  decode () {
    this.message = this.readString()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamChatMessage
