const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamToggleMemberSideMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14357
    this.version = 0
    this.longs = []
    this.unk1 = 0
  }

  decode () {
    for (let i = this.readVInt(); i > 0; i--) {
      this.longs.push(this.readLong().toNumber())
    }
    this.unk1 = this.readVInt()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamToggleMemberSideMessage
