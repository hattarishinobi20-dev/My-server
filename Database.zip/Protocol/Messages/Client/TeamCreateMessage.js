const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamCreateMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14350
    this.version = 0
    this.eventSlot = 0
    this.teamType = 0
  }

  decode () {
    this.readVInt()
    this.eventSlot = this.readVInt()
    this.teamType = this.readVInt()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamCreateMessage
