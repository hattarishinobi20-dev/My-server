const GameMessage = require('../../../Logic/Message/GameMessage')
const CommandManager = require('../../../Logic/Command/CommandManager')

class EndClientTurnMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14102
    this.version = 0
    this.tick = 0
    this.checksum = 0
    this.commands = []
  }

  decode () {
    this.readBoolean()
    this.tick = this.readVInt()
    this.checksum = this.readVInt()
    const count = this.readVInt()
    for (let i = 0; i < count; i++) {
      const command = CommandManager.decodeCommand(this)
      if (command == null) return
      this.commands.push(command)
    }
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = EndClientTurnMessage
