const GameMessage = require('../../../Logic/Message/GameMessage')

class GoHomeFromMapEditorMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 12108
    this.version = 0
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = GoHomeFromMapEditorMessage
