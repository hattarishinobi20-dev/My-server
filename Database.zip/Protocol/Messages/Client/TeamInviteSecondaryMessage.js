const TeamInviteMessage = require('./TeamInviteMessage')

class TeamInviteSecondaryMessage extends TeamInviteMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14370
  }
}

module.exports = TeamInviteSecondaryMessage
