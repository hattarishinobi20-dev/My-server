const GameMessage = require('../../../Logic/Message/GameMessage')

class AddFriendMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 10502
    this.version = 0
    this.avatarId = 0
    this.reason = 0
    this.reasonDetails = 0
  }

  decode () {
    this.avatarId = this.readLong().toNumber()
    this.reason = this.readInt()
    this.reasonDetails = this.readInt()
  }

  getServiceNodeType () {
    return 3
  }
}

module.exports = AddFriendMessage
