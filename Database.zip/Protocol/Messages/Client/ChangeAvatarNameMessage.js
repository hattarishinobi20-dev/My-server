const GameMessage = require('../../../Logic/Message/GameMessage')

class ChangeAvatarNameMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 10212
    this.version = 0
    this.name = null
  }

  decode () {
    this.name = this.readString()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = ChangeAvatarNameMessage
