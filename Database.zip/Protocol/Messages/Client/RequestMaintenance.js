const GameMessage = require('../../../Logic/Message/GameMessage')

class RequestMaintenance extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 19996
    this.version = 0
    this.authPass = null
  }

  decode () {
    this.authPass = this.readString()
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = RequestMaintenance
