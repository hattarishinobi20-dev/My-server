const GameMessage = require('../../../Logic/Message/GameMessage')

class RemoveFriendMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 10506
    this.version = 0
    this.avatarId = 0
  }

  decode () {
    this.avatarId = this.readLong().toNumber()
  }

  getServiceNodeType () {
    return 3
  }
}

module.exports = RemoveFriendMessage
