const GameMessage = require('../../../Logic/Message/GameMessage')

class ReportAllianceStreamMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 10119
    this.version = 0
    this.messageIndex = 0
  }

  decode () {
    this.messageIndex = this.readLong().toNumber()
  }

  getServiceNodeType () {
    return 11
  }
}

module.exports = ReportAllianceStreamMessage
