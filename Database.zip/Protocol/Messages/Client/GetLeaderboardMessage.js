const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')

class GetLeaderboardMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14403
    this.version = 0
    this.isRegional = false
    this.leaderboardType = 0
    this.charachterId = 0
  }

  decode () {
    this.isRegional = this.readBoolean()
    this.leaderboardType = this.readVInt()
    this.charachterId = ByteStreamHelper.readDataReference(this)
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = GetLeaderboardMessage
