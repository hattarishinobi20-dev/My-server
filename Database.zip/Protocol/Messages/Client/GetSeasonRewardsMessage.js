const GameMessage = require('../../../Logic/Message/GameMessage')

class GetSeasonRewardsMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14277
    this.version = 0
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = GetSeasonRewardsMessage
