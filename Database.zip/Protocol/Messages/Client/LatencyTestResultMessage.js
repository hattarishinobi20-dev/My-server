const GameMessage = require('../../../Logic/Message/GameMessage')

class LatencyTestResultMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 19001
    this.version = 0
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = LatencyTestResultMessage
