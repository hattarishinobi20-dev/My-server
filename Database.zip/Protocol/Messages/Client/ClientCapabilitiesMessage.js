const GameMessage = require('../../../Logic/Message/GameMessage')

class ClientCapabilitiesMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 10107
    this.version = 0
    this.ping = 0
  }

  encode () {
    this.writeVInt(this.ping)
  }

  decode () {
    this.ping = this.readVInt()
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = ClientCapabilitiesMessage
