const GameMessage = require('../../../Logic/Message/GameMessage')

class AuthenticationMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 10101
    this.version = 0
    this.accountId = 0
    this.passToken = null
    this.deviceId = null
    this.device = null
    this.isAndroid = false
    this.rndKey = 0
    this.major = 0
    this.minor = 0
    this.build = 0
  }

  decode () {
    this.accountId = this.readLong().toNumber()
    this.passToken = this.readString()
    this.major = this.readInt()
    this.minor = this.readInt()
    this.build = this.readInt()
    this.readString()
    this.deviceId = this.readString()
    this.readVInt()
    this.readVInt()
    this.readString()
    this.readString()
    this.isAndroid = this.readBoolean()
    this.readString()
    this.readString()
    this.readBoolean()
    this.readString()
    this.rndKey = this.readInt()
    console.log('[LoginMessage::deocde] AccountID: ' + this.accountId + ' PassToken: ' + this.passToken)
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = AuthenticationMessage
