const { LogicJSONNode, LogicJSONNodeType } = require('./LogicJSONNode')

class LogicJSONBoolean extends LogicJSONNode {
  constructor (value) {
    super()
    this.value = value
  }

  isTrue () {
    return this.value
  }

  getJSONNodeType () {
    return LogicJSONNodeType.BOOLEAN
  }

  writeToString (builder) {
    builder.push(this.value ? 'true' : 'false')
  }
}

module.exports = LogicJSONBoolean
