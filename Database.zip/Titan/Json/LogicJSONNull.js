const { LogicJSONNode, LogicJSONNodeType } = require('./LogicJSONNode')

class LogicJSONNull extends LogicJSONNode {
  getJSONNodeType () {
    return LogicJSONNodeType.NULL
  }

  writeToString (builder) {
    builder.push('null')
  }
}

module.exports = LogicJSONNull
