class LogicRandom {
  constructor (seed = 0) {
    this.seed = seed | 0
  }

  getIteratedRandomSeed () {
    return this.seed
  }

  setIteratedRandomSeed (value) {
    this.seed = value | 0
  }

  rand (max) {
    if (max > 0) {
      this.seed = this.iterateRandomSeed()
      let tmpVal = this.seed

      if (tmpVal < 0) {
        tmpVal = -tmpVal
      }

      return tmpVal % max
    }

    return 0
  }

  iterateRandomSeed () {
    let seed = this.seed

    if (seed === 0) {
      seed = -1
    }

    const tmp = seed ^ (seed << 13) ^ ((seed ^ (seed << 13)) >> 17)
    const tmp2 = tmp ^ (tmp << 5)

    return tmp2 | 0
  }

  decode (stream) {
    this.seed = stream.readVInt()
  }

  encode (stream) {
    stream.writeVInt(this.seed)
  }
}

module.exports = LogicRandom
