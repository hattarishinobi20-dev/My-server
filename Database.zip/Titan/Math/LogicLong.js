class LogicLong {
  constructor (highInteger = 0, lowInteger = 0) {
    this.high = highInteger | 0
    this.low = lowInteger | 0
  }

  static toLong (highValue, lowValue) {
    return (BigInt(highValue | 0) << 32n) | BigInt(lowValue >>> 0)
  }

  static from (value) {
    if (value instanceof LogicLong) return value
    if (Array.isArray(value)) return new LogicLong(value[0], value[1])
    if (value == null) return new LogicLong(0, 0)

    const long = BigInt.asIntN(64, BigInt(value))
    return new LogicLong(Number(BigInt.asIntN(32, long >> 32n)), Number(BigInt.asIntN(32, long)))
  }

  static equals (a1, a2) {
    if (a1 == null || a2 == null) {
      return a1 == null && a2 == null
    }

    return a1.high === a2.high && a1.low === a2.low
  }

  clone () {
    return new LogicLong(this.high, this.low)
  }

  isZero () {
    return this.high === 0 && this.low === 0
  }

  getHigherInt () {
    return this.high
  }

  getLowerInt () {
    return this.low
  }

  decode (stream) {
    this.high = stream.readInt()
    this.low = stream.readInt()
  }

  encode (stream) {
    stream.writeInt(this.high)
    stream.writeInt(this.low)
  }

  hashCode () {
    return (this.low + Math.imul(31, this.high)) | 0
  }

  equals (obj) {
    if (obj != null && obj instanceof LogicLong) {
      return obj.high === this.high && obj.low === this.low
    }

    return false
  }

  toBigInt () {
    return LogicLong.toLong(this.high, this.low)
  }

  toNumber () {
    return Number(this.toBigInt())
  }

  toArray () {
    return [this.high, this.low]
  }

  toString () {
    return `LogicLong(${this.high}-${this.low})`
  }

  toJSON () {
    return [this.high, this.low]
  }
}

module.exports = LogicLong
