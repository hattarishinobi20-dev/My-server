const LogicMath = require('./LogicMath')

class LogicVector2 {
  constructor (x = 0, y = 0) {
    this.x = x | 0
    this.y = y | 0
  }

  static squaredDistance (x, y) {
    let distance = 0x7FFFFFFF

    if (((x + 46340) >>> 0) <= 92680) {
      if (((y + 46340) >>> 0) <= 92680) {
        const distanceX = x * x
        const distanceY = y * y

        if (distanceY < (distanceX ^ 0x7FFFFFFF)) {
          distance = distanceX + distanceY
        }
      }
    }

    return distance
  }

  destruct () {
    this.x = 0
    this.y = 0
  }

  add (vector2) {
    this.x = (this.x + vector2.x) | 0
    this.y = (this.y + vector2.y) | 0
  }

  clone () {
    return new LogicVector2(this.x, this.y)
  }

  dot (vector2) {
    return (Math.imul(this.x, vector2.x) + Math.imul(this.y, vector2.y)) | 0
  }

  getAngle () {
    return LogicMath.getAngle(this.x, this.y)
  }

  getAngleBetween (x, y) {
    return LogicMath.getAngleBetween(LogicMath.getAngle(this.x, this.y), LogicMath.getAngle(x, y))
  }

  getDistance (vector2) {
    return LogicMath.sqrt(LogicVector2.squaredDistance(this.x - vector2.x, this.y - vector2.y))
  }

  getDistanceSquared (vector2) {
    return LogicVector2.squaredDistance(this.x - vector2.x, this.y - vector2.y)
  }

  getDistanceSquaredTo (x, y) {
    return LogicVector2.squaredDistance(x - this.x, y - this.y)
  }

  getLength () {
    return LogicMath.sqrt(LogicVector2.squaredDistance(this.x, this.y))
  }

  getLengthSquared () {
    return LogicVector2.squaredDistance(this.x, this.y)
  }

  isEqual (vector2) {
    return this.x === vector2.x && this.y === vector2.y
  }

  isInArea (minX, minY, maxX, maxY) {
    if (this.x >= minX && this.y >= minY) {
      return this.x < minX + maxX && this.y < maxY + minY
    }

    return false
  }

  multiply (vector2) {
    this.x = Math.imul(this.x, vector2.x)
    this.y = Math.imul(this.y, vector2.y)
  }

  normalize (value) {
    const length = this.getLength()

    if (length !== 0) {
      this.x = Math.trunc(this.x * value / length) | 0
      this.y = Math.trunc(this.y * value / length) | 0
    }

    return length
  }

  rotate (degrees) {
    const newX = LogicMath.getRotatedX(this.x, this.y, degrees)
    const newY = LogicMath.getRotatedY(this.x, this.y, degrees)

    this.x = newX | 0
    this.y = newY | 0
  }

  set (x, y) {
    this.x = x | 0
    this.y = y | 0
  }

  substract (vector2) {
    this.x = (this.x - vector2.x) | 0
    this.y = (this.y - vector2.y) | 0
  }

  decode (stream) {
    this.x = stream.readVInt()
    this.y = stream.readVInt()
  }

  encode (stream) {
    stream.writeVInt(this.x)
    stream.writeVInt(this.y)
  }

  toString () {
    return `LogicVector2(${this.x},${this.y})`
  }
}

module.exports = LogicVector2
