class StringUtil {
  static hexToBytes (hex) {
    hex = hex.replace(/ /g, '').replace(/-/g, '')

    if (hex.length % 2 !== 0 || /[^0-9a-fA-F]/.test(hex)) {
      throw new Error('Invalid hex string')
    }

    return Buffer.from(hex, 'hex')
  }
}

module.exports = StringUtil
