const AllianceStreamEntry = require('./Entry/AllianceStreamEntry')

class AllianceStream {
  static MAX_STREAM_ENTRY_COUNT = 200

  constructor () {
    this.entryIdCounter = 0
    this.streamEntryList = []
  }

  sendChatMessage (author, content) {
    const entry = new AllianceStreamEntry()
    entry.authorId = author.accountId
    entry.authorName = author.displayData != null ? author.displayData.name : null
    entry.authorRole = author.role
    entry.id = ++this.entryIdCounter
    entry.type = 2
    entry.message = content

    this.addEntry(entry)
    return entry
  }

  addEntry (entry) {
    while (this.streamEntryList.length >= AllianceStream.MAX_STREAM_ENTRY_COUNT) {
      this.streamEntryList.shift()
    }
    this.streamEntryList.push(entry)
  }

  getEntries () {
    return this.streamEntryList.slice()
  }

  toJSON () {
    return {
      entry_id_counter: this.entryIdCounter,
      entries: this.streamEntryList
    }
  }

  static fromJSON (data) {
    const stream = new AllianceStream()
    if (data == null) return stream
    if (data.entry_id_counter != null) stream.entryIdCounter = data.entry_id_counter
    if (Array.isArray(data.entries)) stream.streamEntryList = data.entries.map(entry => AllianceStreamEntry.fromJSON(entry))
    return stream
  }
}

module.exports = AllianceStream
