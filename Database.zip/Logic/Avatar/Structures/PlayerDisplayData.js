class PlayerDisplayData {
  constructor (hasPremiumPass, thumbnail, namecolor, name) {
    this.thumbnailId = 0
    this.nameColorId = 0
    this.highNameColorId = 0
    this.name = null

    if (arguments.length > 0) {
      this.thumbnailId = thumbnail
      this.nameColorId = namecolor
      this.highNameColorId = hasPremiumPass ? namecolor : 0
      this.name = name
    }
  }

  encode (stream) {
    stream.writeString(this.name)
    stream.writeVInt(100)
    stream.writeVInt(this.thumbnailId)
    stream.writeVInt(this.nameColorId)
    stream.writeVInt(this.highNameColorId)
  }

  static fromJSON (data) {
    const displayData = new PlayerDisplayData()
    if (data == null) return displayData

    if (data.thumbnailId != null) displayData.thumbnailId = data.thumbnailId
    if (data.nameColorId != null) displayData.nameColorId = data.nameColorId
    if (data.highNameColorId != null) displayData.highNameColorId = data.highNameColorId
    if (data.name !== undefined) displayData.name = data.name

    return displayData
  }
}

module.exports = PlayerDisplayData
