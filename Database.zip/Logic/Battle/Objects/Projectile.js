const GameObject = require('./GameObject')
const GameObjectFactory = require('./GameObjectFactory')
const DataTables = require('../../Data/DataTables')
const DataType = require('../../Data/DataType')
const GamePlayUtil = require('../../Util/GamePlayUtil')
const LogicMath = require('../../../Titan/Math/LogicMath')
const LogicVector2 = require('../../../Titan/Math/LogicVector2')

function teamOf (index) {
  return Math.trunc(index / 16)
}

function mulShift32 (a, b) {
  return Number((BigInt(Math.trunc(a)) * BigInt(Math.trunc(b))) >> 32n)
}

function scaleDamage (started, ended, damage, delta) {
  const v16 = Math.trunc(ended * damage * delta)
  const v17 = (351843721n * BigInt(Math.trunc(started * damage * (1000 - delta)))) >> 32n
  return Number(v17 >> 13n) + Number(v17 >> 31n) + Math.trunc(v16 / 100000)
}

function roundHalfEven (value) {
  const floor = Math.floor(value)
  const diff = value - floor
  if (diff > 0.5) return floor + 1
  if (diff < 0.5) return floor
  return floor % 2 === 0 ? floor : floor + 1
}

function getCharacterClass () {
  return require('./Character')
}

function getItemClass () {
  return require('./Item')
}

function getAreaEffectClass () {
  return require('./AreaEffect')
}

class Ignoring {
  constructor (gid, ticks) {
    this.gid = gid
    this.ticks = ticks
  }
}

class Projectile extends GameObject {
  static spawnTicks = 0

  constructor (data) {
    super(data)

    this.projectileData = data
    this.skinProjectileData = data

    if (this.projectileData.parentProjectileForSkin) {
      const parent = DataTables.get(DataType.Projectile).getData(this.projectileData.parentProjectileForSkin)
      if (parent != null) this.projectileData = parent
    }

    this.isCamera = false
    this.normalDMG = 0
    this.deployedTick = 0
    this.endingTick = 0
    this.nowX = 0
    this.nowY = 0
    this.prevX = 0
    this.prevY = 0
    this.healing = 0
    this.skillType = 0
    this.defaultZ = 0
    this.lengthDelta = 0
    this.curving = 0
    this.owner = null
    this.angle = 0
    this.damage = 0
    this.percentDamage = 0
    this.speedModifier = 0
    this.state = 0
    this.orginalEndX = 0
    this.orginalEndY = 0
    this.shouldDestructImmediately = false
    this.triggerDelay = 0
    this.dword148 = 0
    this.dword14C = 0
    this.indexForTP3 = 0
    this.rotatedForTP6 = false
    this.homingTarget = null
    this.specialEffect = false
    this.bounceTimes = 0
    this.bounceDirection = 0
    this.damageAddFromBounce = 0
    this.cripplePercent = 0
    this.chained = false
    this.canPierceCharacter = false
    this.areaEffectCantPushback = false
    this.attackSpecialParamsAreaEffectData = null
    this.attackSpecialParamsStun = 0
    this.attackSpecialParamsWeaklyStun = 0
    this.attackSpecialParamsBounceHeal = 0
    this.attackSpecialParamsStealBulletPercent = 0
    this.attackSpecialParamsStealBulletPercentSelf = 0
    this.attackSpecialParamsDamageDebuff = 0
    this.attackSpecialParamsDamageBuff = 0
    this.attackSpecialParamsStaticPercentDamage = 0
    this.attackSpecialParamsMinPercentDamage = 0
    this.attackSpecialParamsTrailArea = null
    this.attackSpecialParamsTrailAreaInterval = 0
    this.attackSpecialParamsPushback = 0
    this.healOthersAreaEffect = 0
    this.aoeDot = 0
    this.trailX = 0
    this.trailY = 0
    this.stealSouls2Buff = 0
    this.stealSouls2BuffTicks = 0
    this.displayScale = 0
    this.chargedShotHit = false
    this.belleWeaponBounces = 0
    this.spawnedItem = null
    this.speedBuffModifier = 0
    this.speedBuffLength = 0
    this.preyOnTheWeakDamage = 0
    this.preyOnTheWeakPercent = 0
    this.summonedCharacter = null
    this.numSpawns = 0
    this.numSpawnsItem = 0
    this.maxSpawns = 0
    this.maxSpawnsItem = 0
    this.spawnDamage = 0
    this.spawnedItemDamage = 0
    this.spawnHealth = 0
    this.spawnStarPowerIC = false
    this.freezeStrength = 0
    this.freezeDuration = 0
    this.maxRange = 0
    this.totalDelta = 0

    this.fullTravelTicks = -1
    this.z = 500
    this.scale = this.projectileData.scale

    if (this.projectileData.scaleStart !== 0 && this.projectileData.scaleStart != null) {
      this.scale = this.projectileData.scaleStart
    }

    this.linkedProjectileGIDs = []
    this.targetPosition = new LogicVector2()
    this.ignoredTargets = []
    this.targetHitCounts = []
    this.passedEnrager = []
    this.rewardedEnrager = []
    this.mineAnimations = []
    this.startX = 0
    this.startY = 0
    this.targetX = 0
    this.targetY = 0
    this.earlyTicks = 0
    this.pos = new LogicVector2()
    this.destroyedTicks = 0
    this.onDeploy = true
    this.steerAngle = -1
    this.bounceTileIndex = -1
  }

  get mapHeight () {
    return this.gameObjectManager.getBattle().getTileMap().logicHeight
  }

  get mapWidth () {
    return this.gameObjectManager.getBattle().getTileMap().logicWidth
  }

  get speed () {
    return this.projectileData.speed + this.speedModifier
  }

  getOwner () {
    return this.owner
  }

  setStealSouls2BuffingData (buff, ticks) {
    this.stealSouls2Buff = buff
    this.stealSouls2BuffTicks = ticks
  }

  setPreyOnTheWeak (percent, damage) {
    this.preyOnTheWeakPercent = percent
    this.preyOnTheWeakDamage = damage
  }

  setCharacterSummonProjectileData (a2, a3, a4, a5, a6, starPowerIC) {
    this.summonedCharacter = a2
    this.numSpawns = a3
    this.maxSpawns = a4
    this.spawnDamage = a5
    this.spawnHealth = a6
    this.spawnStarPowerIC = starPowerIC
  }

  setItemSummonProjectileData (a2, numSpawns, maxSpawns, damage, normalDMG, owner) {
    this.spawnedItem = a2
    this.numSpawnsItem = numSpawns
    this.maxSpawnsItem = maxSpawns
    this.spawnedItemDamage = damage
    this.normalDMG = normalDMG
    this.owner = owner
  }

  addIgnoredTarget (a2, a3) {
    for (const id of this.linkedProjectileGIDs) {
      const result = this.gameObjectManager.getGameObjectByID(id)
      if (result != null && result.ignoredTargets != null) {
        result.ignoredTargets.push(new Ignoring(a2, a3))
      }
    }
  }

  setFreeze (a2, a3) {
    this.freezeDuration = a2
    this.freezeStrength = a3
  }

  getModifiedDamage (a2, a3, a4) {
    const started = this.projectileData.getDamagePercentStart()
    const ended = this.projectileData.getDamagePercentEnd()

    if (!(started === 100 && ended === 100)) {
      const v14 = ended > started ? 150 : -150
      const v15 = LogicMath.clamp(this.totalDelta + v14, 0, 1000)
      a2 = scaleDamage(started, ended, a2, v15)
    }

    if (!a3) {
      const v18 = this.getCardValueForPassiveFromPlayer('increase_dmg_consecutive_dot', 1)

      if (v18 >= 0 && a4 >= 0) {
        let v19 = 0

        for (const ignoring of this.targetHitCounts) {
          if (ignoring.gid === a4) {
            v19 = ignoring.ticks - 1
            break
          }
        }

        a2 = Math.trunc(a2 * (100 + v19 * v18) / 100)
      }
    }

    let v28 = this.getCardValueForPassiveFromPlayer('increase_missile_dmg_over_distance', 1)

    if (v28 >= 1 && this.skillType === 2) {
      a2 += Math.trunc(LogicMath.clamp(this.totalDelta, 0, 1000) * v28 / 1000)
    }

    v28 = this.getCardValueForPassiveFromPlayer('grow_damage_shrapnel', 1)

    if (v28 >= 1 && this.skillType === 1 && this.owner != null && this.owner.weaponSkillData != null && this.owner.weaponSkillData.projectile !== this.projectileData.name) {
      const v13 = 100 + v28
      const v14 = this.totalDelta >= 800 ? 0 : -150
      const v15 = LogicMath.clamp(this.totalDelta + v14, 0, 1000)
      a2 = scaleDamage(100, v13, a2, v15)
    }

    return a2
  }

  getNextSteeredPos (a2) {
    const data = this.projectileData
    const v8 = data.steerIgnoreTicks
    let v9 = data.speed
    const v10 = this.earlyTicks + this.ticksGone
    let v22 = this.angle

    if (v10 - this.deployedTick > v8) {
      if (data.travelType === 4) {
        let v15 = null
        let v42 = 300 * data.homeDistance * 300 * data.homeDistance

        for (const v17 of this.gameObjectManager.getGameObjects()) {
          if (v17.getObjectType() !== 0) continue
          if (!v17.isAlive()) continue
          const v18 = teamOf(v17.getIndex())

          if (v18 !== teamOf(this.getIndex()) && (v18 !== -1 || !v17.isObject()) && (!v17.isInvisible || v17.yellowEye)) {
            const v20 = GamePlayUtil.getDistanceSquaredBetween(this.getX(), this.getY(), v17.getX(), v17.getY())

            if (v20 < v42) {
              v15 = v17
              v42 = v20
            }
          }
        }

        if (v15 != null) {
          v22 = LogicMath.getAngle(v15.getX() - this.getX(), v15.getY() - this.getY())
        }
      } else if (data.travelType === 5) {
        if (this.steerAngle > -1) v22 = this.steerAngle
      }
    }

    if (data.travelType === 5) {
      const v28 = data.speed
      v9 = Math.trunc(Math.fround(v28 * 0.4) + v28 * 0.6 * Math.fround(Math.fround(this.totalDelta) * Math.fround(0.001)))
    }

    const v29 = LogicMath.normalizeAngle360(v22 - this.angle) < 180 ? 1 : -1
    const v30 = LogicMath.getAngleBetween(this.angle, v22)
    const v32 = LogicMath.min(v30, data.steerStrength)
    this.angle = LogicMath.normalizeAngle360(this.angle + v32 * v29)

    a2.x = this.getX() + (Math.trunc(LogicMath.cos(this.angle) * v9 / 20) >> 10)
    const v35 = mulShift32(1717986919, LogicMath.sin(this.angle) * v9) | 0
    a2.y = this.getY() + (((v35 >> 3) + (v35 >> 31)) >> 10)

    return this.defaultZ
  }

  getTravelTicks (a2, a3) {
    const v5 = LogicMath.max(1, a3)
    let v6 = 18000
    if (!this.projectileData.constantFlyTime) v6 = 20 * a2
    const v7 = Math.trunc(Math.fround(v6 / v5) + 0.5)
    return LogicMath.max(1, v7)
  }

  static getSpreadMax (projectileData, a2, a3) {
    const v5 = LogicMath.abs(a2)
    if (projectileData.constantFlyTime) return 3 * v5

    if (projectileData.indirect) {
      if (projectileData.minDistanceForSpread > a3) a3 = projectileData.minDistanceForSpread
    }

    return Math.trunc(a3 * v5 / 300)
  }

  static shootProjectile (a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15) {
    if (a5 == null || a4 == null || a13 == null) return null

    let v16 = a7
    const v61 = a13.getTicksGone()
    const v18 = new Projectile(a5)
    v18.setIndex(a4.getIndex())

    const v56 = a4.getX()
    const v19 = a6 - v56
    const v20 = a4.getY()
    const v21 = a7 - v20
    const v22 = LogicMath.sqrt(v19 * v19 + v21 * v21)

    let v23
    let v24
    let v26 = 0

    if (a5.travelType === 6) {
      const v58 = v22
      v23 = a6
      v24 = a7

      if (a14 !== 1) {
        const v27 = LogicMath.cos(Math.trunc(a10 / 2))
        const v28 = LogicMath.getRotatedX(v19, v21, Math.trunc(a10 / 2))
        const v29 = LogicMath.getRotatedY(v19, v21, Math.trunc(a10 / 2))

        if (v27 !== 0 && v58 > 0) {
          const v30 = Math.trunc(2 * ((((v58 + (v58 >> 31)) << 9) & 0xFFFFFC00) >>> 0) / v27)
          v23 = Math.trunc(v30 * v28 / v58) + v56
          v24 = Math.trunc(v30 * v29 / v58) + v20
          v26 = Math.trunc(v30 * a5.speed / v58) - a5.speed
        }
      }
    } else {
      const v34 = Projectile.getSpreadMax(a5, a10, v22)

      if (v34 < 3) {
        v23 = a6
        v24 = a7
      } else {
        let v36
        let v37

        if (a11) {
          v36 = LogicMath.getRotatedX(v19, v21, 90)
          v37 = LogicMath.getRotatedY(v19, v21, 90)
          const v38 = LogicMath.sqrt(v36 * v36 + v37 * v37)

          if (v38 > 0) {
            v36 = Math.trunc(v36 * v34 / v38)
            v37 = Math.trunc(v37 * v34 / v38)
          }

          if (a10 < 0) {
            v36 = -v36
            v37 = -v37
          }
        } else {
          v36 = 2 * a13.getLogicRandom().rand(v34) - (v34 - 1)
          v37 = 2 * a13.getLogicRandom().rand(v34) - (v34 - 1)
        }

        const v43 = v37 + a7
        const v44 = v36 + a6

        if (a5.indirect) {
          v23 = LogicMath.clamp(v44, 1, a13.getTileMap().logicWidth - 2)
          v24 = LogicMath.clamp(v43, 1, a13.getTileMap().logicHeight - 2)
        } else {
          let v48 = v43 - v20
          let v49 = v44 - v56
          const v50 = LogicMath.sqrt(v48 * v48 + v49 * v49)

          if (v50 > 0) {
            v49 = Math.trunc(v49 * v22 / v50)
            v48 = Math.trunc(v48 * v22 / v50)
          }

          v24 = v48 + v20
          v23 = v49 + v56
        }
      }
    }

    a13.getGameObjectManager().addGameObject(v18)
    v18.init(a1, a2, a3, a4, v23, v24, 0, 0, v61, a8, a9, a12 - v26, a15)
    v18.dword148 = a6
    v18.dword14C = v16
    v18.indexForTP3 = a14
    return v18
  }

  static getProjectileSpeed (a1, a2, a3) {
    let v5 = a2.speed

    if (a1 != null) {
      const v6 = a1.getCardValueForPassive('projectile_speed', 1)
      if (v6 > 0) v5 += v6

      const v8 = a1.getCardValueForPassive(a3 ? 'super_range' : 'attack_range', 1)

      if (v8 >= 0 && a1.rapidFireRange - v8 !== 0) {
        return Math.trunc(v5 * a1.rapidFireRange / (a1.rapidFireRange - v8))
      }

      if (a1.attackAcceleratingFactor > 0) return v5 + a1.attackAcceleratingFactor
    }

    return v5
  }

  init (x, y, a4, a5, targettX, targettY, a8, a9, ticksGone, a11, a12, a13, a14) {
    let v19 = a5.getObjectType() === 0 ? 200 : 0
    let v20 = null

    if (a4 === a5 && a4 != null) {
      v20 = a4.characterData
      v19 = 50
    }

    this.skillType = a14

    if (x === -1) {
      let v22 = targettX - a5.getX()
      let v23 = targettY - a5.getY()
      const v24 = LogicMath.sqrt(v22 * v22 + v23 * v23)

      if (v24 > 0) {
        v22 = Math.trunc(v22 * v19 / v24)
        v23 = Math.trunc(v23 * v19 / v24)
      }

      x = a5.getX() + v22
      y = a5.getY() + v23
    }

    let v26 = a5.getZ()
    if (v20 != null) v26 += v20.projectileStartZ
    else v26 += 300

    const v58 = LogicMath.clamp(x, 1, this.mapWidth - 2)
    const v55 = LogicMath.clamp(y, 1, this.mapHeight - 2)

    this.damage = a11
    this.normalDMG = a12
    this.deployedTick = ticksGone

    const v33 = Projectile.getProjectileSpeed(a4, this.projectileData, a14 === 2)
    let v38

    if (this.projectileData.steerLifeTime < 1) {
      const v42 = LogicMath.sqrt((targettX - v58) * (targettX - v58) + (targettY - v55) * (targettY - v55))
      v38 = this.getTravelTicks(v42, v33 - a13)
    } else {
      v38 = this.projectileData.steerLifeTime
    }

    let v44 = v38 + ticksGone
    if (this.projectileData.travelType === 11) v44 += this.projectileData.travelTypeVariable

    this.endingTick = v44
    this.lengthDelta = Math.trunc(1000 / LogicMath.max(1, v44 - this.deployedTick))
    this.setIndex(a5.getIndex())
    this.owner = a4
    this.targetX = targettX
    this.targetY = targettY
    this.orginalEndX = targettX
    this.orginalEndY = targettY
    this.setPosition(v58, v55, v26)
    this.defaultZ = v26
    this.nowX = v58
    this.nowY = v55
    this.prevX = this.nowX
    this.prevY = this.nowY
    this.startX = this.getX()
    this.startY = this.getY()
    this.angle = LogicMath.getAngle(this.targetX - this.startX, this.targetY - this.startY)

    const result = this.projectileData.triggerWithDelayMs
    if (result > 0) this.triggerDelay = Math.trunc(result / 50) + ticksGone
  }

  shouldCheckCollision () {
    if (this.projectileData.indirect || this.projectileData.isFriendlyHomingMissile) return false
    return !this.projectileData.isHomingMissile
  }

  executeChainBullet (a2, a3, a4) {
    const v7 = this.projectileData.chainsToEnemies
    let v9 = this.projectileData.chainBullets
    let v11

    if (this.getCardValueForPassiveFromPlayer('attack_chain_count', 1) >= 1) {
      v9 = this.getCardValueForPassiveFromPlayer('attack_chain_count', 1)
    }

    if (this.getCardValueForPassiveFromPlayer('chain_spread', 0) >= 1) {
      v9 = this.getCardValueForPassiveFromPlayer('chain_spread', 0)
    }

    if (!(v9 >= 1)) {
      v11 = true
      if (!(v7 >= 1)) return
    } else {
      v11 = v7 > 0
    }

    const chainData = this.skinProjectileData.chainBullet ? DataTables.getProjectileByName(this.skinProjectileData.chainBullet) : null
    if (chainData == null) return

    if (a4 == null && this.bounceDirection !== 0) {
      let v12 = this.getX()
      let v13 = this.getY()
      const v16 = this.projectileData.travelType === 7 ? 150 : 5

      switch (this.bounceDirection) {
        case 4:
          v13 += v16
          break
        case 2:
          v12 += v16
          break
        case 1:
          v13 -= v16
          break
        default:
          v12 -= v16
          break
      }

      this.setPosition(v12, v13, this.getZ())
    }

    if (v11) {
      let v77 = 999999999
      let c = null

      for (const v32 of this.gameObjectManager.getGameObjects()) {
        if (v32.getObjectType() !== 0) continue
        if (!v32.isAlive()) continue
        if (v32 === a4 || teamOf(v32.getIndex()) === teamOf(this.getIndex())) continue
        if (v32.isImmuneAndBulletsGoThrough(this.isInRealm)) continue
        if (v32.characterData.isTrain()) continue
        if (this.ignoredTargets.some(ignoring => ignoring.gid === v32.getGlobalID())) continue

        const v30 = (v32.getX() - a2) * (v32.getX() - a2) + (v32.getY() - a3) * (v32.getY() - a3)

        if (v30 <= 0x35A4E900 && v30 < v77) {
          v77 = v30
          c = v32
        }
      }

      if (c == null) return

      const v55 = this.projectileData.chainTravelDistance
      let v56 = c.getX() - a2
      let v57 = c.getY() - a3
      const v58 = LogicMath.sqrt(v56 * v56 + v57 * v57)

      if (v58 > 0) {
        const v60 = 100 * v55
        v56 = Math.trunc(v56 * v60 / v58)
        v57 = Math.trunc(v57 * v60 / v58)
      }

      const v62 = this.getModifiedDamage(this.damage, false, -1)
      const v63 = this.getModifiedDamage(this.normalDMG, true, -1)
      const v65 = Projectile.shootProjectile(-1, -1, this.owner, this, chainData, v56 + a2, v57 + a3, v62, v63, 25, false, 0, this.getBattle(), 0, this.skillType)
      if (v65 == null) return

      v65.attackSpecialParamsAreaEffectData = this.attackSpecialParamsAreaEffectData
      v65.chained = true
      v65.ignoredTargets = this.ignoredTargets.slice()
      if (a4 != null) v65.ignoredTargets.push(new Ignoring(a4.getGlobalID(), 999999999))
      return
    }

    const v71 = LogicMath.getAngle(this.targetX - this.startX, this.targetY - this.startY)
    const v35 = this.projectileData.chainTravelDistance
    let v36 = this.projectileData.chainSpread * 5

    if (this.getCardValueForPassiveFromPlayer('chain_spread', 1) >= 1) {
      v36 = this.getCardValueForPassiveFromPlayer('chain_spread', 1) * 5
    }

    let v67

    if (v9 >= 2) {
      v67 = Math.trunc(2 * v36 / (v9 - 1))
    } else {
      v67 = 0
      if (v9 !== 1) return
    }

    const v70 = 100 * v35

    for (let v37 = 0; v37 < v9; v37++) {
      const v38 = a4 != null ? a4.getGlobalID() : -1
      let v39 = this.getModifiedDamage(this.damage, false, v38)
      const v40 = this.getModifiedDamage(this.normalDMG, true, v38)
      let v46
      let v45
      let v74
      let v72
      let v78
      let v76

      if (this.projectileData.executeChainOnNoHit()) {
        v39 = Math.trunc(v39 / v9)
      }

      const v40d = this.projectileData.executeChainOnNoHit() ? Math.trunc(v40 / v9) : v40

      if (this.projectileData.travelType === 7) {
        const v41 = v37 <= 5 ? [90, 270, 60, 120, 240, 300][v37] : 0
        v78 = this.getX()
        v76 = this.getY()
        const v43 = v41 + v71
        v74 = LogicMath.getRotatedX(v70, 0, v43) + this.getX()
        v72 = LogicMath.getRotatedY(v70, 0, v43) + this.getY()
        v45 = 0
        v46 = Math.trunc(v40d / 2)
        v39 = Math.trunc(v39 / 2)
      } else if (!this.projectileData.chainBullets) {
        const turn = [0, 90, 180, 270][v37 % 4]
        v74 = LogicMath.getRotatedX(v70, 0, v71 + turn) + this.getX()
        v72 = LogicMath.getRotatedY(v70, 0, v71 + turn) + this.getY()
        v46 = v40d
        v45 = 0
        v78 = this.getX()
        v76 = this.getY()
      } else {
        v74 = LogicMath.getRotatedX(v70, 0, v71) + this.getX()
        v72 = LogicMath.getRotatedY(v70, 0, v71) + this.getY()
        v46 = v40d
        v45 = v37 * v67 - v36
        v78 = -1
        v76 = -1
      }

      const v52 = Projectile.shootProjectile(v78, v76, this.owner, this, chainData, v74, v72, v39, v46, v45, true, 0, this.getBattle(), 0, this.skillType)
      if (v52 == null) continue

      v52.attackSpecialParamsAreaEffectData = this.attackSpecialParamsAreaEffectData
      v52.ignoredTargets = this.ignoredTargets.slice()
      if (a4 != null) v52.ignoredTargets.push(new Ignoring(a4.getGlobalID(), 999999999))
    }
  }

  tick () {
    if (this.isCamera) return
    this.onDeploy = false

    if (this.state > 0) {
      ++this.destroyedTicks
      this.animateMines()
      this.clampToMap()
      return
    }

    const data = this.projectileData

    this.prevX = this.nowX
    this.prevY = this.nowY
    this.nowX = this.getX()
    this.nowY = this.getY()

    if (this.curving >= 1) {
      const v9 = this.orginalEndY - this.startY
      const v10 = Math.trunc(this.totalDelta * this.curving / 1000)
      const v11 = this.orginalEndX - this.startX
      const v15 = this.startX + LogicMath.getRotatedX(v11, v9, v10)
      const v17 = this.startY + LogicMath.getRotatedY(v11, v9, v10)
      this.targetX = v15
      this.targetY = v17
      this.angle = LogicMath.getAngle(v15 - this.getX(), v17 - this.getY())
    }

    if (data.travelType === 1) {
      const v19 = Math.fround(Math.fround(this.totalDelta * Math.fround(-0.0015)) + 1.5)
      this.targetY = this.orginalEndY + Math.trunc(Math.fround(v19 * (this.orginalEndY - this.startY)))
      this.targetX = this.orginalEndX + Math.trunc(Math.fround(v19 * (this.orginalEndX - this.startX)))
    } else {
      if (data.travelType === 2) {
        const t = Math.fround(this.totalDelta * Math.fround(0.001))
        const v22 = Math.fround(0.5 - Math.fround(Math.fround(t * t) * 0.5))
        this.targetY = this.orginalEndY - Math.trunc(Math.fround(v22 * (this.orginalEndY - this.startY)))
        this.targetX = this.orginalEndX - Math.trunc(Math.fround(v22 * (this.orginalEndX - this.startX)))
      }

      if (data.travelType === 3) {
        this.tickTravelType3()
      } else if (data.travelType === 6 && this.totalDelta >= 500 && !this.rotatedForTP6) {
        const v78 = this.endingTick - this.deployedTick
        this.getPosAtTick(this.deployedTick + Math.trunc(v78 / 2), this.pos)
        const v83 = this.dword148 - this.pos.x
        const v84 = this.dword14C - this.pos.y
        this.startX = this.pos.x
        this.startY = this.pos.y
        this.targetX = this.dword148
        this.targetY = this.dword14C
        const v86 = GamePlayUtil.getDistanceBetween(0, 0, v83, v84)

        if (v86 > 0) {
          this.targetX += Math.trunc(900 * v83 / v86)
          this.targetY += Math.trunc(900 * v84 / v86)
        }

        const v92 = this.earlyTicks + this.ticksGone
        this.deployedTick = v92 - 1
        const v94 = Projectile.getProjectileSpeed(this.owner, data, false)
        const v96 = this.getTravelTicks(900, v94)
        this.rotatedForTP6 = true
        this.endingTick = v92 + Math.trunc(v78 / 2) + v96
      }
    }

    if (data.isFriendlyHomingMissile || data.isHomingMissile || (data.isBoomerang && !data.chainBullet)) {
      if (this.homingTarget != null) {
        this.targetX = this.homingTarget.getX()
        this.targetY = this.homingTarget.getY()
      }
    }

    let v62 = this.tickMovement()
    this.totalDelta = LogicMath.min(1000, this.totalDelta + this.lengthDelta)

    let v64 = 0
    let v65 = 1

    if (this.shouldCheckCollision()) {
      const v66 = this.handleCollisions()
      v64 = v66

      if (v66 !== 0) {
        if (v66 !== 1) {
          v65 = v66 === 2 ? 3 : 1
          v62 = true
        } else {
          v65 = this.bounceTileIndex === -1 ? 2 : 4
          v64 = 1

          if (data.isBouncing) {
            if (this.attackSpecialParamsBounceHeal > 0 && this.owner != null) this.owner.heal(this.getIndex(), this.attackSpecialParamsBounceHeal, true, data)
            const v68 = this.deployedTick
            let v158 = this.targetX - this.startX
            const v161 = this.targetY - this.startY
            const v157 = this.earlyTicks + this.ticksGone
            const v69 = LogicMath.sqrt(v158 * v158 + v161 * v161)
            const v71 = Math.trunc(v69 * (1000 - Math.trunc(1000 * (v157 - v68) / LogicMath.max(1, this.endingTick - v68))) / 1000)
            let v155 = v71

            if (this.bounceTimes <= 6 && data.distanceAddFromBounce >= 1) {
              v155 = data.distanceAddFromBounce + v71
              v62 = false
              this.endingTick = this.getTravelTicks(v155, data.speed) + v157
            }

            let v162 = v161
            if (this.bounceDirection === 4 || this.bounceDirection === 1) v162 = -v161
            else v158 = -v158

            if (v69 !== 0) {
              v158 = Math.trunc(v158 * v155 / v69)
              v162 = Math.trunc(v162 * v155 / v69)
            }

            this.startX = this.getX()
            this.startY = this.getY()

            switch (this.bounceDirection) {
              case 4:
                this.startY += 5
                break
              case 2:
                this.startX += 5
                break
              case 1:
                this.startY -= 5
                break
              default:
                this.startX -= 5
                break
            }

            this.setPosition(this.startX, this.startY, this.getZ())

            if (this.damageAddFromBounce >= 1) {
              this.damage += this.damageAddFromBounce
              this.specialEffect = true
              this.damageAddFromBounce = 0
            }

            this.targetX = this.startX + v158
            this.targetY = this.startY + v162
            this.angle = LogicMath.getAngle(v158, v162)
            this.deployedTick = v157
            this.bounceTimes++

            if (data.canHitAgainAfterBounce) this.ignoredTargets.length = 0
          } else {
            v62 = true
          }
        }
      }
    }

    if (this.triggerDelay !== 0) {
      if (this.earlyTicks + this.ticksGone === this.triggerDelay) this.targetReached(v65)
    } else if (v62) {
      this.targetReached(v65)
      const v129 = this.getCardValueForPassiveFromPlayer('always_bounce_shot', 1)

      if (v64 === 0 && data.chainBullets >= 1) {
        if (data.executeChainOnNoHit() || v129 > -1 || data.executeChainAlways()) {
          this.executeChainBullet(this.getX(), this.getY(), null)
        }
      }
    }

    if (this.ignoredTargets.length >= 1) {
      this.ignoredTargets = this.ignoredTargets.filter(ignoring => {
        if (ignoring.ticks > 1) {
          ignoring.ticks--
          return true
        }
        return false
      })
    }

    this.clampToMap()
  }

  clampToMap () {
    if (this.projectileData.travelType === 8 || this.projectileData.ignoreLevelBoarder) return
    this.position.x = LogicMath.clamp(this.position.x, 1, this.mapWidth - 2)
    this.position.y = LogicMath.clamp(this.position.y, 1, this.mapHeight - 2)
  }

  tickTravelType3 () {
    const idx = this.indexForTP3
    let v35 = idx <= 1
    const v37 = this.orginalEndX - this.startX
    const v38 = Math.trunc(LogicMath.max(0, idx - 1) / 2)
    const v39 = 100 * v38 + 350
    const v41 = this.orginalEndY - this.startY

    if (idx >= 1) v35 = this.totalDelta <= v39

    if (v35) {
      if (this.totalDelta < 100) return
      const v42 = idx === 0 ? true : (v41 | v37) === 0
      if (v42) return

      const v43 = Math.trunc((180 * (idx % 3) + 180) * this.totalDelta / v39)
      const v44 = LogicMath.sin(v43)
      const v45 = (idx & 1) === 0 ? 300 : -300
      const v46 = (v45 * v44) >> 10
      const v47 = LogicMath.getRotatedX(v37, v41, 90)
      const v48 = LogicMath.getRotatedY(v37, v41, 90)
      const v49 = LogicMath.sqrt(v37 * v37 + v41 * v41)
      this.targetX = Math.trunc(v46 * v47 / v49) + this.orginalEndX
      this.targetY = Math.trunc(v46 * v48 / v49) + this.orginalEndY

      if (this.nowX === this.prevX && this.nowY === this.prevY) return
      this.angle = LogicMath.getAngle(this.nowX - this.prevX, this.nowY - this.prevY)
    } else {
      const v98 = this.totalDelta - v39
      const v100 = (idx & 1) === 0 ? -75 + 25 * v38 : -25 * v38 + 75
      const v101 = Math.trunc(v39 * v37 / 1000)
      const v104 = Math.trunc(v98 * v100 / (650 - 100 * v38))
      const v105 = LogicMath.abs(v104)
      const v106 = Math.trunc(v41 * v39 / 1000) + this.startY
      const v107 = v101 + this.startX
      const v108 = LogicMath.getRotatedX(this.orginalEndX - v107, this.orginalEndY - v106, v104)
      const v109 = LogicMath.getRotatedY(this.orginalEndX - v107, this.orginalEndY - v106, v104)
      const v114 = 100 - Math.trunc(50 * v105 / 180)
      this.targetX = Math.trunc(v108 * v114 / 100) + v107
      this.targetY = Math.trunc(v109 * v114 / 100) + v106
      this.angle = LogicMath.getAngle(this.nowX - this.prevX, this.nowY - this.prevY)
    }
  }

  setTargetPosition (x, y) {
    this.targetPosition.set(x, y)
  }

  setSummonedCharacter (data) {
    this.summonedCharacter = data
  }

  getModifiedPushback () {
    if (this.attackSpecialParamsPushback !== 0) return this.attackSpecialParamsPushback
    return this.projectileData.pushbackStrength
  }

  getModifiedScale (a2) {
    const started = this.projectileData.getScaleStart()
    const ended = this.projectileData.getScaleEnd()

    if (started === 100 && ended === 100) return 100
    return Math.trunc(ended * a2 / 1000) + Math.trunc(started * (1000 - a2) / 1000)
  }

  increaseTargetHitCount (gid) {
    for (const ignoring of this.targetHitCounts) {
      if (ignoring.gid === gid) {
        ignoring.ticks++
        return
      }
    }

    this.targetHitCounts.push(new Ignoring(gid, 1))
  }

  handleCollisions () {
    const data = this.projectileData
    const gom = this.gameObjectManager
    const v5 = this.getX()
    const v6 = this.getY()
    const v276 = Math.trunc(this.getModifiedScale(this.totalDelta) * data.radius / 100)
    let v10 = v5 - this.nowX
    let v11 = v6 - this.nowY
    const v296 = Math.trunc((v276 + 150) / 300)
    const v311 = v296 + 1
    const v13 = LogicMath.sqrt(v10 * v10 + v11 * v11)

    if (v13 > 0) {
      v10 = Math.trunc(20 * v10 / v13)
      v11 = Math.trunc(20 * v11 / v13)
    }

    const tileMap = gom.getBattle().getTileMap()
    const v295 = LogicMath.clamp(this.nowX, 1, this.mapWidth - 2)
    const v292 = LogicMath.clamp(this.nowY, 1, this.mapHeight - 2)
    let v282 = v10 + v5
    let v283 = v11 + v6
    this.pos.x = 0
    this.pos.y = 0

    const v21 = Math.trunc(Math.trunc(v295 / 100) / 3)
    const v22 = Math.trunc(Math.trunc(v282 / 100) / 3)
    const v28 = Math.trunc(Math.trunc(v292 / 100) / 3)
    const v29 = Math.trunc(Math.trunc(v283 / 100) / 3)
    const xStart = LogicMath.min(v21, v22) - v311
    const xEnd = LogicMath.max(v21, v22) + v311
    const yStart = LogicMath.min(v28, v29) - v311
    const yEnd = LogicMath.max(v28, v29) + v311

    const v269 = new LogicVector2(-1, -1)
    let v277 = 999999999
    let v271 = -1
    let v268 = -1
    let v267 = false

    const passable = tile => tile != null && !tile.data.blocksProjectiles

    for (let tx = xStart; tx <= xEnd; tx++) {
      for (let ty = yStart; ty <= yEnd; ty++) {
        const tile = tileMap.getTile(tx, ty, true)
        if (tile == null || tile.isDestructed()) continue

        const td = tile.data

        if ((!td.blocksProjectiles || data.passesEnvironment) &&
          (!data.piercesEnvironment || !td.isDestructible) &&
          (!td.isDestructibleNormalWeapon || (!td.blocksProjectiles && !td.blocksMovement))) {
          continue
        }

        const margin = td.collisionMargin
        const left = passable(tileMap.getTile(tx - 1, ty, true)) ? 300 * tx + margin : 300 * tx - 1
        const right = passable(tileMap.getTile(tx + 1, ty, true)) ? 300 * tx + 300 - margin : 300 * tx + 301
        const top = passable(tileMap.getTile(tx, ty - 1, true)) ? 300 * ty + margin : 300 * ty - 1
        const bottom = passable(tileMap.getTile(tx, ty + 1, true)) ? 300 * ty + 300 - margin : 300 * ty + 301

        let v56 = true

        if (!data.piercesEnvironment || (td.blocksMovement && td.blocksProjectiles && !td.isDestructible)) {
          v56 = false
          if (td.isDestructibleNormalWeapon) v56 = td.blocksProjectiles ? true : td.blocksMovement
        }

        const side = GamePlayUtil.lineSegmentIntersectsRectangle(v295, v292, v282, v283, left, top, right, bottom, this.pos)
        if (side <= 0) continue

        let pierced = false

        if (v56) {
          if (!data.piercesEnvironmentLikeButter && td.blocksMovement && td.blocksProjectiles && !tile.isDestructed() && tile.code !== 'B' && tile.code !== 'F') v267 = true
          tile.destruct()
          pierced = data.piercesEnvironmentLikeButter
        }

        if (pierced) continue

        const dist = (this.pos.x - v295) * (this.pos.x - v295) + (this.pos.y - v292) * (this.pos.y - v292)

        if (dist < v277) {
          v268 = tx + tileMap.width * ty
          v271 = side
          v269.x = this.pos.x
          v269.y = this.pos.y
          if (tile.code !== 'B' && tile.code !== 'F') v267 = true
          v277 = dist
        }
      }
    }

    let v286 = false

    if (v267) {
      if (!(v269.x === v295 && v269.y === v292)) {
        v282 = v269.x
        v283 = v269.y
      }
      v286 = true
    }

    const v70 = data.grapplesEnemy && !!data.chainBullet
    const v71 = v70 || data.uniqueProperty === 2 || data.suppressHealing > 0
    const v73 = v71 || this.damage !== 0
    const v298 = data.healOwnPercent
    let v291 = 0
    let v294 = false

    if (this.skillType === 2) {
      const v74 = this.getCardValueForPassiveFromPlayer('super_heals', 1)
      v291 = v74 < 0 ? 0 : v74
    } else {
      v294 = this.getCardValueForPassiveFromPlayer('cure_debuffs', 1) > -1
    }

    let v289 = null

    if (v73) {
      const v262 = v294 || v291 !== 0
      const myTeam = teamOf(this.getIndex())
      const pierces = () => data.piercesCharacters || this.canPierceCharacter

      for (const gameObject of [...gom.getGameObjects()]) {
        if (gameObject.getObjectType() !== 0) continue

        const target = gameObject
        if (target.characterData.isCarryable() || target.characterData.name === 'VolleyBall') continue

        const ally = teamOf(target.getIndex()) === myTeam
        const v82 = v298 > 0
        let v85 = false

        if (ally && (v294 || v291 !== 0 || this.healing > 0 || data.uniqueProperty === 2)) {
          if (target.characterData.isHero()) v85 = this.owner !== target
        }

        const v92 = target.isImmuneAndBulletsGoThrough(this.isInRealm)
        if (!target.isAlive() || !((v82 && ally) || !ally || v85) || !(v82 || !v92)) continue

        const gid = target.getGlobalID()
        if (this.ignoredTargets.some(ignoring => ignoring.gid === gid)) continue

        const v99 = target.characterData.collisionRadius + v276
        const v113 = target.getX() - v282
        if (LogicMath.abs(v113) > v99) continue
        const v118 = target.getY() - v283
        if (!(LogicMath.abs(v118) <= v99 && v113 * v113 + v118 * v118 <= v99 * v99)) continue

        this.pos.x = v282
        this.pos.y = v283

        if (!pierces()) {
          v286 = true

          if (!(v262 && ally)) {
            const dist = (this.pos.x - v295) * (this.pos.x - v295) + (this.pos.y - v292) * (this.pos.y - v292)
            if (dist > v277) continue
            v277 = dist
            v289 = target
            v269.x = this.pos.x
            v269.y = this.pos.y
          }
        }

        if (data.spawnAreaEffectObject) return 2

        if (data.damagesConstantly) {
          const delay = data.damagesConstantlyTickDelay
          this.ignoredTargets.push(new Ignoring(gid, delay))
          this.increaseTargetHitCount(gid)

          for (const id of this.linkedProjectileGIDs) {
            const linked = gom.getGameObjectByID(id)
            if (linked != null && typeof linked.increaseTargetHitCount === 'function') linked.increaseTargetHitCount(gid)
          }

          if (data.damageOnlyWithOneProj) this.addIgnoredTarget(gid, delay)
        } else {
          this.ignoredTargets.push(new Ignoring(gid, 9999999))
          if (data.damageOnlyWithOneProj) this.addIgnoredTarget(gid, 9999999)
        }

        const v122 = this.getModifiedDamage(this.damage, false, gid)
        let v125 = this.getModifiedDamage(this.normalDMG, true, gid)

        if (ally) {
          if (data.uniqueProperty === 2 && this.owner != null) {
            const buff = this.owner.getCardValueForPassive('ulti_damage_buff', 1)
            if (buff >= 0) target.giveDamageBuff(buff, this.owner.getCardValueForPassive('ulti_damage_buff', 0))
          }

          if (target.characterData.isHero() && !v294) {
            if (data.uniqueProperty === 2) {
              target.addExtraHealthRegen(v122, 61, this.getIndex())
            } else {
              if (this.healing <= 0) this.healing = Math.trunc(v122 * v298 / 100)
              if (v291 > 0) this.healing = v291
              target.heal(this.getIndex(), this.healing, true, data)
            }
          }
        } else {
          this.applyEnemyHit(target, v122, v125)
        }

        if (!pierces()) break
      }
    }

    if (!v286) {
      let v166 = 2

      if (v282 >= 2) {
        v166 = 3
        if (v282 < this.mapWidth - 2) {
          v166 = 4
          if (v283 >= 2) {
            v166 = 1
            if (v283 < this.mapHeight - 2) return 0
          }
        }
      }

      this.bounceDirection = v166
      this.setPosition(LogicMath.clamp(v282, 1, this.mapWidth - 2), LogicMath.clamp(v283, 1, this.mapHeight - 2), this.getZ())
      return 1
    }

    this.setPosition(v269.x, v269.y, this.getZ())
    let chained = false

    if (v289 != null) {
      if (data.executeChainOnObjectHit()) {
        this.executeChainBullet(v269.x, v269.y, v289)
        chained = true
      }
    } else {
      this.bounceDirection = v271
      this.bounceTileIndex = v268
    }

    if (!chained && (data.executeChainAlways() || data.executeChainOnAnyHit() || this.getCardValueForPassiveFromPlayer('split_also_wall_hit', 1) > -1)) {
      this.executeChainBullet(v269.x, v269.y, v289)
    }

    if (v289 == null) return 1
    if (data.spawnAreaEffectObject) return 2

    if (this.damage < 1) {
      if (!data.grapplesEnemy || !data.chainBullet) return 2
      return 1
    }

    const countsAsHit = !v289.isObject() || v289.getIndex() !== -16

    if (this.healOthersAreaEffect >= 1 && this.owner != null && countsAsHit) {
      const area = GameObjectFactory.createGameObjectByData(DataTables.getAreaEffectByName('HealWithAutoAttack'))

      if (area != null) {
        area.setPosition(this.owner.getX(), this.owner.getY(), 0)
        area.setIndex(this.owner.getIndex())
        area.setSource(this.owner, this.skillType)
        area.damage = -this.healOthersAreaEffect
        area.normalDMG = 0
        area.canHealOwner = true
        gom.addGameObject(area)
        area.trigger()
      }
    }

    if (this.owner != null && countsAsHit) {
      const reload = this.owner.getCardValueForPassive('reload_on_hit', 1)
      if (reload >= 0 && this.owner.skills.length >= 1) this.owner.skills[0].addCharge(this.owner, reload)
    }

    return 2
  }

  applyEnemyHit (target, v122, v125) {
    const data = this.projectileData
    const owner = this.owner
    const v127 = this.healing

    if (data.grapplesEnemy && target.characterData.isHero()) {
      const pullX = owner != null ? owner.getX() : this.startX
      const pullY = owner != null ? owner.getY() : this.startY
      this.normalDMG = 0
      this.damage = 0

      if (owner != null && this.getCardValueForPassiveFromPlayer('grapple_damage', 1) !== -1) {
        target.causeDamage(owner, owner.getWeaponSkillDamage() - 1, 2000, true, data, true)
      }

      target.interruptAllSkills()
      target.triggerCharge(pullX, pullY, data.speed, 99, 0, 0, false)
    }

    const isIceDude = data.name === 'IceDudeProjectile' || data.parentProjectileForSkin === 'IceDudeProjectile'

    if (isIceDude && !target.isInvincible && !target.characterData.isCarryable()) {
      target.addFrozen(15, owner)
    }

    if (owner != null && owner.isHealer) target.heal(owner.getIndex(), owner.characterData.autoAttackDamage, true, data)

    if ((data.name === 'RopeDudeUltiProjectile' || data.parentProjectileForSkin === 'RopeDudeUltiProjectile') && owner != null) {
      owner.triggerCharge(this.getX(), this.getY(), 3500, 105, 0, 0, false)
    }

    if (v127 <= -1) return

    let v129 = v122
    let v130 = v122

    if (this.percentDamage > 0) {
      v130 = this.attackSpecialParamsStaticPercentDamage + GamePlayUtil.calculatePercentDamage(this.percentDamage, v130, false, this.attackSpecialParamsDamageBuff, this.attackSpecialParamsDamageDebuff, this.attackSpecialParamsMinPercentDamage, target)
      v125 = 1000
    }

    if (this.preyOnTheWeakDamage >= 1 && (!target.isObject() || target.getIndex() !== -16)) {
      if (target.getHitpointPercentage() <= this.preyOnTheWeakPercent) v130 += this.preyOnTheWeakDamage
    }

    if (target.tagged) v130 *= 2

    if (data.name === 'SilencerUltiProjectile') {
      target.setSilence(60)
      this.attachItem('SilencerHugger', target)
    }

    if (data.name === 'AmbusherUltiProjectile' && owner != null) {
      const teleport = DataTables.getAreaEffectByName('ArcadeTeleport')
      owner.triggerBlink(target.getX() + LogicMath.getRotatedX(-300, 0, target.attackAngle), target.getY() + LogicMath.getRotatedY(-300, 0, target.attackAngle), teleport, teleport, 0, 0)
    }

    if (data.name === 'SplitterProjectile') target.setCharacterTagged(0, this.ticksGone, owner)

    if (data.travelType === 10) {
      v130 = Math.trunc(v130 / 2)
      v125 = Math.trunc(v125 / 2)
    }

    if (data.name === 'StickyBombProjectile' || data.name === 'StickyBombUltiProjectile2') {
      this.spawnedItem = null
      this.attachItem(this.skinProjectileData.spawnItem, target)
      v130 = 0
    }

    if (owner != null && owner.getCardValueForPassive('explosion_damage_increase', 1) >= 1 && (data.name === 'SpawnerDudeProjectile' || data.name === 'SpawnerDudeIndirectProjectile')) {
      if (owner.chargeUp >= owner.chargeUpMax) {
        v130 = roundHalfEven(v130 + v130 * 0.4)
        owner.chargeUp = 0
      }
    }

    if (target.causeDamage(owner, v130, v125, this.skillType === 2, data, true, false, this.getX(), this.getY())) {
      if (this.attackSpecialParamsStealBulletPercent > 0) {
        const percent = this.attackSpecialParamsStealBulletPercent

        if (target.skills.length >= 1 && target.skills[0].maxCharge >= 1) {
          const charge = Math.trunc(target.skills[0].maxCharge * percent / 100)
          target.skills[0].addCharge(target, -Math.trunc(charge / 10))
          if (owner != null && owner.skills.length >= 1) owner.skills[0].addCharge(owner, Math.trunc(charge * this.attackSpecialParamsStealBulletPercentSelf / 1000))
        }
      }

      if (data.poisonDamagePercent >= 1) {
        let poison = Math.trunc(v130 * data.poisonDamagePercent / 100)
        if (owner != null && owner.getGearBoost(9) >= 1) poison += Math.trunc(poison * owner.getGearBoost(9) / 100)
        target.applyPoison(this.getIndex() % 16, poison, Math.trunc(v125 * data.poisonDamagePercent / 100), this.skillType === 2, owner, this.skinProjectileData.poisonType)
      }

      if (this.cripplePercent >= 1) target.cripple(this.cripplePercent)

      if (data.lifeStealPercent >= 1 && owner != null && !target.isObject()) {
        const increase = this.getCardValueForPassiveFromPlayer('self_heal_increase', 1)
        if (increase >= 1) v129 += Math.trunc(v129 * increase / 100)
        owner.heal(this.getIndex(), Math.trunc(data.lifeStealPercent * v129 / 100), true, data)
      }

      if (data.freezeStrength >= 1) {
        target.giveSpeedSlowerBuff(-data.freezeStrength, data.getFreezeDuration())
      } else if (this.freezeStrength >= 1) {
        target.giveSpeedSlowerBuff(-this.freezeStrength, this.freezeDuration)
      } else if (owner != null && owner.getGearBoost(20) >= 1) {
        target.giveSpeedSlowerBuff(-Math.trunc(owner.getGearBoost(20) * target.characterData.speed / 100), 20)
      }

      if (this.skillType !== 2 && owner != null && (target.characterData.isHero() || target.characterData.isTrainingDummy())) {
        if (owner.getMaxChargedShots() >= 1 && data.name !== owner.getWeaponSkill().skillData.secondaryProjectile) {
          owner.chargedShotCount = LogicMath.clamp(owner.chargedShotCount + 1, 0, owner.getMaxChargedShots())
          this.chargedShotHit = true
        }
      }

      if (data.uniqueProperty === 3 && this.belleWeaponBounces < 3) {
        target.giveElectrocution(this.damage, this.normalDMG, this.skinProjectileData.appliedEffectVisualType, this.belleWeaponBounces)
      }

      if (data.uniqueProperty === 4) {
        const buff = target.applyBuff(15, 16383, 35, 0)
        if (buff != null) buff.belleWeaponBounces = owner != null ? owner.getCardValueForPassive('ulti_buff_buff', 1) : 0
      }
    }

    const v152 = this.getModifiedPushback()

    if (v152 !== 0) {
      let v153 = v152
      let x = this.startX
      let y = this.startY

      if (data.pushbackType === 1 || this.attackSpecialParamsPushback !== 0) {
        if (v152 > 0) {
          x = this.getX() - this.targetX + this.startX
          y = this.getY() - this.targetY + this.startY
          v153 = Math.trunc(v153 * (1000 - this.totalDelta) / 1000)
        } else {
          x = this.targetX * 2 - this.startX
          y = this.targetY * 2 - this.startY
          v153 = -v153
        }
      }

      if (this.attackSpecialParamsPushback !== 0) target.triggerPushback(x, y, v153, false, 0, false, false, false, false, false, false, false, 0, this.startX, this.startY)
      else target.triggerPushback(x, y, v153, false, 0, false, false, false, false, false, false, false, 0)
    }

    if (!isIceDude) {
      target.triggerStun(data.getStunLengthTicks(), false)

      if (this.attackSpecialParamsWeaklyStun >= 1) {
        target.triggerStun(this.attackSpecialParamsWeaklyStun, false)
        target.isWeaklyStunned = true
      }
    }

  }

  attachItem (name, target) {
    const itemData = name ? DataTables.getItemByName(name) : null
    if (itemData == null) return

    const Item = getItemClass()
    const item = new Item(itemData)
    item.setPosition(this.getX(), this.getY(), 0)
    item.setIndex(this.getIndex())
    item.owner = this.owner
    item.damage = this.damage
    item.attachedCharacter = target
    this.gameObjectManager.addGameObject(item)
  }

  runEarlyTicks () {
    if (this.projectileData.earlyTicks >= 1) {
      for (let i = 0; i < this.projectileData.earlyTicks; i++) {
        this.earlyTicks++
        this.tick()
        this.onDeploy = true
      }
    }
  }

  updateTrailAreaEffect () {
    const data = this.projectileData

    if (data.spawnAreaEffectTrail) {
      const area = GameObjectFactory.createGameObjectByData(DataTables.getAreaEffectByName(data.spawnAreaEffectTrail))

      if (area != null) {
        area.setPosition(this.getX(), this.getY(), 0)
        area.setIndex(this.getIndex())
        area.setSource(this.owner, this.skillType)
        area.damage = this.getModifiedDamage(this.damage, false, -1)
        area.normalDMG = this.normalDMG
        this.gameObjectManager.addGameObject(area)
        area.trigger()
      }
    }

    if (this.attackSpecialParamsTrailArea != null) {
      if (GamePlayUtil.getDistanceBetween(this.trailX, this.trailY, this.getX(), this.getY()) < this.attackSpecialParamsTrailAreaInterval) return

      const area = GameObjectFactory.createGameObjectByData(DataTables.getAreaEffectByName(this.attackSpecialParamsTrailArea))

      if (area != null) {
        area.setPosition(this.getX(), this.getY(), 0)
        area.setIndex(this.getIndex())
        area.setSource(this.owner, 4)
        area.normalDMG = 0
        this.gameObjectManager.addGameObject(area)
        area.trigger()
      }

      this.trailX = this.getX()
      this.trailY = this.getY()
    }
  }

  getCirclingPosAt (a2, a3) {
    const v11 = Math.trunc(this.projectileData.speed * (this.earlyTicks + this.ticksGone - this.deployedTick) / 20)
    this.steerAngle += 15
    a3.x = this.owner.getX() + ((LogicMath.cos(this.steerAngle) * v11) >> 10)
    a3.y = this.owner.getY() + ((LogicMath.sin(this.steerAngle) * v11) >> 10)
    return this.defaultZ
  }

  tickMovement () {
    const data = this.projectileData

    if (data.travelType === 8) {
      if (this.owner == null || !this.owner.isAlive()) return true
    }

    const v6 = this.earlyTicks + this.ticksGone
    const v7 = v6 - this.deployedTick
    const v8 = this.endingTick - this.deployedTick

    if (v7 > v8) return true

    let v11
    if (data.travelType === 8) v11 = this.getCirclingPosAt(0, this.pos)
    else if (data.steerStrength < 1) v11 = this.getPosAtTick(v6, this.pos)
    else v11 = this.getNextSteeredPos(this.pos)

    this.updateTrailAreaEffect()

    if (data.indirect) {
      if (this.pos.x < 2 || this.pos.x >= this.mapWidth - 2 || this.pos.y < 2 || this.pos.y >= this.mapHeight - 2) {
        this.setPosition(LogicMath.clamp(this.pos.x, 1, this.mapWidth - 2), LogicMath.clamp(this.pos.y, 1, this.mapHeight - 2), v11)
        return true
      }
    }

    if (data.travelType !== 1 || (this.orginalEndX - this.startX) * (this.pos.x - this.getX()) + (this.orginalEndY - this.startY) * (this.pos.y - this.getY()) >= 1) {
      this.setPosition(this.pos.x, this.pos.y, v11)
    }

    return v7 === v8
  }

  getPosAtTick (a2, a3) {
    const data = this.projectileData
    let v15 = 0
    const v70 = this.targetX - this.startX
    const v71 = this.targetY - this.startY
    const v73 = LogicMath.max(1, LogicMath.sqrt(v70 * v70 + v71 * v71))
    let v11 = a2 - this.deployedTick
    let v12 = this.endingTick - this.deployedTick
    const v77 = this.targetX

    if (v12 >= v11) {
      const v72 = this.targetY

      if (data.bouncePercent < 1) {
        if (data.travelType === 11) {
          v11 = LogicMath.max(0, v11 - data.travelTypeVariable)
          v12 = LogicMath.max(1, v12 - data.travelTypeVariable)
        }

        if (v12 <= 0) v12 = 1

        const v29 = v12 - v11
        a3.y = Math.trunc(v29 * this.startY / v12) + Math.trunc(v11 * v72 / v12)
        a3.x = Math.trunc(v29 * this.startX / v12) + Math.trunc(v11 * v77 / v12)
        v15 = this.defaultZ
        if (data.gravity > 0) v15 = Math.trunc(v15 * v29 / v12)
      } else {
        if (v12 <= 0) v12 = 1

        const v16 = data.bouncePercent
        const v17 = 5 * v16
        const v18 = 10 * v16
        const v67 = 1000 * v11
        const v21 = 1000 - 2 * v17
        const v22 = Math.trunc(v67 / v12)
        let v23 = 0
        let v24 = 0

        if (v18 * v73 + 1499 >= 0xBB7) {
          const v64 = Math.trunc(v18 * v73 / 1500)
          v24 = Math.trunc(v64 * v70 / v73)
          v23 = Math.trunc(v64 * v71 / v73)
        }

        const v25 = v23 + v72
        const v26 = v24 + v77

        if (v22 <= v21) {
          const v35 = LogicMath.max(1, Math.trunc(v21 * v12 / 1000))
          const v36 = Math.trunc(v67 / v35)
          const v38 = (274877907n * BigInt(1000 - v36) * BigInt(this.defaultZ)) >> 32n
          a3.x = Math.trunc(((1000 - v22) * this.startX + v26 * v22) / 1000)
          a3.y = Math.trunc(((1000 - v22) * this.startY + v25 * v22) / 1000)
          v15 = Number(BigInt.asIntN(32, (v38 >> 6n) + (v38 >> 31n)))
        } else {
          const v68 = Math.trunc((v26 - this.startX) * v21 / 1000) + this.startX + Math.trunc((v26 - this.startX) * v18 / 2000)
          const v27 = v22 - v21
          const v28 = v18 - v27
          const yMid = Math.trunc((v25 - this.startY) * v21 / 1000) + this.startY + Math.trunc((v25 - this.startY) * v18 / 2000)
          a3.y = Math.trunc((Math.trunc((v18 * this.startY + v25 * v21) / 1000) * v28 + yMid * v27) / v18)
          a3.x = Math.trunc((Math.trunc((v18 * this.startX + v26 * v21) / 1000) * v28 + v68 * v27) / v18)
          v15 = 0
        }
      }

      this.targetY = v72
    } else {
      a3.x = this.targetX
      a3.y = this.targetY
      v15 = 0
      if (data.gravity < 1) v15 = this.defaultZ
    }

    if (data.gravity > 0) {
      const v40 = Math.fround(-data.gravity)
      const v41 = data.constantFlyTime
        ? Math.fround(v40 * Math.fround(0.001))
        : Math.fround(v40 / Math.fround(LogicMath.sqrt(v73) * 40))
      const v42 = data.bouncePercent
      const v43 = data.speed
      let v44 = Math.fround(0.1)
      let v45 = Math.fround(0.1)
      const speedTenth = Math.fround(v43 * Math.fround(0.1))
      if (speedTenth > Math.fround(0.1)) v45 = speedTenth

      let v60 = 0

      if (v42 < 1) {
        const v58 = Math.fround(GamePlayUtil.getDistanceBetween(this.startX, this.startY, v77, this.targetY))
        const v59 = Math.fround(GamePlayUtil.getDistanceBetween(this.startX, this.startY, a3.x, a3.y) / v45)
        if (Math.fround(v58 / v45) > 0.1) v44 = Math.fround(v58 / v45)

        if (data.constantFlyTime) {
          const squared = Math.fround(v58 * v58)
          v60 = squared === 0 ? 0 : Math.fround(Math.fround(v59 * Math.fround(Math.fround(v41 * 2000000.0) / squared)) * Math.fround(v59 - v44))
        } else {
          v60 = Math.fround(Math.fround(v59 * v41) * Math.fround(v59 - v44))
        }
      } else {
        const v46 = LogicMath.sqrt(v70 * v70 + v71 * v71)
        const v47 = v46 * v42
        let v49 = 0
        let v51 = 0

        if (v47 + 149 >= 0x12B && v46 > 0) {
          const v52 = Math.trunc(v47 / 150)
          v49 = Math.trunc(v52 * v70 / v46)
          v51 = Math.trunc(v52 * v71 / v46)
        }

        const v80 = new LogicVector2(v77 - v49, this.targetY - v51)
        const v79 = new LogicVector2(v77 - v80.x, this.targetY - v80.y)
        const v78 = new LogicVector2(a3.x - v80.x, a3.y - v80.y)
        let v53
        let v56
        let v57

        if (v79.dot(v78) <= -1) {
          v53 = Math.fround(GamePlayUtil.getDistanceBetween(this.startX, this.startY, v80.x, v80.y))
          v56 = this.startX
          v57 = this.startY
        } else {
          v53 = Math.fround(GamePlayUtil.getDistanceBetween(v80.x, v80.y, v77, this.targetY))
          v56 = v80.x
          v57 = v80.y
        }

        const v62 = Math.fround(GamePlayUtil.getDistanceBetween(v56, v57, a3.x, a3.y) / v45)
        if (Math.fround(v53 / v45) > Math.fround(0.1)) v44 = Math.fround(v53 / v45)
        v60 = Math.fround(Math.fround(v62 * v41) * Math.fround(v62 - v44))
      }

      const lift = Math.fround(v60 * 300)
      if (Number.isFinite(lift)) v15 += Math.trunc(lift)
    }

    return LogicMath.clamp(v15, 0, 3000)
  }

  handleEnragers () {
    for (const gameObject of this.gameObjectManager.getGameObjects()) {
      if (gameObject == null) continue
      if (gameObject.getObjectType() !== 0) continue
      if (!gameObject.isAlive()) continue
      if (this.passedEnrager.includes(gameObject) || this.rewardedEnrager.includes(gameObject)) continue
      if (teamOf(gameObject.getIndex()) === teamOf(this.getIndex())) continue
      if (gameObject.characterData.name !== 'Luchador') continue

      if (this.position.getDistance(gameObject.getPosition()) <= 1000) {
        this.passedEnrager.push(gameObject)
        return
      }
    }

    for (const character of this.passedEnrager) {
      if (character == null) continue
      if (!character.isAlive()) continue

      if (this.position.getDistance(character.getPosition()) >= 1100) {
        this.passedEnrager.splice(this.passedEnrager.indexOf(character), 1)
        this.rewardedEnrager.push(character)
        const enemy = this.gameObjectManager.getBattle().getPlayerWithObject(character.getGlobalID())
        if (enemy != null) enemy.addUltiCharge(1000)
        return
      }
    }
  }

  returnBoomerang () {
    const owner = this.owner
    const startX = owner != null ? owner.getX() : this.startX
    const startY = owner != null ? owner.getY() : this.startY
    const speedBoost = this.state === 4 && owner != null ? Math.trunc(-owner.getGearBoost(17) * this.projectileData.speed / 100) : 0

    const projectile = Projectile.shootProjectile(
      -1,
      -1,
      owner,
      this,
      this.projectileData.chainBullet ? DataTables.getProjectileByName(this.projectileData.chainBullet) : null,
      startX,
      startY,
      this.damage,
      this.normalDMG,
      0,
      false,
      speedBoost,
      this.gameObjectManager.getBattle(),
      0,
      this.skillType
    )

    if (projectile != null) projectile.homingTarget = owner
  }

  targetReached (a2) {
    const data = this.projectileData
    const skin = this.skinProjectileData
    const owner = this.owner
    const gom = this.gameObjectManager

    if (data.name === 'BowDudeSpawnMineProjectile') {
      this.spawnMines(this.getX(), this.getY())
    } else if (data.name.includes('ClusterBombProjectile')) {
      let mineName = 'ClusterMine'
      const projectileName = skin != null && skin.name ? skin.name : ''

      for (let skinIndex = 2; skinIndex <= 5; skinIndex++) {
        if (projectileName.includes('00' + skinIndex)) {
          mineName = 'Tick00' + skinIndex + 'Mine'
          break
        }
      }

      const mineData = DataTables.getItemByName(mineName) || DataTables.getItemByName('ClusterMine')

      if (mineData != null && owner != null) {
        let minesToSpawn = 3

        if (owner.nextAttackModifier === 'ClusterBombDude_ExtraMines') {
          minesToSpawn = 6
          owner.nextAttackModifier = ''
          if (owner.activeNextAttackGadget != null) owner.activeNextAttackGadget.endAccessoryActivation()
        }

        Projectile.summonClusterMines(mineData, this.getX(), this.getY(), this.getZ(), this.targetX, this.targetY, owner, this.damage, minesToSpawn)
      }
    }

    if (this.state !== 0) return

    this.state = a2

    if (a2 !== 5) {
      for (let v6 = 2; v6 > 0; v6--) {
        let v8

        if (v6 === 2) {
          v8 = skin.spawnAreaEffectObject ? DataTables.getAreaEffectByName(skin.spawnAreaEffectObject) : null
          if (this.attackSpecialParamsAreaEffectData != null && v8 != null) v8 = this.attackSpecialParamsAreaEffectData
        } else {
          v8 = skin.spawnAreaEffectObject2 ? DataTables.getAreaEffectByName(skin.spawnAreaEffectObject2) : null
        }

        if (v8 == null) continue

        const AreaEffect = getAreaEffectClass()
        const area = new AreaEffect(v8)
        const x = this.getX()
        const y = this.getY()
        let z = 0

        if (v8.type === 'BulletExplosion') {
          const v13 = v8.bulletExplosionBullet ? DataTables.getProjectileByName(v8.bulletExplosionBullet) : null
          const v14 = v13 == null ? true : !v13.indirect
          if (!v14 || v8.bulletExplosionItem) z = this.getZ()
        }

        if ((v8.name === 'BlackHoleUltiExplosion' || v8.name === 'Tara004UltiExplosion') && owner != null) {
          const player = owner.getPlayer()

          if (player != null) {
            let petName = null
            let healer = false

            if (player.getCardValueForPassive('black_hole_monster', 1) >= 1) {
              petName = 'BlackHolePet'
            } else if (player.getCardValueForPassive('black_hole_healer', 1) >= 1) {
              petName = 'BlackHolePet2'
              healer = true
            }

            const petData = petName != null ? DataTables.getCharacterByName(petName) : null

            if (petData != null) {
              const Character = getCharacterClass()
              const monster = new Character(petData)
              monster.setPosition(x, y, z)
              monster.setIndex(this.getIndex())
              monster.parentGID = owner.getGlobalID()
              if (healer) monster.isHealer = true
              gom.addGameObject(monster)
            }
          }
        }

        area.setPosition(x, y, z)
        area.setIndex(this.getIndex())
        area.setSource(owner, this.skillType)
        area.damage = this.getModifiedDamage(this.damage, false, -1)
        area.normalDMG = this.normalDMG
        if (this.attackSpecialParamsStun >= 1) area.stun = this.attackSpecialParamsStun
        if (this.areaEffectCantPushback) area.cantPushback = true
        if (this.aoeDot !== 0) area.damage = this.aoeDot
        gom.addGameObject(area)
        area.trigger()
      }

      if (owner != null && owner.getGearBoost(21) >= 1 && this.skillType === 2) {
        const visionData = DataTables.getAreaEffectByName('BlackHoleVisionArea')

        if (visionData != null) {
          const AreaEffect = getAreaEffectClass()
          const area = new AreaEffect(visionData)
          area.setPosition(this.getX(), this.getY(), 0)
          area.setIndex(this.getIndex())
          area.setSource(owner, this.skillType)
          area.damage = 0
          area.normalDMG = 0
          gom.addGameObject(area)
          area.trigger()
        }
      }

      if (this.summonedCharacter != null) {
        const Character = getCharacterClass()
        Character.summonMinion(
          this.summonedCharacter,
          this.getX(),
          this.getY(),
          0,
          this.numSpawns,
          this.maxSpawns,
          this.spawnDamage,
          this.spawnHealth,
          gom.getBattle(),
          this.getIndex() % 16,
          teamOf(this.getIndex()),
          owner != null ? owner.getGlobalID() : 0,
          true,
          true,
          0,
          this.spawnStarPowerIC,
          this.aoeDot
        )
      }

      if (this.spawnedItem != null && (this.spawnedItem.name !== 'SoulCollectorSoul' || this.chargedShotHit)) {
        const item = GameObjectFactory.createGameObjectByData(this.spawnedItem)

        if (item != null) {
          item.setPosition(this.getX(), this.getY(), 0)
          item.setIndex(this.getIndex())
          item.owner = owner
          item.damage = this.damage
          gom.addGameObject(item)
        }
      }

      if (owner != null && owner.getMaxChargedShots() >= 1 && this.skillType !== 2) {
        if (owner.characterData.uniqueProperty === 10) {
          if (this.chargedShotHit && this.spawnedItem != null) owner.chargedShotCount = 0
        } else if (!this.chargedShotHit) {
          if (owner.chargedShotMisses < 1 || a2 === 3 || owner.chargedShotMisses >= this.getCardValueForPassiveFromPlayer('instant_charged_shot', 1)) {
            owner.chargedShotCount = LogicMath.clamp(0, 0, owner.getMaxChargedShots())
          } else {
            owner.chargedShotCount = LogicMath.clamp(1, 0, owner.getMaxChargedShots())
          }
        }
      }
    }

    if (data.name === 'StickyBombUltiProjectile2') {
      this.spawnedItem = null
      const itemData = skin.spawnItem ? DataTables.getItemByName(skin.spawnItem) : null

      if (itemData != null) {
        const Item = getItemClass()
        const item = new Item(itemData)
        item.setPosition(this.getX(), this.getY(), 0)
        item.setIndex(this.getIndex())
        item.owner = owner
        item.damage = this.damage
        gom.addGameObject(item)
      }
    }

    if (data.name === 'RopeDudeUltiProjectile' || data.parentProjectileForSkin === 'RopeDudeUltiProjectile') {
      if (owner != null && getClosestTile(this.getX(), this.getY(), this.getBattle().getTileMap()) != null) {
        owner.triggerCharge(this.getX(), this.getY(), 3500, 105, 0, 0, false)
      }
    }

    if (data.isBoomerang) {
      if (data.chainBullet) this.returnBoomerang()
      else if (owner != null && owner.skills.length >= 1) owner.skills[0].addCharge(owner, 100)
    }

    if (data.isFriendlyHomingMissile && this.homingTarget != null) {
      if (this.speedBuffModifier >= 1) {
        this.homingTarget.giveSpeedFasterBuff(this.speedBuffModifier, this.speedBuffLength, true)
      } else if (this.stealSouls2Buff >= 1) {
        this.homingTarget.giveDamageBuff(this.stealSouls2Buff, this.stealSouls2BuffTicks)
      } else {
        this.homingTarget.heal(this.getIndex(), this.damage, true, data)
      }
    }

    if (data.isHomingMissile && this.homingTarget != null) {
      const gid = this.homingTarget.getGlobalID()
      this.homingTarget.causeDamage(owner, this.getModifiedDamage(this.damage, false, gid), this.getModifiedDamage(this.normalDMG, true, gid), this.skillType === 2, data, true)
    }
  }

  spawnMines (centerX, centerY) {
    const owner = this.owner
    if (owner == null) return

    const battle = this.gameObjectManager.getBattle()
    const player = battle.getPlayerWithObject(owner.getGlobalID())
    if (player == null) return

    let mineName = 'Mine'
    const skinData = DataTables.get(DataType.Skin).getDataByGlobalId(player.skinId)
    const skinConfData = skinData != null && skinData.conf ? DataTables.get(DataType.SkinConf).getData(skinData.conf) : null
    if (skinConfData != null && skinConfData.spawnedItem) mineName = skinConfData.spawnedItem

    const mineData = DataTables.getItemByName(mineName) || DataTables.getItemByName('Mine')
    if (mineData == null) return

    const radius = 450
    const startHeight = 100
    const tileMap = battle.getTileMap()
    const offsets = [[0, -radius], [-radius, Math.trunc(radius / 2)], [radius, Math.trunc(radius / 2)]]
    const Item = getItemClass()

    for (const [dx, dy] of offsets) {
      const target = Projectile.validatePosition(centerX + dx, centerY + dy, tileMap)
      const mine = new Item(mineData)
      mine.owner = owner
      mine.setIndex(owner.getIndex())
      mine.setPosition(centerX, centerY, startHeight)
      this.gameObjectManager.addGameObject(mine)

      if (player.boMines.length >= 3) player.boMines.length = 0
      player.boMines.push(mine)

      this.mineAnimations.push({ mine, startX: centerX, startY: centerY, startZ: startHeight, targetX: target.x, targetY: target.y })
    }
  }

  animateMines () {
    if (this.mineAnimations.length < 1) return

    const duration = Projectile.mineAnimationTicks
    const step = LogicMath.min(this.destroyedTicks, duration)
    const tileMap = this.gameObjectManager.getBattle().getTileMap()
    const progress = Math.fround(step / duration)

    for (const animation of this.mineAnimations) {
      if (step >= duration) {
        animation.mine.setPosition(animation.targetX, animation.targetY, 0)
        continue
      }

      const curX = Math.trunc(Math.fround(animation.startX + Math.fround((animation.targetX - animation.startX) * progress)))
      const curY = Math.trunc(Math.fround(animation.startY + Math.fround((animation.targetY - animation.startY) * progress)))
      const curZ = animation.startZ - Math.trunc(Math.fround(Math.fround(animation.startZ * progress) * progress))
      const pos = Projectile.validatePosition(curX, curY, tileMap)
      animation.mine.setPosition(pos.x, pos.y, curZ)
    }

    if (step >= duration) this.mineAnimations.length = 0
  }

  static summonClusterMines (mineData, startX, startY, startZ, targetX, targetY, owner, damage, count = 3) {
    if (mineData == null || owner == null) return

    const battle = owner.getBattle()
    const player = battle.getPlayerWithObject(owner.getGlobalID())
    if (player == null) return

    const tileMap = battle.getTileMap()
    const distanceToTarget = GamePlayUtil.getDistanceBetween(owner.getX(), owner.getY(), targetX, targetY)
    const explosionRadius = distanceToTarget < 1500 ? 300 + Math.trunc(distanceToTarget * 250 / 1500) : 550
    const randomRotation = battle.getRandomInt(0, 360) * Math.PI / 180.0
    const Item = getItemClass()

    for (let mineIndex = 0; mineIndex < count; mineIndex++) {
      const angle = (Math.PI * 2 / count) * mineIndex + randomRotation
      const currentRadius = explosionRadius + battle.getRandomInt(-50, 50)
      let finalX = LogicMath.clamp(targetX + Math.trunc(Math.cos(angle) * currentRadius), 150, tileMap.logicWidth - 151)
      let finalY = LogicMath.clamp(targetY + Math.trunc(Math.sin(angle) * currentRadius), 150, tileMap.logicHeight - 151)

      if (!tileMap.isPassable(0, Math.trunc(finalX / 300), Math.trunc(finalY / 300), 0, 0)) {
        const closestSpot = new LogicVector2(finalX, finalY)
        GamePlayUtil.getClosestPassableSpot(0, finalX, finalY, 6, tileMap, closestSpot, false)
        finalX = closestSpot.x
        finalY = closestSpot.y
      }

      const mine = new Item(mineData)
      mine.setIndex(owner.getIndex())
      mine.owner = owner
      mine.teamId = owner.getTeamIndex()
      mine.damage = damage
      mine.setPosition(startX, startY, startZ)
      mine.pickUpStartX = startX
      mine.pickUpStartY = startY
      mine.pickUpStartZ = startZ
      mine.targetX = finalX
      mine.targetY = finalY
      const flightDuration = 10 + mineIndex * 2
      mine.moveTimer = flightDuration * 50
      mine.moveTimerDefault = flightDuration * 50
      owner.getGameObjectManager().addGameObject(mine)
      if (player.boMines != null) player.boMines.push(mine)
    }
  }

  static validatePosition (x, y, tileMap) {
    const margin = 50
    return {
      x: LogicMath.clamp(x, margin, tileMap.logicWidth - margin),
      y: LogicMath.clamp(y, margin, tileMap.logicHeight - margin)
    }
  }

  launchCirclingProjectile (source, a3, projectileData, character, damage, a6, projectiletype, a8) {
    return null
  }

  onDestruct () {
  }

  isDestroyed () {
    return (this.totalDelta > this.maxRange && !this.projectileData.indirect) || this.shouldDestructImmediately
  }

  shouldDestruct () {
    return this.state !== 0 && this.destroyedTicks > 5
  }

  encode (bitStream, isOwnObject, visionTeam) {
    super.encode(bitStream, isOwnObject, visionTeam)

    const data = this.projectileData

    bitStream.writePositiveIntMax7(this.state)
    bitStream.writeBoolean(data.isBouncing)

    if (this.state === 4 || (data.isBouncing && bitStream.writeBoolean(true))) {
      if (this.getBattle().getTileMap().width < 22) bitStream.writePositiveIntMax1023(this.bounceTileIndex)
      else bitStream.writePositiveIntMax4095(this.bounceTileIndex)
    }

    if (data.triggerWithDelayMs > 0) {
      bitStream.writePositiveVIntMax65535(this.triggerDelay)
    } else if (data.preExplosionTimeMs > 0) {
      bitStream.writePositiveVIntMax65535(this.endingTick)
    }

    if (data.preExplosionTimeMs > 0) {
      bitStream.writePositiveVIntMax65535(this.targetX)
      bitStream.writePositiveVIntMax65535(this.targetY)
    }

    bitStream.writePositiveIntMax1023(this.displayScale !== 0 ? this.displayScale : this.totalDelta)

    if (this.skinProjectileData.rendering !== 'DoNotRotateClip') bitStream.writePositiveIntMax511(this.angle)

    if (bitStream.writeBoolean(this.onDeploy)) {
      if (data.ignoreLevelBoarder) {
        bitStream.writeIntMax65535(this.nowX)
        bitStream.writeIntMax65535(this.nowY)
      } else {
        bitStream.writePositiveVIntMax65535(this.nowX)
        bitStream.writePositiveVIntMax65535(this.nowY)
      }
    }
  }

  getObjectType () {
    return 1
  }
}

Projectile.mineAnimationTicks = 4
Projectile.Ignoring = Ignoring

function getClosestTile (x, y, tileMap) {
  const tileX = Math.trunc(x / 300)
  const tileY = Math.trunc(y / 300)
  let best = null
  let bestDistance = 0

  for (let dx = -1; dx <= 1; dx++) {
    for (let dy = -1; dy <= 1; dy++) {
      const tile = tileMap.getTile(tileX + dx, tileY + dy, true)
      if (tile == null || tile.isDestructed() || tile.data == null || !tile.data.blocksMovement) continue

      const distance = GamePlayUtil.getDistanceSquaredBetween(x, y, (tileX + dx) * 300 + 150, (tileY + dy) * 300 + 150)

      if (best == null || distance < bestDistance) {
        best = tile
        bestDistance = distance
      }
    }
  }

  return best
}

module.exports = Projectile
