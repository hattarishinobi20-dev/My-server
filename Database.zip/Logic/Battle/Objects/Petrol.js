class Petrol {
  static BURN_TICKS = 40
  static BURN_INTERVAL = 10

  constructor (x, y, damage, playerIndex, teamIndex, ignited) {
    this.x = x
    this.y = y
    this.damage = damage
    this.playerIndex = playerIndex
    this.teamIndex = teamIndex
    this.slowing = 0
    this.ignited = ignited !== 0 && ignited !== false && ignited != null
    this.burnTicks = 0
  }

  ignite (gameObjectManager, damage) {
    if (this.ignited) return
    this.ignited = true
    if (damage > 0) this.damage = damage
    this.burnTicks = 0
  }

  tick (gameObjectManager) {
    if (!this.ignited) return false

    this.burnTicks++
    if (this.burnTicks % Petrol.BURN_INTERVAL === 0) {
      let source = null
      const characters = gameObjectManager.getCharacters()
      for (const character of characters) {
        if (character != null && character.getIndex() === this.playerIndex) {
          source = character
          break
        }
      }
      for (const character of characters) {
        if (character == null || !character.isAlive()) continue
        if (Math.trunc(character.getIndex() / 16) === this.teamIndex) continue
        if (Math.trunc(character.getX() / 300) !== this.x || Math.trunc(character.getY() / 300) !== this.y) continue
        character.causeDamage(source, this.damage, this.damage, false, null, true)
      }
    }

    return this.burnTicks >= Petrol.BURN_TICKS
  }
}

module.exports = Petrol
