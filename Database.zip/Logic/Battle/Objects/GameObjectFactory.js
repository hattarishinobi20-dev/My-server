const DataType = require('../../Data/DataType')

class GameObjectFactory {
  static createGameObjectByData (data) {
    if (data == null) return null

    switch (data.getDataType()) {
      case DataType.AreaEffect: {
        const AreaEffect = require('./AreaEffect')
        return new AreaEffect(data)
      }
      case DataType.Item: {
        const Item = require('./Item')
        return new Item(data)
      }
      case DataType.Character: {
        const Character = require('./Character')
        return new Character(data)
      }
      case DataType.Projectile: {
        const Projectile = require('./Projectile')
        return new Projectile(data)
      }
      default:
        return null
    }
  }
}

module.exports = GameObjectFactory
