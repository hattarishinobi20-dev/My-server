const GlobalId = require('../../Data/Helper/GlobalId')
const ByteStreamHelper = require('../../Helper/ByteStreamHelper')
const GameModeUtil = require('../../Util/GameModeUtil')
const LogicMath = require('../../../Titan/Math/LogicMath')

class GameObjectManager {
  constructor (battle) {
    this.battle = battle
    this.gameObjects = []
    this.petrols = []

    this.addObjects = []
    this.removeObjects = []

    this.objectCounter = 0
    this.ended = -1
  }

  getGameObjects () {
    return this.gameObjects.slice()
  }

  getProjectiles () {
    return this.gameObjects.filter(obj => obj != null && obj.getObjectType() === 1)
  }

  getCharacters () {
    const objects = this.gameObjects.filter(obj => obj != null && obj.getObjectType() === 0)
    for (const obj of this.addObjects) {
      if (obj != null && obj.getObjectType() === 0) objects.push(obj)
    }
    return objects
  }

  getItems () {
    const objects = this.gameObjects.filter(obj => obj != null && obj.getObjectType() === 3)
    for (const obj of this.addObjects) {
      if (obj != null && obj.getObjectType() === 3) objects.push(obj)
    }
    return objects
  }

  getAreaEffects () {
    const objects = this.gameObjects.filter(obj => obj != null && obj.getObjectType() === 2)
    for (const obj of this.addObjects) {
      if (obj != null && obj.getObjectType() === 2) objects.push(obj)
    }
    return objects
  }

  getSpecificProjectiles (gameObject) {
    const objects = []

    for (const obj of this.gameObjects) {
      if (obj != null && obj.getObjectType() === 1 && Math.trunc(obj.getIndex() / 16) !== Math.trunc(gameObject.getIndex() / 16) && obj.getPosition().getDistance(gameObject.getPosition()) <= 600) {
        objects.push(obj)
      }
    }
    return objects
  }

  getBattle () {
    return this.battle
  }

  preTick () {
    for (let i = 0; i < this.gameObjects.length; i++) {
      const gameObject = this.gameObjects[i]
      if (gameObject == null) {
        this.gameObjects.splice(i, 1)
        i--
        continue
      }
      if (gameObject.shouldDestruct()) {
        gameObject.onDestruct()
        this.removeGameObject(gameObject)
      } else {
        gameObject.resetEventsOnTick()
      }
    }

    while (this.addObjects.length > 0) {
      const addedObject = this.addObjects.shift()
      if (addedObject != null) this.gameObjects.push(addedObject)
    }

    while (this.removeObjects.length > 0) {
      const removedObject = this.removeObjects.shift()
      if (removedObject == null) continue
      const index = this.gameObjects.indexOf(removedObject)
      if (index !== -1) this.gameObjects.splice(index, 1)
    }
  }

  findObject (name) {
    for (const character of this.getCharacters()) {
      if (character.characterData != null && character.characterData.name === name) return character
    }
    return null
  }

  tick () {
    for (let i = 0; i < this.gameObjects.length; i++) {
      const gameObject = this.gameObjects[i]
      if (gameObject == null) {
        this.gameObjects.splice(i, 1)
        i--
        continue
      }
      gameObject.tick()
    }
  }

  addGameObject (gameObject) {
    if (gameObject != null) {
      const objectCounter = this.objectCounter++
      gameObject.attachGameObjectManager(this, GlobalId.createGlobalId(gameObject.getObjectType(), objectCounter))
      this.addObjects.push(gameObject)
    }
  }

  removeGameObject (gameObject) {
    this.removeObjects.push(gameObject)
  }

  getGameObjectByID (globalId) {
    let gameObject = this.gameObjects.find(obj => obj != null && obj.getGlobalID() === globalId)
    if (gameObject == null) gameObject = this.addObjects.find(obj => obj != null && obj.getGlobalID() === globalId)
    return gameObject || null
  }

  getGameObjectsByID (globalId) {
    const objects = []

    for (const obj of this.gameObjects) {
      if (obj != null && obj.getGlobalID() === globalId) objects.push(obj)
    }
    for (const obj of this.addObjects) {
      if (obj != null && obj.getGlobalID() === globalId) objects.push(obj)
    }

    return objects
  }

  getGameObjectByCloneOfObjectGlobalId (globalId) {
    return this.gameObjects.filter(obj => obj != null && obj.getCloneOfObjectGlobalId() === globalId)
  }

  getVisibleGameObjects (teamIndex, ownObjectGlobalId) {
    const objects = []
    const ownObject = this.getGameObjectByID(ownObjectGlobalId)
    const isInRealm = ownObject != null && ownObject.isInRealm

    for (const obj of this.gameObjects.slice()) {
      if (this.isVisibleToTeam(obj, teamIndex, isInRealm)) objects.push(obj)
    }
    for (const obj of this.addObjects.slice()) {
      if (this.isVisibleToTeam(obj, teamIndex, isInRealm)) objects.push(obj)
    }

    return objects
  }

  isVisibleToTeam (obj, teamIndex, isInRealm) {
    if (obj == null) return false
    try {
      if (obj.isInRealm !== isInRealm) return false
      const type = obj.getObjectType()
      if (type === 1) return true
      if (type === 0 && obj.characterData != null &&
        (obj.characterData.name === 'BasketBall' ||
          obj.characterData.name === 'HoldingBall' ||
          obj.characterData.name === 'CaptureFlag')) return true
      if (this.battle.getGameModeVariation() === 22 && type === 3 &&
        obj.itemData != null && obj.itemData.name === 'BasketBrawlHoop') return true
      return obj.getFadeCounter() > 0 || Math.trunc(obj.getIndex() / 16) === teamIndex
    } catch (e) {
      return false
    }
  }

  encode (bitStream, tileMap, ownObjectId, playerIndex, teamIndex) {
    this.battle.encodingOwnObjectId = ownObjectId
    const visibleGameObjects = this.getVisibleGameObjects(teamIndex, ownObjectId)
    const gameMode = this.battle.getGameModeVariation()
    const battle = this.battle
    const players = battle.getPlayers()

    bitStream.writePositiveIntMax2097151(ownObjectId)

    switch (gameMode) {
      case 0:
        bitStream.writePositiveVIntMax65535(battle.getGemGrabCountdown())
        break
      case 100:
        bitStream.writePositiveIntMax7(0)
        break
      case 17:
        bitStream.writePositiveIntMax7(1)
        bitStream.writePositiveIntMax127(LogicMath.clamp(battle.getZone1Score(), 0, 127))
        bitStream.writePositiveIntMax127(LogicMath.clamp(battle.getZone2Score(), 0, 127))
        break
      case 20: {
        bitStream.writePositiveIntMax2047(0)
        bitStream.writeBoolean(battle.isRoundEnding)
        bitStream.writeBoolean(true)
        bitStream.writePositiveIntMax3(LogicMath.clamp(battle.currentRound, 0, 3))
        bitStream.writeBoolean(true)

        const knockoutWinners = battle.getKnockoutRoundWinners(teamIndex)
        bitStream.writeIntMax127(knockoutWinners[0])
        bitStream.writeIntMax127(knockoutWinners[1])
        bitStream.writeIntMax127(knockoutWinners[2])
        break
      }
    }

    bitStream.writeBoolean(false)
    bitStream.writeIntMax15(-1)

    bitStream.writeBoolean(false)
    bitStream.writeBoolean(false)
    bitStream.writeBoolean(false)
    bitStream.writeBoolean(false)

    const v1 = LogicMath.clamp(tileMap.width, 0, tileMap.width - 1)
    const v2 = LogicMath.clamp(tileMap.height, 0, tileMap.height - 1)

    if (v1 > 21) {
      bitStream.writePositiveIntMax63(0)
      bitStream.writePositiveIntMax63(0)
      bitStream.writePositiveIntMax63(v1)
    } else {
      bitStream.writePositiveIntMax31(0)
      bitStream.writePositiveIntMax63(0)
      bitStream.writePositiveIntMax31(v1)
    }

    bitStream.writePositiveIntMax63(v2)

    for (let i = 0; i < tileMap.width; i++) {
      for (let j = 0; j < tileMap.height; j++) {
        const tile = tileMap.getTile(i, j, true)
        if (tile.data.respawnSeconds > 0 || tile.data.isDestructible || tile.data.tileCode === 'I') {
          bitStream.writeBoolean(tile.isDestructed())
        }
      }
    }

    bitStream.writePositiveVIntMax65535OftenZero(tileMap.newTiles.length)
    for (let i = 0; i < tileMap.newTiles.length; i++) {
      bitStream.writePositiveIntMax4095(tileMap.newTiles[i].tileX + tileMap.width * tileMap.newTiles[i].tileY)
      bitStream.writePositiveIntMax7(tileMap.newTiles[i].data.dynamicCode)
    }

    bitStream.writePositiveVIntMax65535OftenZero(this.petrols.length)
    for (let i = 0; i < this.petrols.length; i++) {
      bitStream.writePositiveIntMax63(this.petrols[i].x)
      bitStream.writePositiveIntMax63(this.petrols[i].y)
      bitStream.writeIntMax15(this.petrols[i].playerIndex % 16)
    }

    for (let i = 0; i < players.length; i++) {
      const isUsingPin = players[i].isUsingPin(battle.getTicksGone())

      bitStream.writeBoolean(players[i].isAlive)
      bitStream.writeBoolean(players[i].hasUlti())
      if (gameMode === 6) bitStream.writePositiveIntMax15(0)

      if (players[i].accessory != null) {
        players[i].accessory.encode(bitStream, players[i].ownObjectId === ownObjectId)
      }

      if (gameMode === 3) bitStream.writeBoolean(false)

      bitStream.writePositiveVIntMax255OftenZero(0)

      bitStream.writeBoolean(false)
      bitStream.writeBoolean(isUsingPin)
      if (isUsingPin) {
        bitStream.writeIntMax7(players[i].pinIndex)
        bitStream.writePositiveIntMax16383(LogicMath.clamp(players[i].startUsingPinTicks, 0, 16383))
      }

      if (i !== playerIndex) continue
      bitStream.writePositiveIntMax4095(LogicMath.clamp(players[i].getUltiCharge(), 0, 4000))
      bitStream.writeBoolean(players[i].hasUlti())
      bitStream.writeBoolean(false)
    }

    bitStream.writePositiveVIntMax255OftenZero(0)

    if (GameModeUtil.modeHasCarryables(gameMode)) {
      bitStream.writeBoolean(!(battle.getGoalTeam() !== -1) || battle._setStopTicks)
      bitStream.writeIntMax1(battle.getGoalTeam() !== -1 ? battle.getGoalTeam() : 0)
    }

    switch (gameMode) {
      case 6:
        bitStream.writePositiveIntMax15(LogicMath.clamp(battle.getPlayersAliveCountForBattleRoyale(), 0, 15))
        break
      case 8:
        bitStream.writePositiveIntMax127(0)
        bitStream.writePositiveIntMax127(0)
        bitStream.writeBoolean(true)
        break
      case 9:
        bitStream.writePositiveIntMax7(battle.getAliveTeams())
        break
      case 16:
        bitStream.writePositiveIntMax8191(0)
        bitStream.writePositiveIntMax8191(0)
        break
      default:
        if (GameModeUtil.hasTwoBases(gameMode)) {
          let hp1 = 0
          let hp2 = 0
          for (const character of this.getCharacters()) {
            if (!character.characterData.isBase()) continue
            if (!character.isAlive()) continue
            if (Math.trunc(character.getIndex() / 16) === 0) hp1 = character.getHitpointPercentage()
            else hp2 = character.getHitpointPercentage()
          }
          bitStream.writePositiveIntMax127(LogicMath.clamp(hp1, 0, 127))
          bitStream.writePositiveIntMax127(LogicMath.clamp(hp2, 0, 127))

          if (gameMode === 11) {
            bitStream.writePositiveIntMax255(0)
            bitStream.writePositiveIntMax255(0)
            bitStream.writePositiveIntMax7(0)
            bitStream.writePositiveIntMax7(0)
            bitStream.writePositiveIntMax63(0)
            bitStream.writePositiveIntMax63(0)
            bitStream.writeBoolean(false)
          }
        } else {
          switch (gameMode) {
            case 18:
              bitStream.writePositiveIntMax127(0)
              break
            case 14:
              bitStream.writePositiveIntMax127(0)
              bitStream.writePositiveIntMax16383(0)
              break
            case 13:
              bitStream.writePositiveIntMax131071(0)
              break
            case 10:
              bitStream.writePositiveIntMax127(10)
              break
            case 7:
              bitStream.writePositiveIntMax127(0)
              break
          }
        }
        break
    }

    for (let i = 0; i < players.length; i++) {
      if (gameMode !== 6 && gameMode !== 9) {
        bitStream.writeBoolean(true)
        bitStream.writePositiveVIntMax255(players[i].getScore())
      } else {
        bitStream.writeBoolean(false)
      }
      if (gameMode !== 6 && gameMode !== 9) {
        if (bitStream.writeBoolean(players[i].killList.length > 0)) {
          const count = LogicMath.min(players[i].killList.length, 15)
          bitStream.writePositiveIntMax15(count)
          for (let j = 0; j < count; j++) {
            bitStream.writePositiveIntMax15(players[i].killList[j].playerIndex)
            bitStream.writeIntMax7(players[i].killList[j].bountyStarsEarned)
          }
        }
      } else {
        bitStream.writeBoolean(false)
      }
    }

    bitStream.writePositiveVIntMax65535(visibleGameObjects.length)

    if (visibleGameObjects.length > 0) {
      for (const gameObject of visibleGameObjects) {
        ByteStreamHelper.writeBitDataReference(bitStream, gameObject.getDataId())
      }

      for (const gameObject of visibleGameObjects) {
        ByteStreamHelper.writeObjectRunningId(bitStream, gameObject.getGlobalID())
      }

      for (const gameObject of visibleGameObjects) {
        gameObject.encode(bitStream, ownObjectId === gameObject.getGlobalID(), teamIndex)
      }
    }

    if (gameMode !== 7) return
    if (!bitStream.writeBoolean(false)) return

    bitStream.writePositiveIntMax32767(0)
    bitStream.writePositiveIntMax65535(0)
  }
}

module.exports = GameObjectManager
