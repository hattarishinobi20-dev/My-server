const GameObject = require('./GameObject')
const GameObjectFactory = require('./GameObjectFactory')
const TileMap = require('../Level/TileMap')
const Skill = require('../Component/Skill')
const Poison = require('../Component/Poison')
const Immunity = require('../Component/Immunity')
const Buff = require('../Component/Buff')
const DataTables = require('../../Data/DataTables')
const DataType = require('../../Data/DataType')
const GamePlayUtil = require('../../Util/GamePlayUtil')
const LogicMath = require('../../../Titan/Math/LogicMath')
const LogicVector2 = require('../../../Titan/Math/LogicVector2')
const LogicPathFinder = require('../Level/LogicPathFinder')
const GlobalId = require('../../Data/Helper/GlobalId')
const GameModeUtil = require('../../Util/GameModeUtil')

const PICKUP_RADIUS_SQR = 90000
const DEFENSE_RADIUS = 400
const DEFENSE_RADIUS_SQR = DEFENSE_RADIUS * DEFENSE_RADIUS
const BASE_FLIGHT_DURATION = 140
const MIN_FLIGHT_DURATION = 40
const BOUNCE_DURATION_DECREMENT = 10
const MAX_HEIGHT = 3000
const CENTER_X = 3150
const CENTER_Y = 4950
const TARGET_MIN_X = 1200
const TARGET_MAX_X = 4800
const TEAM0_TARGET_MIN_Y = 1200
const TEAM0_TARGET_MAX_Y = 3500
const TEAM1_TARGET_MIN_Y = 5500
const TEAM1_TARGET_MAX_Y = 7800
const MAX_BOUNCES = 9999999

const SKIN_PROJECTILE_BLACKLIST = [
  'FleaProjectile3',
  'CocoonerUltiProjectile',
  'PuppeteerProjectile',
  'PuppeteerUltiProjectile',
  'ReviverUltiProjectile',
  'Roller003Projectile',
  'Poco003Projectile',
  'Poco003UltiProjectile',
  'Poco004Projectile',
  'Poco004UltiProjectile',
  'Poco005Projectile',
  'Poco005UltiProjectile',
  'Poco006UltiProjectile',
  'Poco007Projectile',
  'Poco007UltiProjectile'
]

function teamOf (index) {
  return Math.trunc(index / 16)
}

function sign (value) {
  return value > 0 ? 1 : value < 0 ? -1 : 0
}

function f32 (value) {
  return Math.fround(value)
}

function getProjectileClass () {
  return require('./Projectile')
}

function getAreaEffectClass () {
  return require('./AreaEffect')
}

function getItemClass () {
  return require('./Item')
}

class DamageNumber {
  constructor (value, dealerIndex, delay) {
    this.dealer = dealerIndex
    this.value = value
    this.delay = delay
  }
}

class Character extends GameObject {
  static MAX_HOLD_TICKS = 15
  static MAX_SKILL_HOLD_TICKS = 15
  static INTRO_TICKS = 100
  static DAMAGE_NUMBERS_DELAY_TICKS = 2
  static DEPLOY_TICKS_FIRST_SPAWN = 4
  static DEPLOY_TICKS = 19

  constructor (characterData) {
    super(characterData)

    this.forcedAngleTicks = 0
    this.hitpoints = 0
    this.maxHitpoints = 0
    this.orginalMaxHP = 0
    this.int344 = 0
    this.dword348 = 0
    this.state = 0
    this.moveAngle = 0
    this.attackAngle = 0
    this.ultiSkill = false
    this.isControlled = false
    this.shaking = 0
    this.isInvincible = false
    this.usingUltiCurrently = false
    this.shouldExecuteColetteChargeOnReturn = false
    this.wayPoint2 = new LogicVector2()
    this.wayPoint = null
    this.wayPointStart = null
    this.posDelta = null
    this.movementVector = new LogicVector2()
    this.moveStart = 0
    this.moveEnd = 0
    this.pathLength = 0
    this.healthRegenBlockedTick = 0
    this.lastSelfHealTick = 0
    this.bulletIndex = 0
    this.prevY = 0
    this.prevX = 0
    this.yellowEye = false
    this.visibilityState = 0
    this.invisibleTicks = 0
    this.isInvisible = false
    this.seeInvisibilityDistance = 0
    this.breakInvisibilityOnAttack = false
    this.spawnTick = 0
    this.chargeAreaEffectData = null
    this.knockBacked = false
    this.knockback1 = false
    this.knockback2 = false
    this.knockback3 = false
    this.boostSet = false
    this.extraRegenAmount = 0
    this.extraRegenTicks = 0
    this.extraRegenerIndex = 0
    this.healthRegenedTick = 0
    this.healthRegenedTickSP = 0
    this.reloadBuffTicks = 0
    this.areaEffect = null
    this.chargeUpType = 0
    this.chargeUp = 0
    this.chargeUpMax = 0
    this.meleeAttackPushBacks = false
    this.meleeAttackPushBack = 0
    this.consumableShield = 0
    this.consumableShieldMax = 0
    this.consumableShieldTick = 0
    this.consumableShieldDuration = 0
    this.blinkX = 0
    this.blinkY = 0
    this.draggingObject = null
    this.draggingOffsetX = 0
    this.draggingOffsetY = 0
    this.starPowerIC = false
    this.autoAttackDamangeBoost = 0
    this.deployedTick = 0
    this.starPowerProjectileTimer = 0
    this.parentGID = 0
    this.hitEffectAngle = 0
    this.hitEffectProjectile = 0
    this.hitEffectSkin = 0
    this.staticSpeedBuff = 0
    this.aoeRegenerate = 0
    this.isCrippled = false
    this.cripplePercent = 0
    this.crippleEndTick = 0
    this.chargeBreaksEnvironment = false
    this.castingTime = 0
    this.transformAnimation = false
    this.steerAngle = 0
    this.steerStartTicks = 0
    this.autoUltiChargeTimer = 0
    this.ccImmunityTicks = 0
    this.chargedShotCount = 0
    this.chargedShotMisses = 0
    this.runningChargingUlti = 0
    this.isWeaklyStunned = false
    this.jesterSkillCount = 0
    this.itemPickedUpTick = 0
    this.ultiButtonPressedTimes = 0
    this.displayUltiTmp = false
    this.viusalChargeType = 0
    this.visionOverrideX = 0
    this.visionOverrideY = 0
    this.visionOverrideTicks = 0
    this.ashLastRageTick = 0
    this.attacking = false
    this.autoAttackTarget = null
    this.autoAttackSpeedMs = 0
    this.afkTicks = 0
    this.skillHoldTicks = 0
    this.rapidFireTick = 0
    this.buffs = null
    this.damageNumbers = null
    this.chargeHitGIDs = null
    this.fangHitGIDs = null
    this.isTeleporting = false
    this.previousPlayer = null
    this.ultiing = false
    this.skills = null
    this.immunitys = null
    this.itemCount = 0
    this.battleRoyaleBuffs = 0
    this.realmEffect = null
    this.summonedCharacter = null
    this.spawnedItem = null
    this.numSpawns = 0
    this.numSpawnsItem = 0
    this.maxSpawns = 0
    this.maxSpawnsItem = 0
    this.spawnDamage = 0
    this.spawnedItemDamage = 0
    this.spawnedItemNormalDMG = 0
    this.spawnHealth = 0
    this.heroLevel = 0
    this.leftHand = 0
    this.attackOffsetX = 0
    this.attackOffsetY = 0
    this.attackOffset2X = 0
    this.attackOffset2Y = 0
    this.attackVector = null
    this.attackTarget = null
    this.projectileShieldAngle = 0
    this.projectileShieldScale = 0
    this.projectileShieldCoolDown = 0
    this.rapidFireX = 0
    this.rapidFireY = 0
    this.rapidFireDamage = 0
    this.rapidFireNormalDMG = 0
    this.rapidFireAttackPattern = 0
    this.rapidFireRange = 0
    this.rapidFireSpread = 0
    this.rapidFireProjectile = null
    this.skinProjectileData = null
    this.rapidFireBulletsPerShoot = 0
    this.rapidFireMsBetweenAttacks = 0
    this.rapidFireShootTimes = 0
    this.rapidFireRepeatX = 0
    this.rapidFireRepeatY = 0
    this.isRapidFireHeld = false
    this.rapidFireRepeatTick = 0
    this.shootIndex = 0
    this.slowingModifier = 0
    this.acceleratingModifier = 0
    this.damageModifier = 0
    this.realmTimer = 0
    this.isBot = 0
    this.ticksSinceBotEnemyCheck = 100
    this.lastAIAttackTick = 0
    this.lastUltiTick = 0
    this.lastBotPosX = 0
    this.lastBotPosY = 0
    this.lastBotMoveTick = 0
    this.botStuckTicks = 0
    this.botDetourX = 0
    this.botDetourY = 0
    this.botDetourUntil = 0
    this.botHadPathThisTick = false
    this.botState = 0
    this.botStateUntil = 0
    this.botWanderX = 0
    this.botWanderY = 0
    this.botWanderUntil = 0
    this.botStrafeDir = 0
    this.botLastHp = 0
    this.botReactionDelay = 0
    this.botTeamingWith = -1
    this.botTeamingUntil = 0
    this.closestEnemy = null
    this.closestEnemyPosition = null
    this.activeChargeType = 0
    this.longerDashExtraBullets = 0
    this.longerDashGaugeTimer = 0
    this.longerDashGaugeReady = false
    this.chargeHits = 0
    this.fangUltiCount = 0
    this.isCharging = false
    this.ultiNoStun = false
    this.chargeSpeed = 0
    this.chargePushback = 0
    this.chargeAnimation = 0
    this.chargeDamage = 0
    this.chargeNormalDMG = 0
    this.chargePercentDamage = 0
    this.stunTicks = 0
    this.destructafterticks = 0
    this.damageMultiplier = 0
    this.lastTileDamageTick = 0
    this.lastTileHealTick = 0
    this.lastSpeedTileTick = 0
    this.shieldTicks = 0
    this.shieldPercent = 0
    this.attackingTicks = 0
    this.lastAttckTick = 0
    this.poisons = null
    this.partialStunPromille = 0
    this.ticksSincePartialStun = 0
    this.chargestart = null
    this.characterAreaEffect = null
    this.tms = null
    this.transformationState = 0
    this.isRage = false
    this.passiveCounter = 0
    this.passiveCounter2 = 0
    this.gear1 = null
    this.gear2 = null
    this.characterData = null
    this.taraGadget = false
    this.piperTick = 0
    this.samState = false
    this.immunToPushbackOutOfWalls = false
    this.isReviverUlti = false
    this.attackAcceleratingFactor = 0
    this.stopAI = false
    this.isOvercharged = false
    this.bigState = false
    this.canHeal = false
    this.isHealer = false
    this.frozenPercentage = 0
    this.slippery = false
    this.slipperyTicks = 0
    this.frozenDecayTick = 0
    this.speedX = 0
    this.speedY = 0
    this.lastFrozenTick = 0
    this.isMovementControlDisabled = false
    this.silence = false
    this.silenceTick = 0
    this.portalTicks = 0
    this.redCharacter = false
    this.isWillowControl = false
    this.controlledCharacter = null
    this.splitterLegsActive = false
    this.tagged = false
    this.lastTagTick = 0
    this.isFirstTag = false
    this.attached = false
    this.attachedCharacter = null
    this.isDragging = false
    this.carringCharacter = null
    this.spawnedEffects = []
    this.lastX = -1
    this.lastY = -1
    this.samuraiAttackSlashAttack = false
    this.carryablePersonImunTicks = 0
    this.lastPickupPlayerIndex = 0
    this.lastPickupPlayerIndexTOCHNO = 0
    this.carryablePickTicks = 0
    this.landingTick = 0
    this.ballState = 0
    this.currentZone = null
    this.servingTeam = -1
    this.currentZoneName = ''
    this.currentDistanceIndicator = null
    this.moveStartX = 0
    this.moveStartY = 0
    this.moveStartZ = 0
    this.isScored = false
    this.lastLaunchTick = 0
    this.indicatorSpawned = false
    this.distanceIndicator = null
    this.indicatorSpawnTick = 0
    this.isKicked = false
    this.totalKickDistance = 2400
    this.distanceTraveled = 0
    this.bounceCount = 0
    this.shamanPetTarget = null
    this.targetX = 0
    this.targetY = 0
    this.kickStartX = 0
    this.kickStartY = 0
    this.currentKickSpeed = 0
    this.maxKickSpeed = 0
    this.kickDirection = null
    this.nextAttackModifier = null
    this.activeNextAttackGadget = null
    this.pushbackImmunTicks = 0
    this.yellowEyeTicks = 0
    this.timedDamageState = null

    this.characterData = characterData
    this.damageNumbers = []
    this.skills = []
    this.buffs = []
    this.posDelta = new LogicVector2()
    this.wayPoint = new LogicVector2()
    this.wayPointStart = new LogicVector2()
    this.attackTarget = new LogicVector2()
    this.attackVector = new LogicVector2()
    this.moveStart = 0
    this.moveEnd = 0
    this.maxHitpoints = this.characterData.hitpoints
    this.autoAttackSpeedMs = this.characterData.autoAttackSpeedMs
    this.hitpoints = this.maxHitpoints
    this.orginalMaxHP = this.maxHitpoints
    this.blinkX = -1
    this.poisons = []
    this.immunitys = []
    this.isControlled = false
    this.realmTimer = 0
    this.state = 4
    this.ultiSkill = false
    this.destructafterticks = 5
    this.steerAngle = -1
    this.skillHoldTicks = -1
    this.visionOverrideX = -1
    this.afkTicks = 0
    const weaponSkillData = this.weaponSkillData
    if (weaponSkillData != null) {
      this.skills.push(new Skill(weaponSkillData.getGlobalId(), false, this))
      if (this.isBot === 2) this.skills[0].infinity = true
      const ultimateSkillData = this.ultimateSkillData
      if (ultimateSkillData != null) {
        this.skills.push(new Skill(ultimateSkillData.getGlobalId(), true, this))
      }
    }
    if (this.characterData.name === 'Mummy') this.transformationState = 0
    this.canHeal = true
    this.activeChargeType = -1
    this.passiveCounter = 1
    this.passiveCounter2 = 4
    this.samState = true
    this.isInRealm = false
    this.pendingArcBombs = null
  }

  get starPowerData () {
    const player = this.getPlayer()
    return player == null ? null : player.starPowerData
  }

  get accessory () {
    const player = this.getPlayer()
    return player == null ? null : player.accessory
  }

  get mapHeight () {
    return this.gameObjectManager.getBattle().getTileMap().logicHeight
  }

  get mapWidth () {
    return this.gameObjectManager.getBattle().getTileMap().logicWidth
  }

  get weaponSkillData () {
    const name = this.characterData.weaponSkill
    return name ? DataTables.getByName(DataType.Skill, name) : null
  }

  get ultimateSkillData () {
    const name = this.characterData.ultimateSkill
    return name ? DataTables.getByName(DataType.Skill, name) : null
  }

  get ticksGone () {
    return this.gameObjectManager.getBattle().getTicksGone()
  }

  triggerPushbackImmun () {
    this.pushbackImmunTicks = 100
    this.immunToPushbackOutOfWalls = true
  }

  isBlackListSkinPro (projectile) {
    return SKIN_PROJECTILE_BLACKLIST.includes(projectile)
  }

  getMaxHoldTicks () {
    const v2 = this.getCardValueForPassive('faster_focus', 1)
    if (v2 >= 1) return 13 - Math.trunc(13 * v2 / 100)
    return 13
  }

  getMaxChargedShots () {
    const weaponSkillData = this.weaponSkillData
    if (weaponSkillData != null && weaponSkillData.chargedShotCount >= 1) return weaponSkillData.chargedShotCount
    if (this.characterData.uniqueProperty === 10) return this.characterData.uniquePropertyValue1
    return -1
  }

  setKing () {
    this.bigState = true
    this.giveSpeedSlowerBuff(-100, 9999)
    this.canHeal = false
    this.hitpoints = 100000
    this.maxHitpoints = 100000
  }

  pushOutOfWalls () {
    if (this.characterData.isCarryable()) return
    if (!this.isSteerMovementActive() && this.draggingObject == null && !this.knockback3 && !this.knockback1 && !this.knockback2 && (!this.isCharging || !GamePlayUtil.isJumpCharge(this.activeChargeType))) {
      if (this.immunToPushbackOutOfWalls) return
      const tileMap = this.getBattle().getTileMap()
      if (!tileMap.isPassable(1, Math.trunc(this.getX() / 300), Math.trunc(this.getY() / 300), 0, 0, this.characterData.canWalkOverWater)) {
        this.triggerStun(1, true)
        GamePlayUtil.getClosestPassableSpot(1, this.getX(), this.getY(), 10, tileMap, this.posDelta, this.characterData.canWalkOverWater)
        this.triggerPushback(
          this.getX() - this.posDelta.x + this.getX(),
          this.getY() - this.posDelta.y + this.getY(),
          Math.trunc(LogicMath.max(GamePlayUtil.getDistanceBetween(this.getX(), this.getY(), this.posDelta.x, this.posDelta.y), 300) / 6),
          true, 0, true, false, false, true, false, true, false, 0)
      }
    }
  }

  triggerImmunToPushOutOfWalls (ticks) {
    this.pushbackImmunTicks = ticks > 0 ? ticks : 100
    this.immunToPushbackOutOfWalls = true
  }

  checkTileCollision (startX, startY, endX, endY) {
    const tileMap = this.getBattle().getTileMap()
    const startTileX = Math.trunc(startX / 300)
    const startTileY = Math.trunc(startY / 300)
    const endTileX = Math.trunc(endX / 300)
    const endTileY = Math.trunc(endY / 300)
    const dx = Math.abs(endTileX - startTileX)
    const dy = Math.abs(endTileY - startTileY)
    const sx = startTileX < endTileX ? 1 : -1
    const sy = startTileY < endTileY ? 1 : -1
    let err = dx - dy
    let currentX = startTileX
    let currentY = startTileY
    while (true) {
      const tile = tileMap.getTile(currentX, currentY, true)
      if (tile != null && tile.data != null && tile.data.blocksMovement && !tile.isDestructed()) {
        return this.calculateTileNormal(currentX, currentY, startTileX, startTileY)
      }
      if (currentX === endTileX && currentY === endTileY) break
      const e2 = 2 * err
      if (e2 > -dy) {
        err -= dy
        currentX += sx
      }
      if (e2 < dx) {
        err += dx
        currentY += sy
      }
    }
    return null
  }

  calculateTileNormal (tileX, tileY, fromTileX, fromTileY) {
    const tileCenterX = tileX * 300 + 150
    const tileCenterY = tileY * 300 + 150
    const toStartX = fromTileX * 300 + 150 - tileCenterX
    const toStartY = fromTileY * 300 + 150 - tileCenterY
    const normal = new LogicVector2(0, 0)
    if (Math.abs(toStartX) > Math.abs(toStartY)) {
      normal.x = sign(toStartX)
    } else {
      normal.y = sign(toStartY)
    }
    const length = Math.trunc(Math.sqrt(normal.x * normal.x + normal.y * normal.y))
    if (length > 0) {
      normal.x = Math.trunc((normal.x * 1024) / length)
      normal.y = Math.trunc((normal.y * 1024) / length)
    }
    return normal
  }

  setVisionOverride (x, y, ticks) {
    this.visionOverrideX = x
    this.visionOverrideY = y
    this.visionOverrideTicks = ticks
    this.stopMovement()
  }

  addCcImmunity (ticks) {
    for (let i = 0; i < this.buffs.length; i++) {
      if (this.buffs[i].type === 3) {
        this.buffs.splice(i, 1)
        i--
      }
    }
    this.knockback3 = false
    this.knockBacked = false
    this.ccImmunityTicks = ticks
    this.stopMovement()
  }

  static summonMinion (characterData, x, y, a4, numSpawn, maxSpawn, extraDamage, extraHealth, battle, a10, a11, a12, overridePrevious, a14, a15, starPowerIC, a17) {
    if (characterData == null || battle == null) return null
    const gameObjectManager = battle.getGameObjectManager()
    const index = a11 * 16 + a10
    const existing = []
    for (const character of gameObjectManager.getCharacters()) {
      if (character.getIndex() === index && character.characterData === characterData && character.hitpoints > 0) existing.push(character)
    }
    let count = existing.length
    let spawnCount = numSpawn
    if (overridePrevious) {
      if (count + numSpawn > maxSpawn) {
        const toKill = LogicMath.min(count, count + numSpawn - maxSpawn)
        for (let i = 0; i < toKill; i++) {
          const character = existing[i]
          character.causeDamage(null, character.hitpoints, 0, false, null, false, true)
          count--
        }
      }
    } else if (maxSpawn - count < numSpawn) {
      spawnCount = maxSpawn - count
    }
    if (spawnCount < 1) return null
    let minion = null
    let spawned = 0
    do {
      let spawnX = x
      let spawnY = y
      if (numSpawn === 5) {
        const angle = spawned * 72 - 18
        const tileMap = battle.getTileMap()
        spawnX = LogicMath.clamp(LogicMath.getRotatedX(600, 0, angle) + x, 101, tileMap.logicWidth - 101)
        spawnY = LogicMath.clamp(LogicMath.getRotatedY(600, 0, angle) + y, 101, tileMap.logicHeight - 101)
      }
      const tmp = new LogicVector2()
      GamePlayUtil.getClosestPassableSpot(0, spawnX, spawnY, 10, battle.getTileMap(), tmp, characterData.canWalkOverWater)
      minion = GameObjectFactory.createGameObjectByData(characterData)
      minion.setPosition(tmp.x, tmp.y, characterData.flyingHeight)
      minion.setIndex(index)
      let boost = minion.autoAttackDamangeBoost
      const hitpoints = minion.maxHitpoints + extraHealth
      minion.hitpoints = hitpoints
      if (characterData.autoAttackDamage > 0) boost += extraDamage
      minion.maxHitpoints = hitpoints
      minion.autoAttackDamangeBoost = boost
      minion.deployedTick = battle.getTicksGone()
      minion.parentGID = a12
      gameObjectManager.addGameObject(minion)
      minion.addAreaEffect(extraDamage, a17, null, 0, false)
      minion.starPowerIC = starPowerIC
      spawned++
    } while (spawned < spawnCount)
    return minion
  }

  setUpgrades (a2) {
    this.setHeroLevel(a2)
    this.calculateChargeUp()
  }

  setStarPowerBoosts () {
    if (this.starPowerData != null && !this.boostSet) {
      this.boostSet = true
      if (this.getCardValueForPassive('aoe_regenerate', 1) !== -1) {
        this.aoeRegenerate = Math.trunc((this.getCardValueForPassive('aoe_regenerate', 1) / 1000) * this.maxHitpoints)
      }
      if (this.getCardValueForPassive('speed', 1) !== -1) {
        this.staticSpeedBuff += this.getCardValueForPassive('speed', 1)
      }
      if (this.getCardValueForPassive('gain_health', 1) !== -1) {
        this.maxHitpoints += Math.trunc((this.getCardValueForPassive('gain_health', 1) / 1000) * this.maxHitpoints)
        this.hitpoints = this.maxHitpoints
      }
      if (this.getCardValueForPassive('extra_bullet', 1) !== -1 && this.skills[0] != null) {
        this.skills[0].maxCharge += 1000 * this.getCardValueForPassive('extra_bullet', 1)
        this.skills[0].charge = this.skills[0].maxCharge
      }
      this.starPowerIC = true
    }
  }

  triggerTransforming (a2) {
    const c = this.getBattle().spawnHero(a2, this.heroLevel, this.getIndex(), 0, false)
    if (c == null) return null
    c.setPosition(this.getX(), this.getY(), 0)
    if (this.characterData.uniqueProperty === 7) c.hitpoints = this.hitpoints
    c.itemCount = this.itemCount
    c.battleRoyaleBuffs = this.battleRoyaleBuffs
    if (c.skills[0] != null && this.skills[0] != null) c.skills[0].charge = this.skills[0].charge
    c.blockHealthRegen()
    const player = this.getPlayer()
    if (player != null) player.ownObjectId = c.getGlobalID()
    this.gameObjectManager.removeGameObject(this)
    this.transformAnimation = true
    return c
  }

  causeTimedDamage (target, time, damage, old, player, hp) {
    target.timedDamageState = {
      source: this,
      old,
      player,
      hp,
      nextTick: target.ticksGone + 40,
      finished: false
    }
  }

  tickTimedTransform () {
    const state = this.timedDamageState
    if (state == null || state.finished) return
    if (this.hitpoints > 0) {
      if (this.ticksGone < state.nextTick) return
      state.nextTick = this.ticksGone + 40
      this.causeDamage(state.source, 800, 0, false, null, false, true)
      this.blockHealthRegen()
      if (this.hitpoints > 0) return
    }
    state.finished = true
    const battle = this.getBattle()
    this.gameObjectManager.removeGameObject(this)
    if (state.old == null) return
    const c = battle.spawnHero(state.old.characterData, state.old.getHeroLevel(), state.old.getIndex(), 0, false)
    if (c == null) return
    c.setPosition(this.getX(), this.getY(), 0)
    if (state.player != null) state.player.ownObjectId = c.objectGlobalId
    c.hitpoints = state.hp
  }

  timedTransform (a2, duration, x, y, index, oldModel, oldPlayer, hitPoints, owner) {
    const c = this.getBattle().spawnHero(a2, 11, index, 0, false)
    if (c == null) return null
    c.setPosition(x, y, 0)
    if (oldPlayer != null) oldPlayer.ownObjectId = c.getGlobalID()
    c.causeTimedDamage(c, 0, 0, oldModel, oldPlayer, hitPoints)
    return c
  }

  ultiButtonPressedTwice () {
    if (this.isCharging && this.activeChargeType === 1) {
      this.ultiButtonPressedTimes = 0
      this.stopMovement()
      this.interruptAllSkills(true)
    }
  }

  calculateChargeUp () {
    let result = 0
    if (this.skills.length >= 2) {
      if (this.skills[0].skillData.chargeSpeed > 0 && this.skills[0].skillData.chargeType === 0) {
        this.chargeUpType = 1
        this.chargeUpMax = this.skills[0].skillData.chargeSpeed
        return
      }
      if (this.skills[1].skillData.chargeType === 15) {
        this.chargeUpType = 7
        this.chargeUpMax = this.skills[1].skillData.activeTime
        this.chargeUp = 0
      }
    }
    if (this.getCardValueForPassive('medikit', 1) >= 0) {
      this.chargeUpType = 2
      this.chargeUpMax = this.getCardValueForPassive('medikit', 2)
      return
    }
    if (this.getCardValueForPassive('grow_from_damage', 1) >= 0) {
      this.chargeUpType = 3
      this.chargeUpMax = this.getCardValueForPassive('grow_from_damage', 0)
      return
    }
    if (this.getCardValueForPassive('armor', 1) >= 0) {
      this.chargeUpType = 4
      this.chargeUpMax = this.getCardValueForPassive('armor', 1)
      this.chargeUp = this.chargeUpMax
      return
    }
    if (this.getCardValueForPassive('increased_explosion', 1) >= 0) {
      this.chargeUpType = 6
      this.chargeUpMax = this.getCardValueForPassive('increased_explosion', 1)
      return
    }
    if (this.getCardValueForPassive('attack_pierce', 1) >= 0) {
      this.chargeUpType = 6
      this.chargeUpMax = this.getCardValueForPassive('attack_pierce', 1) * 50
      return
    }
    if (this.getCardValueForPassive('explosion_damage_increase', 1) >= 0) {
      this.chargeUpType = 6
      this.chargeUpMax = this.getCardValueForPassive('explosion_damage_increase', 1)
      return
    }
    if (this.getCardValueForPassive('reduce_damage_periodically', 1) >= 0) {
      this.chargeUpType = 2
      this.chargeUpMax = this.getCardValueForPassive('reduce_damage_periodically', 1) * 50
      return
    }
    if (this.getCardValueForPassive('spawn_pet_on_hit', 1) >= 0) {
      this.chargeUpType = 6
      this.chargeUpMax = this.getCardValueForPassive('spawn_pet_on_hit', 1) * 50
      return
    }
    if (this.getCardValueForPassive('longer_dash', 1) >= 0) {
      this.chargeUpType = 1
      let ldTimeMs = this.getCardValueForPassive('longer_dash', 2)
      if (ldTimeMs <= 0) ldTimeMs = 2500
      this.chargeUpMax = ldTimeMs
      return
    }
    switch (this.characterData.uniqueProperty) {
      case 1:
        this.chargeUpMax = 1000
        this.chargeUpType = 8
        break
      case 3:
        this.chargeUpType = 1
        this.chargeUpMax = this.characterData.uniquePropertyValue1 * 50
        result = this.getCardValueForPassive('faster_long_dash', 1)
        if (result >= 1) this.chargeUpMax -= 50 * result
        break
      case 10:
        this.chargeUpType = 9
        this.chargeUpMax = this.characterData.uniquePropertyValue1
        break
      case 12:
        this.chargeUpType = 10
        this.chargeUpMax = this.characterData.uniquePropertyValue1
        break
      case 17:
        this.chargeUpType = 6
        this.chargeUpMax = this.characterData.uniquePropertyValue1
        break
    }
    const player = this.getPlayer()
    if (player != null && player.accessory != null && player.accessory.accessoryData.showCountdown) {
      this.chargeUpType = 7
      this.chargeUpMax = player.accessory.accessoryData.activeTicks * 50
    }
  }

  addExtraHealthRegen (a2, a3, a4) {
    this.applyBuff(10, a3, a2, 0, a4)
  }

  setStartRotation (angle) {
    this.moveAngle = angle
    this.attackAngle = angle
  }

  applyPoison (sourceIndex, damage, normalDMG, isUlti, source, type) {
    for (const poison of this.poisons) {
      if (poison.sourceIndex === sourceIndex && !poison.allowStacking()) {
        poison.refreshPosion(damage, normalDMG, isUlti, type)
        return
      }
    }
    this.poisons.push(new Poison(damage, normalDMG, isUlti, source, sourceIndex, type))
  }

  triggerShake () {
    this.shaking = 6
  }

  isChargeUpReady () {
    return this.chargeUp >= this.chargeUpMax
  }

  addShield (time, percentage) {
    this.shieldPercent = percentage
    this.shieldTicks = time
  }

  setBot (isbot) {
    this.isBot = isbot
  }

  applyItem (logicItem) {
    const battle = this.gameObjectManager.getBattle()
    let player = battle.getPlayer(this.getGlobalID())
    switch (logicItem.itemData.name) {
      case 'SoulCollectorSoul': {
        let heal = logicItem.damage
        if (this.getCardValueForPassive('item_healing_increased', 1) >= 1) heal *= 2
        this.heal(logicItem.getIndex(), heal, true, logicItem.itemData)
        break
      }
      case 'BattleRoyaleBuff': {
        const ownPlayer = this.getPlayer()
        if (battle.getGameModeVariation() === 9 && ownPlayer != null) {
          for (const character of battle.getCharactersByTeam(ownPlayer.teamIndex)) {
            character.battleRoyaleBuffs++
            character.maxHitpoints += 400
            character.hitpoints += 400
            character.damageMultiplier++
          }
        } else {
          this.battleRoyaleBuffs++
          this.maxHitpoints += 400
          this.hitpoints += 400
          this.damageMultiplier++
        }
        break
      }
      case 'Money':
        if (player != null) {
          player.addScore(1)
        }
        break
      case 'Point':
        player = battle.getPlayer(this.getGlobalID())
        if (player != null) {
          this.itemCount++
          player.addScore(1)
        }
        break
      case 'RuffsBuff':
        player = battle.getPlayer(this.getGlobalID())
        if (this.hasBuff(13)) return
        if (player != null) {
          this.applyBuff(13, 1230, 1, 10)
        }
        this.hitpoints += 700
        this.maxHitpoints += 700
        this.damageMultiplier++
        break
      case 'WeaponThrowerWeapon':
        player = battle.getPlayer(this.getGlobalID())
        if (player != null && this.characterData.name === 'WeaponThrower') {
          player.addUltiCharge(4000)
        }
        this.samState = true
        return
    }
    switch (logicItem.itemData.parentItemForSkin) {
      case 'WeaponThrowerWeapon':
        player = battle.getPlayer(this.getGlobalID())
        if (player != null && this.characterData.name === 'WeaponThrower') {
          player.addUltiCharge(4000)
        }
        this.samState = true
        break
    }
  }

  static transformPushBackStrengthToLength (a1) {
    return 6 * LogicMath.abs(a1)
  }

  static transformPushBackLengthToStrength (a1) {
    return Math.trunc(a1 / 6)
  }

  giveReloadBuff (a2) {
    this.reloadBuffTicks = a2
  }

  setDraggingObject (a2, a3, a4) {
    if (this.hasCcImmunity() || this.isInvincible || this.isCharging) return
    this.draggingObject = a2
    this.draggingOffsetX = a3
    this.draggingOffsetY = a4
    this.moveStart = this.ticksGone - 1
    this.moveEnd = this.ticksGone - 1
    this.interruptAllSkills(false)
  }

  tickSkills () {
    this.castingTime = LogicMath.max(0, this.castingTime - 50)
    for (let i = 0; i < this.skills.length; i++) {
      this.skills[i].tick(this)
    }
  }

  tickAutoUltiCharge () {
    if (this.state !== 4) {
      let v1 = Math.trunc(this.characterData.chargeUltiAutomatically / 4)
      if (v1 >= 1) {
        this.autoUltiChargeTimer--
        if (this.autoUltiChargeTimer <= 0) {
          if (this.getPlayer() != null) {
            const accessory = this.accessory
            if (accessory != null && accessory.type === 'auto_super_load_boost' && accessory.isActive) {
              v1 += Math.trunc(v1 * accessory.accessoryData.customValue1 / 100)
            }
            this.chargeUlti(v1, false, true, this.getPlayer(), this)
          }
          this.autoUltiChargeTimer = 5
        }
      }
    }
  }

  createVolleyAreaEffect (data, x, y) {
    const AreaEffect = getAreaEffectClass()
    const areaEffect = new AreaEffect(data)
    areaEffect.setPosition(x, y, 0)
    areaEffect.setIndex(this.getIndex())
    areaEffect.setSource(this, 1)
    return areaEffect
  }

  tickVolleyBall () {
    if (this.isScored) return
    const battle = this.gameObjectManager.getBattle()
    const manager = battle != null ? battle.getGameObjectManager() : null
    if (manager == null) return
    const currentTick = this.ticksGone
    if (this.ballState === 0) {
      if (!this.indicatorSpawned) {
        const indicatorData = DataTables.getAreaEffectByName('VolleyBallDistanceIndicator')
        if (indicatorData != null) {
          this.distanceIndicator = this.createVolleyAreaEffect(indicatorData, this.getX(), this.getY())
          manager.addGameObject(this.distanceIndicator)
          this.distanceIndicator.trigger()
          this.indicatorSpawned = true
          this.indicatorSpawnTick = currentTick
        }
      }
      if (currentTick < this.lastLaunchTick + 40) return
      for (const c of manager.getCharacters()) {
        if (!c.isAlive() || c.getPlayer() == null || c.getGlobalID() === this.getGlobalID()) continue
        const dx = this.getX() - c.getX()
        const dy = this.getY() - c.getY()
        if (dx * dx + dy * dy <= PICKUP_RADIUS_SQR) {
          if (this.distanceIndicator != null) {
            manager.removeGameObject(this.distanceIndicator)
            this.distanceIndicator = null
          }
          this.bounceCount = 0
          this.moveStartX = this.getX()
          this.moveStartY = this.getY()
          this.moveStartZ = this.getZ()
          this.lastLaunchTick = currentTick
          this.launchBallToOpponent(c.getPlayer().teamIndex, battle, manager)
          return
        }
      }
    } else if (this.ballState === 1) {
      if (this.distanceIndicator != null) {
        manager.removeGameObject(this.distanceIndicator)
        this.distanceIndicator = null
      }
      this.updateFlightPosition(currentTick)
      if (currentTick >= this.landingTick) {
        this.checkLanding(battle, manager)
      }
    }
  }

  updateFlightPosition (currentTick) {
    const totalDuration = this.landingTick - this.moveStart
    if (totalDuration <= 0) return
    let t = f32((currentTick - this.moveStart) / totalDuration)
    if (t > 1) t = 1
    const curX = this.moveStartX + Math.trunc(f32((this.targetX - this.moveStartX) * t))
    const curY = this.moveStartY + Math.trunc(f32((this.targetY - this.moveStartY) * t))
    const curZ = Math.trunc(f32(f32(f32(4 * MAX_HEIGHT) * t) * f32(1 - t)))
    this.setPosition(curX, curY, curZ)
    if (currentTick % 2 === 0) {
      const manager = this.gameObjectManager.getBattle().getGameObjectManager()
      const defendingTeam = this.servingTeam === 0 ? 1 : 0
      let isAnyDefendingPlayerInside = false
      for (const c of manager.getCharacters()) {
        const player = c.getPlayer()
        if (!c.isAlive() || !c.characterData.isHero() || player == null || player.teamIndex !== defendingTeam) continue
        const dx = this.targetX - c.getX()
        const dy = this.targetY - c.getY()
        if (dx * dx + dy * dy <= DEFENSE_RADIUS_SQR) {
          isAnyDefendingPlayerInside = true
          break
        }
      }
      const targetName = isAnyDefendingPlayerInside ? 'VolleyBallTargetOccupied' : 'VolleyBallTarget'
      if (this.currentZoneName !== targetName) {
        if (this.currentZone != null) manager.removeGameObject(this.currentZone)
        this.spawnArea(targetName, manager)
      }
    }
  }

  launchBallToOpponent (attackerTeam, battle, manager) {
    this.ballState = 1
    this.servingTeam = attackerTeam
    this.moveStart = this.ticksGone
    let duration = BASE_FLIGHT_DURATION - this.bounceCount * BOUNCE_DURATION_DECREMENT
    if (duration < MIN_FLIGHT_DURATION) duration = MIN_FLIGHT_DURATION
    this.landingTick = this.ticksGone + duration
    this.currentZoneName = ''
    const tileMap = battle.getTileMap()
    const targetMinY = attackerTeam === 0 ? TEAM0_TARGET_MIN_Y : TEAM1_TARGET_MIN_Y
    const targetMaxY = attackerTeam === 0 ? TEAM0_TARGET_MAX_Y : TEAM1_TARGET_MAX_Y
    this.targetX = battle.getRandomInt(TARGET_MIN_X, TARGET_MAX_X)
    this.targetY = battle.getRandomInt(targetMinY, targetMaxY)
    const passableSpot = new LogicVector2()
    GamePlayUtil.getClosestPassableSpot(1, this.targetX, this.targetY, 15, tileMap, passableSpot, true)
    if (passableSpot.x > 0) {
      this.targetX = passableSpot.x
      this.targetY = passableSpot.y
    }
    const hitData = DataTables.getAreaEffectByName('VolleyBallHit')
    if (hitData != null) {
      const hitEff = this.createVolleyAreaEffect(hitData, this.getX(), this.getY())
      manager.addGameObject(hitEff)
      hitEff.trigger()
    }
    if (this.currentZone != null) {
      manager.removeGameObject(this.currentZone)
      this.currentZone = null
    }
    this.spawnArea('VolleyBallTarget', manager)
  }

  isTileBlocking (x, y, map) {
    const tileX = Math.trunc(x / 300)
    const tileY = Math.trunc(y / 300)
    for (let dx = -1; dx <= 1; dx++) {
      for (let dy = -1; dy <= 1; dy++) {
        const tx = tileX + dx
        const ty = tileY + dy
        if (tx < 0 || tx >= map.width || ty < 0 || ty >= map.height) continue
        const t = map.getTile(tx, ty, true)
        if (t == null || t.data == null) continue
        if (t.isDestructed()) continue
        if (t.data.blocksMovement || t.data.blocksProjectiles) return true
      }
    }
    return false
  }

  spawnArea (name, manager) {
    const aeData = DataTables.getAreaEffectByName(name)
    if (aeData != null) {
      const newZone = this.createVolleyAreaEffect(aeData, this.targetX, this.targetY)
      this.currentZone = newZone
      this.currentZoneName = name
      manager.addGameObject(newZone)
      newZone.trigger()
      if (this.ballState === 1) {
        const indicatorData = DataTables.getAreaEffectByName('VolleyBallDistanceIndicator')
        if (indicatorData != null) {
          if (this.currentDistanceIndicator != null) manager.removeGameObject(this.currentDistanceIndicator)
          const indicator = this.createVolleyAreaEffect(indicatorData, this.targetX, this.targetY)
          this.currentDistanceIndicator = indicator
          manager.addGameObject(indicator)
          indicator.trigger()
        }
      }
    }
  }

  checkLanding (battle, manager) {
    if (battle.goalPauseEndTick > 0 && battle.getTicksGone() < battle.goalPauseEndTick) return
    const defendingTeam = this.servingTeam === 0 ? 1 : 0
    const scoringTeam = this.servingTeam
    let defender = null
    for (const c of manager.getCharacters()) {
      const player = c.getPlayer()
      if (!c.isAlive() || !c.characterData.isHero() || player == null) continue
      if (player.teamIndex !== defendingTeam) continue
      const dx = this.targetX - c.getX()
      const dy = this.targetY - c.getY()
      if (dx * dx + dy * dy <= DEFENSE_RADIUS_SQR) {
        defender = c
        break
      }
    }
    if (this.currentDistanceIndicator != null) {
      manager.removeGameObject(this.currentDistanceIndicator)
      this.currentDistanceIndicator = null
    }
    if (defender != null) {
      if (this.currentZone != null) {
        manager.removeGameObject(this.currentZone)
        this.currentZone = null
      }
      this.bounceCount++
      this.moveStartX = this.getX()
      this.moveStartY = this.getY()
      this.moveStartZ = this.getZ()
      this.launchBallToOpponent(defendingTeam, battle, manager)
    } else {
      if (this.currentZone != null) {
        manager.removeGameObject(this.currentZone)
        this.currentZone = null
      }
      battle.addWinInLaserBall(scoringTeam)
      battle.setGoalLaserBall(scoringTeam)
      manager.removeGameObject(this)
      this.isScored = true
      this.indicatorSpawned = false
    }
  }

  spawnHitEffect (manager) {
    const hitData = DataTables.getAreaEffectByName('VolleyBallHit')
    if (hitData != null) {
      const hitEff = this.createVolleyAreaEffect(hitData, this.getX(), this.getY())
      manager.addGameObject(hitEff)
      hitEff.trigger()
    }
  }

  resetBallToCenter () {
    if (this.currentDistanceIndicator != null) {
      this.gameObjectManager.getBattle().getGameObjectManager().removeGameObject(this.currentDistanceIndicator)
      this.currentDistanceIndicator = null
    }
    this.ballState = 0
    this.setPosition(CENTER_X, CENTER_Y, 0)
    if (this.currentZone != null) {
      this.gameObjectManager.removeGameObject(this.currentZone)
      this.currentZone = null
    }
  }

  tick () {
    const battle = this.gameObjectManager != null ? this.gameObjectManager.getBattle() : null
    const isHero = this.characterData.isHero()
    const gameModeVariation = battle != null ? battle.getGameModeVariation() : -1
    const goalPause = isHero && battle != null && (gameModeVariation === 5 || gameModeVariation === 23) && battle.goalTicks > 0
    const knockoutRoundPause = isHero && battle != null && gameModeVariation === 20 && battle.isRoundEnding
    const transitionPause = goalPause || knockoutRoundPause
    if (this.pushbackImmunTicks > 0) this.pushbackImmunTicks--
    if (this.pendingArcBombs != null) this.tickArcBombs()
    if (this.yellowEyeTicks > 0) {
      this.yellowEyeTicks--
      if (this.yellowEyeTicks === 0) this.yellowEye = false
    }
    if (this.isAlive()) {
      if (!this.stopAI) this.tickTimers()
      this.tickStarPowers()
      this.executeBlink()
      this.pushOutOfWalls()
      this.tickSkills()
      if (this.isRapidFireHeld) {
        const weaponSkill = this.getWeaponSkill()
        if (weaponSkill != null && weaponSkill.skillData.buttonExportName === 'rapid_fire_button') {
          if (!weaponSkill.isActive && weaponSkill.coolDown <= 0) this.activateSkill(0, this.rapidFireRepeatX, this.rapidFireRepeatY)
          if (this.ticksGone - this.rapidFireRepeatTick > 2) this.isRapidFireHeld = false
        } else {
          this.isRapidFireHeld = false
        }
      }
      this.tickInvisibility()
      if (isHero) this.tickHeals()
      if (transitionPause) this.stopMovement()
      if (!this.stopAI && !transitionPause) this.handleMoveAndAttack()
      this.tickEffects()
      this.tickFrozen()
      this.tickAutoUltiCharge()
      this.tickTile()
      this.immunToPushbackOutOfWalls = ((this.activeChargeType === 8 || this.activeChargeType === 99 || this.activeChargeType === 105) && this.isChargeActive()) || this.pushbackImmunTicks > 0
      if (this.ticksGone > Character.INTRO_TICKS && !this.stopAI && !transitionPause) this.tickAI()
      this.afkTicks++
      if (this.areaEffect != null) {
        this.areaEffect.setPosition(this.getX(), this.getY(), 0)
      }
    }
    this.tickTimedTransform()
    if (this.hitpoints <= 0) this.gameObjectManager.removeGameObject(this)
    if (this.characterData.isCarryable()) {
      switch (this.characterData.name) {
        case 'LaserBall':
        case 'HoldingBall':
        case 'BasketBall':
          this.tickLaserBallMove()
          break
      }
    }
    if (this.characterData.name === 'VolleyBall') this.tickVolleyBall()
    if (this.afkTicks > 380 && battle != null && gameModeVariation !== 13) {
      const player = battle.getPlayer(this.getGlobalID())
      if (player == null) return
      if (player.isBot() !== 0) return
      if (!isHero) return
      this.afkTicks = 0
      if (player.gameListener != null) {
        const DisconnectedMessage = require('../../../Protocol/Messages/Server/DisconnectedMessage')
        const message = new DisconnectedMessage()
        message.reason = 2
        player.gameListener.sendTCPMessage(message)
      }
      battle.removePlayer(player)
      this.setBot(2)
    }
  }

  isBrawlBallBlockedAt (x, y) {
    const map = this.getBattle().getTileMap()
    if (x < 0 || y < 0 || x >= map.logicWidth || y >= map.logicHeight) return true
    const tile = map.getTile(Math.trunc(x / 300), Math.trunc(y / 300), true)
    return tile == null || (tile.data != null && tile.data.blocksMovement && !tile.isDestructed())
  }

  tryRegisterBrawlBallGoal (x, y) {
    const battle = this.getBattle()
    const map = battle.getTileMap()
    const centerX = Math.trunc(map.logicWidth / 2)
    const goalHalfWidth = Math.min(1050, Math.trunc(map.logicWidth / 6))
    if (Math.abs(x - centerX) > goalHalfWidth) return false
    if (y < 1150) {
      if (battle.carryable.lastPickupPlayerIndex !== 0) {
        this.stopKicking()
        this.setPosition(x, 1300, 0)
        return true
      }
      battle.registerBrawlBallGoal(this.lastPickupPlayerIndexTOCHNO, 0)
      return true
    }
    if (y > map.logicHeight - 1150) {
      if (battle.carryable.lastPickupPlayerIndex !== 1) {
        this.stopKicking()
        this.setPosition(x, map.logicHeight - 1300, 0)
        return true
      }
      battle.registerBrawlBallGoal(this.lastPickupPlayerIndexTOCHNO, 1)
      return true
    }
    return false
  }

  tryRegisterBasketBrawlGoal (x, y) {
    const battle = this.getBattle()
    if (battle == null || battle.carryable !== this || battle.getGameModeVariation() !== 22) return false
    const map = battle.getTileMap()
    const centerY = Math.trunc(map.logicHeight / 2)
    const goalHalfHeight = 500
    if (Math.abs(y - centerY) > goalHalfHeight) return false
    const leftGoal = x < 500
    const rightGoal = x > map.logicWidth - 500
    if (!leftGoal && !rightGoal) return false
    if ((leftGoal && this.kickDirection.x >= 0) || (rightGoal && this.kickDirection.x <= 0)) return false
    const scoringTeam = leftGoal ? 1 : 0
    if (battle.toGoalTeam !== -1 || battle._setStopTicks) return true
    if (battle.carryable.lastPickupPlayerIndex !== scoringTeam || this.lastPickupPlayerIndexTOCHNO < 0) {
      this.stopKicking()
      this.setPosition(leftGoal ? 1300 : map.logicWidth - 1300, centerY, 0)
      this.carryablePickTicks = 3
      return true
    }
    const dx = this.kickStartX - (leftGoal ? 300 : map.logicWidth - 300)
    const dy = this.kickStartY - centerY
    const points = dx * dx + dy * dy >= 3000 * 3000 ? 3 : 2
    battle.registerBasketBrawlGoal(this.lastPickupPlayerIndexTOCHNO, scoringTeam, points)
    return true
  }

  tickBrawlBallPhysics () {
    const battle = this.getBattle()
    if (battle == null || battle.carryable !== this || !this.isAlive()) return
    if (battle.getGameModeVariation() === 22 && battle.goalTicks > 0) {
      this.stopKicking()
      this.z = 0
      return
    }
    if (this.carringCharacter != null && !this.carringCharacter.isAlive()) this.carringCharacter = null
    if (this.carringCharacter != null || !this.isKicked) {
      this.z = 0
      return
    }
    const progress = this.totalKickDistance > 0 ? Math.min(Math.max(f32(this.distanceTraveled / this.totalKickDistance), 0), 1) : 1
    this.z = Math.trunc(Math.sin(progress * Math.PI) * 250)
    const slowdown = Math.min(Math.max(f32(f32(progress - f32(0.2)) / f32(0.8)), 0), 1)
    this.currentKickSpeed = Math.max(350, Math.trunc(f32(this.maxKickSpeed * f32(1 - f32(slowdown * f32(0.7))))))
    const dx = Math.trunc(Math.trunc((this.kickDirection.x * this.currentKickSpeed) / 1024) / 20)
    const dy = Math.trunc(Math.trunc((this.kickDirection.y * this.currentKickSpeed) / 1024) / 20)
    if (dx === 0 && dy === 0) {
      this.stopKicking()
      this.z = 0
      return
    }
    const parts = Math.max(1, Math.trunc((Math.max(Math.abs(dx), Math.abs(dy)) + 39) / 40))
    const startX = this.getX()
    const startY = this.getY()
    let x = startX
    let y = startY
    for (let part = 1; part <= parts; part++) {
      const nextX = startX + Math.trunc(dx * part / parts)
      const nextY = startY + Math.trunc(dy * part / parts)
      if (battle.getGameModeVariation() === 22) {
        if (this.tryRegisterBasketBrawlGoal(nextX, nextY)) return
      } else if (battle.getGameModeVariation() === 5 && this.tryRegisterBrawlBallGoal(nextX, nextY)) {
        return
      }
      if (!this.isBrawlBallBlockedAt(nextX, nextY)) {
        x = nextX
        y = nextY
        continue
      }
      const xBlocked = this.isBrawlBallBlockedAt(nextX, y)
      const yBlocked = this.isBrawlBallBlockedAt(x, nextY)
      const normal = new LogicVector2(0, 0)
      if (xBlocked) normal.x = -sign(dx) * 1024
      if (yBlocked) normal.y = -sign(dy) * 1024
      if (normal.x === 0 && normal.y === 0) {
        if (Math.abs(dx) >= Math.abs(dy)) normal.x = -sign(dx) * 1024
        else normal.y = -sign(dy) * 1024
      }
      this.bounce(normal)
      break
    }
    this.setPosition(x, y, this.z)
    this.distanceTraveled += Math.trunc(Math.sqrt((x - startX) * (x - startX) + (y - startY) * (y - startY)))
    if (this.distanceTraveled >= this.totalKickDistance || this.currentKickSpeed <= 350) {
      this.stopKicking()
      this.z = 0
    }
  }

  tickLaserBallMove () {
    const battle = this.getBattle()
    const variation = battle != null ? battle.getGameModeVariation() : -1
    if (variation === 5 || variation === 21 || variation === 22) {
      this.tickBrawlBallPhysics()
      return
    }
    if (battle == null) {
      this.stopKicking()
      return
    }
    if (battle.goalTicks > 0) return
    if (this.getY() < 1150) {
      if (battle.carryable != null && battle.carryable.lastPickupPlayerIndex === 1) {
        this.stopKicking()
        this.triggerBlink(this.getX(), 1300, null, null, 0, 0)
        if (battle.carryable.carringCharacter != null) battle.carryable.carringCharacter.carryablePersonImunTicks = 20
        battle.carryable.carringCharacter = null
        return
      }
      this.carringCharacter = null
      this.stopKicking()
      battle.addWinInLaserBall(this.lastPickupPlayerIndexTOCHNO)
      battle.resetCarryable()
      battle.setGoalLaserBall(0)
      return
    }
    if (this.getY() > 8850) {
      if (battle.carryable != null && battle.carryable.lastPickupPlayerIndex === 0) {
        this.stopKicking()
        this.triggerBlink(this.getX(), 8700, null, null, 0, 0)
        if (battle.carryable.carringCharacter != null) battle.carryable.carringCharacter.carryablePersonImunTicks = 20
        battle.carryable.carringCharacter = null
        return
      }
      this.carringCharacter = null
      this.stopKicking()
      battle.addWinInLaserBall(this.lastPickupPlayerIndexTOCHNO)
      battle.resetCarryable()
      battle.setGoalLaserBall(1)
      return
    }
    if (this.carringCharacter != null && !this.carringCharacter.isAlive()) this.carringCharacter = null
    if (!this.isKicked) {
      this.z = 0
      return
    }
    let newZ = 1
    if (this.totalKickDistance > 0) {
      const progress = f32(this.distanceTraveled / this.totalKickDistance)
      if (progress <= f32(0.1)) {
        const normalizedProgress = f32(progress / f32(0.1))
        const smoothProgress = normalizedProgress < 0.5
          ? f32(2 * normalizedProgress * normalizedProgress)
          : f32(1 - f32(2 * f32(1 - normalizedProgress) * f32(1 - normalizedProgress)))
        newZ = Math.trunc(f32(smoothProgress * 250))
      } else if (progress <= f32(0.4)) {
        const normalizedProgress = f32(f32(progress - f32(0.1)) / f32(0.3))
        const smoothProgress = normalizedProgress < 0.5
          ? f32(2 * normalizedProgress * normalizedProgress)
          : f32(1 - f32(2 * f32(1 - normalizedProgress) * f32(1 - normalizedProgress)))
        newZ = Math.trunc(f32(250 - f32(smoothProgress * 249)))
      } else {
        newZ = 1
      }
    }
    this.z = newZ
    if (this.totalKickDistance > 0) {
      const progress = f32(this.distanceTraveled / this.totalKickDistance)
      if (progress >= 0.25) {
        const normalizedProgress = f32(f32(progress - 0.25) / f32(0.95))
        const minSpeedMultiplier = 0.25
        this.currentKickSpeed = Math.trunc(f32(this.maxKickSpeed * f32(1 - f32(normalizedProgress * (1 - minSpeedMultiplier)))))
      } else {
        this.currentKickSpeed = this.maxKickSpeed
      }
    }
    const deltaX = Math.trunc(Math.trunc((this.kickDirection.x * this.currentKickSpeed) / 1024) / 20)
    const deltaY = Math.trunc(Math.trunc((this.kickDirection.y * this.currentKickSpeed) / 1024) / 20)
    if (Math.abs(deltaX) < 1 && Math.abs(deltaY) < 1) {
      this.stopKicking()
      return
    }
    let newX = this.getX() + deltaX
    let newY = this.getY() + deltaY
    let collisionNormal = null
    const borderCollision = new LogicVector2(newX, newY)
    const hasBorderCollision = GamePlayUtil.getClosestLevelBorderCollision(this.getX(), this.getY(), newX, newY, battle.getTileMap(), 1, borderCollision)
    if (hasBorderCollision) {
      collisionNormal = this.calculateBorderNormal(this.getX(), this.getY(), borderCollision.x, borderCollision.y)
      newX = borderCollision.x
      newY = borderCollision.y
    } else {
      collisionNormal = this.checkTileCollision(this.getX(), this.getY(), newX, newY)
    }
    if (collisionNormal != null) {
      this.bounce(collisionNormal)
      newX = this.getX() + Math.trunc((collisionNormal.x * 50) / 1024)
      newY = this.getY() + Math.trunc((collisionNormal.y * 50) / 1024)
    }
    const tileMap = battle.getTileMap()
    const borderRight = tileMap.logicWidth
    const borderBottom = tileMap.logicHeight
    newX = Math.max(0, Math.min(borderRight, newX))
    newY = Math.max(0, Math.min(borderBottom, newY))
    this.setPosition(newX, newY, this.getZ())
    const distanceThisTick = Math.trunc(Math.sqrt(deltaX * deltaX + deltaY * deltaY))
    this.distanceTraveled += distanceThisTick
    if (this.distanceTraveled >= this.totalKickDistance) {
      this.stopKicking()
    }
  }

  kick (angle, speed, totalDistance) {
    if (this.isKicked) return
    this.isKicked = true
    this.maxKickSpeed = speed
    this.currentKickSpeed = speed
    this.kickDirection = new LogicVector2(LogicMath.cos(angle), LogicMath.sin(angle))
    this.kickStartX = this.getX()
    this.kickStartY = this.getY()
    this.distanceTraveled = 0
    this.bounceCount = 0
    this.totalKickDistance = totalDistance
    if (this.kickDirection.x === 0 && this.kickDirection.y === 0) {
      this.stopKicking()
    }
  }

  stopKicking () {
    this.isKicked = false
    this.currentKickSpeed = 0
    this.distanceTraveled = 0
  }

  bounce (normal) {
    if (this.kickDirection == null) return
    if (this.bounceCount >= MAX_BOUNCES) {
      this.stopKicking()
      return
    }
    this.bounceCount++
    this.currentKickSpeed = Math.trunc(f32(this.currentKickSpeed * f32(0.7)))
    const remainingDistance = this.totalKickDistance - this.distanceTraveled
    this.totalKickDistance = this.distanceTraveled + Math.trunc(f32(remainingDistance * f32(0.8)))
    const dotProduct = Math.trunc((this.kickDirection.x * normal.x + this.kickDirection.y * normal.y) / 1024)
    const reflectX = this.kickDirection.x - Math.trunc(2 * dotProduct * normal.x / 1024)
    const reflectY = this.kickDirection.y - Math.trunc(2 * dotProduct * normal.y / 1024)
    const length = Math.trunc(Math.sqrt(reflectX * reflectX + reflectY * reflectY))
    if (length > 0) {
      this.kickDirection.x = Math.trunc((reflectX * 1024) / length)
      this.kickDirection.y = Math.trunc((reflectY * 1024) / length)
    }
    this.maxKickSpeed = this.currentKickSpeed
  }

  calculateBorderNormal (startX, startY, collisionX, collisionY) {
    const normal = new LogicVector2(0, 0)
    const tileMap = this.getBattle().getTileMap()
    const borderRight = tileMap.logicWidth
    const borderBottom = tileMap.logicHeight
    if (collisionX <= 10) {
      normal.x = 1
    } else if (collisionX >= borderRight - 10) {
      normal.x = -1
    }
    if (collisionY <= 10) {
      normal.y = 1
    } else if (collisionY >= borderBottom - 10) {
      normal.y = -1
    }
    if (normal.x === 0 && normal.y === 0) {
      const dx = collisionX - startX
      const dy = collisionY - startY
      if (Math.abs(dx) > Math.abs(dy)) {
        normal.x = -sign(dx)
      } else {
        normal.y = -sign(dy)
      }
    }
    const length = Math.trunc(Math.sqrt(normal.x * normal.x + normal.y * normal.y))
    if (length > 0) {
      normal.x = Math.trunc((normal.x * 1024) / length)
      normal.y = Math.trunc((normal.y * 1024) / length)
    }
    return normal
  }

  setSilence (ticks) {
    this.silence = true
    this.silenceTick = this.ticksGone + ticks
  }

  addFrozen (count, attacker = null) {
    if (this.frozenPercentage >= 100) return
    if (this.stunTicks <= this.ticksGone) this.frozenPercentage += count
    this.lastFrozenTick = this.ticksGone
    this.frozenDecayTick = this.ticksGone
    if (attacker != null && attacker.getCardValueForPassive('slippery_to_frost', 1) !== -1) {
      this.slipperyTicks = Math.max(this.slipperyTicks, attacker.getCardValueForPassive('slippery_to_frost', 1))
    }
    if (this.frozenPercentage >= 100 && attacker != null && attacker.getCardValueForPassive('freeze_reload', 1) !== -1) {
      attacker.giveReloadBuff(attacker.getCardValueForPassive('freeze_reload', 1))
    }
  }

  tickFrozen () {
    if (this.frozenPercentage >= 100) {
      this.triggerStun(20, true)
      if (this.getBattle().getTicksGone() >= this.lastFrozenTick + 20) this.frozenPercentage = 0
    }
    if (this.slipperyTicks > 0) {
      this.slipperyTicks--
    }
    this.slippery = this.slipperyTicks > 0
    if (this.lastFrozenTick + 29 < this.ticksGone && this.frozenPercentage > 0) {
      if (this.ticksGone - this.frozenDecayTick >= 6) {
        this.frozenPercentage--
        this.frozenDecayTick = this.ticksGone
      }
    }
  }

  resetAFKTicks () {
    this.afkTicks = 0
  }

  setImmunity (targetIndex, ticks, targetData) {
    this.immunitys.push(new Immunity(targetIndex, targetData, ticks))
  }

  hasBuff (type) {
    for (const buff of this.buffs) {
      if (buff.type === type) return true
    }
    return false
  }

  getBuff (type) {
    for (const buff of this.buffs) {
      if (buff.type === type) return buff
    }
    return null
  }

  getBuffedSpeed () {
    let v1 = 0
    for (const buff of this.buffs) {
      if (buff.type <= 6 && ((1 << buff.type) & 88) !== 0) v1 += buff.modifier
    }
    return v1
  }

  getUnbuffedSpeed () {
    let v1 = 0
    v1 += this.staticSpeedBuff
    if (this.characterData.hasPowerLevels && this.getPowerLevel() > 0) v1 += 170
    if (this.characterData.uniqueProperty === 1) v1 += 60 * this.getPowerLevel()
    if (this.getBattle().hasEventModifier(14)) v1 += 350
    const player = this.getPlayer()
    if (player != null && player.overCharging) {
      if (this.characterData.overchargeSpeedPercent > 0) {
        v1 += Math.trunc(this.characterData.overchargeSpeedPercent * this.characterData.speed / 100)
      } else {
        v1 += Math.trunc(20 * this.characterData.speed / 100)
      }
    }
    return v1
  }

  tickEffects () {
    const immunitysToRemove = []
    for (const immunity of this.immunitys) {
      if (immunity.tick(50)) immunitysToRemove.push(immunity)
    }
    for (const immunity of immunitysToRemove) {
      const index = this.immunitys.indexOf(immunity)
      if (index !== -1) this.immunitys.splice(index, 1)
    }
    const poisonsToRemove = []
    for (const poison of this.poisons.slice()) {
      if (poison.tick(this)) poisonsToRemove.push(poison)
    }
    for (const poison of poisonsToRemove) {
      const index = this.poisons.indexOf(poison)
      if (index !== -1) this.poisons.splice(index, 1)
    }
    const buffsToRemove = []
    for (const buff of this.buffs.slice()) {
      if (buff.tick(this)) buffsToRemove.push(buff)
    }
    for (const buff of buffsToRemove) {
      const index = this.buffs.indexOf(buff)
      if (index !== -1) this.buffs.splice(index, 1)
    }
  }

  tickTimers () {
    const battle = this.getBattle()
    const player = this.getPlayer()
    const ticksGone = this.ticksGone
    if (player != null && battle.getGameModeVariation() === 13 && player.damageHistory != null) {
      for (let i = player.damageHistory.length - 1; i >= 0; i--) {
        if (player.damageHistory[i].tick + 20 < ticksGone) player.damageHistory.splice(i, 1)
      }
    }
    if (this.attachedCharacter != null) this.setPosition(this.attachedCharacter.getX(), this.attachedCharacter.getY(), 0)
    if (this.silence && this.silenceTick < ticksGone) this.silence = false
    if (this.characterData.uniqueProperty === 1 && ticksGone - this.ashLastRageTick >= 21) this.chargeUp = LogicMath.max(0, this.chargeUp - 3)
    if (this.realmTimer >= 1) this.realmTimer--
    if (this.realmTimer === 0) this.isInRealm = false
    if (this.rapidFireTick !== ticksGone) this.attackingTicks = 63
    if (this.lastTagTick <= ticksGone) this.tagged = false
    this.isCrippled = ticksGone < this.crippleEndTick
    if (!this.isCrippled) this.cripplePercent = 0
    if (this.visionOverrideTicks >= 1) this.visionOverrideTicks--
    if (this.shieldTicks >= 1) this.shieldTicks--
    if (this.ccImmunityTicks >= 1) this.ccImmunityTicks--
    if (this.shaking >= 1) this.shaking--
    if (this.reloadBuffTicks >= 1) this.reloadBuffTicks--
    if (this.skillHoldTicks >= 0) this.skillHoldTicks++
    const gameModeVariation = battle.getGameModeVariation()
    this.isInvincible = ticksGone <= this.spawnTick + 60 && gameModeVariation !== 5 && gameModeVariation !== 23
    if (this.carryablePickTicks > 0) this.carryablePickTicks--
    if (this.carryablePersonImunTicks > 0) this.carryablePersonImunTicks--
    if (battle.carryable != null && battle.carryable.carringCharacter === this) this.setFadeCounter(10)
    if (this.chargeUpMax > 0 && this.characterData.name === 'Ghost') {
      this.immunToPushbackOutOfWalls = true
      this.chargeUp--
    }
    const weaponSkill = this.skills[0]
    const weaponFull = weaponSkill != null && weaponSkill.hasFullCharge()
    if (this.chargeUpType === 2 || this.chargeUpType === 6 || (this.chargeUpType === 1 && (weaponFull || this.characterData.name === 'CannonGirlSmall'))) {
      if (this.state !== 4) this.chargeUp = LogicMath.min(this.chargeUp + 50, this.chargeUpMax)
    } else if (this.chargeUpType === 10) {
      if (this.state === 1 || this.state === 3) this.chargeUp = 0
      else if (this.state !== 4) this.chargeUp = LogicMath.min(this.chargeUp + 50, this.chargeUpMax)
    }
    if (this.getCardValueForPassive('longer_dash', 1) >= 0 && !this.longerDashGaugeReady) {
      let longerDashChargeTimeMs = this.getCardValueForPassive('longer_dash', 2)
      if (longerDashChargeTimeMs <= 0) longerDashChargeTimeMs = 2500
      const longerDashChargeTime = Math.trunc(longerDashChargeTimeMs / 50)
      if (weaponFull && this.state !== 4) {
        if (this.longerDashGaugeTimer <= 0) this.longerDashGaugeTimer = longerDashChargeTime
        this.longerDashGaugeTimer--
        if (this.longerDashGaugeTimer <= 0) this.longerDashGaugeReady = true
      } else if (!weaponFull) {
        this.longerDashGaugeTimer = 0
      }
    }
    if (this.consumableShield >= 1 && ticksGone > this.consumableShieldTick) {
      const period = LogicMath.max(1, Math.trunc(this.consumableShieldDuration / 20))
      if ((ticksGone - this.consumableShieldTick) % period === 0) {
        this.consumableShield = LogicMath.max(0, this.consumableShield - Math.trunc(this.consumableShieldMax / 20))
      }
    }
    if (this.chargeUpType === 7 && this.state !== 4) {
      const ultimateSkill = this.getUltimateSkill()
      if (ultimateSkill != null && ultimateSkill.skillData.chargeType === 15) {
        this.chargeUp = ultimateSkill.ticksActive
        return
      }
      if (player != null) {
        const accessory = player.accessory
        if (accessory != null && accessory.accessoryData.showCountdown && accessory.isActive) {
          this.chargeUp = this.chargeUpMax - 50 * accessory.ticksActive
          return
        }
        this.chargeUp = 0
      }
    }
  }

  setCharacterTagged (a1, a2, a3) {
    this.tagged = true
    if (a3 != null && a3.getCardValueForPassive('tag_lasts_longer', 1) >= 1) {
      this.lastTagTick = a2 + (4 + a3.getCardValueForPassive('tag_lasts_longer', 1)) * 20
      return
    }
    this.lastTagTick = a2 + 4 * 20
  }

  giveSpeedSlowerBuff (a2, a3) {
    this.applyBuff(3, a3, a2, 0)
  }

  giveElectrocution (damage, normalDMG, effectType, bounces) {
    for (let i = 0; i < this.buffs.length; i++) {
      if (this.buffs[i].type === 14) {
        this.buffs.splice(i, 1)
        i--
      }
    }
    const b = this.applyBuff(14, 20, damage, 0)
    b.effectType = effectType
    b.normalDMG = normalDMG
    b.belleWeaponBounces = bounces
  }

  giveSpeedFasterBuff (a2, a3, a4) {
    if (a4) {
      if (this.buffs.length < 1) {
        this.int344 = 10
        this.dword348 = 0
      } else {
        for (const buff of this.buffs) {
          if (buff.type === 4) {
            this.applyBuff(4, a3, a2, 0)
            return
          }
        }
        this.int344 = 10
        this.dword348 = 0
      }
    }
    this.applyBuff(4, a3, a2, 0)
  }

  giveDamageBuff (a2, a3) {
    this.applyBuff(1, a3, a2, 1)
    this.int344 = 10
    this.dword348 = 2
  }

  giveDamageBuff2 (a2, a3) {
    if (this.buffs.length < 1) {
      this.int344 = 10
      this.dword348 = 2
    } else {
      for (const buff of this.buffs) {
        if (buff.type === 5) {
          this.applyBuff(5, a3, a2, 1)
          return
        }
      }
      this.int344 = 10
      this.dword348 = 2
    }
    this.applyBuff(5, a3, a2, 1)
  }

  eyeActive () {
    if (this.yellowEye) return
    this.yellowEye = true
    this.yellowEyeTicks = 160
  }

  tickGears () {
    if (this.gear1 != null) this.gear1.tick(this)
    if (this.gear2 != null) this.gear2.tick(this)
  }

  triggerBlink (x, y, areaEffectData1, areaEffectData2, damage, normalDMG) {
    this.isTeleporting = true
    if (areaEffectData1 != null) {
      const AreaEffect = getAreaEffectClass()
      const areaEffect = new AreaEffect(areaEffectData1)
      areaEffect.setPosition(x, y, 0)
      areaEffect.setIndex(this.getIndex())
      areaEffect.damage = damage
      areaEffect.normalDMG = normalDMG
      this.gameObjectManager.addGameObject(areaEffect)
      areaEffect.trigger()
    }
    if (areaEffectData2 != null) {
      const AreaEffect = getAreaEffectClass()
      const areaEffect2 = new AreaEffect(areaEffectData2)
      areaEffect2.setPosition(this.getX(), this.getY(), 0)
      areaEffect2.setIndex(this.getIndex())
      this.gameObjectManager.addGameObject(areaEffect2)
      areaEffect2.trigger()
    }
    this.moveStart = this.ticksGone - 1
    this.moveEnd = this.ticksGone - 1
    this.blinkX = x
    this.blinkY = y
  }

  resetEventsOnTick () {
    this.isTeleporting = false
    this.hitEffectProjectile = 0
    this.hitEffectSkin = 0
    const toRemove = []
    for (const damageNumber of this.damageNumbers) {
      if (damageNumber.delay <= 0) {
        toRemove.push(damageNumber)
      } else {
        damageNumber.delay--
      }
    }
    for (const damageNumber of toRemove) {
      const index = this.damageNumbers.indexOf(damageNumber)
      if (index !== -1) this.damageNumbers.splice(index, 1)
    }
  }

  applyBuff (type, dura, modi, sizeInc, index = -1) {
    for (const buff of this.buffs) {
      if (buff.type === type && !buff.canStack()) {
        let v14 = buff.duration < dura
        if (buff.duration >= dura) v14 = LogicMath.abs(buff.modifier) < LogicMath.abs(modi)
        if (v14) {
          buff.modifier = modi
          buff.sizeIncrease = sizeInc
          buff.duration = dura
          if (index !== -1) buff.sourceIndex = index
        }
        return buff
      }
    }
    const buff = new Buff(type, dura, modi, sizeInc)
    buff.sourceIndex = index
    this.buffs.push(buff)
    return buff
  }

  executeBlink () {
    if (this.blinkX !== -1) {
      this.moveStart = this.ticksGone - 1
      this.moveEnd = this.ticksGone - 1
      this.setPosition(this.blinkX, this.blinkY, this.characterData.flyingHeight)
      this.isTeleporting = true
      this.blinkX = -1
    }
  }

  tickStarPowers () {
    if (this.getPlayer() == null) return
    if (this.getCardValueForPassive('shield_while_ulti', 1) >= 1) {
      if (this.getControlledProjectile() != null) this.addShield(2, this.getCardValueForPassive('shield_while_ulti', 1))
      return
    }
    if (this.getCardValueForPassive('bush_shield', 1) >= 1) {
      if (this.isInBush()) this.addShield(this.getCardValueForPassive('bush_shield', 0), this.getCardValueForPassive('bush_shield', 1))
      return
    }
    if (this.getCardValueForPassive('speed_full_ammo', 1) >= 1) {
      if (this.chargeUp >= this.chargeUpMax || this.meleeAttackPushBacks) this.giveSpeedFasterBuff(this.getCardValueForPassive('speed_full_ammo', 1), 10, true)
      return
    }
    if (this.getCardValueForPassive('speed_low_health', 0) >= 1) {
      if (this.getHitpointPercentage() <= this.getCardValueForPassive('speed_low_health', 0)) this.giveSpeedFasterBuff(this.getCardValueForPassive('speed_low_health', 1), 10, true)
      return
    }
    if (this.getCardValueForPassive('berserker', 1) >= 1) {
      if (this.getHitpointPercentage() <= this.getCardValueForPassive('berserker', 1)) this.giveReloadBuff(10)
      return
    }
    if (this.getCardValueForPassive('low_health_shield', 1) >= 1) {
      if (this.getHitpointPercentage() <= this.getCardValueForPassive('low_health_shield', 1)) this.addShield(4, this.getCardValueForPassive('low_health_shield', 0))
      return
    }
    if (this.getCardValueForPassive('shield_homerun', 1) >= 1) {
      if (this.chargeUp >= this.chargeUpMax || this.meleeAttackPushBacks) this.addShield(4, this.getCardValueForPassive('shield_homerun', 1))
      return
    }
    if (this.getCardValueForPassive('shield_while_charged_shots', 1) >= 1) {
      if (this.chargedShotCount >= 1) this.addShield(4, this.getCardValueForPassive('shield_while_charged_shots', 1))
      return
    }
    if (this.getCardValueForPassive('shield_while_charged_up', 1) >= 1) {
      if (this.chargeUp >= this.chargeUpMax) this.addShield(4, this.getCardValueForPassive('shield_while_charged_up', 1))
    }
    if (this.getCardValueForPassive('charged_bullet_speed', 1) >= 1) {
      if (this.chargeUp >= this.chargeUpMax) this.attackAcceleratingFactor = this.getCardValueForPassive('charged_bullet_speed', 1) * 2
      else this.attackAcceleratingFactor = 0
    }
    if (this.getCardValueForPassive('speed_ulti', 1) >= 1) {
      if (this.hasUlti()) this.giveSpeedFasterBuff(this.getCardValueForPassive('speed_ulti', 1), 10, true)
      return
    }
    if (this.getCardValueForPassive('medikit', 1) >= 1) {
      if (this.getHitpointPercentage() <= this.getCardValueForPassive('medikit', 1) && this.chargeUp >= this.chargeUpMax) {
        const v890 = this.getCardValueForPassive('medikit', 0)
        this.heal(this.getIndex(), v890, true, this.characterData)
        this.chargeUp = 0
      }
      return
    }
    const v51 = this.getPlayer()
    if (v51 != null) {
      let v52 = v51.getCardValueForPassive('plugged_in', 1)
      if (v52 >= 1 && !this.characterData.isHero()) {
        this.starPowerProjectileTimer--
        if (this.starPowerProjectileTimer <= 0) {
          const v55 = this.gameObjectManager.getGameObjectByID(this.parentGID)
          const v56 = v51.getCardValueForPassive('plugged_in', 2)
          if (v55 != null && v55.getObjectType() === 0 && v55.isAlive()) {
            const v57 = 300 * v51.getCardValueForPassive('plugged_in', 0)
            if (GamePlayUtil.getDistanceSquaredBetween(this.getX(), this.getY(), v55.getX(), v55.getY()) < v57 * v57) {
              const projectileData = DataTables.getProjectileByName('ArcadeStarPowerProjectile')
              const v66 = projectileData == null
                ? null
                : getProjectileClass().shootProjectile(-1, -1, this, this, projectileData, v55.getX(), v55.getY(), 0, 0, 0, false, 0, this.getBattle(), 0, 3)
              if (v66 != null) {
                v66.homingTarget = v55
                v66.setIndex(this.getIndex())
                v66.speedBuffModifier = v52
                v66.speedBuffLength = 2 * v56
              }
            }
          }
          this.starPowerProjectileTimer = v56
        }
      }
      v52 = v51.getCardValueForPassive('ulti_item_repeated_area', 1)
      if (v52 >= 1) {
        this.starPowerProjectileTimer--
        if (this.starPowerProjectileTimer <= 0) {
          let v55 = null
          for (const gameObject of this.gameObjectManager.getGameObjects()) {
            if (gameObject.getObjectType() !== 3) continue
            if (gameObject.getIndex() !== this.getIndex()) continue
            v55 = gameObject
            break
          }
          if (v55 != null) {
            const areaEffect = GameObjectFactory.createGameObjectByData(DataTables.getAreaEffectByName('WeaponThrowerElectroArea'))
            if (areaEffect != null) {
              areaEffect.setPosition(v55.getX(), v55.getY(), 0)
              areaEffect.setIndex(this.getIndex())
              areaEffect.setSource(this, 3)
              areaEffect.damage = this.getCardValueForPassive('ulti_item_repeated_area', 1)
              areaEffect.normalDMG = 0
              this.gameObjectManager.addGameObject(areaEffect)
              areaEffect.trigger()
            }
            this.starPowerProjectileTimer = this.getCardValueForPassive('ulti_item_repeated_area', 0)
          }
        }
      }
    }
  }

  tickTile () {
    const tileMap = this.gameObjectManager.getBattle().getTileMap()
    const tile = tileMap.getTile(this.getX(), this.getY())
    if (tile == null || tile.data == null) return
    if ((tile.data.hidesHero && !tile.isDestructed()) || this.isInvisible) {
      this.decrementFadeCounter()
    } else {
      this.incrementFadeCounter()
    }
    const tx = TileMap.logicToTile(this.getX())
    const ty = TileMap.logicToTile(this.getY())
    const ticksGone = this.ticksGone
    if (ticksGone - this.lastTileDamageTick > 20) {
      if (this.gameObjectManager.getBattle().isTileOnPoisonArea(tx, ty)) {
        this.lastTileDamageTick = ticksGone
        this.causeDamage(null, 1000, 0, false, null)
      }
      const tileDamage = tile.data.damage | 0
      if (!tile.isDestructed() && tileDamage > 0) {
        this.lastTileDamageTick = ticksGone
        this.causeDamage(null, tileDamage, 0, false, null)
      }
    }
    if (ticksGone - this.lastTileHealTick > 25 && tileMap.isOnHealTile(this.getX(), this.getY())) {
      this.lastTileHealTick = ticksGone
      this.heal(-1, 200, true, null)
    }
    const speedChange = tile.data.speedChange | 0
    if (!tile.isDestructed() && speedChange !== 0 && ticksGone - this.lastSpeedTileTick > 5) {
      this.lastSpeedTileTick = ticksGone
      if (speedChange > 0) this.applyBuff(4, 8, Math.trunc(speedChange / 10), 0)
      else this.applyBuff(3, 8, Math.trunc(speedChange / 10), 0)
    }
  }

  isInBush () {
    const tileMap = this.gameObjectManager.getBattle().getTileMap()
    const tile = tileMap.getTile(this.getX(), this.getY())
    return tile != null && tile.data != null && tile.data.hidesHero && !tile.isDestructed()
  }

  isInWater () {
    const tileMap = this.gameObjectManager.getBattle().getTileMap()
    const tile = tileMap.getTile(this.getX(), this.getY())
    return tile != null && tile.code === 'W' && !tile.isDestructed()
  }

  showDamageNumber (a2, a3, a4) {
    let v7 = false
    if (a4 != null) {
      const weaponSkill = a4.getWeaponSkill()
      const v8 = weaponSkill == null ? null : weaponSkill.skillData
      if (v8 != null) v7 = v8.numBulletsInOneAttack > 1
    }
    const delay = v7 ? Character.DAMAGE_NUMBERS_DELAY_TICKS : 0
    for (const damageNumber of this.damageNumbers) {
      if (damageNumber.dealer === a2) {
        damageNumber.value += a3
        damageNumber.delay = delay
        return
      }
    }
    this.damageNumbers.push(new DamageNumber(a3, a2, delay))
  }

  stopMovement () {
    this.moveStart = this.ticksGone - 1
    this.moveEnd = this.ticksGone - 1
  }

  tickAI () {
    if (this.isBot !== 0) {
      this.tickBot()
    }
  }

  setInvisible (ticks = 3) {
    if (this.invisibleTicks <= 0) this.isInvisible = true
    this.invisibleTicks = ticks
  }

  tickBot () {
    if (this.isControlled) return
    const battle = this.gameObjectManager.getBattle()
    if (battle.isGameOver) return
    const ticksGone = this.ticksGone
    this.ticksSinceBotEnemyCheck++
    this.botHadPathThisTick = false
    if (ticksGone - this.lastBotMoveTick >= 10) {
      const dx = LogicMath.abs(this.getX() - this.lastBotPosX)
      const dy = LogicMath.abs(this.getY() - this.lastBotPosY)
      this.botStuckTicks = (dx < 50 && dy < 50) ? this.botStuckTicks + 1 : 0
      this.lastBotPosX = this.getX()
      this.lastBotPosY = this.getY()
      this.lastBotMoveTick = ticksGone
    }
    if (this.ticksSinceBotEnemyCheck > 20 || this.closestEnemy == null) {
      this.ticksSinceBotEnemyCheck = 0
      let found = null
      let foundDist = 99999999
      for (const c of this.gameObjectManager.getCharacters().slice()) {
        if (!c.characterData.isHero()) continue
        if (!c.isAlive() || c.hitpoints <= 0) continue
        if (c.characterData.isCarryable()) continue
        if (teamOf(c.getIndex()) === teamOf(this.getIndex())) continue
        if (c.isInvisible) continue
        const d = this.position.getDistance(c.getPosition())
        if (d < foundDist) {
          foundDist = d
          found = c
        }
      }
      if (found != null) {
        this.closestEnemy = found
        this.closestEnemyPosition = found.getPosition()
      }
    }
    if (this.closestEnemy != null && this.closestEnemy.hitpoints > 0) {
      this.closestEnemyPosition = this.closestEnemy.getPosition()
    } else {
      this.closestEnemy = null
    }
    const tookDamage = this.hitpoints < this.botLastHp
    this.botLastHp = this.hitpoints
    const tileMap = battle.getTileMap()
    const pathFinder = battle.getPathFinder()
    const mapWidth = this.mapWidth
    const mapHeight = this.mapHeight
    let moveTargetX = -1
    let moveTargetY = -1
    const mode = battle.getGameModeVariation()
    const myTeam = teamOf(this.getIndex())
    let separationOffsetX = 0
    let separationOffsetY = 0
    const botIndexInTeam = this.getIndex() % 16
    if (botIndexInTeam > 0) {
      const sepAngle = (botIndexInTeam * 90) % 360
      const sepDist = 600 + botIndexInTeam * 200
      separationOffsetX = (LogicMath.sin(sepAngle) * sepDist) >> 10
      separationOffsetY = (LogicMath.cos(sepAngle) * sepDist) >> 10
    }
    if (mode === 0 || mode === 25) {
      const myTeamGems = battle.getTeamScore(myTeam)
      const eneTeamGems = battle.getTeamScore(myTeam === 0 ? 1 : 0)
      const player = this.getPlayer()
      const spawn = player != null ? player.getSpawnPoint() : null
      if (myTeamGems >= 10 && spawn != null) {
        moveTargetX = LogicMath.clamp(spawn.x + separationOffsetX, 300, mapWidth - 300)
        moveTargetY = LogicMath.clamp(spawn.y + separationOffsetY, 300, mapHeight - 300)
      } else if (eneTeamGems >= 7 && this.closestEnemy != null) {
        moveTargetX = this.closestEnemyPosition.x
        moveTargetY = this.closestEnemyPosition.y
      } else {
        let closestGem = null
        let gemDist = 99999999
        for (const item of this.gameObjectManager.getItems()) {
          if (item.itemData.name !== 'Point') continue
          const d = this.position.getDistance(item.getPosition())
          if (d < gemDist) {
            gemDist = d
            closestGem = item
          }
        }
        if (closestGem != null) {
          moveTargetX = closestGem.getX() + Math.trunc(separationOffsetX / 2)
          moveTargetY = closestGem.getY() + Math.trunc(separationOffsetY / 2)
        } else if (this.closestEnemy != null) {
          moveTargetX = this.closestEnemyPosition.x
          moveTargetY = this.closestEnemyPosition.y
        }
      }
    } else if (mode === 5 || mode === 23) {
      const ball = battle.carryable
      if (ball != null) {
        const ballIsCarried = ball.carringCharacter != null && ball.carringCharacter.isAlive()
        const myTeamHasBall = ballIsCarried && teamOf(ball.carringCharacter.getIndex()) === myTeam
        const enemyHasBall = ballIsCarried && teamOf(ball.carringCharacter.getIndex()) !== myTeam
        if (myTeamHasBall) {
          const mySpawns = myTeam === 0 ? tileMap.spawnPointsTeam1 : tileMap.spawnPointsTeam2
          const enemySpawns = myTeam === 0 ? tileMap.spawnPointsTeam2 : tileMap.spawnPointsTeam1
          const mySpawnY = mySpawns.length > 0 ? mySpawns[0].y : Math.trunc(tileMap.logicHeight / 2)
          const enemySpawnY = enemySpawns.length > 0 ? enemySpawns[0].y : Math.trunc(tileMap.logicHeight / 2)
          const goalY = mySpawnY > enemySpawnY ? 600 : tileMap.logicHeight - 600
          const goal = new LogicVector2(Math.trunc(tileMap.logicWidth / 2), goalY)
          let iAmClosestToGoal = true
          const myDistToGoal = this.position.getDistance(goal)
          for (const ally of battle.getCharactersByTeam(myTeam)) {
            if (ally === this || !ally.isAlive() || !ally.characterData.isHero()) continue
            if (ally.position.getDistance(goal) < myDistToGoal) iAmClosestToGoal = false
          }
          if (iAmClosestToGoal) {
            moveTargetX = goal.x
            moveTargetY = goal.y
          } else {
            moveTargetX = LogicMath.clamp(ball.getX() + separationOffsetX, 300, mapWidth - 300)
            moveTargetY = LogicMath.clamp(ball.getY() + separationOffsetY, 300, mapHeight - 300)
          }
        } else if (enemyHasBall) {
          moveTargetX = ball.carringCharacter.getX() + Math.trunc(separationOffsetX / 3)
          moveTargetY = ball.carringCharacter.getY() + Math.trunc(separationOffsetY / 3)
        } else {
          moveTargetX = LogicMath.clamp(ball.getX() + Math.trunc(separationOffsetX / 3), 600, mapWidth - 600)
          moveTargetY = LogicMath.clamp(ball.getY() + Math.trunc(separationOffsetY / 3), 600, mapHeight - 600)
        }
      } else {
        moveTargetX = Math.trunc(tileMap.logicWidth / 2) + separationOffsetX
        moveTargetY = Math.trunc(tileMap.logicHeight / 2) + separationOffsetY
      }
    } else if (mode === 3) {
      if (this.closestEnemy != null) {
        moveTargetX = this.closestEnemyPosition.x + Math.trunc(separationOffsetX / 3)
        moveTargetY = this.closestEnemyPosition.y + Math.trunc(separationOffsetY / 3)
      }
    } else if (mode === 9 || mode === 6) {
      const hpPercent = this.maxHitpoints > 0 ? Math.trunc(this.hitpoints * 100 / this.maxHitpoints) : 100
      let closestItem = null
      let itemDist = 99999999
      for (const item of this.gameObjectManager.getItems()) {
        const d = this.position.getDistance(item.getPosition())
        if (d < itemDist) {
          itemDist = d
          closestItem = item
        }
      }
      let teamingAlly = null
      const characters = this.gameObjectManager.getCharacters().slice()
      if (this.botTeamingUntil > ticksGone && this.botTeamingWith !== -1) {
        for (const c of characters) {
          if (!c.characterData.isHero() || !c.isAlive()) continue
          if (c === this) continue
          if (c.isBot !== 1) continue
          if (c.botTeamingWith === this.getIndex()) {
            teamingAlly = c
            break
          }
        }
      }
      if (this.botTeamingUntil <= ticksGone && this.botTeamingWith === -1) {
        let nearbyBot = null
        let nearbyDist = 99999999
        for (const c of characters) {
          if (!c.characterData.isHero() || !c.isAlive()) continue
          if (c === this) continue
          if (c.isBot !== 1) continue
          if (c.botTeamingWith !== -1) continue
          const d = this.position.getDistance(c.getPosition())
          if (d < 2000 && d < nearbyDist) {
            nearbyDist = d
            nearbyBot = c
          }
        }
        const totalBotCount = characters.filter(c => c.characterData.isHero() && c.isAlive() && c.isBot === 1).length
        if (nearbyBot != null && totalBotCount > 3 && battle.getRandomInt(4) === 0 && nearbyBot.botTeamingWith === -1) {
          this.botTeamingWith = nearbyBot.getIndex()
          this.botTeamingUntil = ticksGone + battle.getRandomInt(40, 100)
          nearbyBot.botTeamingWith = this.getIndex()
          nearbyBot.botTeamingUntil = this.botTeamingUntil
        }
      }
      if (this.botTeamingWith !== -1 && this.botTeamingUntil <= ticksGone) {
        this.botTeamingWith = -1
        this.botTeamingUntil = 0
      }
      if (teamingAlly != null) {
        if (this.closestEnemy != null) {
          moveTargetX = this.closestEnemyPosition.x
          moveTargetY = this.closestEnemyPosition.y
        } else {
          moveTargetX = LogicMath.clamp(teamingAlly.getX() + separationOffsetX, 300, mapWidth - 300)
          moveTargetY = LogicMath.clamp(teamingAlly.getY() + separationOffsetY, 300, mapHeight - 300)
        }
      } else if (hpPercent < 40 && closestItem != null) {
        moveTargetX = closestItem.getX()
        moveTargetY = closestItem.getY()
      } else if (this.closestEnemy != null) {
        moveTargetX = this.closestEnemyPosition.x + Math.trunc(separationOffsetX / 3)
        moveTargetY = this.closestEnemyPosition.y + Math.trunc(separationOffsetY / 3)
      } else if (closestItem != null) {
        moveTargetX = closestItem.getX()
        moveTargetY = closestItem.getY()
      }
    } else if (mode === 17) {
      moveTargetX = LogicMath.clamp(Math.trunc(tileMap.logicWidth / 2) + separationOffsetX, 300, mapWidth - 300)
      moveTargetY = LogicMath.clamp(Math.trunc(tileMap.logicHeight / 2) + separationOffsetY, 300, mapHeight - 300)
    } else {
      if (this.closestEnemy != null) {
        moveTargetX = this.closestEnemyPosition.x + Math.trunc(separationOffsetX / 3)
        moveTargetY = this.closestEnemyPosition.y + Math.trunc(separationOffsetY / 3)
      } else {
        this.updateBotWander(battle, mapWidth, mapHeight)
        moveTargetX = this.botWanderX
        moveTargetY = this.botWanderY
      }
    }
    if (this.closestEnemy != null) {
      const weaponSkill = this.skills[0]
      const distToEnemy = this.position.getDistance(this.closestEnemyPosition)
      const attackRange = weaponSkill != null ? weaponSkill.skillData.castingRange * 50 : 3000
      const retreatRange = Math.trunc(attackRange * 5 / 10)
      const hpPercent = this.maxHitpoints > 0 ? Math.trunc(this.hitpoints * 100 / this.maxHitpoints) : 100
      if (ticksGone >= this.botStateUntil) {
        if (tookDamage && hpPercent < 50) {
          if (this.botState !== 2) this.botReactionDelay = battle.getRandomInt(5, 15)
          this.botState = 2
          this.botStateUntil = ticksGone + battle.getRandomInt(40, 80)
        } else if (tookDamage && hpPercent < 75 && battle.getRandomInt(2) === 0) {
          if (this.botState !== 3) {
            this.botStrafeDir = battle.getRandomInt(2) === 0 ? 1 : -1
            this.botReactionDelay = battle.getRandomInt(5, 15)
          }
          this.botState = 3
          this.botStateUntil = ticksGone + battle.getRandomInt(25, 50)
        } else if (distToEnemy < retreatRange && battle.getRandomInt(3) === 0) {
          if (this.botState !== 3) {
            this.botStrafeDir = battle.getRandomInt(2) === 0 ? 1 : -1
            this.botReactionDelay = battle.getRandomInt(5, 15)
          }
          this.botState = 3
          this.botStateUntil = ticksGone + battle.getRandomInt(20, 40)
        } else {
          if (this.botState !== 1) this.botReactionDelay = battle.getRandomInt(8, 18)
          this.botState = 1
          this.botStateUntil = ticksGone + battle.getRandomInt(30, 60)
        }
      }
      if (this.botReactionDelay > 0) {
        this.botReactionDelay--
      } else if (this.botState === 2) {
        let retreatAngle = LogicMath.getAngle(this.getX() - this.closestEnemyPosition.x, this.getY() - this.closestEnemyPosition.y)
        retreatAngle += battle.getRandomInt(-20, 20)
        const dist = 700
        moveTargetX = LogicMath.clamp(this.getX() + ((LogicMath.sin(retreatAngle) * dist) >> 10), 300, mapWidth - 300)
        moveTargetY = LogicMath.clamp(this.getY() + ((LogicMath.cos(retreatAngle) * dist) >> 10), 300, mapHeight - 300)
      } else if (this.botState === 3) {
        let strafeAngle = LogicMath.getAngle(this.closestEnemyPosition.x - this.getX(), this.closestEnemyPosition.y - this.getY())
        strafeAngle += 90 * this.botStrafeDir
        const dist = battle.getRandomInt(400, 700)
        moveTargetX = LogicMath.clamp(this.getX() + ((LogicMath.sin(strafeAngle) * dist) >> 10), 300, mapWidth - 300)
        moveTargetY = LogicMath.clamp(this.getY() + ((LogicMath.cos(strafeAngle) * dist) >> 10), 300, mapHeight - 300)
      }
      if (ticksGone - this.lastAIAttackTick > 30 && weaponSkill != null) {
        if (weaponSkill.hasEnoughCharge() && distToEnemy < Math.trunc(attackRange * 70 / 100)) {
          this.lastAIAttackTick = ticksGone
          const targetX = this.closestEnemyPosition.x
          const targetY = this.closestEnemyPosition.y
          this.activateSkill(0, targetX, targetY)
          const bot = battle.getPlayerWithObject(this.getGlobalID())
          if (bot != null && bot.getUltiCharge() >= 4000 && this.getUltimateSkill() != null && battle.getRandomInt(3) === 0) {
            this.activateSkill(1, targetX, targetY)
          }
        }
      }
    }
    if (moveTargetX === -1) {
      this.updateBotWander(battle, mapWidth, mapHeight)
      moveTargetX = this.botWanderX
      moveTargetY = this.botWanderY
    }
    moveTargetX = LogicMath.clamp(moveTargetX, 300, mapWidth - 300)
    moveTargetY = LogicMath.clamp(moveTargetY, 300, mapHeight - 300)
    const path = pathFinder.findPath(new LogicVector2(this.getX(), this.getY()), new LogicVector2(moveTargetX, moveTargetY))
    if (path == null || path.length <= 1) {
      if (this.botStuckTicks >= 3 && ticksGone >= this.botDetourUntil) {
        const escapeSteps = [[600, 0], [-600, 0], [0, 600], [0, -600], [450, 450], [-450, 450], [450, -450], [-450, -450]]
        const start = (Math.trunc(ticksGone / 10) + this.getIndex()) % escapeSteps.length
        this.botDetourUntil = ticksGone + 20
        for (let i = 0; i < escapeSteps.length; i++) {
          const step = escapeSteps[(start + i) % escapeSteps.length]
          const targetX = LogicMath.clamp(this.getX() + step[0], 300, mapWidth - 300)
          const targetY = LogicMath.clamp(this.getY() + step[1], 300, mapHeight - 300)
          const escapePath = pathFinder.findPath(new LogicVector2(this.getX(), this.getY()), new LogicVector2(targetX, targetY))
          if (escapePath == null || escapePath.length <= 1) continue
          const escapeIndex = Math.min(2, escapePath.length - 1)
          this.moveTo(0, escapePath[escapeIndex].x, escapePath[escapeIndex].y, 0, 0, 0, 0)
          this.botDetourUntil = ticksGone + 20
          this.botStuckTicks = 0
          return
        }
      }
      return
    }
    this.botHadPathThisTick = true
    const pathIndex = Math.min(2, path.length - 1)
    this.moveTo(0, path[pathIndex].x, path[pathIndex].y, 0, 0, 0, 0)
    if (this.botStuckTicks >= 3 && ticksGone >= this.botDetourUntil) {
      const targetX = this.closestEnemy != null ? this.closestEnemyPosition.x : moveTargetX
      const targetY = this.closestEnemy != null ? this.closestEnemyPosition.y : moveTargetY
      let detourAngle = LogicMath.normalizeAngle360(LogicMath.getAngle(targetX - this.getX(), targetY - this.getY()))
      if (LogicMath.abs(targetX - this.getX()) < 50 && LogicMath.abs(targetY - this.getY()) < 50) detourAngle = battle.getRandomInt(360)
      detourAngle += battle.getRandomInt(2) === 1 ? 90 : -90
      const detourDist = battle.getRandomInt(500, 900)
      const dtx = LogicMath.clamp(this.getX() + ((LogicMath.sin(detourAngle) * detourDist) >> 10), 300, mapWidth - 300)
      const dty = LogicMath.clamp(this.getY() + ((LogicMath.cos(detourAngle) * detourDist) >> 10), 300, mapHeight - 300)
      this.botDetourUntil = ticksGone + 20
      const detourPath = pathFinder.findPath(new LogicVector2(this.getX(), this.getY()), new LogicVector2(dtx, dty))
      if (detourPath != null && detourPath.length > 1) {
        const di = Math.min(2, detourPath.length - 1)
        this.botDetourX = detourPath[di].x
        this.botDetourY = detourPath[di].y
        this.moveTo(0, this.botDetourX, this.botDetourY, 0, 0, 0, 0)
        this.botStuckTicks = 0
      }
    }
  }

  updateBotWander (battle, mapWidth, mapHeight) {
    const ticksGone = this.ticksGone
    const wanderReached = LogicMath.abs(this.getX() - this.botWanderX) < 400 && LogicMath.abs(this.getY() - this.botWanderY) < 400
    if (ticksGone >= this.botWanderUntil || wanderReached) {
      this.botWanderX = battle.getRandomInt(300, mapWidth - 300)
      this.botWanderY = battle.getRandomInt(300, mapHeight - 300)
      this.botWanderUntil = ticksGone + battle.getRandomInt(60, 150)
    }
  }

  tickAreaEffectForCharge () {
    if (this.wayPoint.x === this.wayPointStart.x) return
    if (this.wayPoint.y === this.wayPointStart.y) return
    const area = DataTables.getAreaEffectByName('RollerFire')
    if (area == null) return
    const AreaEffect = getAreaEffectClass()
    const areaEffect = new AreaEffect(area)
    areaEffect.setPosition(this.getX(), this.getY(), 0)
    areaEffect.setIndex(this.getIndex())
    areaEffect.setSource(this, 2)
    areaEffect.damage = area.damage
    areaEffect.normalDMG = area.damage
    this.gameObjectManager.addGameObject(areaEffect)
    areaEffect.trigger()
  }

  triggerCharge (x, y, speed, type, damage, pushback, returning, areaEffectData = null) {
    const X = this.getX()
    const Y = this.getY()
    const tileMap = this.getBattle().getTileMap()
    const t = new LogicVector2(x, y)
    const hitBorder = GamePlayUtil.getClosestLevelBorderCollision(X, Y, x, y, tileMap, 1, t)
    if (type === 7 && hitBorder) {
      let origDirX = x - X
      let origDirY = y - Y
      if (LogicMath.abs(origDirX) > LogicMath.abs(origDirY)) origDirX = -origDirX
      else origDirY = -origDirY
      this.wayPoint2 = new LogicVector2(
        LogicMath.clamp(t.x + origDirX * 2, 101, tileMap.logicWidth - 102),
        LogicMath.clamp(t.y + origDirY * 2, 101, tileMap.logicHeight - 102))
      this.shouldExecuteColetteChargeOnReturn = true
    }
    if (t.x > x) t.x += 50
    if (t.x < x) t.x -= 50
    if (t.y > y) t.y += 50
    if (t.y < y) t.y -= 50
    x = t.x
    y = t.y
    if (this.chargeUpType === 1) this.chargeUp = 0
    if (this.getCardValueForPassive('heal_on_charge', 1) >= 1) this.heal(this.getIndex(), this.getCardValueForPassive('heal_on_charge', 1), true, null)
    this.chargeBreaksEnvironment = false
    this.fangUltiCount = 0
    if (type !== 10 || returning) {
      if (this.getCardValueForPassive('shield_charge', 1) >= 1) {
        this.addShield(this.getCardValueForPassive('shield_charge', 2), this.getCardValueForPassive('shield_charge', 1))
      }
      this.stunTicks = 0
      this.chargeHits = 0
      if (type === 10) this.wayPoint2 = this.getPosition()
    }
    this.chargeHitGIDs = []
    this.fangHitGIDs = []
    if (type === 4 || type === 7 || type === 8 || type === 10 || (type === 12 && !this.chargeBreaksEnvironment)) {
      const collision = new LogicVector2(-1, -1)
      const collided = GamePlayUtil.getClosestAnyCollision(X, Y, x, y, tileMap, collision, 0, 0, 0, 0)
      if (collision.x !== -1) {
        let dx = collision.x - X
        let dy = collision.y - Y
        const length = LogicMath.sqrt(dx * dx + dy * dy)
        if (length > 0) {
          let back = 20
          if (length <= 20) back = LogicMath.max(1, length - 5)
          dx = Math.trunc((length - back) * dx / length)
          dy = Math.trunc((length - back) * dy / length)
        }
        x = dx + X
        y = dy + Y
      }
      if (type === 7 && collided) {
        let moveDirX = x - X
        let moveDirY = y - Y
        const length = LogicMath.sqrt(moveDirX * moveDirX + moveDirY * moveDirY)
        if (length > 0) {
          if (LogicMath.abs(moveDirX) > LogicMath.abs(moveDirY)) moveDirX = -moveDirX
          else moveDirY = -moveDirY
          this.wayPoint2 = new LogicVector2(
            LogicMath.clamp(x + moveDirX * 2, 101, tileMap.logicWidth - 102),
            LogicMath.clamp(y + moveDirY * 2, 101, tileMap.logicHeight - 102))
          this.shouldExecuteColetteChargeOnReturn = true
        }
      }
      x = LogicMath.clamp(x, 101, tileMap.logicWidth - 102)
      y = LogicMath.clamp(y, 101, tileMap.logicHeight - 102)
    }
    const isJump = type === 2 || type === 6 || type === 9 || type === 11 || type === 16
    if (isJump) {
      const v = new LogicVector2(x, y)
      GamePlayUtil.getClosestPassableSpot(1, x, y, 10, tileMap, v, true)
      x = v.x
      y = v.y
    }
    if (x === this.getX()) y -= 100
    this.pathfindTo(0, x, y, 0, 0, 0, 0, 0, 0)
    const pathLengthNow = this.getPathLength()
    this.pathLength = pathLengthNow
    let pathLength = this.pathLength
    if (pathLengthNow > 0) {
      this.moveStart = this.ticksGone
      if (isJump) {
        const ulti = this.skills[1]
        let range = ulti != null ? ulti.skillData.castingRange : 0
        if (range === 0) range = 22
        if (type === 9) {
          pathLength = LogicMath.min(pathLength, range * 100)
          speed = LogicMath.max(speed, 1)
        }
        if (type === 16) speed = Math.trunc(speed * 0.8)
        speed = LogicMath.max(speed, 1)
        if (type === 2 || type === 6 || type === 11) pathLength = 2300
      }
      this.moveEnd = LogicMath.max(1, Math.trunc(20 * pathLength / LogicMath.max(speed, 1))) + this.ticksGone
    }
    this.isCharging = true
    if (this.getCardValueForPassive('super_reload', 1) >= 0) this.reloadBuffTicks = this.getCardValueForPassive('super_reload', 1)
    this.chargeSpeed = speed
    this.chargeDamage = damage
    this.chargePushback = pushback
    this.activeChargeType = type
    this.shouldExecuteColetteChargeOnReturn = returning
    if ((type === 2 || type === 11) && areaEffectData != null) {
      const AreaEffect = getAreaEffectClass()
      const areaEffect = new AreaEffect(areaEffectData)
      areaEffect.setPosition(this.getX(), this.getY(), 0)
      areaEffect.setIndex(this.getIndex())
      areaEffect.setSource(this, 2)
      areaEffect.damage = damage
      areaEffect.normalDMG = this.chargeNormalDMG
      const prey = this.getCardValueForPassive('prey_on_the_weak', 1)
      if (prey >= 0) areaEffect.setPreyOnTheWeak(prey, this.getCardValueForPassive('prey_on_the_weak', 0))
      this.gameObjectManager.addGameObject(areaEffect)
      areaEffect.trigger()
      this.chargeAreaEffectData = areaEffectData
    }
  }

  getActiveSkillShield () {
    for (const skill of this.skills) {
      if (skill.skillData.behaviorType === 'Shield' && skill.ticksActive > 0) return skill.skillData.msBetweenAttacks
    }
    return 0
  }

  getClosestProjectileFlyingAgainstYou () {
    let closest = null
    let distance = 99999999
    for (const gameObject of this.gameObjectManager.getGameObjects()) {
      if (gameObject.getObjectType() !== 1) continue
      if (teamOf(gameObject.getIndex()) === teamOf(this.getIndex()) || gameObject.state === 4) continue
      const d = this.position.getDistance(gameObject.getPosition())
      if (d < distance) {
        closest = gameObject
        distance = d
      }
    }
    return closest
  }

  getClosestEnemy (rangeSubTiles, type, ignoreVisibility, ignoreVisibility2, ignoreTargets, requireLOS, targetTeammates, targetFullHP) {
    const limited = rangeSubTiles !== undefined
    let closest = null
    let distance = limited ? rangeSubTiles * 100 : 99999999
    for (const gameObject of this.gameObjectManager.getGameObjects()) {
      if (gameObject.getObjectType() !== 0) continue
      const enemy = gameObject
      if (enemy.hitpoints <= 0) continue
      if (enemy.characterData.isCarryable()) continue
      if (teamOf(enemy.getIndex()) === teamOf(this.getIndex()) || enemy.isImmuneAndBulletsGoThrough(!!this.isInRealm) || enemy.isInvincible) continue
      if (limited) {
        if (!enemy.isAlive()) continue
        if (enemy.getFadeCounter() < 1 && !ignoreVisibility) continue
      }
      const d = this.position.getDistance(enemy.getPosition())
      if (d < distance) {
        closest = enemy
        distance = d
      }
    }
    return closest
  }

  getClosestVisibleEnemy () {
    let closest = null
    let distance = 99999999
    for (const gameObject of this.gameObjectManager.getVisibleGameObjects(this.getIndex(), this.getGlobalID())) {
      if (gameObject.getObjectType() !== 0) continue
      if (gameObject.hitpoints <= 0) continue
      if (gameObject.characterData.isCarryable()) continue
      if (teamOf(gameObject.getIndex()) === teamOf(this.getIndex()) || gameObject.isInvisible) continue
      const d = this.position.getDistance(gameObject.getPosition())
      if (d < distance) {
        closest = gameObject
        distance = d
      }
    }
    return closest
  }

  getEnemy () {
    let closest = null
    let distance = 99999999
    for (const gameObject of this.gameObjectManager.getVisibleGameObjects(this.getIndex(), this.getGlobalID())) {
      if (gameObject.getObjectType() !== 0) continue
      if (gameObject.hitpoints <= 0) continue
      if (gameObject.characterData.isCarryable()) continue
      if (teamOf(gameObject.getIndex()) === teamOf(this.getIndex())) continue
      const d = this.position.getDistance(gameObject.getPosition())
      if (d < distance) {
        closest = gameObject
        distance = d
      }
    }
    return closest
  }

  getTeammateForHeal () {
    let closest = null
    let distance = 99999999
    for (const gameObject of this.gameObjectManager.getVisibleGameObjects(this.getIndex(), this.getGlobalID())) {
      if (gameObject.getObjectType() !== 0) continue
      if (gameObject.hitpoints <= 0) continue
      if (gameObject.hitpoints >= gameObject.maxHitpoints) continue
      if (!gameObject.characterData.isHero()) continue
      if (gameObject.characterData.isCarryable()) continue
      if (teamOf(gameObject.getIndex()) !== teamOf(this.getIndex())) continue
      const d = this.position.getDistance(gameObject.getPosition())
      if (d < distance) {
        closest = gameObject
        distance = d
      }
    }
    return closest
  }

  getRegeneratePerSecond () {
    if (this.characterData.isHero()) return Math.trunc(13 * this.maxHitpoints / 100)
    return 0
  }

  getCardValueForPassive (type, index) {
    const starPowerData = this.starPowerData
    if (starPowerData == null || starPowerData.type !== type) return -1
    if (index === 2) return starPowerData.value3
    return index > 0 ? starPowerData.value : starPowerData.value2
  }

  tickHeals () {
    if (!this.canHeal) return
    if (!this.characterData.isHero()) return
    const ticksGone = this.ticksGone
    if (this.isInvincible) this.healthRegenBlockedTick = ticksGone
    if (this.extraRegenTicks >= 1) {
      this.extraRegenTicks--
      if ((this.extraRegenTicks + 1) % 20 === 0) this.heal(this.extraRegenerIndex, this.extraRegenAmount, true, null)
    }
    for (const buff of this.buffs.slice()) {
      if (buff.type === 10 && buff.duration % 20 === 0) this.heal(buff.sourceIndex, buff.modifier, true, null)
    }
    const repair = this.getCardValueForPassive('repair_self', 1)
    let regenDelay = 60
    if (repair >= 0) {
      regenDelay = 60 - repair
      if (regenDelay <= 21) regenDelay = 21
    }
    if (ticksGone >= this.healthRegenedTick + 20) {
      let regen = this.getRegeneratePerSecond()
      if (regen > 0 && ticksGone >= this.healthRegenBlockedTick + regenDelay && ticksGone >= Character.DEPLOY_TICKS_FIRST_SPAWN) {
        if (this.hitpoints < this.maxHitpoints) regen += Math.trunc(regen * this.getGearBoost(1) / 100)
        if (regen >= 1) {
          this.heal(this.getIndex(), regen, false, this.characterData)
          this.healthRegenedTick = ticksGone
        }
      }
    }
    if (ticksGone >= this.healthRegenedTickSP + 20) {
      let healed = false
      const forest = this.getCardValueForPassive('heal_forest', 1)
      if (forest >= 0 && this.isInBush()) {
        this.heal(this.getIndex(), forest, true, this.characterData)
        healed = true
      }
      const invisibleHeal = this.getCardValueForPassive('heal_invisible', 1)
      if (invisibleHeal >= 0 && this.getActiveSkill('Invisibility') != null && this.isInvisible) {
        this.heal(this.getIndex(), invisibleHeal, true, this.characterData)
        healed = true
      }
      if (this.aoeRegenerate >= 1) {
        const autoHeal = DataTables.getAreaEffectByName('AutoHeal')
        if (autoHeal != null) {
          const AreaEffect = getAreaEffectClass()
          for (const ally of this.gameObjectManager.getGameObjects()) {
            if (ally.getObjectType() !== 0) continue
            if (!ally.isAlive() || teamOf(ally.getIndex()) !== teamOf(this.getIndex())) continue
            if (ally === this || !ally.characterData.isHero() || ally.hitpoints >= ally.maxHitpoints) continue
            const dx = ally.getX() - this.getX()
            const dy = ally.getY() - this.getY()
            const range = AreaEffect.getRangeAgainst(autoHeal, ally) - 100
            if (LogicMath.abs(dx) <= range && LogicMath.abs(dy) <= range && dx * dx + dy * dy <= range * range) {
              const areaEffect = GameObjectFactory.createGameObjectByData(autoHeal)
              areaEffect.setPosition(this.getX(), this.getY(), 0)
              areaEffect.setIndex(this.getIndex())
              areaEffect.setSource(this, 3)
              areaEffect.damage = -this.aoeRegenerate
              areaEffect.normalDMG = 0
              this.gameObjectManager.addGameObject(areaEffect)
              areaEffect.trigger()
              this.healthRegenedTick = ticksGone
              healed = true
              break
            }
          }
        }
      }
      if (this.getCardValueForPassive('heal_continuous', 1) >= 1) {
        if (ticksGone >= this.healthRegenedTickSP + this.getCardValueForPassive('heal_continuous', 0)) {
          this.heal(this.getIndex(), Math.trunc((this.maxHitpoints - this.hitpoints) * this.getCardValueForPassive('heal_continuous', 1) / 100), false, this.characterData)
          healed = true
        }
      }
      if (healed) this.healthRegenedTickSP = ticksGone
    }
  }

  isObject () {
    return !this.characterData.hasAutoAttack() && this.characterData.speed === 0
  }

  triggerStun (ticks, force) {
    if (this.characterData.isCarryable()) return
    if (ticks < 1) return
    if ((!this.isInvincible && !this.hasCcImmunity()) || force) {
      this.stunTicks = ticks
      this.interruptAllSkills(false)
      if (this.getCardValueForPassive('ulti_defense', 1) >= 0) this.shieldTicks = 0
      if ((!this.isCharging && !this.knockBacked) || force) this.stopMovement()
      const controlled = this.getControlledProjectile()
      if (controlled != null) controlled.targetReached(5)
    }
    this.isWeaklyStunned = false
  }

  heal (dealerIndex, healing, shouldShow, projectileData) {
    if (this.hitpoints < 1) return false
    for (const immunity of this.immunitys) {
      if (immunity.targetIndex === dealerIndex && immunity.targetData === projectileData) return false
    }
    const before = this.hitpoints
    this.hitpoints = LogicMath.min(this.maxHitpoints, before + healing)
    const actualHeal = this.hitpoints - before
    if (actualHeal > 0 && dealerIndex >= 0) {
      const healerTeam = teamOf(dealerIndex)
      const healerIdx = dealerIndex % 16
      const healer = this.getBattle().getPlayers().find(p => p.teamIndex === healerTeam && p.playerIndex === healerIdx)
      if (healer != null) healer.healed(actualHeal)
    }
    if (shouldShow && this.hitpoints > before) this.damageNumbers.push(new DamageNumber(-healing, dealerIndex, 0))
    return true
  }

  chargeUlti (amount, isUlti, ignoreGear, player, dealer) {
    if (player == null) return
    if (!ignoreGear) amount += Math.trunc((amount * player.getGearBoost(6) + 50) / 100)
    player.chargeUlti(amount, isUlti, ignoreGear)
  }

  causeDamage (damageDealer, damage, normalDMG, skillType, source, shouldShow = true, ignoreInvincible = false, X = -1, Y = -1, isTransform = false) {
    if (this.characterData.isCarryable()) return false
    if (this.stopAI && this.characterData.isHero()) return false
    if (damage === 1) damage = 0
    if (normalDMG === 1) normalDMG = 0
    const index = damageDealer == null ? -1 : damageDealer.getIndex()
    if (!ignoreInvincible) {
      if (this.isInvincible) {
        if (shouldShow) this.showDamageNumber(index, 0, damageDealer)
        return false
      }
      if (this.hasBuff(15)) damage += Math.trunc(damage * 35 / 100)
      for (const immunity of this.immunitys) {
        if (immunity.targetData === source && immunity.targetIndex === (damageDealer != null ? damageDealer.getIndex() : undefined)) return false
      }
      if (this.hitpoints <= 0) return false
      if (this.isWeaklyStunned) {
        if (this.stunTicks > 0) this.stunTicks = 0
        this.isWeaklyStunned = false
      }
      const accessory = this.accessory
      if (accessory != null && (accessory.type === 'return_damage' || accessory.type === 'reload_shield') && accessory.isActive) {
        const data = accessory.accessoryData
        if (accessory.type === 'return_damage') {
          if (damageDealer != null) {
            const Projectile = getProjectileClass()
            const returned = Projectile.shootProjectile(-1, -1, this, this, DataTables.getProjectileByName(data.customObject), damageDealer.getX(), damageDealer.getY(), Math.trunc(data.customValue1 * damage / 100), 0, 0, false, 0, this.getBattle(), 0, 4)
            if (returned != null) returned.homingTarget = damageDealer
          }
        } else {
          const weapon = this.getWeaponSkill()
          if (weapon != null) weapon.addCharge(this, 100 * data.customValue2)
        }
        damage -= Math.trunc(damage * data.customValue1 / 100)
        accessory.endAccessoryActivation()
      }
      if (accessory != null && accessory.type === 'take_damage' && accessory.accessoryData.subType === 3 && accessory.isActive) {
        accessory.rewindHP += damage
      }
      let shield = 0
      if (this.shieldTicks > 0) shield += this.shieldPercent
      else shield = this.getActiveSkillShield()
      if (this.getCardValueForPassive('reduce_all_damage', 1) >= 1) shield += this.getCardValueForPassive('reduce_all_damage', 1)
      if (this.getCardValueForPassive('running_reduces_damage', 1) >= 1 && X !== -1) {
        const angle = LogicMath.normalizeAngle360(LogicMath.getAngle(X - this.getX(), Y - this.getY()) - 180)
        const half = Math.trunc(this.getCardValueForPassive('running_reduces_damage', 0) / 2)
        if (angle >= this.moveAngle - half && angle <= this.moveAngle + half) shield += this.getCardValueForPassive('running_reduces_damage', 1)
      }
      const player = this.getPlayer()
      if (player != null && player.overCharging) {
        if (this.characterData.overchargeShieldPercent > 0) shield += this.characterData.overchargeShieldPercent
        else shield += 20
      }
      if (shield >= 100) {
        this.showDamageNumber(index, 0, damageDealer)
        return false
      }
      damage = LogicMath.max(1, damage - Math.trunc(shield * damage / 100))
      if (damage === 1) damage = 0
      if (shouldShow && damage !== 0) this.showDamageNumber(index, damage, damageDealer)
      if (this.getCardValueForPassive('reduce_damage_periodically', 1) >= 1 && this.chargeUp >= this.chargeUpMax) {
        damage -= LogicMath.min(Math.trunc(damage * this.getCardValueForPassive('reduce_damage_periodically', 2) / 100), this.getCardValueForPassive('reduce_damage_periodically', 0))
        this.chargeUp = 0
      }
      if (this.consumableShield >= 1) {
        const absorbed = LogicMath.min(damage, this.consumableShield)
        damage -= absorbed
        this.consumableShield -= absorbed
      }
      for (const gear of [this.gear1, this.gear2]) {
        if (gear != null && gear.shieldAmount >= 1) {
          const absorbed = LogicMath.min(damage, gear.shieldAmount)
          damage -= absorbed
          gear.shieldAmount -= absorbed
        }
      }
      if (source == null) {
        if (damageDealer != null && damageDealer.characterData.isHero()) {
          const dealerPlayer = damageDealer.getPlayer()
          if (dealerPlayer != null && dealerPlayer.skinData != null) {
            this.hitEffectSkin = dealerPlayer.skinData.getInstanceId() + 1
          } else {
            const defaultSkin = DataTables.getByName(DataType.Skin, damageDealer.characterData.defaultSkin)
            if (defaultSkin != null) this.hitEffectSkin = defaultSkin.getInstanceId() + 1
          }
        }
      } else if (source.getDataType() === 6) {
        this.hitEffectProjectile = source.getInstanceId() + 1
      }
      this.handleHealFromDamage(damage, skillType, damageDealer)
      const reflect = this.getCardValueForPassive('reflect_damage_aoe', 1)
      if (reflect >= 1 && reflect * damage >= 100) {
        const reflectArea = DataTables.getAreaEffectByName('DrillerReflectArea')
        if (reflectArea != null) this.triggerAreaEffect(reflectArea, this.getX(), this.getY(), Math.trunc(reflect * damage / 100), 3)
      }
    }
    const result = damage > 0
    this.hitpoints -= damage
    this.hitpoints = LogicMath.max(this.hitpoints, 0)
    this.hitpoints = LogicMath.min(this.hitpoints, this.maxHitpoints)
    if (damage > 0) {
      this.blockHealthRegen()
      this.setForcedVisible()
    }
    const battle = this.gameObjectManager.getBattle()
    if (this.characterData.name === 'KnightPet') {
      const explosionData = DataTables.getAreaEffectByName('KnightPetExplosion')
      if (explosionData != null) {
        const explosion = GameObjectFactory.createGameObjectByData(explosionData)
        explosion.setPosition(this.getX(), this.getY(), 0)
        explosion.setIndex(this.getIndex())
        explosion.setSource(this, 3)
        explosion.damage = 300
        explosion.normalDMG = 0
        this.gameObjectManager.addGameObject(explosion)
        explosion.trigger()
      }
    }
    let removed = false
    const removeSelf = () => {
      if (removed) return
      removed = true
      this.gameObjectManager.removeGameObject(this)
    }
    if (this.characterData.isHero() || this.characterData.isTrainingDummy() || this.characterData.isLootBox()) {
      if (damageDealer != null && damageDealer !== this && !this.isControlled) {
        const enemy = battle.getPlayerWithObject(damageDealer.getGlobalID())
        if (enemy != null && damage > 0 && !this.characterData.isLootBox()) {
          if (damageDealer.characterData.name === 'Roller' && !skillType) enemy.addUltiCharge(4000)
          else this.chargeUlti(normalDMG, skillType, false, enemy, damageDealer)
          if (damageDealer.characterData.uniqueProperty === 1) {
            damageDealer.ashLastRageTick = this.ticksGone
            if (skillType) damageDealer.chargeUp += Math.trunc(normalDMG / 2)
            else damageDealer.chargeUp += Math.trunc(normalDMG / 6) + Math.trunc(Math.trunc(normalDMG / 6) * damageDealer.getPowerLevel() / 4)
            damageDealer.chargeUp = LogicMath.clamp(damageDealer.chargeUp, 0, damageDealer.chargeUpMax)
          }
          if (this.getBattle().getGameModeVariation() !== 13) enemy.damageDealed(damage)
          else enemy.damageDealed(damage, this.ticksGone)
        }
      }
      if (this.hitpoints <= 0) {
        const gmv = battle.getGameModeVariation()
        if (gmv === 6 || gmv === 9) {
          const buffData = DataTables.getItemByName('BattleRoyaleBuff')
          if (this.characterData.name === 'LootBox') this.createBattleRoyaleItems(buffData, 1)
          else if (this.characterData.isHero()) this.createBattleRoyaleItems(buffData, LogicMath.max(1, LogicMath.min(this.battleRoyaleBuffs, 5)))
          removeSelf()
        }
        const controlled = this.getControlledProjectile()
        if (controlled != null) controlled.targetReached(5)
        const player = battle.getPlayerWithObject(this.getGlobalID())
        if (this.characterData.uniqueProperty === 2 && this.characterData.name === 'MechaDudeBig') {
          const small = this.triggerTransforming(DataTables.getCharacterByName('MechaDude'))
          if (small != null) {
            small.itemCount = this.itemCount
            small.battleRoyaleBuffs = this.battleRoyaleBuffs
            small.hitpoints = small.maxHitpoints
            if (small.skills[0] != null) small.skills[0].charge = 1000
            if (player != null) player.ownObjectId = small.getGlobalID()
            if (this.getCardValueForPassive('mecha_explosion', 1) >= 1) {
              const destroyArea = DataTables.getAreaEffectByName('MechaDudeDestroyExplosion')
              if (destroyArea != null) this.triggerAreaEffect(destroyArea, this.getX(), this.getY(), 0, 3)
            }
            if (this.getCardValueForPassive('downgrade_shield', 1) !== -1) small.addShield(this.getCardValueForPassive('downgrade_shield', 0), this.getCardValueForPassive('downgrade_shield', 1))
            small.triggerPushback(small.getX(), small.getY(), 50, true, 0, false, false, false, true, false, false, false, 0)
            small.knockback3 = true
            return result
          }
        }
        if (player != null) {
          if (damageDealer != null && damageDealer.getPlayer() != null && gmv === 25) damageDealer.getPlayer().addScore(1)
          removeSelf()
          this.hitEffectSkin = 0
          if (!isTransform) battle.playerDied(player)
          for (const item of this.gameObjectManager.getItems()) {
            if (item.owner != null && item.owner.getIndex() === this.getIndex() && item.owner.characterData.name === 'WeaponThrower') item.pickedUp = true
          }
        }
        if (damageDealer != null) {
          const stealSouls = damageDealer.getCardValueForPassive('steal_souls', 1)
          if (stealSouls > 0) damageDealer.heal(-1, stealSouls, true, null)
          if (damageDealer.getCardValueForPassive('steal_souls2', 1) >= 0) {
            const Projectile = getProjectileClass()
            const soul = Projectile.shootProjectile(-1, -1, this, this, DataTables.getProjectileByName('HammerDudeStarPowerProjectile'), damageDealer.getX(), damageDealer.getY(), damageDealer.getCardValueForPassive('steal_souls2', 1), 0, 0, false, 0, this.getBattle(), 0, 3)
            if (soul != null) {
              soul.homingTarget = damageDealer
              soul.setStealSouls2BuffingData(damageDealer.getCardValueForPassive('steal_souls2', 1), 20 * damageDealer.getCardValueForPassive('steal_souls2', 0))
              soul.setIndex(damageDealer.getIndex())
            }
          }
          if (this.isInRealm) {
            damageDealer.isInRealm = false
            this.isInRealm = false
            if (this.realmEffect != null) this.gameObjectManager.removeGameObject(this.realmEffect)
          }
          const enemy = battle.getPlayerWithObject(damageDealer.getGlobalID())
          if (gmv === 3 && enemy != null) {
            damageDealer.addItemsCollected(1)
            enemy.addScore(this.itemCount + 2)
          }
          if (enemy != null) {
            enemy.killedPlayer(this.getIndex() % 16, gmv === 3 ? this.itemCount + 1 : 0)
            if (this.hasBuff(15) && this.getBuff(15).belleWeaponBounces >= 0) enemy.addUltiCharge(2000)
          }
        }
        if (gmv === 0) {
          const pointData = DataTables.getItemByName('Point')
          const Item = getItemClass()
          for (let i = 0; i < this.itemCount && pointData != null; i++) {
            const distance = battle.getRandomInt(300, 600)
            const angle = battle.getRandomInt(360)
            let tx = LogicMath.clamp(this.getX() + LogicMath.getRotatedX(distance, 0, angle), 1, this.mapWidth - 2)
            let ty = LogicMath.clamp(this.getY() + LogicMath.getRotatedY(distance, 0, angle), 1, this.mapHeight - 2)
            const spot = new LogicVector2(tx, ty)
            GamePlayUtil.getClosestPassableSpot(0, tx, ty, 10, battle.getTileMap(), spot, true)
            tx = spot.x
            ty = spot.y
            const item = new Item(pointData)
            item.setFromToPosition(this.getX(), this.getY(), this.getZ(), tx, ty, 0)
            item.setAngle(battle.getRandomInt(0, 360))
            this.gameObjectManager.addGameObject(item)
          }
        }
      }
    }
    if (this.hitpoints <= 0) {
      if (this.characterData.deathAreaEffect != null) {
        const deathArea = DataTables.getAreaEffectByName(this.characterData.deathAreaEffect)
        if (deathArea != null) this.triggerAreaEffect(deathArea, this.getX(), this.getY(), 0, 2)
      }
      if (this.areaEffect != null) this.gameObjectManager.removeGameObject(this.areaEffect)
    }
    return result
  }

  createBattleRoyaleItems (data, count) {
    if (data == null) return
    const Item = getItemClass()
    const battle = this.getBattle()
    const tileMap = battle.getTileMap()
    for (let i = 0; i < count; i++) {
      const drop = new LogicVector2()
      if (!GamePlayUtil.findSafeDropPosition(tileMap, this.getX(), this.getY(), 300, 400, drop)) continue
      const scatter = battle.getRandomInt(-400, 400)
      const target = new LogicVector2(drop.x + scatter, drop.y + scatter)
      if (!GamePlayUtil.findSafeDropPosition(tileMap, target.x, target.y, 0, 300, target)) target.set(drop.x, drop.y)
      const item = new Item(data)
      item.startJumpEffect(this.getX(), this.getY(), 0, target.x, target.y, 0)
      this.gameObjectManager.addGameObject(item)
    }
  }

  addItemsCollected (amount) {
    this.itemCount += amount
    if (this.gameObjectManager.getBattle().getGameModeVariation() === 3) this.itemCount = LogicMath.min(6, this.itemCount)
  }

  resetItemsCollected () {
    this.itemCount = 0
  }

  holdSkillStarted () {
    this.skillHoldTicks = 0
  }

  endRapidFire () {
    this.attacking = false
    const accessory = this.accessory
    if (!this.ultiSkill && accessory != null && accessory.isActive && accessory.type === 'next_attack_change' && accessory.accessoryData.activeTicks === 100000) {
      accessory.endAccessoryActivation()
    }
  }

  getWeaponSkill () {
    return this.skills.length > 0 ? this.skills[0] : null
  }

  getUltimateSkill () {
    return this.skills.length > 1 ? this.skills[1] : null
  }

  getPowerLevel () {
    if (this.characterData.uniqueProperty === 1) return this.chargeUpMax > 0 ? LogicMath.clamp(Math.trunc(3 * this.chargeUp / this.chargeUpMax), 0, 2) : 0
    const player = this.getPlayer()
    if (player != null) return player.powerLevel
    return 0
  }

  interruptAllSkills (ignoreAccessory = true) {
    this.chargeAnimation = 0
    this.isCharging = false
    for (const skill of this.skills) skill.interrupt(this)
    const player = this.getPlayer()
    if (player == null || player.accessory == null) return
    player.accessory.interrupt(ignoreAccessory, this)
  }

  addAreaEffect (bonus, aoeDot, data, skillType, a6) {
    if (data == null) {
      const player = this.getPlayer()
      const skinData = player != null ? player.skinData : null
      const skinConf = skinData != null ? DataTables.getByName(DataType.SkinConf, skinData.conf) : null
      if (this.getCardValueForPassiveFromPlayer('larger_area_ulti', 1) >= 1) {
        if (skinConf != null) data = DataTables.getAreaEffectByName(skinConf.areaEffectStarPower)
        if (data == null) data = DataTables.getAreaEffectByName('DamageBoost_larger')
        if (data == null) return
      } else if (this.getCardValueForPassiveFromPlayer('plugged_in', 1) >= 1) {
        if (skinConf != null) data = DataTables.getAreaEffectByName(skinConf.areaEffectStarPower2)
        if (data == null) data = DataTables.getAreaEffectByName('DamageBoostPlugIn')
        if (data == null) return
      } else if (this.getCardValueForPassiveFromPlayer('super_charge_area', 1) >= 1) {
        data = DataTables.getAreaEffectByName('RopeDudeSuperChargeAreaLarge')
        if (data == null) return
      } else {
        if (skinConf != null) data = DataTables.getAreaEffectByName(skinConf.areaEffect)
        if (data == null) data = DataTables.getAreaEffectByName(this.characterData.areaEffect)
        if (data == null) return
      }
    }
    const AreaEffect = getAreaEffectClass()
    this.areaEffect = new AreaEffect(data)
    this.areaEffect.setPosition(this.getX(), this.getY(), 0)
    this.areaEffect.setIndex(this.getIndex())
    this.areaEffect.setSource(this, skillType)
    this.areaEffect.aoeDot = aoeDot
    if (data.damage < 1) {
      this.areaEffect.damage = data.damage - bonus
      this.areaEffect.normalDMG = 0
    } else {
      this.areaEffect.damage = data.damage + bonus
      this.areaEffect.normalDMG = data.damage
    }
    this.gameObjectManager.addGameObject(this.areaEffect)
    this.areaEffect.trigger()
  }

  blockHealthRegen () {
    this.healthRegenBlockedTick = this.ticksGone
  }

  scheduleArcBombs (itemName) {
    const player = this.gameObjectManager.getBattle().getPlayerWithObject(this.getGlobalID())
    if (player == null) return
    const x = this.getX()
    const y = this.getY()
    const z = this.getZ()
    const start = this.ticksGone
    if (this.pendingArcBombs == null) this.pendingArcBombs = []
    const targets = [[x + 700, y, 0], [x - 700, y, 2], [x, y + 700, 3], [x, y - 700, 5]]
    for (const [tx, ty, delay] of targets) {
      this.pendingArcBombs.push({ tick: start + delay, itemName, startX: x, startY: y, startZ: z, targetX: tx, targetY: ty, teamIndex: player.teamIndex })
    }
    this.tickArcBombs()
  }

  tickArcBombs () {
    if (this.pendingArcBombs == null || this.pendingArcBombs.length === 0) return
    const ticksGone = this.ticksGone
    const ready = this.pendingArcBombs.filter(b => b.tick <= ticksGone)
    if (ready.length === 0) return
    this.pendingArcBombs = this.pendingArcBombs.filter(b => b.tick > ticksGone)
    const tileMap = this.getBattle().getTileMap()
    for (const bomb of ready) {
      const data = DataTables.getItemByName(bomb.itemName) || DataTables.getItemByName('Bomb')
      if (data == null) continue
      const item = GameObjectFactory.createGameObjectByData(data)
      if (item == null) continue
      const collision = new LogicVector2(bomb.targetX, bomb.targetY)
      const hitBorder = GamePlayUtil.getClosestLevelBorderCollision(bomb.startX, bomb.startY, bomb.targetX, bomb.targetY, tileMap, 0, collision)
      let spawnX = collision.x
      let spawnY = collision.y
      if (hitBorder) {
        const dx = spawnX - bomb.startX
        const dy = spawnY - bomb.startY
        const length = Math.sqrt(dx * dx + dy * dy)
        if (length !== 0) {
          spawnX = Math.trunc(spawnX + f32(dx / length) * -50)
          spawnY = Math.trunc(spawnY + f32(dy / length) * -50)
        }
      }
      item.setPosition(spawnX, spawnY, bomb.startZ)
      item.setIndex(16 * bomb.teamIndex)
      item.owner = this
      this.gameObjectManager.addGameObject(item)
    }
  }

  spawnBombsWithDelay () {
    this.scheduleArcBombs('Piper002Bomb')
  }

  spawnTickItems () {
    const player = this.gameObjectManager.getBattle().getPlayerWithObject(this.getGlobalID())
    if (player == null) return
    const skinData = player.skinData
    if (skinData == null) return
    const skinConf = DataTables.getByName(DataType.SkinConf, skinData.conf)
    if (skinConf == null) return
    this.scheduleArcBombs(skinConf.spawnedItem || 'PiperdefBomb')
  }

  toggleSam () {
    this.samState = !this.samState
  }

  toggleSamurai () {
    this.samuraiAttackSlashAttack = !this.samuraiAttackSlashAttack
  }

  triggerPortals (a1Pos, a2Pos) {
  }

  setControl (owner, ticks) {
    this.isControlled = true
    owner.controlledCharacter = this
  }

  activateSkill (type, x, y) {
    if (this.silence) return
    if (this.getZ() > 1) return
    const battle = this.getBattle()
    if (battle.getTicksGone() < 100) return
    const accessory = this.accessory
    if (this.isPlayerControlRemoved() || (accessory != null && accessory.accessoryData.interruptsAction && accessory.isActive)) return
    const skill = this.skills[type]
    if (skill == null) return
    const carryable = battle.carryable
    const carryingBall = carryable != null && carryable.carringCharacter === this
    const carryingFlag = battle.getGameModeVariation() === 16 && battle.ctf != null && battle.ctf.getCarriedFlagObject(this) != null
    if ((skill.isActive || skill.coolDown > 0) && !carryingBall && !carryingFlag) return
    const tileMap = battle.getTileMap()
    this.attackAngle = LogicMath.getAngle(x - this.getX(), y - this.getY())
    if (battle.getGameModeVariation() === 16 && battle.ctf != null && battle.ctf.tryThrow(this, this.attackAngle)) {
      skill.activateLaserBall(this, type)
      return
    }
    if (carryingBall) {
      let speed = type === 1 ? 3400 : 2000
      let distance = type === 1 ? 3600 : 2400
      if (battle.getGameModeVariation() === 21) {
        distance = type === 0 ? 3000 : 4200
        speed = type === 0 ? 2200 : 3200
      } else if (battle.getGameModeVariation() === 22) {
        distance = type === 0 ? 3800 : 5600
        speed = type === 0 ? 2400 : 3600
      }
      carryable.setPosition(this.getX(), this.getY(), 0)
      skill.activateLaserBall(this, type)
      carryable.carryablePickTicks = 10
      carryable.stopKicking()
      carryable.kick(this.attackAngle, speed, distance)
      carryable.setForcedVisible()
      carryable.carringCharacter = null
      if (battle.getGameModeVariation() === 21) battle.onHoldTheBallDropped()
      this.carryablePersonImunTicks = 15
      return
    }
    const ultimateSkillData = this.ultimateSkillData
    const spawnsBombs = type === 1 && ultimateSkillData != null && ultimateSkillData.name === 'SniperUlti'
    const activates = skill.charge >= 1000 || skill.skillData.maxCharge === 0
    skill.activate(this, x, y, tileMap)
    if (!activates) return
    if (spawnsBombs) this.spawnBombsWithDelay()
    if (type === 1 && this.getCardValueForPassive('speed_after_ulti', 1) >= 1) this.applyBuff(4, this.getCardValueForPassive('speed_after_ulti', 1), this.getCardValueForPassive('speed_after_ulti', 0), 10)
    if (skill.skillData.chargeType === 1) this.displayUltiTmp = true
    if (skill.skillData.chargeType === 15) {
      this.steerAngle = LogicMath.getAngle(x - this.getX(), y - this.getY())
      this.moveAngle = this.steerAngle
      this.activeChargeType = 15
      this.chargeSpeed = skill.skillData.chargeSpeed
      this.steerStartTicks = this.ticksGone
    }
  }

  hasUlti () {
    if (!this.characterData.isHero()) return this.characterData.isBoss()
    const player = this.getPlayer()
    if (player != null) return player.hasUlti()
    return false
  }

  triggerAreaEffect (data, x, y, bonusDamage, skillType) {
    const AreaEffect = getAreaEffectClass()
    const areaEffect = new AreaEffect(data)
    areaEffect.setPosition(x, y, 0)
    areaEffect.setIndex(this.getIndex())
    areaEffect.setSource(this, skillType)
    const normal = skillType === 1 ? areaEffect.getDamage(0) : 0
    areaEffect.damage = areaEffect.getDamage(0) + bonusDamage
    areaEffect.normalDMG = normal
    this.gameObjectManager.addGameObject(areaEffect)
    areaEffect.trigger()
    return areaEffect
  }

  getShootPositionModifiers (fromX, fromY, toX, toY, leftHand, forwardOffset, sideOffset) {
    const dx = toX - fromX
    const dy = toY - fromY
    const length = LogicMath.sqrt(dx * dx + dy * dy)
    let forwardX = dx
    let forwardY = dy
    if (length !== 0) {
      forwardX = Math.trunc(dx * forwardOffset / length)
      forwardY = Math.trunc(dy * forwardOffset / length)
    }
    let sideX = LogicMath.getRotatedX(dx, dy, 90)
    let sideY = LogicMath.getRotatedY(dx, dy, 90)
    const sideLength = LogicMath.sqrt(sideX * sideX + sideY * sideY)
    if (sideLength !== 0) {
      sideX = Math.trunc(sideX * sideOffset / sideLength)
      sideY = Math.trunc(sideY * sideOffset / sideLength)
    }
    const baseX = forwardX + fromX
    const baseY = forwardY + fromY
    if (leftHand !== 0) {
      this.attackOffsetX = baseX - sideX
      this.attackOffsetY = baseY - sideY
      this.attackOffset2X = -sideX
      this.attackOffset2Y = -sideY
    } else {
      this.attackOffsetX = sideX + baseX
      this.attackOffsetY = sideY + baseY
      this.attackOffset2X = sideX
      this.attackOffset2Y = sideY
    }
  }

  meleeAttack (target, X, Y, damage, normalDMG) {
    if (target == null) return
    if (GamePlayUtil.getDistanceBetween(this.getX(), this.getY(), target.getX(), target.getY()) <= this.characterData.autoAttackRange * 100) {
      target.causeDamage(this, damage, normalDMG, this.ultiSkill, null)
    }
  }

  rapidFireMeleeAttack (X, Y, damage, normalDMG, spread) {
    const dx = X - this.getX()
    const dy = Y - this.getY()
    const reach = LogicMath.sqrt(dx * dx + dy * dy)
    const aimAngle = LogicMath.getAngle(dy, dx)
    const halfCone = Math.fround(GamePlayUtil.radToDeg(GamePlayUtil.weaponSpreadToAngleRad(spread)) / 2)
    const tileMap = this.gameObjectManager.getBattle().getTileMap()
    for (const target of this.gameObjectManager.getGameObjects()) {
      if (target.getObjectType() !== 0) continue
      if (!target.isAlive()) continue
      if (teamOf(target.getIndex()) === teamOf(this.getIndex())) continue
      const tx = target.getX() - this.getX()
      const ty = target.getY() - this.getY()
      const distance = LogicMath.sqrt(tx * tx + ty * ty)
      if (distance > target.characterData.collisionRadius + reach) continue
      const angleBetween = LogicMath.getAngleBetween(aimAngle, LogicMath.getAngle(ty, tx))
      const extra = distance > 300 ? 10 : 0
      if (distance > 300 && angleBetween > extra + halfCone) continue
      const width = target.characterData.collisionRadius + 80
      if (!tileMap.calculateLOSWithCollision(this.getX(), this.getY(), target.getX(), target.getY(), width * 2)) continue
      const hit = target.causeDamage(this, damage, normalDMG, this.ultiSkill, null)
      if (hit && this.meleeAttackPushBacks) {
        target.triggerPushback(this.getX(), this.getY(), this.meleeAttackPushBack, false, 0, false, false, false, false, false, false, false, 0)
      }
    }
    this.meleeAttackPushBacks = false
  }

  handleHealFromDamage (damage, isUlti, target) {
    if (this.hitpoints < 1) return
    if (target == null) return
    if (!target.characterData.isHero()) return
    const value = target.getCardValueForPassive('ulti_heals_self', 1)
    if (value >= 1 && isUlti) target.heal(target.getIndex(), value, true, target.characterData)
  }

  getCurrentAttackSpeedTicks () {
    if (this.hasActiveSkill('Attack') && this.rapidFireMsBetweenAttacks >= 1) return Math.trunc(this.rapidFireMsBetweenAttacks / 50)
    if (this.castingTime >= 1) {
      for (const skill of this.skills) {
        if (skill.skillData.castingTime >= 1) return Math.trunc(skill.skillData.castingTime / 50)
      }
    }
    if (!this.characterData.isBoss()) {
      const weapon = this.getWeaponSkill()
      if (weapon != null) return Math.trunc(weapon.skillData.msBetweenAttacks / 50)
    }
    return Math.trunc(this.characterData.autoAttackSpeedMs / 50)
  }

  cripple (percent, ticks = 80) {
    this.isCrippled = true
    this.cripplePercent = percent
    this.crippleEndTick = this.ticksGone + ticks
  }

  setCharacterSummoningVariables (summonedCharacter, numSpawns, maxSpawns, damage, health) {
    this.summonedCharacter = summonedCharacter
    this.numSpawns = numSpawns
    this.maxSpawns = maxSpawns
    this.spawnDamage = damage
    this.spawnHealth = health
  }

  setItemSummoningVariables (itemData, numSpawns, maxSpawns, damage, normalDMG) {
    this.spawnedItem = itemData
    this.numSpawnsItem = numSpawns
    this.maxSpawnsItem = maxSpawns
    this.spawnedItemDamage = damage
    this.spawnedItemNormalDMG = normalDMG
  }

  getSkinProjectile (projectileData, player) {
    if (player == null || this.isControlled || projectileData == null) return projectileData
    const skinId = player.skinId
    if (!(skinId > 0)) return projectileData
    const skinData = DataTables.get(DataType.Skin).getDataByGlobalId(skinId)
    if (skinData == null) return projectileData
    const skinConf = DataTables.getByName(DataType.SkinConf, skinData.conf)
    if (skinConf == null) return projectileData
    const name = this.ultiSkill ? skinConf.ultiProjectile : skinConf.mainAttackProjectile
    const skinProjectile = name ? DataTables.getProjectileByName(name) : null
    if (skinProjectile == null) return projectileData
    if (this.isBlackListSkinPro(projectileData.name) || this.isBlackListSkinPro(skinProjectile.name)) return projectileData
    return skinProjectile
  }

  attack (autoAttackTarget, x, y, range, projectileData, damage, normalDMG, spread, bulletsPerShot, a11 = 0) {
    const Projectile = getProjectileClass()
    const battle = this.gameObjectManager.getBattle()
    const projectiles = []
    const player = this.getPlayer()
    let skinProjectileData = this.getSkinProjectile(projectileData, player)
    if (skinProjectileData != null && player != null && player.overCharging && skinProjectileData.name.endsWith('UltiProjectile')) {
      let overchargedName = this.characterData.name + 'OverchargedUltiProjectile'
      if (this.characterData.name === 'Maisie') overchargedName = 'MaisieOverchargedProjectile'
      else if (this.characterData.name === 'Rosa') overchargedName = 'RosaOverchargedProjectile'
      const overcharged = DataTables.getProjectileByName(overchargedName)
      if (overcharged != null) skinProjectileData = overcharged
    }
    if (skinProjectileData != null && this.characterData.name === 'WeaponThrower') {
      if (!this.samState) {
        const second = DataTables.getProjectileByName('WeaponThrowerProjectile2')
        if (skinProjectileData.name.startsWith('Bronson') && !skinProjectileData.name.endsWith('UltiProjectile')) {
          if (second != null) skinProjectileData = second
        } else if (skinProjectileData.name.startsWith(this.characterData.name) && skinProjectileData.name !== 'WeaponThrowerUltiProjectile') {
          if (second != null) skinProjectileData = second
        }
      } else if (skinProjectileData.name.endsWith('UltiProjectile')) {
        for (const item of this.gameObjectManager.getItems()) {
          if (item.owner !== this) continue
          if (player != null) player.chargeUlti(4000, false, false)
          item.pickedUp = true
          let recallName = 'WeaponThrowerUltiProjectile2'
          if (skinProjectileData.name === 'Bronson002UltiProjectile') recallName = 'Bronson002UltiProjectile2'
          else if (skinProjectileData.name === 'Bronson003UltiProjectile') recallName = 'Bronson003UltiProjectile2'
          else if (skinProjectileData.name === 'Bronson004UltiProjectile') recallName = 'Bronson004UltiProjectile2'
          const recall = Projectile.shootProjectile(-1, -1, this, this, DataTables.getProjectileByName(recallName), this.getX(), this.getY(), 0, 0, 0, false, skinProjectileData.speed, battle, 0, 1)
          if (recall != null) recall.homingTarget = this
        }
        return
      }
    }
    let newDMG = damage
    let speedDelta = 0
    const accessory = player == null ? null : player.accessory
    if (!this.ultiSkill && accessory != null && accessory.isActive && accessory.type === 'next_attack_change' && accessory.accessoryData.subType === 2) {
      if (accessory.accessoryData.customObject != null) {
        const replaced = DataTables.getProjectileByName(accessory.accessoryData.customObject)
        if (replaced != null) skinProjectileData = replaced
      }
      newDMG = Math.trunc(newDMG * (100 + accessory.accessoryData.customValue1) / 100)
      if (accessory.accessoryData.activeTicks === 100000) accessory.endAccessoryActivation()
    }
    const ticksGone = this.ticksGone
    const nextAttackTick = this.lastAttckTick + this.getCurrentAttackSpeedTicks()
    this.attackingTicks = LogicMath.clamp(nextAttackTick - ticksGone, 0, 63)
    if (nextAttackTick <= ticksGone) {
      const weaponSkillData = this.weaponSkillData
      if (!this.ultiSkill && this.getMaxChargedShots() >= 1 && this.characterData.uniqueProperty !== 10) {
        if (this.chargedShotCount < this.getMaxChargedShots()) {
          this.chargedShotMisses = 0
        } else if (weaponSkillData != null) {
          newDMG = Math.trunc(newDMG * weaponSkillData.damageModifier / 100)
          const skinConf = player != null ? player.skinConfData : null
          const name = skinConf != null && skinConf.secondaryProjectile ? skinConf.secondaryProjectile : weaponSkillData.secondaryProjectile
          const secondary = name ? DataTables.getProjectileByName(name) : null
          if (secondary != null) skinProjectileData = secondary
          this.chargedShotCount = 0
          this.chargedShotMisses++
        }
      }
      let specialEffect = false
      if (this.getCardValueForPassive('ambush', 1) >= 1 && !this.ultiSkill && this.isInBush()) {
        newDMG += this.getCardValueForPassive('ambush', 1)
        specialEffect = true
      }
      if (this.ultiSkill) {
        if (this.getCardValueForPassive('gain_damage_super', 1) !== -1) newDMG += this.getCardValueForPassive('gain_damage_super', 1)
        if (this.getCardValueForPassive('damage_ulti', 1) !== -1) newDMG += this.getCardValueForPassive('damage_ulti', 1)
      } else if (this.getCardValueForPassive('damage_main_attack', 1) !== -1) {
        newDMG += this.getCardValueForPassive('damage_main_attack', 1)
      }
      newDMG -= Math.trunc(this.cripplePercent * newDMG / 100)
      if (newDMG <= 1) newDMG = 1
      let staticDMG = 0
      if (accessory != null && accessory.isActive && !this.ultiSkill && accessory.type === 'next_attack_change' && accessory.accessoryData.subType === 4) {
        staticDMG = accessory.accessoryData.customValue1
        accessory.endAccessoryActivation()
      }
      this.lastAttckTick = ticksGone
      if (projectileData == null || skinProjectileData == null) {
        if (a11 === 3) this.rapidFireMeleeAttack(x, y, newDMG, normalDMG, spread)
        else this.meleeAttack(autoAttackTarget, 0, 0, newDMG, normalDMG)
      } else {
        this.shootAttackProjectiles(projectiles, x, y, projectileData, skinProjectileData, newDMG, spread, accessory, speedDelta, staticDMG, specialEffect, player, bulletsPerShot)
        this.shootIndex++
        if (this.rapidFireAttackPattern === 14) {
          const extra = this.getCardValueForPassive('attack_sequence_extra_steps', 1)
          this.jesterSkillCount++
          if (this.jesterSkillCount >= 3 + (extra > 0 ? extra : 0)) this.jesterSkillCount = 0
        }
      }
      this.attacking = false
      this.blockHealthRegen()
      this.setForcedVisible()
    }
    if (projectiles.length >= 1 && this.isInRealm) {
      for (const projectile of projectiles) projectile.isInRealm = true
    }
    this.attackAngle = LogicMath.getAngle(x - this.getX(), y - this.getY())
    const castingSkill = this.getCurrentCastingSkill()
    if (castingSkill != null && !castingSkill.canMoveAtSameTime && this.characterData.speed > 0) this.moveAngle = this.attackAngle
  }

  shootAttackProjectiles (projectiles, x, y, projectileData, skinProjectileData, newDMG, spread, accessory, speedDelta, staticDMG, specialEffect, player, bulletsPerShot) {
    const Projectile = getProjectileClass()
    const battle = this.gameObjectManager.getBattle()
    const skillType = this.ultiSkill ? 2 : 1
    const sideOffset = this.characterData.twoWeaponAttackEffectOffset
    this.getShootPositionModifiers(this.getX(), this.getY(), x, y, this.leftHand, 50, sideOffset)
    this.leftHand = this.leftHand === 0 ? 1 : 0
    const pattern = this.rapidFireAttackPattern
    const nextAttackActive = () => {
      const current = this.accessory
      return current != null && current.isActive && current.type === 'next_attack_change' ? current : null
    }
    if ((pattern >= 0 && pattern <= 6 && ((1 << pattern) & 78) !== 0) || pattern === 22) {
      const shootIndex = this.shootIndex
      let angleOffset = 0
      if (shootIndex % 3 === 2) angleOffset = -spread
      else if (shootIndex % 3 === 1) angleOffset = spread
      if (this.rapidFireShootTimes >= 5) {
        angleOffset = (LogicMath.sin(Math.trunc(1080 * shootIndex / (this.rapidFireShootTimes - 1))) * spread) >> 10
      }
      const times = LogicMath.max(2, this.rapidFireShootTimes)
      switch (pattern) {
        case 6:
          if (shootIndex !== 0) {
            const step = Math.trunc((shootIndex - ((shootIndex & 1) !== 0 ? 0 : 1)) / 2) + 1
            const dir = (shootIndex & 1) === 0 ? 1 : -1
            angleOffset = Math.trunc(Math.trunc(step * dir * spread / LogicMath.max(1, this.rapidFireShootTimes)) * 2)
          } else {
            angleOffset = 0
          }
          break
        case 3:
          angleOffset = (LogicMath.sin(Math.trunc(720 * shootIndex / (times - 1))) * spread) >> 10
          break
        case 2:
          angleOffset = Math.trunc(shootIndex * (2 * spread) / (times - 1)) - spread
          break
        case 22: {
          const baseAngle = Math.trunc(shootIndex * 360 / (times - 1))
          if (shootIndex % 2 === 0) angleOffset = (LogicMath.sin(baseAngle) * spread) >> 10
          else angleOffset = -(LogicMath.sin(baseAngle) * spread) >> 10
          break
        }
      }
      const projectile = Projectile.shootProjectile(this.attackOffsetX, this.attackOffsetY, this, this, skinProjectileData, this.attackOffset2X + x, this.attackOffset2Y + y, newDMG, this.rapidFireNormalDMG, angleOffset, true, -speedDelta, battle, shootIndex, skillType)
      if (projectile == null) return
      const healOthers = this.getCardValueForPassive('heal_others_main_attack', 1)
      if (healOthers >= 0) projectile.healOthersAreaEffect = healOthers
      const bounced = this.getCardValueForPassive('bounced_bullets_stronger', 1)
      if (bounced >= 0) projectile.damageAddFromBounce = bounced
      projectiles.push(projectile)
      const nac = nextAttackActive()
      if (nac != null) {
        if (nac.accessoryData.subType === 9) {
          projectile.attackSpecialParamsBounceHeal = nac.accessoryData.customValue1
        } else if (nac.accessoryData.subType === 10) {
          projectile.attackSpecialParamsStealBulletPercent = nac.accessoryData.customValue1
          projectile.attackSpecialParamsStealBulletPercentSelf = nac.accessoryData.customValue2
          projectile.specialEffect = true
        }
      }
      projectile.runEarlyTicks()
      return
    }
    if (bulletsPerShot >= 2) {
      const bullets = bulletsPerShot
      const gaps = bullets - 1
      let spreadStep = Math.trunc(2 * spread / gaps)
      let speedStep = Math.trunc(projectileData.speed / 7)
      let spreadStart = -spread
      const speedGroups = bullets === 5 ? 2 : 3
      if (projectileData.travelType === 3) {
        spreadStart = 0
        spreadStep = 0
        speedStep = 0
      }
      let localSpeedDelta = speedDelta
      if (!this.ultiSkill && accessory != null && accessory.isActive && accessory.type === 'next_attack_change' && accessory.accessoryData.subType === 1) {
        spreadStep = Math.trunc(Math.trunc(2 * accessory.accessoryData.customValue1 / gaps) / 5)
        spreadStart = -Math.trunc(accessory.accessoryData.customValue1 / 5)
        localSpeedDelta = accessory.accessoryData.customValue3
        if (accessory.accessoryData.activeTicks === 100000) accessory.endAccessoryActivation()
      }
      for (let b = 0; b !== bullets; b++) {
        let speedOffset = 0
        if (bullets >= 4) {
          const group = (b + this.shootIndex) % speedGroups
          if (group === 2) speedOffset = speedStep
          else if (group === 1) speedOffset = Math.trunc(speedStep / 2)
        }
        let targetOffsetX = 0
        let targetOffsetY = 0
        if (pattern === 5 && (b & 1) !== 0) {
          const vx = x - this.getX()
          const vy = y - this.getY()
          const length = LogicMath.sqrt(vx * vx + vy * vy)
          const speed = projectileData.speed
          if (length >= 1 && speed > 0) {
            const boosted = speed * (b & 1)
            speedOffset = Math.trunc(boosted / 4)
            const extra = Math.trunc(length / speed) * (speed - Math.trunc(boosted / 4)) - length
            targetOffsetX = Math.trunc(Math.trunc(extra * vx / length) / 2)
            targetOffsetY = Math.trunc(Math.trunc(extra * vy / length) / 2)
          }
        }
        if (pattern === 4) speedOffset = speedStep * b
        if (pattern === 13 || pattern === 10) {
          targetOffsetX = 0
          targetOffsetY = 0
          speedOffset = 0
        }
        let startOffsetX = 0
        let startOffsetY = 0
        let speedOut = speedOffset
        if (pattern === 7) {
          const vx = x - this.getX()
          const vy = y - this.getY()
          const length = LogicMath.sqrt(vx * vx + vy * vy)
          if (length >= 1) {
            const rx = LogicMath.getRotatedX(vx, vy, 90)
            const ry = LogicMath.getRotatedY(vx, vy, 90)
            const gap = 2 * projectileData.radius
            const half = Math.trunc(gap * gaps / 2)
            startOffsetY = Math.trunc(gap * b * ry / length) - Math.trunc(half * ry / length)
            startOffsetX = Math.trunc(gap * b * rx / length) - Math.trunc(half * rx / length)
            speedOut = 0
            targetOffsetX = startOffsetX
            targetOffsetY = startOffsetY
          }
        }
        const projectile = Projectile.shootProjectile(this.attackOffsetX + startOffsetX, this.attackOffsetY + startOffsetY, this, this, skinProjectileData, targetOffsetX + x + this.attackOffset2X, targetOffsetY + y + this.attackOffset2Y, newDMG, this.rapidFireNormalDMG, spreadStart + spreadStep * b, true, speedOut - localSpeedDelta, battle, b, skillType)
        if (projectile == null) continue
        projectiles.push(projectile)
        const nac = this.ultiSkill ? null : nextAttackActive()
        if (nac != null) {
          switch (nac.accessoryData.subType) {
            case 3:
              projectile.attackSpecialParamsStun = nac.accessoryData.customValue1
              break
            case 11:
              projectile.attackSpecialParamsWeaklyStun = nac.accessoryData.customValue1
              break
            case 7:
              projectile.damage += Math.trunc(projectile.damage * nac.accessoryData.customValue2 / 100)
              projectile.attackSpecialParamsPushback = -nac.accessoryData.customValue1
              break
          }
        }
        if (projectileData.healOwnPercent > 0) {
          const superHeal = this.getCardValueForPassive('damage_super', 1)
          if (superHeal >= 0) projectile.healing = -superHeal
        } else {
          const mainHeal = this.getCardValueForPassive('heal_main_attack', 1)
          if (mainHeal >= 0) {
            projectile.healing = mainHeal
            projectile.specialEffect = true
          }
        }
        const crippleValue = this.getCardValueForPassive('cripple', 1)
        if (crippleValue >= 0) projectile.cripplePercent = crippleValue
        if (this.ultiSkill) {
          const freeze = this.getCardValueForPassive('freeze', 1)
          if (freeze >= 0) projectile.setFreeze(freeze, this.getCardValueForPassive('freeze', 0))
        } else {
          const basicFreezeLength = this.getCardValueForPassive('basic_freeze', 0)
          if (basicFreezeLength >= 0) projectile.setFreeze(this.getCardValueForPassive('basic_freeze', 1), basicFreezeLength)
        }
        const prey = this.getCardValueForPassive('prey_on_the_weak', 1)
        if (prey >= 0) projectile.setPreyOnTheWeak(prey, this.getCardValueForPassive('prey_on_the_weak', 0))
        if (!projectile.projectileData.damageOnlyWithOneProj) projectile.runEarlyTicks()
      }
      const nac = this.ultiSkill ? null : nextAttackActive()
      if (nac != null && nac.accessoryData.activeTicks !== 100000) nac.endAccessoryActivation()
      if (projectiles.length > 1 && projectileData.damageOnlyWithOneProj) {
        for (const projectile of projectiles) {
          for (const other of projectiles) {
            if (projectile === other) continue
            projectile.linkedProjectileGIDs.push(other.getGlobalID())
          }
          projectile.runEarlyTicks()
        }
      }
      return
    }
    if (!projectileData.indirect && !projectileData.isFriendlyHomingMissile) {
      const projectile = Projectile.shootProjectile(this.attackOffsetX, this.attackOffsetY, this, this, skinProjectileData, this.attackOffset2X + x, this.attackOffset2Y + y, newDMG + this.getGearBoost(16) * 2, this.rapidFireNormalDMG, spread, false, -speedDelta, battle, 0, skillType)
      if (projectile == null) return
      projectiles.push(projectile)
      const weapon = this.skills[0]
      if (weapon != null && weapon.skillData.percentDamage >= 1) {
        projectile.percentDamage = weapon.skillData.percentDamage
        projectile.attackSpecialParamsMinPercentDamage = 750 + this.getGearBoost(16)
        projectile.attackSpecialParamsDamageBuff = this.getDamageBuffTemporary()
        projectile.attackSpecialParamsDamageDebuff = this.cripplePercent
        let distance = 600
        let guess = null
        const aim = new LogicVector2(x, y)
        for (const gameObject of this.gameObjectManager.getGameObjects()) {
          if (gameObject.getObjectType() !== 0) continue
          if (teamOf(gameObject.getIndex()) === teamOf(this.getIndex())) continue
          const d = gameObject.getPosition().getDistance(aim)
          if (d > distance) continue
          distance = d
          guess = gameObject
        }
        projectile.displayScale = guess != null ? LogicMath.clamp(Math.trunc(guess.hitpoints / 10) - 100, 100, 1000) : 250
      }
      if (staticDMG >= 1) projectile.attackSpecialParamsStaticPercentDamage = staticDMG
      if (this.getCardValueForPassive('attack_pierce', 1) >= 0 && this.chargeUp >= this.chargeUpMax) {
        projectile.canPierceCharacter = true
        this.chargeUp = 0
      }
      const nac = nextAttackActive()
      if (nac != null) {
        if (nac.accessoryData.subType === 5) {
          this.setDraggingObject(projectile, 0, 0)
        } else if (nac.accessoryData.subType === 13) {
          projectile.attackSpecialParamsTrailArea = nac.accessoryData.customObject
          projectile.attackSpecialParamsTrailAreaInterval = nac.accessoryData.customValue1
        }
      }
      const spawnedItem = this.spawnedItem
      if (spawnedItem != null && skinProjectileData.parentProjectileForSkin !== 'WeaponThrowerUltiProjectile' && spawnedItem.name !== 'SilencerHugger') {
        projectile.setItemSummonProjectileData(spawnedItem, this.numSpawnsItem, this.maxSpawnsItem, this.spawnedItemDamage, this.spawnedItemNormalDMG, this)
      } else if (spawnedItem != null && skinProjectileData.parentProjectileForSkin === 'WeaponThrowerUltiProjectile') {
        let itemName = 'Bronson002Weapon'
        if (skinProjectileData.name === 'Bronson003UltiProjectile') itemName = 'Bronson003Weapon'
        else if (skinProjectileData.name === 'Bronson004UltiProjectile') itemName = 'Bronson004Weapon'
        const itemData = DataTables.getItemByName(itemName)
        if (itemData != null) projectile.setItemSummonProjectileData(itemData, this.numSpawnsItem, this.maxSpawnsItem, this.spawnedItemDamage, this.spawnedItemNormalDMG, this)
      }
      projectile.specialEffect = specialEffect
      projectile.runEarlyTicks()
      return
    }
    this.attackOffset2X += x
    this.attackOffset2Y += y
    let targetY = this.attackOffset2Y
    if (pattern === 9) {
      const slot = this.shootIndex % 5
      const distance = GamePlayUtil.getDistanceBetween(this.getX(), this.getY(), this.attackOffset2X, this.attackOffset2Y)
      const maxSpread = Projectile.getSpreadMax(projectileData, spread, distance)
      let offX = 0
      let offY = 0
      switch (slot) {
        case 1:
          offX = -maxSpread
          offY = -maxSpread
          break
        case 2:
          offX = maxSpread
          offY = -maxSpread
          break
        case 3:
          offX = -maxSpread
          offY = maxSpread
          break
        case 4:
          offX = maxSpread
          offY = maxSpread
          break
      }
      const LogicRandom = require('../../../Titan/Math/LogicRandom')
      const random = new LogicRandom(this.shootIndex + 12345)
      const quarter = Math.trunc(maxSpread / 4)
      const jitterX = offX - quarter + Math.trunc(random.rand(1000) * quarter / 500)
      const jitterY = offY - quarter + Math.trunc(random.rand(1000) * quarter / 500)
      this.attackOffset2X = LogicMath.clamp(this.attackOffset2X + jitterX, 1, this.mapWidth - 2)
      targetY = LogicMath.clamp(this.attackOffset2Y + jitterY, 1, this.mapHeight - 2)
      this.attackOffset2Y = targetY
    }
    const lobbed = Projectile.shootProjectile(this.attackOffsetX, this.attackOffsetY, this, this, skinProjectileData, this.attackOffset2X, targetY, newDMG, this.rapidFireNormalDMG, 0, false, -speedDelta, battle, this.shootIndex, skillType)
    if (lobbed == null) return
    projectiles.push(lobbed)
    if (this.summonedCharacter != null) lobbed.setCharacterSummonProjectileData(this.summonedCharacter, this.numSpawns, this.maxSpawns, this.spawnDamage, this.spawnHealth, this.starPowerIC)
    if (this.getCardValueForPassive('increased_explosion', 1) >= 0 && !this.ultiSkill && this.chargeUp >= this.chargeUpMax) {
      let areaEffectData = null
      if (player != null && player.skinConfData != null) areaEffectData = DataTables.getAreaEffectByName(player.skinConfData.areaEffectStarPower)
      if (areaEffectData == null) areaEffectData = DataTables.getAreaEffectByName('WallyExplosionBig')
      this.chargeUp = 0
      if (areaEffectData != null) projectiles[0].attackSpecialParamsAreaEffectData = areaEffectData
    }
    if (this.getCardValueForPassive('aoe_dot', 1) !== -1) {
      let aoeDot = Math.trunc((this.getCardValueForPassive('aoe_dot', 1) / 1000) * this.maxHitpoints)
      if (this.getCardValueForPassive('aoe_dot', 2) !== -1) aoeDot = Math.trunc(aoeDot * 0.23658) + 2
      if (aoeDot !== -1) projectiles[0].aoeDot = aoeDot
    }
    if (!this.ultiSkill) {
      const selfHeal = this.getCardValueForPassive('heal_self_main_attack', 1)
      if (selfHeal >= 0) this.heal(this.getIndex(), selfHeal, false, this.characterData)
    }
  }
  shouldDestruct () {
    return this.hitpoints <= 0 && this.destructafterticks < 1
  }

  isChargeActive () {
    return this.isCharging
  }

  getHitpointPercentage () {
    if (this.maxHitpoints <= 0) return 0
    return Math.trunc(f32(f32(this.hitpoints / this.maxHitpoints) * 100))
  }

  hasActiveSkill (type) {
    if (type === undefined) {
      if (this.skills.length === 0) return false
      if (this.skills.length === 1) return this.skills[0].isActive
      return this.skills[0].isActive || this.skills[1].isActive
    }
    for (const skill of this.skills) {
      if (skill.skillData.behaviorType === type && skill.ticksActive > 0) return true
    }
    return false
  }

  getActiveSkill (type) {
    for (const skill of this.skills) {
      if (skill.skillData.behaviorType === type && skill.ticksActive > 0) return skill.skillData
    }
    return null
  }

  getCurrentActiveOrCastingSkill () {
    for (const skill of this.skills) {
      if (skill.ticksActive > 0) return skill.skillData
    }
    return null
  }

  getSkill (type) {
    for (const skill of this.skills) {
      if (skill.skillData.behaviorType === type) return skill
    }
    return null
  }

  isSteerMovementActive () {
    for (const skill of this.skills) {
      if (skill.ticksActive > 0 && skill.skillData.chargeType === 15) return true
    }
    return false
  }

  isImmuneAndBulletsGoThrough (isInRealm = false) {
    const accessory = this.accessory
    if (accessory != null && accessory.type === 'dive' && accessory.isActive) return true
    if (!!this.isInRealm !== !!isInRealm) return true
    const v2 = this.activeChargeType - 2
    if ((!this.isCharging || v2 >= 16 || ((0x4293 >> v2) & 1) === 0) && !this.isSteerMovementActive()) {
      return !!this.knockback3
    }
    return true
  }

  getControlledProjectile () {
    for (const gameObject of this.gameObjectManager.getGameObjects()) {
      if (gameObject.getObjectType() === 1 && gameObject.getIndex() === this.getIndex() && gameObject.projectileData.travelType === 5) return gameObject
    }
    return null
  }

  triggerWhirlwind (damage, normalDMG, speedIncrease) {
    this.chargeDamage = damage
    this.chargeNormalDMG = normalDMG
    this.ultiSkill = true
    this.chargeHitGIDs = []
    this.applyBuff(4, 2, speedIncrease, 0)
    if (this.getCardValueForPassive('ulti_defense', 1) > 0) this.addShield(this.getCardValueForPassive('ulti_defense', 1), this.getCardValueForPassive('ulti_defense', 0))
  }

  tickChargeHitGIDs () {
    if (this.chargeHitGIDs == null) {
      this.chargeHitGIDs = []
      return
    }
    for (let i = 0; i < this.chargeHitGIDs.length; i++) {
      const ignoring = this.chargeHitGIDs[i]
      ignoring.ticks--
      if (ignoring.ticks <= 0) {
        this.chargeHitGIDs.splice(i, 1)
        i--
      }
    }
  }

  isChargeHit (gid) {
    return this.chargeHitGIDs != null && this.chargeHitGIDs.some(ignoring => ignoring.gid === gid)
  }

  destructTilesAround (radius) {
    const tileMap = this.getBattle().getTileMap()
    const tileX = Math.trunc(this.getX() / 300)
    const tileY = Math.trunc(this.getY() / 300)
    const xMin = LogicMath.clamp(tileX - 2, 0, tileMap.width - 1)
    const yMin = LogicMath.clamp(tileY - 2, 0, tileMap.height - 1)
    const xMax = LogicMath.clamp(tileX + 2, 0, tileMap.width - 1)
    const yMax = LogicMath.clamp(tileY + 2, 0, tileMap.height - 1)
    for (let i = xMin; i <= xMax; i++) {
      for (let j = yMin; j <= yMax; j++) {
        const dx = i * 300 + 150 - this.getX()
        const dy = j * 300 + 150 - this.getY()
        if (dx * dx + dy * dy <= radius * radius) {
          const tile = tileMap.getTile(i, j, true)
          if (tile != null) tile.destruct()
        }
      }
    }
  }

  tickWhirlwind () {
    const skillData = this.getActiveSkill('Ww')
    if (skillData == null) return
    this.applyBuff(4, 2, skillData.msBetweenAttacks, 0)
    let damage = this.chargeDamage
    damage += Math.trunc(this.chargeDamage * this.getDamageBuffTemporary() / 100)
    damage -= Math.trunc(this.chargeDamage * this.cripplePercent / 100)
    this.tickChargeHitGIDs()
    if (this.knockback3) return
    const range = 100 * skillData.castingRange
    for (const gameObject of this.gameObjectManager.getGameObjects()) {
      if (gameObject.getObjectType() !== 0) continue
      const character = gameObject
      if (!character.isAlive() || teamOf(character.getIndex()) === teamOf(this.getIndex()) || character.isImmuneAndBulletsGoThrough(this.isInRealm)) continue
      const dx = character.getX() - this.getX()
      const dy = character.getY() - this.getY()
      if (LogicMath.abs(dx) > range || LogicMath.abs(dy) > range) continue
      if (dx * dx + dy * dy > range * range) continue
      if (this.isChargeHit(character.getGlobalID())) continue
      this.chargeHitGIDs.push({ gid: character.getGlobalID(), ticks: 5 })
      character.causeDamage(this, damage, this.chargeNormalDMG, this.ultiSkill, null, true)
    }
    this.getBattle().getTileMap().destroyEnvironment(this.getX(), this.getY(), range, true)
    const destroyWalls = this.getCardValueForPassive('super_destroy_walls', 1)
    if (destroyWalls <= 0) return
    this.destructTilesAround(destroyWalls - 100)
  }

  tickCharge () {
    let radius = 0
    const type = this.activeChargeType
    if (type === 1 || type === 3 || type === 4 || (type === 5 && this.chargeDamage >= 1) || type === 7 || type === 9 || type === 10 || type === 12 || type === 8 || type === 14 || type === 16) {
      radius = this.characterData.isBoss() ? 800 : 400
      if (type === 9 || type === 3) radius = 800
      let damage = this.chargeDamage
      damage += Math.trunc(this.chargeDamage * this.getDamageBuffTemporary() / 100)
      damage -= Math.trunc(this.chargeDamage * this.cripplePercent / 100)
      if (type === 7 || type === 10 || this.characterData.isTrain()) this.tickChargeHitGIDs()
      if (this.chargeHitGIDs == null) this.chargeHitGIDs = []
      for (const gameObject of this.gameObjectManager.getGameObjects()) {
        if (gameObject.getObjectType() !== 0) continue
        const character = gameObject
        if (!character.isAlive() || teamOf(character.getIndex()) === teamOf(this.getIndex()) || character.isImmuneAndBulletsGoThrough(this.isInRealm)) continue
        const dx = character.getX() - this.getX()
        const dy = character.getY() - this.getY()
        if (LogicMath.abs(dx) > radius || LogicMath.abs(dy) > radius) continue
        if (dx * dx + dy * dy > radius * radius) continue
        if (this.isChargeHit(character.getGlobalID())) continue
        if (this.activeChargeType === 10) {
          this.chargeHitGIDs.push({ gid: character.getGlobalID(), ticks: 100 })
          damage = GamePlayUtil.calculatePercentDamage(this.chargePercentDamage, this.chargeDamage, true, this.getDamageBuffTemporary(), this.cripplePercent, Math.trunc(this.chargeDamage / 4), character)
          this.chargeNormalDMG = 1000
        } else if (!this.characterData.isTrain()) {
          this.chargeHitGIDs.push({ gid: character.getGlobalID(), ticks: 10 })
        }
        if (character.causeDamage(this, damage, this.chargeNormalDMG, this.ultiSkill, null, true)) {
          this.chargeHits++
          if (this.getCardValueForPassive('fire_dot_ulti', 1) >= 1) character.applyPoison(this.getIndex() % 16, this.getCardValueForPassive('fire_dot_ulti', 1), 0, true, this, 2)
          if (this.getCardValueForPassive('push_charge', 1) >= 1 && this.shouldExecuteColetteChargeOnReturn && character.isAlive()) {
            if ((character.characterData.isHero() || character.characterData.isTrainingDummy()) && this.ticksGone + 2 < this.moveEnd) {
              character.setDraggingObject(this, character.getX() - this.getX(), character.getY() - this.getY())
            }
          }
          const shieldPerHit = this.getCardValueForPassive('shield_charge', 0)
          if (shieldPerHit >= 1) this.addShield(this.getCardValueForPassive('shield_charge', 2), this.getCardValueForPassive('shield_charge', 1) + this.chargeHits * shieldPerHit)
          if (this.getCardValueForPassive('charge_ulti_on_kill', 1) >= 1 && !character.isAlive()) {
            const player = this.getPlayer()
            if (player != null) player.chargeUlti(4000, false, true)
          }
        }
        character.triggerPushback(this.getX(), this.getY(), this.chargePushback, true, 0, false, false, false, false, false, false, false, 0)
        if (this.activeChargeType === 8) {
          this.isCharging = false
          this.stopMovement()
          if (this.fangHitGIDs == null) this.fangHitGIDs = []
          this.fangHitGIDs.push(character.getGlobalID())
          const ulti = this.getUltimateSkill()
          if (this.fangUltiCount <= 2 && ulti != null) {
            let target = null
            let distance = ulti.skillData.castingRange * 50
            for (const other of this.gameObjectManager.getGameObjects()) {
              if (other.getObjectType() !== 0 || !other.isAlive()) continue
              if (teamOf(other.getIndex()) === teamOf(this.getIndex())) continue
              if (other.isImmuneAndBulletsGoThrough(this.isInRealm)) continue
              const d = GamePlayUtil.getDistanceBetween(this.getX(), this.getY(), other.getX(), other.getY())
              if (d >= distance || this.fangHitGIDs.includes(other.getGlobalID())) continue
              distance = d
              target = other
            }
            if (target != null) {
              const hitGIDs = this.chargeHitGIDs
              const fangHitGIDs = this.fangHitGIDs.slice()
              const count = this.fangUltiCount
              this.triggerCharge(target.getX(), target.getY(), this.chargeSpeed, this.activeChargeType, this.chargeDamage, this.chargePushback, false)
              this.chargeHitGIDs = hitGIDs
              this.fangHitGIDs = fangHitGIDs
              this.fangUltiCount = count + 1
            }
          }
          return
        }
      }
    }
    if (this.characterData.name === 'Roller' && this.isChargeActive()) {
      const area = DataTables.getAreaEffectByName('RollerFire')
      if (area != null) {
        const areaEffect = new (getAreaEffectClass())(area)
        areaEffect.setPosition(this.getX(), this.getY(), 0)
        areaEffect.setIndex(this.getIndex())
        areaEffect.setSource(this, 2)
        areaEffect.damage = area.damage
        areaEffect.normalDMG = area.damage
        this.gameObjectManager.addGameObject(areaEffect)
        areaEffect.trigger()
      }
    }
    if (this.activeChargeType === 101) {
      const currentX = this.getX()
      const currentY = this.getY()
      let canSpawn = true
      if (this.spawnedEffects.length >= 5) {
        canSpawn = false
      } else if (this.lastX !== -1 && this.lastY !== -1) {
        const distance = Math.trunc(Math.sqrt((currentX - this.lastX) * (currentX - this.lastX) + (currentY - this.lastY) * (currentY - this.lastY)))
        if (distance < 550) canSpawn = false
      }
      if (canSpawn) {
        const area = DataTables.getAreaEffectByName('PainterAreaExplosion')
        if (area != null) {
          const areaEffect = new (getAreaEffectClass())(area)
          areaEffect.setPosition(currentX, currentY, 0)
          areaEffect.setIndex(this.getIndex())
          areaEffect.setSource(this, 2)
          areaEffect.damage = 1500
          areaEffect.normalDMG = 1500
          this.gameObjectManager.addGameObject(areaEffect)
          areaEffect.trigger()
          this.spawnedEffects.push(areaEffect)
          this.lastX = currentX
          this.lastY = currentY
        }
      }
    }
    if ((this.activeChargeType | 2) !== 3 && !this.chargeBreaksEnvironment) return
    this.destructTilesAround(radius)
  }

  getCurrentCastingSkill () {
    for (const skill of this.skills) {
      if (skill.onActivate && skill.skillData.castingTime > 0) return skill.skillData
      if (skill.ticksActive >= 1) return skill.skillData
    }
    return null
  }

  getDamageBuffTemporary () {
    let buff = 0
    for (const b of this.buffs) {
      if (b.type === 1 || b.type === 2 || b.type === 5) buff += b.modifier
    }
    const player = this.getPlayer()
    if (player != null && player.overCharging) buff += this.characterData.overchargeDamagePercent > 0 ? this.characterData.overchargeDamagePercent : 20
    return buff
  }

  getBuffedHealthRegen () {
    let buff = 0
    for (const b of this.buffs) {
      if (b.type === 10) buff++
    }
    return buff
  }

  tickRapidFire () {
    this.state = 2
    const castingSkill = this.getCurrentCastingSkill()
    if (castingSkill != null) {
      const projectileData = castingSkill.projectile ? DataTables.getProjectileByName(castingSkill.projectile) : null
      if (projectileData == null || (!projectileData.indirect && projectileData.travelType !== 6)) {
        this.attackTarget.x = this.attackVector.x + this.getX()
        this.attackTarget.y = this.attackVector.y + this.getY()
      }
    }
    let damage = this.rapidFireDamage
    const a11 = this.rapidFireProjectile == null ? 3 : 0
    damage += Math.trunc(this.getDamageBuffTemporary() * damage / 100)
    if (this.rapidFireAttackPattern === 12) {
      const distance = Math.trunc(Math.trunc(Math.trunc(this.chargeSpeed / 20) * this.rapidFireMsBetweenAttacks) / 50)
      this.attack(null, this.getX() + LogicMath.getRotatedX(distance, 0, this.moveAngle), this.getY() + LogicMath.getRotatedY(distance, 0, this.moveAngle), this.rapidFireRange, this.rapidFireProjectile, damage, this.rapidFireNormalDMG, this.rapidFireSpread, this.rapidFireBulletsPerShoot, a11)
    } else {
      this.attack(null, this.attackTarget.x, this.attackTarget.y, this.rapidFireRange, this.rapidFireProjectile, damage, this.rapidFireNormalDMG, this.rapidFireSpread, this.rapidFireBulletsPerShoot, a11)
    }
    this.attacking = true
    this.rapidFireTick = this.ticksGone
  }

  hasCcImmunity () {
    return this.ccImmunityTicks > 0
  }

  updateMoveDirection (a1, a2, a3, a4, a5) {
    this.movementVector = new LogicVector2(a2.x - a3.x, a2.y - a3.y)
    this.movementVector.normalize(256)
    let result = LogicMath.getAngle(this.movementVector.x, this.movementVector.y)
    if (this.slippery) {
      let angleDiff = (result - this.moveAngle) % 360
      if (angleDiff > 180) angleDiff -= 360
      if (angleDiff < -180) angleDiff += 360
      if (angleDiff > 6) result = this.moveAngle + 6
      else if (angleDiff < -6) result = this.moveAngle - 6
      result = LogicMath.normalizeAngle360(result)
    }
    if (this.movementVector.x !== 0 || this.movementVector.y !== 0) this.moveAngle = result
    if (this.knockBacked && !(this.knockback1 || this.knockback3)) {
      this.moveAngle = result + 180
      if (result + 180 >= 360) {
        result -= 180
        this.moveAngle = result
      }
    }
    return result
  }

  triggerPushback (triggerPosX, triggerPosY, pushbackLength, a5, a6, ignoreInvincible, a8, a9, ignoreCcImmunity, a11, a12, a13, a14, maxX = -1, maxY = -1) {
    if (this.characterData.isCarryable()) return
    if (this.knockback2 && !a12) return
    if (this.isInvincible && !ignoreInvincible) return
    const blocked = this.knockBacked && this.knockback1
    if (blocked && !a9) {
      if (!a13) return
      this.knockback1 = false
      this.moveStart = this.ticksGone - 1
      this.moveEnd = this.ticksGone - 1
    }
    if (!ignoreCcImmunity && this.hasCcImmunity()) return
    this.knockback2 = a12
    if (!(this.characterData.speed > 0 || this.characterData.isTrainingDummy())) return
    if (this.isCharging && this.activeChargeType <= 10 && ((1 << this.activeChargeType) & 0x482) !== 0) {
      if (pushbackLength === 0 || !a9) return
    } else if (pushbackLength === 0) {
      return
    }
    let length = pushbackLength
    if (!a12) length = Math.trunc(pushbackLength / 2)
    if (a9 || a8 || this.characterData.collisionRadius < 150 || pushbackLength < 1) length = pushbackLength
    const battle = this.gameObjectManager.getBattle()
    const tileMap = battle.getTileMap()
    if (this.getX() === triggerPosX && this.getY() === triggerPosY) {
      let rx = battle.getRandomInt(10, 100)
      let ry = battle.getRandomInt(10, 100)
      if (battle.getRandomInt(0, 2) === 1) ry = -ry
      if (battle.getRandomInt(0, 2) === 1) rx = -rx
      triggerPosX = LogicMath.clamp(rx + triggerPosX, 1, tileMap.logicWidth - 2)
      triggerPosY = LogicMath.clamp(ry + triggerPosY, 1, tileMap.logicHeight - 2)
    }
    const direction = new LogicVector2(this.getX() - triggerPosX, this.getY() - triggerPosY)
    let distance = 6 * LogicMath.abs(length)
    if (length <= -1) distance = LogicMath.min(distance, direction.getLength())
    direction.normalize(distance)
    let targetX
    let targetY
    if (length < 1) {
      targetX = this.getX() - direction.x
      targetY = this.getY() - direction.y
    } else {
      targetX = this.getX() + direction.x
      targetY = this.getY() + direction.y
    }
    this.knockback1 = false
    this.knockBacked = true
    if (!ignoreInvincible) {
      const startX = this.getX()
      const startY = this.getY()
      if (maxX !== -1) {
        targetX = startX > maxX ? LogicMath.max(maxX, targetX) : LogicMath.min(maxX, targetX)
        targetY = startY > maxY ? LogicMath.max(maxY, targetY) : LogicMath.min(maxY, targetY)
      }
      const collision = new LogicVector2(-1, -1)
      GamePlayUtil.getClosestAnyCollision(startX, startY, targetX, targetY, tileMap, collision, 0, 1, 0, 1, this.immunToPushbackOutOfWalls)
      if (collision.x !== -1) {
        let dx = collision.x - startX
        let dy = collision.y - startY
        const d = LogicMath.sqrt(dx * dx + dy * dy)
        if (d > 0) {
          const back = d <= 20 ? LogicMath.max(1, d - 5) : 20
          dx = Math.trunc((d - back) * dx / d)
          dy = Math.trunc((d - back) * dy / d)
        }
        targetX = dx + startX
        targetY = dy + startY
      }
    } else {
      this.knockback3 = true
      const spot = new LogicVector2()
      GamePlayUtil.getClosestLevelBorderCollision(this.getX(), this.getY(), targetX, targetY, tileMap, 1, spot)
      if (GamePlayUtil.getClosestPassableSpot(1, targetX, targetY, 10, tileMap, spot, false)) {
        targetX = spot.x
        targetY = spot.y
      }
    }
    targetX = LogicMath.clamp(targetX, 101, tileMap.logicWidth - 102)
    targetY = LogicMath.clamp(targetY, 101, tileMap.logicHeight - 102)
    this.interruptAllSkills()
    if (this.getCardValueForPassive('ulti_defense', 1) >= 0) this.shieldTicks = 0
    this.pathfindTo(0, targetX, targetY, 0, 0, 0, 0, 0, 0)
    const baseSpeed = length < 0 ? -8 * length : 12 * length
    this.chargeSpeed = baseSpeed
    if (a12) {
      this.chargeSpeed = 2 * baseSpeed
    } else if (a11) {
      this.chargeSpeed = LogicMath.max(1, Math.trunc(baseSpeed / 2))
    } else if (a8) {
      const factor = length > 500 ? 4 : 6
      this.chargeSpeed = LogicMath.max(1, Math.trunc(Math.trunc(factor * baseSpeed / 14) / 2))
    } else if (ignoreInvincible) {
      this.chargeSpeed = LogicMath.max(1, Math.trunc(baseSpeed / 2))
    }
    if (this.chargeSpeed <= 0) this.chargeSpeed = 1
    const pathLength = this.getPathLength()
    this.pathLength = pathLength
    if (pathLength >= 1) {
      this.moveStart = this.ticksGone
      this.moveEnd = LogicMath.max(1, Math.trunc(20 * pathLength / this.chargeSpeed)) + this.ticksGone
    }
    if (a8) this.chargeSpeed = LogicMath.max(1, Math.trunc(13 * this.chargeSpeed / 14))
    if (!a5) this.chargeSpeed = 0
    const projectile = this.getControlledProjectile()
    if (projectile != null) projectile.targetReached(5)
  }

  getNextSteeredPos (out) {
    const speed = this.chargeSpeed
    const direction = LogicMath.normalizeAngle360(this.moveAngle - this.steerAngle) < 180 ? 1 : -1
    const turn = LogicMath.min(LogicMath.getAngleBetween(this.steerAngle, this.moveAngle), 8)
    this.moveAngle = LogicMath.normalizeAngle360(this.moveAngle + turn * direction)
    const tileMap = this.getBattle().getTileMap()
    out.x = this.getX() + Math.trunc(Math.trunc(Math.trunc(LogicMath.cos(this.moveAngle) * speed) / 1024) / 20)
    out.y = this.getY() + Math.trunc(Math.trunc(Math.trunc(LogicMath.sin(this.moveAngle) * speed) / 1024) / 20)
    out.x = LogicMath.clamp(out.x, 101, tileMap.logicWidth - 102)
    out.y = LogicMath.clamp(out.y, 101, tileMap.logicHeight - 102)
    this.attackAngle = this.moveAngle
    let total = f32(0.1)
    let scaled = f32(0.1)
    if (speed * 0.1 > 0.1) scaled = f32(speed * f32(0.1))
    const height = f32(f32(-0.015) * 300)
    if (f32(8400 / scaled) > 0.1) total = f32(8400 / scaled)
    const progress = f32(Math.trunc(8400 * (this.ticksGone - this.steerStartTicks) / 120) / scaled)
    const value = f32(f32(height * progress) * f32(progress - total))
    if (!Number.isFinite(value)) return 0
    return LogicMath.clamp(Math.trunc(value), 0, 1500)
  }

  getPosAtTick (a1, tick, a3, a4) {
    const moveStart = this.moveStart
    const moveEnd = this.moveEnd
    if (moveEnd === moveStart || this.ticksGone > moveEnd) {
      this.posDelta.x = this.getX()
      this.posDelta.y = this.getY()
      return 0
    }
    const progress = Math.trunc(1000 * LogicMath.min(tick - moveStart + (this.isBot === 0 || this.isBot === false ? 1 : 0), moveEnd - moveStart) / (moveEnd - moveStart))
    const travelled = Math.trunc(this.pathLength * progress / 1000)
    let dx = this.wayPointStart.x - this.wayPoint.x
    let dy = this.wayPointStart.y - this.wayPoint.y
    const length = LogicMath.sqrt(dx * dx + dy * dy)
    if (length >= 1) {
      dx = Math.trunc(dx * (travelled - length) / length)
      dy = Math.trunc(dy * (travelled - length) / length)
    }
    this.posDelta.x = this.wayPoint.x - dx
    this.posDelta.y = this.wayPoint.y - dy
    if ((!this.isCharging || !GamePlayUtil.isJumpCharge(this.activeChargeType)) && !this.knockBacked) return 0
    if (this.chargeSpeed === 0) return 0
    let v39 = 0
    if (!this.isCharging) {
      const root = LogicMath.sqrt(this.pathLength)
      if (root === 0) return 0
      v39 = -6.25 / root
    } else {
      const arc = (scale) => {
        const t = f32(progress / f32(1000))
        const a = f32(f32(f32(4 * t) * f32(1 - t)))
        return LogicMath.clamp(Math.trunc(f32(a * scale)), 0, 3000)
      }
      switch (this.activeChargeType) {
        case 2: return arc(1600)
        case 6: return arc(1800)
        case 3: return arc(1500)
        case 11: return arc(1800)
        case 16:
          v39 = -0.25
          break
        default: return arc(2000)
      }
    }
    let value
    if (this.isCharging && this.activeChargeType === 9) {
      value = Character.jumpHeight9(progress * 0.001)
    } else {
      let v32 = 0.1
      if (this.chargeSpeed * 0.1 > 0.1) v32 = this.chargeSpeed * 0.1
      let v31 = 0.1
      if (this.pathLength / v32 > 0.1) v31 = this.pathLength / v32
      const v42 = Math.trunc(this.pathLength * progress / 1000) / v32
      value = (v39 * 300 * v42) * (v42 - v31)
    }
    if (!Number.isFinite(value)) return 0
    return LogicMath.clamp(Math.trunc(value), 0, 3000)
  }

  static jumpHeight9 (a2) {
    if (a2 >= 0.5) {
      if (a2 < 0.7) return 2250
      const a1 = a2 * 3.3333 + -2.0
      return Math.trunc(2250.0 + a1 * a1 * a1 * (0.0 - 2250.0))
    }
    const a1 = a2 + a2
    return Math.trunc(0.0 + ((a1 + -1.0) * (a1 + -1.0) * (a1 + -1.0) + 1.0) * (2250.0 - 0.0))
  }

  getSkillHoldedTicks () {
    if (this.skillHoldTicks < 0) return 0
    return LogicMath.min(this.skillHoldTicks, this.getMaxHoldTicks())
  }

  tickInvisibility () {
    this.visibilityState = 0
    if (this.invisibleTicks < 1) {
      this.isInvisible = false
      this.yellowEye = false
    } else {
      this.invisibleTicks--
      if (this.invisibleTicks < 1) {
        this.visibilityState = 2
        this.invisibleTicks = 0
        this.isInvisible = false
        this.yellowEye = false
      } else {
        this.isInvisible = true
      }
    }
    const skillData = this.getActiveSkill('Invisibility')
    if (skillData != null) {
      if (this.invisibleTicks <= 0) this.visibilityState = 1
      this.invisibleTicks = 3
      this.breakInvisibilityOnAttack = skillData.breakInvisibilityOnAttack
      this.seeInvisibilityDistance = skillData.seeInvisibilityDistance
      if (this.getCardValueForPassive('speed_invisible', 1) >= 0) this.applyBuff(4, 10, this.getCardValueForPassive('speed_invisible', 1), 0)
    }
  }

  getData () {
    return this.characterData
  }

  triggerRapidFire (x, y, attp, bps, msb, projectileData, damage, range, spread, actime, normalDMG, EFAI) {
    if (this.longerDashExtraBullets > 0 && this.activeChargeType === 4) {
      bps += this.longerDashExtraBullets
      this.longerDashExtraBullets = 0
    }
    this.meleeAttackPushBacks = false
    if (this.characterData.name === 'CannonGirlSmall') {
      if (this.chargeUpType === 1 && this.chargeUp >= this.chargeUpMax) {
        damage += 240
        this.addShield(10, 40)
        this.chargeUp = 0
      }
    } else if (this.chargeUpType === 1) {
      if (this.chargeUp >= this.chargeUpMax && this.skills.length > 0) {
        this.meleeAttackPushBacks = true
        this.meleeAttackPushBack = this.skills[0].skillData.chargePushback
      }
      this.chargeUp = 0
    }
    this.attacking = true
    let vx = x - this.getX()
    let vy = y - this.getY()
    if (projectileData != null && (projectileData.indirect || projectileData.travelType === 6)) {
      this.attackTarget = new LogicVector2(x, y)
    } else {
      const length = LogicMath.sqrt(vx * vx + vy * vy)
      if (length > 0) {
        vx = Math.trunc(vx * 100 * range / length)
        vy = Math.trunc(vy * 100 * range / length)
      }
    }
    this.attackVector = new LogicVector2(vx, vy)
    this.skillHoldTicks = -1
    this.rapidFireAttackPattern = attp
    this.rapidFireBulletsPerShoot = bps
    this.rapidFireDamage = damage
    this.rapidFireNormalDMG = normalDMG
    this.rapidFireMsBetweenAttacks = msb
    this.rapidFireProjectile = projectileData
    this.rapidFireRange = range
    this.rapidFireSpread = spread
    this.rapidFireX = x
    this.rapidFireY = y
    this.shootIndex = 0
    this.leftHand = 0
    if (this.ultiSkill && this.getCardValueForPassive('more_bullets_ulti', 1) >= 1) this.rapidFireMsBetweenAttacks = this.getCardValueForPassive('more_bullets_ulti', 0)
    const unloadSpeed = this.getCardValueForPassive('decrease_unload_time', 1)
    if (!this.ultiSkill && unloadSpeed >= 1) this.rapidFireMsBetweenAttacks -= Math.trunc(this.rapidFireMsBetweenAttacks * unloadSpeed / 100)
    if (this.characterData.uniqueProperty === 1) this.rapidFireDamage += Math.trunc(this.rapidFireDamage * this.getPowerLevel() / 2)
    const accessory = this.accessory
    if (accessory != null && accessory.type === 'take_damage' && accessory.accessoryData.subType === 3 && accessory.isActive) {
      this.rapidFireDamage += Math.trunc(accessory.rewindHP / 2)
      accessory.endAccessoryActivation(this)
    }
    this.rapidFireShootTimes = this.rapidFireMsBetweenAttacks > 0 ? Math.trunc(actime / this.rapidFireMsBetweenAttacks) : 1
    if (!this.ultiSkill && accessory != null && accessory.isActive && accessory.type === 'next_attack_change' && accessory.accessoryData.subType === 14) {
      this.rapidFireBulletsPerShoot = accessory.accessoryData.customValue1
      this.rapidFireSpread = accessory.accessoryData.customValue2
      this.rapidFireDamage += Math.trunc(this.rapidFireDamage * accessory.accessoryData.customValue3 / 100)
      if (accessory.accessoryData.activeTicks === 100000) accessory.endAccessoryActivation(this)
    }
    this.lastAttckTick = EFAI ? -100 : this.ticksGone
    if (this.isInvisible && this.breakInvisibilityOnAttack) {
      for (const skill of this.skills) {
        if (skill.skillData.behaviorType === 'Invisibility') skill.ticksActive = 0
      }
    }
    for (const skill of this.skills) {
      if (skill.skillData.behaviorType === 'ProjectileShield') skill.ticksActive = 0
    }
  }

  pauseMovement () {
    if (this.moveEnd >= this.ticksGone) {
      this.moveStart++
      this.moveEnd++
    }
  }

  getPathLength () {
    const dx = this.wayPoint.x - this.wayPointStart.x
    const dy = this.wayPoint.y - this.wayPointStart.y
    return LogicMath.sqrt(dx * dx + dy * dy)
  }

  setForcedAngle (angle) {
    this.moveAngle = angle
    this.attackAngle = angle
    this.forcedAngleTicks = this.ticksGone
  }

  tickProjectileShield () {
    this.projectileShieldCoolDown = LogicMath.max(0, this.projectileShieldCoolDown - 1)
    for (const gameObject of this.gameObjectManager.getGameObjects()) {
      if (gameObject.getObjectType() !== 1) continue
      if (teamOf(gameObject.getIndex()) === teamOf(this.getIndex())) continue
      const distance = gameObject.getPosition().getDistance(this.position)
      if (distance > this.projectileShieldScale + 100 || distance < this.projectileShieldScale - 100) continue
      const angle = LogicMath.getAngle(gameObject.getX() - this.getX(), gameObject.getY() - this.getY())
      if (LogicMath.getAngleBetween(angle, this.attackAngle) > Math.trunc(this.projectileShieldAngle / 2)) continue
      gameObject.targetReached(3)
      if (this.projectileShieldCoolDown === 0) this.projectileShieldCoolDown = 8
    }
  }

  isPet () {
    if (this.teamIndex !== -1) return false
    if (this.getIndex() < 0) return false
    return !this.characterData.isHero()
  }

  findMinionPathNode (target, straight) {
    const tileMap = this.gameObjectManager.getBattle().getTileMap()
    const pathFinder = new LogicPathFinder(tileMap, false, !!this.characterData.canWalkOverWater)
    const start = new LogicVector2(LogicMath.clamp(this.getX(), 300, tileMap.logicWidth - 300), LogicMath.clamp(this.getY(), 300, tileMap.logicHeight - 300))
    const end = new LogicVector2(LogicMath.clamp(target.getX(), 300, tileMap.logicWidth - 300), LogicMath.clamp(target.getY(), 300, tileMap.logicHeight - 300))
    const points = pathFinder.findPath(start, end)
    if (points == null || points.length === 0) return null
    if (!straight) return points[LogicMath.min(1, points.length - 1)]
    let node = points[0]
    for (let i = 0; i < points.length; i++) {
      if (points[i].x !== node.x && points[i].y !== node.y) {
        node = points[i - 1]
        break
      }
      if (i === points.length - 1) {
        node = points[i]
        break
      }
    }
    return node
  }

  swapVoodooWeapon (name) {
    const skillData = DataTables.getByName(DataType.Skill, name)
    if (skillData == null || this.skills.length === 0) return
    const current = this.skills[0]
    if (current.skillData === skillData) return
    const skill = new Skill(skillData.getGlobalId(), false, this)
    skill.charge = LogicMath.min(skill.maxCharge, current.charge)
    this.skills[0] = skill
  }

  handleMoveAndAttack () {
    const gameObjectManager = this.gameObjectManager
    const battle = gameObjectManager.getBattle()
    const ticksGone = this.ticksGone
    if (this.characterData.name === 'Voodoo') {
      const inBush = this.isInBush()
      const inWater = this.isInWater()
      if (!inBush && !inWater) this.swapVoodooWeapon('VoodooWeaponEarth')
      if (inBush && !inWater) this.swapVoodooWeapon('VoodooWeaponForest')
      if (inWater && !inBush) this.swapVoodooWeapon('VoodooWeaponWater')
    }
    if (this.characterData.name === 'KnightPet_Fixed') {
      let target = this.isHealer ? this.getTeammateForHeal() : this.getEnemy()
      if (target == null) target = gameObjectManager.getGameObjectByID(this.parentGID)
      if (target != null) {
        const node = this.findMinionPathNode(target, true)
        if (node != null) {
          this.botHadPathThisTick = true
          this.moveTo(0, node.x, node.y, 0, 0, 0, 0)
        }
      }
      this.ticksSinceBotEnemyCheck = ticksGone
      const enemyInZone = gameObjectManager.getGameObjects().some(g => g.getObjectType() === 0 && g.isAlive() && teamOf(g.getIndex()) !== teamOf(this.getIndex()) && !g.characterData.isCarryable() && this.position.getDistance(g.getPosition()) <= 600)
      if (enemyInZone) {
        const data = DataTables.getAreaEffectByName('KnightPetExplosion')
        if (data != null) {
          const explosion = GameObjectFactory.createGameObjectByData(data)
          explosion.setPosition(this.getX(), this.getY(), 0)
          explosion.setIndex(this.getIndex())
          const owner = gameObjectManager.getGameObjectByID(this.parentGID)
          const damage = 160
          explosion.setSource(owner, 1)
          explosion.damage = damage
          gameObjectManager.addGameObject(explosion)
          explosion.trigger()
          if (owner != null && owner.getObjectType() === 0) owner.chargeUp += Math.trunc(damage / 6) + Math.trunc(Math.trunc(damage / 6) * owner.getPowerLevel() / 4)
        }
        gameObjectManager.removeGameObject(this)
        return
      }
    }
    const carryVariation = battle != null ? battle.getGameModeVariation() : -1
    if (carryVariation === 5 || carryVariation === 21 || carryVariation === 22) {
      const carryable = battle.carryable
      if (carryable != null && carryable !== this && this.position.getDistance(carryable.getPosition()) < 300 &&
        this.carryablePersonImunTicks <= 0 && carryable.carringCharacter == null && this.characterData.isHero() &&
        this.getZ() <= 0 && !this.knockBacked && carryable.carryablePickTicks <= 0 &&
        (carryVariation !== 22 || battle.goalTicks <= 0) && !this.isChargeActive()) {
        carryable.carringCharacter = this
        if (carryVariation === 21) battle.onHoldTheBallPickedUp()
      }
      if (this.characterData.isCarryable()) {
        if (this.carringCharacter != null && !this.carringCharacter.isAlive()) {
          this.carringCharacter = null
          if (carryVariation === 21) battle.onHoldTheBallDropped()
        }
        const carrier = this.carringCharacter
        if (carrier != null && carrier.characterData.isHero()) {
          this.setPosition(carrier.getX() + LogicMath.getRotatedX(200, 0, carrier.attackAngle), carrier.getY() + LogicMath.getRotatedY(200, 0, carrier.attackAngle), 0)
          const player = carrier.getPlayer()
          if (player != null) {
            this.lastPickupPlayerIndex = player.teamIndex
            this.lastPickupPlayerIndexTOCHNO = player.playerIndex
          }
        }
      }
    }
    for (const obj of gameObjectManager.getGameObjects()) {
      if (this.position.getDistance(obj.getPosition()) <= 900 && teamOf(obj.getIndex()) !== teamOf(this.getIndex())) obj.setForcedVisible()
      if (this.characterData.isHero() && obj.getObjectType() === 3) {
        if (this.position.getDistance(obj.getPosition()) < 350 && obj.canBePickedUp(this) && !this.isImmuneAndBulletsGoThrough(obj.isInRealm)) obj.pickUp(this)
      }
    }
    const active = this.hasActiveSkill('Attack')
    if (!active && !this.isCharging && !this.hasActiveSkill('ProjectileShield')) this.ultiing = false
    const attackingState = active || this.hasActiveSkill('ProjectileShield')
    let shouldHandleMoveAndAttack
    if (ticksGone < this.deployedTick + Character.DEPLOY_TICKS && !this.characterData.isHero()) {
      this.state = 4
      this.blockHealthRegen()
      shouldHandleMoveAndAttack = false
      this.pauseMovement()
    } else {
      shouldHandleMoveAndAttack = true
      if (this.castingTime >= 1) {
        this.state = 0
        this.blockHealthRegen()
        const castingSkill = this.getCurrentCastingSkill()
        if (castingSkill != null && !castingSkill.canMoveAtSameTime) this.pauseMovement()
      } else if (this.hasActiveSkill('Ww')) {
        this.state = 0
        this.blockHealthRegen()
        this.tickWhirlwind()
      } else {
        if (active) {
          this.state = 2
          this.setForcedVisible()
          this.blockHealthRegen()
          if (this.rapidFireTick !== ticksGone) this.tickRapidFire()
        } else if (this.stunTicks >= 1) {
          this.state = 0
          this.healthRegenBlockedTick = ticksGone
          this.stunTicks--
        } else {
          this.isWeaklyStunned = false
        }
        if (this.hasActiveSkill('ProjectileShield')) {
          this.state = 2
          this.tickProjectileShield()
        }
      }
    }
    if (this.draggingObject != null) {
      const dragging = this.draggingObject
      if (dragging.getObjectType() === 0) {
        if (dragging.isAlive() && ticksGone < dragging.moveEnd - 2 && dragging.isCharging) {
          const targetX = this.draggingOffsetX + dragging.getX()
          const targetY = this.draggingOffsetY + dragging.getY()
          const collision = new LogicVector2(-1, -1)
          if (GamePlayUtil.getClosestAnyCollision(this.getX(), this.getY(), targetX, targetY, battle.getTileMap(), collision, 0, 0, 0, 0, dragging.immunToPushbackOutOfWalls)) {
            this.setPosition(dragging.getX() + 1, dragging.getY(), 0)
          } else {
            this.setPosition(targetX, targetY, this.getZ())
          }
        } else {
          this.draggingObject = null
        }
      } else if (dragging.isAlive() && dragging.state === 0) {
        this.setPosition(this.draggingOffsetX + dragging.getX(), this.draggingOffsetY + dragging.getY(), 0)
      } else {
        this.draggingObject = null
      }
    }
    if (!shouldHandleMoveAndAttack) return
    let chargeAnimation = 0
    let target = null
    if (this.isCharging) {
      this.setForcedVisible()
      if (!GamePlayUtil.isJumpCharge(this.activeChargeType) || ticksGone === this.moveEnd) this.tickCharge()
      chargeAnimation = LogicMath.clamp(ticksGone - this.moveStart, 0, 255)
    }
    this.chargeAnimation = chargeAnimation
    if (!this.isPlayerControlRemoved() && this.characterData.hasAutoAttack() && this.characterData.autoAttackRange >= 1 && !this.isInvincible) {
      target = this.getClosestEnemy(this.characterData.autoAttackRange, 1, this.characterData.isBase(), false, null, false, false, false)
      if (this.attacking) target = null
    }
    if (this.attacking) this.attacking = false
    if (target != null && GamePlayUtil.losCleared(this.position.x, this.position.y, target.position.x, target.position.y, battle.getTileMap())) {
      this.attacking = true
      this.autoAttackTarget = target
    }
    if (this.autoAttackTarget != null && this.autoAttackTarget.position.getDistance(this.position) <= this.characterData.autoAttackRange * 100 && this.autoAttackTarget.isAlive()) {
      if (!this.characterData.isHero() && !this.isPlayerControlRemoved()) this.stopMovement()
    }
    if (ticksGone > this.moveEnd && !this.isSteerMovementActive()) {
      const charging = this.isCharging
      if (this.isCharging && (this.activeChargeType === 2 || this.activeChargeType === 11) && this.chargeAreaEffectData != null) {
        const areaEffect = new (getAreaEffectClass())(this.chargeAreaEffectData)
        areaEffect.setPosition(this.getX(), this.getY(), 0)
        areaEffect.setIndex(this.getIndex())
        areaEffect.setSource(this, 2)
        areaEffect.damage = this.chargeDamage
        areaEffect.normalDMG = this.chargeNormalDMG
        const prey = this.getCardValueForPassive('prey_on_the_weak', 1)
        if (prey >= 0) areaEffect.setPreyOnTheWeak(prey, this.getCardValueForPassive('prey_on_the_weak', 0))
        gameObjectManager.addGameObject(areaEffect)
        areaEffect.trigger()
        if (this.getCardValueForPassive('charge_end_damage', 1) >= 0) {
          const data = DataTables.getAreaEffectByName('EnragerStarPowerDamage')
          if (data != null) {
            const extra = new (getAreaEffectClass())(data)
            extra.setPosition(this.getX(), this.getY(), 0)
            extra.setIndex(this.getIndex())
            extra.setSource(this, 2)
            extra.normalDMG = 0
            gameObjectManager.addGameObject(extra)
            extra.trigger()
          }
        }
      }
      if (this.activeChargeType === 19) {
        for (const gameObject of gameObjectManager.getGameObjects()) {
          if (gameObject.getObjectType() !== 0 || gameObject === this) continue
          if (!gameObject.characterData.isHero()) continue
          if (this.position.getDistance(gameObject.getPosition()) > 1000) continue
          this.attached = true
          this.attachedCharacter = gameObject
        }
      }
      if (this.isCharging && this.activeChargeType === 105) {
        if (!this.ultiNoStun) {
          const data = DataTables.getAreaEffectByName('PullRopeStun')
          if (data != null) {
            const areaEffect = new (getAreaEffectClass())(data)
            areaEffect.setPosition(this.getX(), this.getY(), 0)
            areaEffect.setIndex(this.getIndex())
            areaEffect.setSource(this, 2)
            areaEffect.damage = this.chargeDamage
            areaEffect.normalDMG = this.chargeNormalDMG
            const prey = this.getCardValueForPassive('prey_on_the_weak', 1)
            if (prey >= 0) areaEffect.setPreyOnTheWeak(prey, this.getCardValueForPassive('prey_on_the_weak', 0))
            gameObjectManager.addGameObject(areaEffect)
            areaEffect.trigger()
          }
        }
        this.ultiNoStun = false
      }
      if (this.isCharging && this.activeChargeType === 101) {
        this.spawnedEffects = []
        this.lastX = -1
        this.lastY = -1
      }
      this.isCharging = false
      this.knockback3 = false
      this.chargeAnimation = 0
      this.knockback2 = false
      this.knockBacked = false
      this.viusalChargeType = 0
      if (charging) {
        if (this.shouldExecuteColetteChargeOnReturn && this.wayPoint2 != null) {
          this.shouldExecuteColetteChargeOnReturn = false
          this.triggerCharge(this.wayPoint2.x, this.wayPoint2.y, this.chargeSpeed, this.activeChargeType, this.chargeDamage, this.chargePushback, false)
        }
        const speedAfterUlti = this.getCardValueForPassive('speed_after_ulti', 1)
        if (speedAfterUlti >= 0) this.giveSpeedFasterBuff(speedAfterUlti, this.getCardValueForPassive('speed_after_ulti', 0), true)
        if (this.getCardValueForPassive('barrel_defense', 1) >= 0) this.addShield(this.getCardValueForPassive('barrel_defense', 1), this.getCardValueForPassive('barrel_defense', 0))
      }
      if (!this.characterData.hasAutoAttack() || this.autoAttackTarget == null) {
        this.state = attackingState ? 2 : 0
      } else {
        this.state = 2
        const autoTarget = this.autoAttackTarget
        const projectileData = this.characterData.autoAttackProjectile ? DataTables.getProjectileByName(this.characterData.autoAttackProjectile) : null
        const damage = this.characterData.autoAttackDamage + this.autoAttackDamangeBoost
        const healTarget = this.isHealer ? this.getTeammateForHeal() : null
        if (this.characterData.name !== 'KnightPet_Fixed' && !this.isHealer && autoTarget.isAlive() && autoTarget.position.getDistance(this.position) <= this.characterData.autoAttackRange * 100 && GamePlayUtil.losCleared(this.position.x, this.position.y, autoTarget.position.x, autoTarget.position.y, battle.getTileMap())) {
          this.attack(autoTarget, autoTarget.getX(), autoTarget.getY(), this.characterData.autoAttackRange, projectileData, damage, this.characterData.autoAttackDamage, this.characterData.autoAttackProjectileSpread, this.characterData.autoAttackBulletsPerShot)
        } else if (healTarget != null) {
          this.attack(healTarget, healTarget.getX(), healTarget.getY(), this.characterData.autoAttackRange, projectileData, damage, this.characterData.autoAttackDamage, this.characterData.autoAttackProjectileSpread, this.characterData.autoAttackBulletsPerShot)
        } else {
          this.autoAttackTarget = null
        }
      }
    } else {
      const height = this.isSteerMovementActive() ? this.getNextSteeredPos(this.posDelta) : this.getPosAtTick(0, ticksGone, this.posDelta, 0)
      const prevX = this.position.x
      const prevY = this.position.y
      this.setPosition(this.posDelta.x, this.posDelta.y, height)
      this.state = attackingState ? 3 : 1
      if (this.position.x !== prevX || this.position.y !== prevY) {
        if (this.forcedAngleTicks + 1 < ticksGone && !this.isSteerMovementActive()) this.updateMoveDirection(0, this.wayPoint, this.posDelta, this.wayPoint.x, this.wayPoint.y)
        if (this.state === 1) this.attackAngle = this.moveAngle
        const moved = LogicMath.sqrt((this.position.x - prevX) * (this.position.x - prevX) + (this.position.y - prevY) * (this.position.y - prevY))
        const ultiPerStep = this.getCardValueForPassive('running_charges_ulti', 0)
        if (ultiPerStep >= 0) {
          const player = this.getPlayer()
          if (player != null && !player.hasUlti()) {
            const step = this.getCardValueForPassive('running_charges_ulti', 1)
            if (!this.isPlayerControlRemoved() && step > 0) {
              const total = this.runningChargingUlti + moved
              const steps = Math.trunc(total / step)
              this.runningChargingUlti = total - steps * step
              if (steps >= 1) this.chargeUlti(steps * ultiPerStep, false, true, player, this)
            }
          } else {
            this.runningChargingUlti = 0
          }
        }
        const weaponStep = this.getCardValueForPassive('running_charges_weapon', 1)
        const weapon = this.getWeaponSkill()
        if (weaponStep > 0 && weapon != null) {
          if (weapon.hasFullCharge(this)) {
            this.runningChargingUlti = 0
          } else if (!this.isPlayerControlRemoved()) {
            const total = this.runningChargingUlti + moved
            const steps = Math.trunc(total / weaponStep)
            this.runningChargingUlti = total - steps * weaponStep
            if (steps >= 1) weapon.addCharge(this, this.getCardValueForPassive('running_charges_weapon', 0) * steps)
          }
        }
      }
    }
    this.handleMinionBehaviour()
    if (this.displayUltiTmp && !this.isCharging) this.displayUltiTmp = false
  }

  handleMinionBehaviour () {
    const gameObjectManager = this.gameObjectManager
    const ticksGone = this.ticksGone
    const name = this.characterData.name
    if (name === 'SpawnerPet' && gameObjectManager.getGameObjectByID(this.parentGID) == null) {
      gameObjectManager.removeGameObject(this)
      return
    }
    if ((name === 'SpawnerDudeTurret' || name === 'SpawnerDudeTurret002' || name === 'SpawnerDudeTurret003') && ticksGone > this.ticksSinceBotEnemyCheck + 10) {
      const petData = this.characterData.pet ? DataTables.getCharacterByName(this.characterData.pet) : null
      if (petData != null) Character.summonMinion(petData, this.getX(), this.getY(), 0, 1, 1, 0, 0, this.getBattle(), this.getIndex() % 16, teamOf(this.getIndex()), this.getGlobalID(), false, false, 0, false, 0)
      this.ticksSinceBotEnemyCheck = ticksGone
    }
    if (this.characterData.type === 'Minion_FindEnemies' && name !== 'KnightPet_Fixed') {
      let target = this.isHealer ? this.getTeammateForHeal() : this.getEnemy()
      if (name === 'ClusterBombPet') {
        if (target != null && GamePlayUtil.getDistanceBetween(this.getX(), this.getY(), target.getX(), target.getY()) <= 600) {
          const data = this.characterData.deathAreaEffect ? DataTables.getAreaEffectByName(this.characterData.deathAreaEffect) : null
          if (data != null) {
            const explosion = GameObjectFactory.createGameObjectByData(data)
            explosion.setPosition(this.getX(), this.getY(), 0)
            explosion.setSource(this, 1)
            explosion.setIndex(this.getIndex())
            explosion.damage = this.characterData.autoAttackDamage
            explosion.normalDMG = this.characterData.autoAttackDamage
            gameObjectManager.addGameObject(explosion)
            explosion.trigger()
          }
          gameObjectManager.removeGameObject(this)
          return
        }
        const destination = target != null ? target : gameObjectManager.getGameObjectByID(this.parentGID)
        if (destination != null) {
          const node = this.findMinionPathNode(destination, false)
          if (node != null) {
            const savedSlow = this.slowingModifier
            this.slowingModifier = 70
            this.moveTo(0, node.x, node.y, 0, 0, 0, 0)
            this.slowingModifier = savedSlow
          }
        }
        this.ticksSinceBotEnemyCheck = ticksGone
      } else {
        if (target == null) target = gameObjectManager.getGameObjectByID(this.parentGID)
        if (target != null && ticksGone > this.ticksSinceBotEnemyCheck + 10) {
          const node = this.findMinionPathNode(target, false)
          if (node != null) this.moveTo(0, node.x, node.y, 0, 0, 0, 0)
          this.ticksSinceBotEnemyCheck = ticksGone
        }
      }
    }
    if (this.characterData.type === 'Minion_Duplicate' && this.parentGID === 0) this.causeDamage(null, 99999, 99999, false, null)
  }

  checkObstacle (nextTiles) {
    let movingSpeed = Math.trunc(this.characterData.speed / 20)
    movingSpeed *= Math.trunc((100 - this.slowingModifier) / 100)
    movingSpeed *= Math.trunc((100 + this.acceleratingModifier) / 100)
    let newX = this.position.x
    let newY = this.position.y
    const battle = this.gameObjectManager.getBattle()
    for (let i = 0; i < nextTiles; i++) {
      const dx = this.posDelta.x - this.position.x
      const dy = this.posDelta.y - this.position.y
      newX += dx > 0 ? LogicMath.min(movingSpeed, dx) : LogicMath.max(-movingSpeed, dx)
      newY += dy > 0 ? LogicMath.min(movingSpeed, dy) : LogicMath.max(-movingSpeed, dy)
      if (!battle.isInPlayArea(newX, newY)) return true
      const tile = battle.getTileMap().getTile(newX, newY)
      if (tile == null) return true
      if (tile.data.blocksMovement && !tile.isDestructed()) return true
    }
    return false
  }

  ultiEnabled () {
    this.usingUltiCurrently = true
  }

  ultiDisabled () {
    this.usingUltiCurrently = false
  }

  isAlive () {
    return this.hitpoints > 0
  }

  getRadius () {
    return this.characterData.collisionRadius
  }

  getWeaponSkillDamage () {
    const weaponSkillData = this.weaponSkillData
    if (weaponSkillData == null) return 0
    return Math.floor(weaponSkillData.damage * (1.0 + this.heroLevel / 10.0))
  }

  setHeroLevel (level) {
    this.heroLevel = level
    this.maxHitpoints = Math.floor(this.characterData.hitpoints * (1.0 + level / 10.0))
    this.hitpoints = this.maxHitpoints
    this.orginalMaxHP = this.maxHitpoints
    this.setStarPowerBoosts()
  }

  getHeroLevel () {
    return this.heroLevel
  }

  getNormalWeaponDamage () {
    if (this.skills.length === 0) return 0
    const damage = this.skills[0].skillData.damage
    return damage + Math.trunc(f32(f32(5 / 100) * damage)) * (this.heroLevel + this.damageMultiplier)
  }

  getAbsoluteDamage (damage) {
    return damage + Math.trunc(f32(f32(5 / 100) * damage)) * (this.heroLevel + this.damageMultiplier) + Math.trunc(damage * this.damageModifier / 100)
  }

  pathfindTo (a1, x, y) {
    this.wayPoint.x = x
    this.wayPoint.y = y
    this.wayPointStart.x = this.getX()
    this.wayPointStart.y = this.getY()
    return 0
  }

  getGearBoost (logicType) {
    for (const gear of [this.gear1, this.gear2]) {
      if (gear != null && gear.gearData != null && gear.gearData.logicType === logicType) {
        if (typeof gear.onBoost === 'function') gear.onBoost()
        return gear.gearData.modifierValue
      }
    }
    return 0
  }

  watch (target) {
    this.setStartRotation(LogicMath.getAngle(target.getX() - this.getX(), target.getY() - this.getY()))
  }

  isPlayerControlRemoved () {
    if (this.viusalChargeType > 0) return false
    const player = this.getPlayer()
    if (player != null && player.accessory != null && player.accessory.isActive && player.accessory.accessoryData.stopMovement) return true
    if (!this.isCharging && !this.knockBacked && this.stunTicks <= 0) return this.draggingObject != null
    return true
  }

  ultiUsed () {
    const player = this.getPlayer()
    if (player != null) {
      if (!this.getBattle().hasEventModifier(13)) player.useUlti()
      this.usingUltiCurrently = false
    }
    this.ultiing = true
  }

  reloadPlayer (data) {
    const n = this.getBattle().spawnHero(data, this.heroLevel, this.getIndex(), 0, false)
    n.setPosition(this.getX(), this.getY(), 0)
    const player = this.getPlayer()
    if (player != null) player.ownObjectId = n.getGlobalID()
    n.hitpoints = this.hitpoints
    if (n.skills.length > 0 && this.skills.length > 0) n.skills[0].charge = this.skills[0].charge
    this.causeDamage(this, 99999, 0, false, null, false, true)
    this.gameObjectManager.removeGameObject(this)
    return n
  }

  moveTo (a1, deltaX, deltaY, a4, a5, a6, a7) {
    if (deltaY === undefined) {
      deltaY = deltaX
      deltaX = a1
      a1 = 0
    }
    if (this.isPlayerControlRemoved()) return 0
    const vector = new LogicVector2(deltaX, deltaY)
    GamePlayUtil.getClosestLevelBorderCollision(this.getX(), this.getY(), deltaX, deltaY, this.gameObjectManager.getBattle().getTileMap(), 0, vector)
    if (vector.x > deltaX) vector.x += 50
    if (vector.x < deltaX) vector.x -= 50
    if (vector.y > deltaY) vector.y += 50
    if (vector.y < deltaY) vector.y -= 50
    this.pathfindTo(a1, vector.x, vector.y, 0, 0, 0, a6, 1, a7)
    this.pathLength = this.getPathLength()
    if (this.pathLength >= 1) {
      const speed = this.characterData.speed + this.getBuffedSpeed() + this.getUnbuffedSpeed()
      this.moveStart = this.ticksGone
      if (speed > 0) {
        this.moveEnd = LogicMath.max(1, Math.trunc(4 * 5 * this.pathLength / speed)) + this.ticksGone
      } else {
        this.moveEnd = this.ticksGone
      }
    }
    return 0
  }

  addConsumableShield (amount, duration) {
    if (this.consumableShield < amount) {
      this.consumableShield = amount
      this.consumableShieldMax = amount
      this.consumableShieldTick = this.ticksGone
      this.consumableShieldDuration = duration
    }
  }

  getActivePet (ignoreBase) {
    for (const gameObject of this.gameObjectManager.getGameObjects()) {
      if (gameObject.getObjectType() !== 0) continue
      if (gameObject !== this && gameObject.getIndex() === this.getIndex() && gameObject.isAlive()) {
        if (!ignoreBase || gameObject.characterData.speed > 0) return gameObject
      }
    }
    return null
  }

  getEncodeViewerIndex () {
    const battle = this.getBattle()
    let viewer = null
    if (battle != null && battle.encodingOwnObjectId != null) viewer = battle.getPlayerWithObject(battle.encodingOwnObjectId)
    if (viewer == null) viewer = this.getViewerPlayer()
    if (viewer == null) return null
    return viewer.teamIndex * 16 + viewer.playerIndex
  }

  encode (bitStream, isOwnObject, visionTeam) {
    super.encode(bitStream, isOwnObject, visionTeam)
    const data = this.characterData
    const ownHero = isOwnObject && data.isHero()
    const isBoss = data.isBoss()
    const manyHitpoints = (data.hasVeryMuchHitPoints() && data.isHero()) || this.maxHitpoints > 65535
    const weapon = this.getWeaponSkill()
    if (data.hasAutoAttack() || data.speed !== 0 || data.isTrainingDummy()) {
      if (isOwnObject) {
        const controlRemoved = this.isPlayerControlRemoved()
        bitStream.writeBoolean(controlRemoved)
        if (bitStream.writeBoolean(this.forcedAngleTicks + 1 >= this.ticksGone || this.isSteerMovementActive()) || controlRemoved) {
          bitStream.writePositiveIntMax511(LogicMath.clamp(this.attackAngle, 0, 511))
          bitStream.writePositiveIntMax511(LogicMath.clamp(this.moveAngle, 0, 511))
        }
      } else {
        bitStream.writePositiveIntMax511(LogicMath.clamp(this.attackAngle, 0, 511))
        bitStream.writePositiveIntMax511(LogicMath.clamp(this.moveAngle, 0, 511))
      }
      bitStream.writePositiveInt(this.state, 3)
      bitStream.writeBoolean(false)
      bitStream.writeInt(LogicMath.clamp(this.attackingTicks, 0, 63), 6)
      bitStream.writeBoolean(this.knockBacked)
      if (bitStream.writeBoolean(this.stunTicks >= 1)) bitStream.writeBoolean(false)
      bitStream.writeBoolean(this.shaking > 0)
      bitStream.writeBoolean(!!this.starPowerIC)
    } else {
      bitStream.writePositiveIntMax7(this.state)
      if (data.isTrain() || data.manualRotations) {
        bitStream.writePositiveIntMax511(LogicMath.clamp(this.attackAngle, 0, 511))
        bitStream.writePositiveIntMax511(LogicMath.clamp(this.moveAngle, 0, 511))
      } else if (data.areaEffect != null) {
        bitStream.writePositiveIntMax511(LogicMath.clamp(this.moveAngle, 0, 511))
      }
    }
    bitStream.writePositiveVIntMax65535OftenZero(this.hitEffectProjectile)
    bitStream.writePositiveVIntMax65535OftenZero(this.hitEffectSkin)
    bitStream.writeBoolean(!!this.slippery)
    bitStream.writeBoolean(this.hasBuff(4))
    bitStream.writeBoolean(this.hasBuff(3))
    bitStream.writeBoolean(false)
    bitStream.writeBoolean(false)
    if (bitStream.writeBoolean(this.hasBuff(14))) bitStream.writePositiveIntMax3(this.getBuff(14).effectType || 0)
    bitStream.writeBoolean(this.hasBuff(15))
    bitStream.writeBoolean(false)
    bitStream.writePositiveVIntMax255OftenZero(LogicMath.clamp(Math.trunc(this.frozenPercentage), 0, 100))
    bitStream.writePositiveVIntMax255OftenZero(this.poisons.length)
    if (this.poisons.length >= 1) {
      for (const poison of this.poisons) bitStream.writePositiveInt(poison.type, 3)
      bitStream.writeBoolean(false)
    }
    bitStream.writePositiveVIntMax255OftenZero(0)
    const hitpoints = LogicMath.max(0, this.hitpoints)
    if (isBoss) {
      bitStream.writePositiveIntMax2097151(hitpoints)
      bitStream.writePositiveIntMax2097151(this.maxHitpoints)
    } else if (manyHitpoints && !data.isHero()) {
      bitStream.writePositiveIntMax524287(hitpoints)
      bitStream.writePositiveIntMax524287(this.maxHitpoints)
    } else {
      bitStream.writePositiveVIntMax65535(LogicMath.min(hitpoints, 65535))
      bitStream.writePositiveVIntMax65535(LogicMath.min(this.maxHitpoints, 65535))
    }
    if (data.isDecoy()) bitStream.writeBoolean(false)
    if (data.isHero() || data.isDecoy()) {
      bitStream.writePositiveVIntMax255OftenZero(this.itemCount + this.battleRoyaleBuffs)
      if (bitStream.writeBoolean(this.consumableShield > 0)) {
        bitStream.writePositiveIntMax2047(LogicMath.clamp(this.consumableShield, 0, 2047))
        bitStream.writePositiveIntMax2047(LogicMath.clamp(this.consumableShieldMax, 0, 2047))
      }
      bitStream.writeBoolean(this.hasBuff(13))
    }
    if (data.isHero()) {
      const battle = this.getBattle()
      if (battle.carryable != null && battle.carryable.carringCharacter === this) {
        bitStream.writeBoolean(true)
        bitStream.writePositiveVIntMax65535OftenZero(0)
        bitStream.writePositiveVIntMax65535OftenZero(0)
        bitStream.writePositiveVIntMax65535(GlobalId.getInstanceId(battle.carryable.getGlobalID()))
      } else if (GameModeUtil.modeHasCarryables(battle.getGameModeVariation())) {
        bitStream.writeBoolean(false)
      }
      bitStream.writePositiveVIntMax255OftenZero(0)
      bitStream.writeBoolean(!!this.bigState)
      bitStream.writeBoolean(false)
      if (bitStream.writeBoolean(true)) {
        bitStream.writeBoolean(this.isChargeActive())
        bitStream.writeBoolean(!!this.isInvincible)
        bitStream.writeBoolean(false)
        bitStream.writeBoolean(false)
        bitStream.writeBoolean(!!this.ultiing)
        bitStream.writeBoolean(!!this.usingUltiCurrently)
      }
      if (isOwnObject && bitStream.writeBoolean(this.visionOverrideTicks >= 1)) {
        bitStream.writeIntMax65535(this.visionOverrideX)
        bitStream.writeIntMax65535(this.visionOverrideY)
      }
      if (weapon != null && weapon.skillData.chargedShotCount >= 1) bitStream.writeIntMax3(LogicMath.clamp(this.chargedShotCount, 0, 3))
      if (data.shouldEncodePetStatus || data.uniqueProperty === 13) bitStream.writeBoolean(false)
      if (data.hasPowerLevels || data.uniqueProperty === 1) bitStream.writePositiveIntMax3(LogicMath.clamp(this.getPowerLevel(), 0, 3))
      bitStream.writeBoolean(false)
      if (this.isChargeActive()) {
        bitStream.writePositiveInt(this.chargeAnimation, 8)
        bitStream.writePositiveInt(LogicMath.clamp(this.activeChargeType, 0, 15), 4)
      }
      switch (this.chargeUpType) {
        case 0:
        case 5:
          break
        case 1:
        case 7:
        case 11:
        case 12:
          bitStream.writePositiveVIntMax255OftenZero(LogicMath.clamp(Math.trunc(this.chargeUp / 50), 0, 255))
          break
        case 8:
          bitStream.writePositiveIntMax1023(LogicMath.clamp(this.chargeUp, 0, 1023))
          break
        case 9:
          bitStream.writePositiveIntMax7(LogicMath.clamp(this.chargedShotCount, 0, 7))
          break
        default:
          bitStream.writePositiveIntMax1023(LogicMath.clamp(Math.trunc(this.chargeUp / 50), 0, 1023))
          break
      }
    }
    if (data.secondaryPet) bitStream.writePositiveIntMax7(0)
    if (!data.isCarryable()) {
      if (data.name === 'RopeDude') bitStream.writeBoolean(false)
    } else {
      let trail = 0
      if (this.getZ() > 0) trail = this.totalKickDistance > 2400 ? 2 : 1
      bitStream.writePositiveIntMax7(trail)
      bitStream.writePositiveIntMax3(0)
    }
    if (data.name === 'SpawnerDudeTurret' || data.name === 'SpawnerDudeTurret003' || data.name === 'SpawnerDudeTurret002') {
      for (let i = 0; i < 10; i++) bitStream.writeBoolean(false)
    }
    if (isBoss) bitStream.writeBoolean(false)
    bitStream.writeBoolean(this.shieldTicks > 0)
    bitStream.writePositiveIntMax3(LogicMath.clamp(this.visibilityState, 0, 3))
    bitStream.writeBoolean(!!this.isInvisible)
    bitStream.writePositiveIntMax511(0)
    if (ownHero) {
      const ulti = this.getUltimateSkill()
      if (ulti != null && ulti.seemToBeActive) {
        bitStream.writeBoolean(true)
        bitStream.writeIntMax1023(1 - data.speed)
      } else if (bitStream.writeBoolean(this.getBuffedSpeed() !== 0)) {
        bitStream.writeIntMax1023(this.getBuffedSpeed())
      }
      bitStream.writeBoolean(!!this.yellowEye)
    }
    const viewerIndex = this.damageNumbers.length > 0 ? this.getEncodeViewerIndex() : null
    if (viewerIndex == null) {
      bitStream.writePositiveIntMax31(0)
    } else {
      const visible = this.damageNumbers.filter(d => d != null && d.delay === 0 && (d.dealer === viewerIndex || this.getIndex() === viewerIndex)).slice(0, 31)
      bitStream.writePositiveIntMax31(visible.length)
      for (const damageNumber of visible) bitStream.writeInt(LogicMath.clamp(damageNumber.value, -32767, 32767), 15)
    }
    for (const skill of this.skills) skill.encode(bitStream, isOwnObject, this)
  }

  getObjectType () {
    return 0
  }
}

Character.DamageNumber = DamageNumber

module.exports = Character
