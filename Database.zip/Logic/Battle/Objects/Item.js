const GameObject = require('./GameObject')
const GameObjectFactory = require('./GameObjectFactory')
const TileMap = require('../Level/TileMap')
const DataTables = require('../../Data/DataTables')
const GamePlayUtil = require('../../Util/GamePlayUtil')
const LogicMath = require('../../../Titan/Math/LogicMath')
const LogicVector2 = require('../../../Titan/Math/LogicVector2')

function getAreaEffectData (name, fallback) {
  const data = name ? DataTables.getAreaEffectByName(name) : null
  if (data != null) return data
  return fallback ? DataTables.getAreaEffectByName(fallback) : null
}

class Item extends GameObject {
  constructor (itemData) {
    super(itemData)

    this.itemData = itemData
    this.spawningTick = 1
    this.spawnTick = 0
    this.pickUpTimerDefault = 250
    this.pickUpTimer = 0
    this.pickUpStartX = 0
    this.pickUpStartY = 0
    this.pickUpZ = 0
    this.pickUpStartZ = 0
    this.picker = null
    this.pickedUp = false
    this.moveTimer = 750
    this.moveTimerDefault = 750
    this.targetX = 0
    this.targetY = 0
    this.spawnedTick = 0
    this.damage = 0
    this.owner = null
    this.sprayData = null
    this.attachedCharacter = null
    this.attachTicks = 0
    this.silenceDamage = 0
    this.lastAttachDamageTicks = 20
    this.isHealing = false
    this.isVisible = false
    this.lastTick = 0
    this.isTriggeredMine = 0
    this.triggerTicks = 0
    this.triggerTicksSet = false
    this.portalArrive = false
    this.portalClosed = false
    this.portalTicks = 0
    this.twinPortal = null
    this.teleportType = 0
    this.stateTick = 0
    this.teleportIternalId = 0
    this.tramplineState = 0
    this.tramplineStateTick = 0
    this.tramplineStartSet = false
    this._jumpTime = 0
    this._jumpDuration = 10
    this._jumpHeight = 500
    this._isJumping = false
    this._startX = 0
    this._startY = 0
    this._startZ = 0
    this._targetX = 0
    this._targetY = 0
    this._targetZ = 0
    this.teamId = -1
    this._isDestroyed = false
    this._state = 0
  }

  getHeroesInRange (range) {
    const heroes = []

    for (const gameObject of this.gameObjectManager.getGameObjects()) {
      if (gameObject.getObjectType() !== 0) continue
      if (!gameObject.characterData.isHero()) continue
      if (this.position.getDistance(gameObject.getPosition()) > range) continue
      heroes.push(gameObject)
    }

    return heroes
  }

  explode (data, setDamage) {
    const areaEffect = GameObjectFactory.createGameObjectByData(data)
    if (areaEffect == null) return
    areaEffect.setSource(this.owner, 1)
    areaEffect.setPosition(this.getX(), this.getY(), 0)
    areaEffect.setIndex(this.owner.getIndex())
    if (setDamage) areaEffect.damage = this.damage
    this.gameObjectManager.addGameObject(areaEffect)
    areaEffect.trigger()
  }

  tick () {
    this.spawnTick++

    const name = this.itemData.name
    const parentName = this.itemData.parentItemForSkin

    if (name === 'BattleRoyaleBuff' || name === 'Point' || name === 'Scrap') {
      const tileMap = this.getBattle() != null ? this.getBattle().getTileMap() : null

      if (tileMap != null) {
        const tile = tileMap.getTile(this.getX(), this.getY())

        if (tile != null && tile.data != null && tile.data.blocksMovement) {
          const vec = new LogicVector2(this.getX(), this.getY())
          GamePlayUtil.getClosestPassableSpot(1, this.getX(), this.getY(), 10, tileMap, vec, false)
          this.setPosition(vec.x, vec.y, 0)
        }
      }
    }

    if (this._isJumping) {
      this._jumpTime++
      const progress = Math.fround(this._jumpTime / this._jumpDuration)

      if (progress >= 1) {
        this.setPosition(this._targetX, this._targetY, this._targetZ)
        this._isJumping = false
        return
      }

      this.setPosition(
        this._startX + Math.trunc((this._targetX - this._startX) * progress),
        this._startY + Math.trunc((this._targetY - this._startY) * progress),
        this._startZ + Math.trunc(this._jumpHeight * 4 * progress * (1 - progress)))
    }

    if (name === 'Healing') {
      const heroes = this.getHeroesInRange(300).filter(c => c.isAlive())

      if (heroes.length > 0) {
        this.isHealing = true

        if (this.getBattle().getTicksGone() >= this.lastTick + 25) {
          for (const c of heroes) c.heal(0, 500, true, null)
          this.lastTick = this.getBattle().getTicksGone()
        }
      } else {
        this.isHealing = false
      }
    }

    if (name === 'IntervalDamage') {
      if (this.getBattle().getTicksGone() >= this.lastTick + 25) {
        const heroes = this.getHeroesInRange(200).filter(c => c.isAlive())

        if (heroes.length > 0) {
          for (const c of heroes) c.causeDamage(null, 500, 500, false, null)
          this.lastTick = this.getBattle().getTicksGone()
        }
      }
    }

    if (name === 'Teleport1' || name === 'Teleport2' || name === 'Teleport3' || name === 'Teleport4') {
      if (this.teleportIternalId === 0) this.teleportIternalId = this.itemData.value
      if (this.stateTick > 0) this.stateTick--
      if (this.teleportType === 2 && this.stateTick <= 1) this.teleportType = 0

      const pair = TileMap.getTeleportPairLocation(this.teleportIternalId, this.gameObjectManager, this.getGlobalID())

      if (pair != null) {
        const heroes = this.getHeroesInRange(299).filter(c => c.isAlive())

        if (this.teleportType === 0 && heroes.length > 0) {
          this.teleportType = 1
          this.stateTick = 2 * 20
        } else if (this.teleportType === 1 && this.stateTick <= 1) {
          if (heroes.length > 0) {
            for (const c of heroes) {
              c.triggerBlink(pair.getX(), pair.getY(),
                DataTables.getAreaEffectByName('TeleportTileArrive'),
                DataTables.getAreaEffectByName('TeleportTileLeave'), 0, 0)
            }
            this.teleportType = 2
            this.stateTick = 7 * 20
            pair.teleportType = 2
            pair.stateTick = 7 * 20
          } else {
            this.teleportType = 0
          }
        }
      }
    }

    if (name.startsWith('SpringBoard')) {
      let angle = 270
      if (name.includes('Up') && name.includes('Left')) angle = 225
      else if (name.includes('Up') && name.includes('Right')) angle = 315
      else if (name.includes('Down') && name.includes('Left')) angle = 135
      else if (name.includes('Down') && name.includes('Right')) angle = 45
      else if (name.includes('Up')) angle = 270
      else if (name.includes('Right')) angle = 0
      else if (name.includes('Down')) angle = 90
      else if (name.includes('Left')) angle = 180

      let svo = 3500
      if (name.endsWith('_Gale')) svo = 1850

      if (this.getHeroesInRange(300).length > 0) this.tramplineStartSet = true

      if (this.tramplineStartSet) {
        this.tramplineStateTick++
        this.tramplineState = 1

        if (this.tramplineStateTick > 40) {
          if (this.tramplineStateTick === 41) {
            for (const c of this.getHeroesInRange(500)) {
              c.triggerCharge(
                c.getX() - LogicMath.getRotatedX(svo, 0, angle),
                c.getY() - LogicMath.getRotatedY(svo, 0, angle),
                2750, 6, 0, 0, false)
            }
          }
          this.tramplineState = 2
        }

        if (this.tramplineStateTick > 60) {
          this.tramplineStateTick = 0
          this.tramplineState = 0
          this.tramplineStartSet = false
        }
      }
    }

    if (this.spawnTick > 22 && name.startsWith('StickyBomb')) {
      this.spawnTick--
      this.gameObjectManager.removeGameObject(this)
      if (this.owner == null) return
      this.explode(getAreaEffectData(this.itemData.triggerAreaEffect, 'StickyBombClusterExplosion'), true)
    }

    if (name.startsWith('StickyBomb') && this.attachedCharacter != null) {
      this.setPosition(this.attachedCharacter.getX(), this.attachedCharacter.getY(), this.attachedCharacter.getZ())
    }

    if (name === 'ClusterMine' || name.startsWith('Tick00')) {
      let totalProgress = 0
      if (this.moveTimerDefault > 0) totalProgress = LogicMath.min(1000, 1000 - Math.trunc(1000 * this.moveTimer / this.moveTimerDefault))

      if (this._state === 0) {
        const currentX = Math.trunc((this.pickUpStartX * (1000 - totalProgress) + this.targetX * totalProgress) / 1000)
        const currentY = Math.trunc((this.pickUpStartY * (1000 - totalProgress) + this.targetY * totalProgress) / 1000)
        const fallProgress = Math.trunc((totalProgress * totalProgress) / 1000)
        const currentZ = Math.trunc((this.pickUpStartZ * (1000 - fallProgress)) / 1000)
        const peakHeight = 300
        const arcOffset = Math.trunc((4 * peakHeight * totalProgress * (1000 - totalProgress)) / 1000000)
        const finalZ = currentZ + arcOffset

        if (totalProgress < 1000) {
          this.setPosition(currentX, currentY, LogicMath.max(0, finalZ))
        } else {
          this.setPosition(this.targetX, this.targetY, 0)
          this._state = 1
          this.spawnTick = 0
        }
      } else if (this._state === 1) {
        this.spawnTick++

        if (this.spawnTick >= 30) {
          this.executeClusterExplosion()
          return
        }

        for (const character of this.gameObjectManager.getCharacters()) {
          if (character.isAlive() && character.getTeamIndex() !== this.teamId && character.characterData.name !== 'LaserBall') {
            if (character.getPosition().getDistance(this.position) <= 450) {
              this.executeClusterExplosion()
              return
            }
          }
        }
      }
    }

    if (this.spawnTick > 22 && name.endsWith('BombUlti')) {
      this.spawnTick--
      this.gameObjectManager.removeGameObject(this)
      if (this.owner == null) return
      this.explode(getAreaEffectData(this.itemData.triggerAreaEffect, 'StickyBombUltiExplosion'), false)
    }

    if (name.endsWith('BombUlti') && this.attachedCharacter != null) {
      this.setPosition(this.attachedCharacter.getX(), this.attachedCharacter.getY(), this.attachedCharacter.getZ())
    }

    if (name === 'SilencerHugger' || parentName === 'SilencerHugger') {
      const attached = this.attachedCharacter

      if (attached != null) {
        if (attached.silence) this.setPosition(attached.getX(), attached.getY(), attached.getZ())
        if (attached.silenceTick < this.ticksGone || !attached.isAlive()) this.gameObjectManager.removeGameObject(this)
      }
    }

    if (this.spawnTick > 20 && name.startsWith('Piper')) {
      this.spawnTick--
      this.gameObjectManager.removeGameObject(this)
      if (this.owner == null) return
      const aed = getAreaEffectData(this.itemData.triggerAreaEffect, 'SniperBombExplosion')
      if (aed == null) return
      const v224 = GameObjectFactory.createGameObjectByData(aed)
      v224.setPosition(this.getX(), this.getY(), 0)
      v224.setIndex(this.owner.getIndex())
      v224.damage = this.damage > 0 ? this.damage : 900
      v224.normalDMG = v224.damage
      v224.setSource(this.owner, 1)
      this.gameObjectManager.addGameObject(v224)
      v224.trigger()
    }

    if (name === 'Mine' || name === 'ElectroTrap' || parentName === 'Mine') {
      if (this.spawnTick >= 20 && this.isTriggeredMine <= 0) this.isVisible = false
      else this.isVisible = true

      if (this.spawnTick >= 20) {
        const enemies = this.getHeroesInRange(600).filter(c => Math.trunc(c.getIndex() / 16) !== Math.trunc(this.getIndex() / 16))

        if (enemies.length >= 1 && !this.triggerTicksSet) {
          this.isTriggeredMine = 100
          this.triggerTicks = this.ticksGone + 22
          this.triggerTicksSet = true
          this.isVisible = true
        }

        if (this.isTriggeredMine > 0 && this.triggerTicks <= this.ticksGone) {
          this.spawnTick--
          this.gameObjectManager.removeGameObject(this)
          const v224 = GameObjectFactory.createGameObjectByData(getAreaEffectData(this.itemData.triggerAreaEffect, 'Bo_def_ulti2_area'))

          if (v224 != null) {
            v224.setPosition(this.getX(), this.getY(), 0)
            v224.setIndex(this.getIndex())
            v224.setSource(this.owner, 1)
            v224.damage = 900
            v224.normalDMG = 0
            this.gameObjectManager.addGameObject(v224)
            v224.trigger()
          }
        }
      }
    }

    if (name === 'BattleRoyaleBuff' && this.spawnTick === 1) {
      this.pickUpStartX = this.getX()
      this.pickUpStartY = this.getY()
      this.pickUpStartZ = 1000 * this.getZ()
      const angle = this.getBattle().getRandomInt(360)
      this.targetX = this.getX() + LogicMath.getRotatedX(600, 0, angle)
      this.targetY = this.getY() + LogicMath.getRotatedY(600, 0, angle)
    }

    if (name === 'OrbSpawner') {
      if (this.spawningTick === 1) this.spawningTick = 40
      if (this.ticksGone < this.spawningTick) return
      const v269 = GameObjectFactory.createGameObjectByData(DataTables.getItemByName('Point'))
      v269.setPosition(this.getX(), this.getY(), this.getZ())
      v269.pickUpStartX = this.getX()
      v269.pickUpStartY = this.getY()
      v269.pickUpStartZ = 1000 * this.getZ()
      const angle = this.getBattle().getRandomInt(360)
      v269.targetX = this.getX() + LogicMath.getRotatedX(600, 0, angle)
      v269.targetY = this.getY() + LogicMath.getRotatedY(600, 0, angle)
      this.gameObjectManager.addGameObject(v269)
      this.spawningTick = this.ticksGone + 140
      this.spawnedTick = this.ticksGone
    }

    if (name === 'TrainSpawner') {
      if (this.spawningTick === 1) this.spawningTick = 40
      if (this.ticksGone < this.spawningTick) return
      const v269 = GameObjectFactory.createGameObjectByData(DataTables.getItemByName('Point'))
      v269.setPosition(this.getX(), this.getY(), this.getZ())
      this.gameObjectManager.addGameObject(v269)
      this.spawningTick = this.ticksGone + 140
    }

    if (this.pickedUp) {
      if (this.pickUpTimer < 1) return

      if (this.picker == null || !this.picker.isAlive()) {
        this.pickedUp = false
        return
      }

      this.pickUpTimer -= 50
      const v196 = LogicMath.min(1000, 1000 - Math.trunc(1000 * this.pickUpTimer / this.pickUpTimerDefault))
      const v200 = this.pickUpStartZ + (v196 - 1000) * v196 * (-1) + Math.trunc((this.pickUpZ - this.pickUpStartZ) * v196 / 1000)
      this.setPosition(
        Math.trunc((this.picker.getX() * v196 + this.pickUpStartX * (1000 - v196)) / 1000),
        Math.trunc((this.picker.getY() * v196 + this.pickUpStartY * (1000 - v196)) / 1000),
        Math.trunc(v200 / 1000))

      if (this.pickUpTimer <= 0) {
        this.picker.applyItem(this)
      }

      return
    }

    this.moveTimer -= 50
    if (this.moveTimer < 0) this.moveTimer = 0
    if (this.targetX === 0) return

    const v187 = LogicMath.min(1000, 1000 - Math.trunc(1000 * this.moveTimer / this.moveTimerDefault))

    if (name === 'Point') {
      if (v187 > 700) {
        const v186 = 700
        const v189 = 300
        const v206 = v187 - v186
        const v211 = this.targetX - this.pickUpStartX
        const v212 = this.targetY - this.pickUpStartY
        const v213 = (this.targetX - this.pickUpStartX) * v186
        const v214 = this.pickUpStartX * v189 + this.targetX * v186
        const v215 = this.pickUpZ + v206 * (-6) * (v206 - v189)
        const v216 = this.pickUpStartY * v189 + this.targetY * v186
        const v217 = Math.trunc((Math.trunc(v214 / 1000) * (v189 - v206) + (Math.trunc(v213 / 1000) + this.pickUpStartX + Math.trunc(v211 * v189 / 2000)) * v206) / v189)
        const v218 = Math.trunc((Math.trunc(v216 / 1000) * (v189 - v206) + (Math.trunc(v212 * v186 / 1000) + this.pickUpStartY + Math.trunc(v212 * v189 / 2000)) * v206) / v189)
        const v219 = Math.trunc(v215 / 1000)
        this.setPosition(v217, v218, LogicMath.clamp(v219, 0, 3000))
      } else {
        const v186 = 700
        const v206 = v187 - 700
        const v220 = this.pickUpStartY * (1000 - v187) + this.targetY * v187
        const v221 = this.pickUpStartZ + (-6) * v187 * v206 + Math.trunc((this.pickUpZ - this.pickUpStartZ) * v187 / v186)
        const v218 = Math.trunc(v220 / 1000)
        const v217 = Math.trunc((this.pickUpStartX * (1000 - v187) + this.targetX * v187) / 1000)
        const v219 = Math.trunc(v221 / 1000)
        this.setPosition(v217, v218, LogicMath.clamp(v219, 0, 3000))
      }
    }
  }

  executeClusterExplosion () {
    if (this._isDestroyed) return
    this._isDestroyed = true

    const finalOwner = this.owner
    const currentTicks = this.gameObjectManager.getBattle().getTicksGone()
    const data = getAreaEffectData(this.itemData.triggerAreaEffect, 'ClusterBombExplosion')

    if (data != null) {
      const AreaEffect = require('./AreaEffect')
      const areaEffect = new AreaEffect(data)
      areaEffect.setPosition(this.getX(), this.getY(), 0)

      if (finalOwner != null) {
        areaEffect.setSource(finalOwner, 1)
        areaEffect.setIndex(finalOwner.getIndex())
      }

      areaEffect.damage = this.damage
      areaEffect.normalDMG = this.damage
      areaEffect.deployedTick = currentTicks
      areaEffect.endingTick = currentTicks + 10
      this.gameObjectManager.addGameObject(areaEffect)
      areaEffect.trigger()
    }

    if (finalOwner != null) {
      const player = finalOwner.getPlayer()

      if (player != null && player.boMines != null) {
        const index = player.boMines.indexOf(this)
        if (index !== -1) player.boMines.splice(index, 1)
      }
    }

    this.gameObjectManager.removeGameObject(this)
  }

  setCharacter (character) {
    this.owner = character
  }

  pickUp (character) {
    this.pickedUp = true
    this.picker = character
    this.pickUpTimer = this.pickUpTimerDefault
    this.pickUpStartX = this.getX()
    this.pickUpStartY = this.getY()
    this.pickUpZ = 20000
  }

  setAngle (angle) {
  }

  disableAppearAnimation () {
  }

  shouldDestruct () {
    return this.pickedUp && this.pickUpTimer <= 0
  }

  canBePickedUp (a1) {
    if (this.itemData.canBePickedUp && !this.pickedUp) {
      switch (this.itemData.name) {
        case 'BattleRoyaleBuff':
        case 'Money':
        case 'Scrap':
        case 'Point':
        case 'EventCollectToken':
          return true
        case 'RuffsBuff':
          return Math.trunc(a1.getIndex() / 16) === Math.trunc(this.getIndex() / 16) && !a1.hasBuff(13)
        case 'SoulCollectorSoul':
          return Math.trunc(a1.getIndex() / 16) === Math.trunc(this.getIndex() / 16) && a1.getHitpointPercentage() < 100
        case 'WeaponThrowerWeapon':
          return a1.getIndex() === this.getIndex()
      }

      switch (this.itemData.parentItemForSkin) {
        case 'WeaponThrowerWeapon':
          return a1.getIndex() === this.getIndex()
      }
    }

    return false
  }

  encode (bitStream, isOwnObject, visionTeam) {
    super.encode(bitStream, isOwnObject, visionTeam)

    const instanceId = this.itemData.getInstanceId()

    switch (instanceId) {
      case 5:
        bitStream.writePositiveIntMax16383(this.spawningTick)
        bitStream.writePositiveIntMax16383(this.spawnedTick)
        break
      case 24:
        bitStream.writePositiveIntMax16383(170)
        bitStream.writePositiveIntMax16383(30)
        bitStream.writePositiveIntMax16383(0)
        break
      case 1:
      case 2:
      case 4:
      case 7:
      case 13:
      case 17:
      case 18:
      case 19:
      case 20:
      case 21:
      case 22:
      case 23:
        bitStream.writePositiveIntMax63(0)
        bitStream.writePositiveIntMax63(0)
        break
      default:
        if ((instanceId & 7) === 0) return
        break
    }

    const name = this.itemData.name

    if (name.startsWith('Piper')) {
      bitStream.writePositiveIntMax4095(4000)
    }

    if (name.startsWith('Mine')) {
      bitStream.writePositiveIntMax63(0)
      bitStream.writePositiveIntMax63(0)
    }

    if (name.startsWith('ClusterMine')) {
      bitStream.writePositiveIntMax63(0)
      bitStream.writePositiveIntMax63(0)
    }

    if (name.startsWith('Sticky')) {
      bitStream.writePositiveIntMax127(1)
    }

    if (name === 'Healing') {
      bitStream.writeBoolean(this.isHealing)
    }

    if (name === 'ElectroTrap') {
      bitStream.writeBoolean(this.isVisible)
      bitStream.writePositiveIntMax2047(this.isTriggeredMine)
    }

    if (name.startsWith('SpringBoard')) {
      if (bitStream.writeBoolean(true)) {
        bitStream.writePositiveIntMax3(this.tramplineState)
        bitStream.writePositiveIntMax63(this.tramplineStateTick)
      }
    }

    if (name === 'Teleport1' || name === 'Teleport2' || name === 'Teleport3' || name === 'Teleport4') {
      if (bitStream.writeBoolean(true)) {
        bitStream.writePositiveIntMax3(this.teleportType)
        bitStream.writePositiveIntMax63(this.stateTick)
      }
    }
  }

  setFromToPosition (x, y, z, tx, ty, tz) {
    this.setPosition(x, y, z)
    this.pickUpStartX = x
    this.pickUpStartY = y
    this.pickUpStartZ = z
    this.targetX = tx
    this.targetY = ty
    this.pickUpZ = tz
  }

  startJumpEffect (fromX, fromY, fromZ, toX, toY, toZ) {
    this._startX = fromX
    this._startY = fromY
    this._startZ = fromZ
    this._targetX = toX
    this._targetY = toY
    this._targetZ = toZ
    this._jumpTime = 0
    this._isJumping = true
    this.setPosition(fromX, fromY, fromZ)
  }

  getObjectType () {
    return 3
  }
}

module.exports = Item
