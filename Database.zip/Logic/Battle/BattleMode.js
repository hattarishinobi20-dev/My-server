const fs = require('fs')
const DataTables = require('../Data/DataTables')
const DataType = require('../Data/DataType')
const GameModeUtil = require('../Util/GameModeUtil')
const GamePlayUtil = require('../Util/GamePlayUtil')
const LogicMath = require('../../Titan/Math/LogicMath')
const LogicRandom = require('../../Titan/Math/LogicRandom')
const LogicVector2 = require('../../Titan/Math/LogicVector2')
const BitStream = require('../../Titan/DataStream/BitStream')
const Debugger = require('../../Titan/Debug/Debugger')
const GameTime = require('../Time/GameTime')
const LogicServerListener = require('../Listener/LogicServerListener')
const Rect = require('./Level/Rect')
const TileMapFactory = require('./Level/Factory/TileMapFactory')
const GameObjectManager = require('./Objects/GameObjectManager')
const GameObjectFactory = require('./Objects/GameObjectFactory')
const Petrol = require('./Objects/Petrol')
const CtfState = require('./CtfState')
const BattleEndMessage = require('../../Protocol/Messages/Server/BattleEndMessage')
const VisionUpdateMessage = require('../../Protocol/Messages/Server/VisionUpdateMessage')
const AuthenticationFailedMessage = require('../../Protocol/Messages/Server/AuthenticationFailedMessage')

function getCharacterClass () {
  return require('./Objects/Character')
}

function getItemClass () {
  return require('./Objects/Item')
}

function getAreaEffectClass () {
  return require('./Objects/AreaEffect')
}

function countWhere (list, predicate) {
  let count = 0
  for (const value of list) {
    if (predicate(value)) count++
  }
  return count
}

class KingOfHillState {
  constructor (zoneIndex) {
    this.zoneIndex = zoneIndex
    this.zonePercentage = 0
    this.captureEffectActiveTeam0 = false
    this.captureEffectActiveTeam1 = false
    this.currentCaptureEffectTeam0 = null
    this.currentCaptureEffectTeam1 = null
    this.gaugeTeam0 = false
    this.gaugeTeam1 = false
    this.gaugeTeam0Effect = null
    this.gaugeTeam1Effect = null
    this.lastUpTickTeam0 = 0
    this.lastUpTickTeam1 = 0
    this.hillCompleteEffectSpawnedTeam0 = false
    this.canContinueUpTeam0 = true
    this.hillCompleteEffectSpawnedTeam1 = false
    this.canContinueUpTeam1 = true
  }
}

const SHOWDOWN_EXPERIENCE_REWARDS = [30, 24, 18, 12, 10, 8, 6, 4, 2, 0]
const SHOWDOWN_TOKENS_REWARDS = [30, 24, 21, 15, 12, 8, 6, 4, 2, 0]

class BattleMode {
  static ORBS_TO_COLLECT_NORMAL = 0xA
  static INTRO_TICKS = 100
  static NO_TIME_TICKS = 16000
  static NORMAL_TICKS = 3180
  static EXPLOSION_INTERVAL = 20 * 15
  static HOLD_THE_BALL_PROGRESS_INTERVAL_TICKS = 5
  static HOLD_THE_BALL_RETURN_TICKS = 20 * 6
  static GAME_OVER_TICKS = 300
  static KingOfHillState = KingOfHillState

  constructor (locationIdOrPlayerMap) {
    this.updateTimer = null
    this.winnerTeam = -1
    this.playerMap = null
    this.battlePlayerMap = null

    if (locationIdOrPlayerMap != null && typeof locationIdOrPlayerMap === 'object') {
      const playerMap = locationIdOrPlayerMap
      this.playerMap = playerMap
      this.locationId = playerMap.mapEnvironmentData
      this.gameModeVariation = playerMap.gmv
      this.tileMap = TileMapFactory.createPlayerMap(playerMap.mapData != null ? playerMap.mapData.data : null)
    } else {
      this.locationId = locationIdOrPlayerMap
      const location = this.location
      this.gameModeVariation = location != null ? GameModeUtil.getGameModeVariation(location.gameMode) : -1
      this.tileMap = location != null ? TileMapFactory.createTileMap(location.allowedMaps) : null
    }

    this.playersCountWithGameModeVariation = GamePlayUtil.getPlayerCountWithGameModeVariation(this.gameModeVariation)
    this.battleWithTrophies = false
    this.isFriendlyMatch = false
    this.inputQueue = []
    this.players = []
    this.playersBySessionId = new Map()
    this.spectators = new Map()
    this.randomSeed = 0
    this.random = new LogicRandom(this.randomSeed)
    this.time = new GameTime()
    this.playArea = this.tileMap != null ? new Rect(0, 0, this.tileMap.logicWidth, this.tileMap.logicHeight) : null
    this.gameObjectManager = new GameObjectManager(this)
    this.storyModeStuffs = []
    this.playersAlive = 0
    this.gemGrabCountdown = 0
    this.isStoryMode = false
    this.isGameOver = false
    this.eventModifiers = []
    this.zone1Score = 0
    this.zone2Score = 0
    this.team0Zone1Score = 0
    this.team1Zone1Score = 0
    this.team0Zone2Score = 0
    this.team1Zone2Score = 0
    this.team0Zone3Score = 0
    this.team1Zone3Score = 0
    this._playersAliveForDuo = 0
    this._stopTicks = 0
    this._setStopTicks = false
    this.team1King = 0
    this.team2King = 0
    this.playerIndexesForTeam1 = []
    this.playerIndexesForTeam2 = []
    this.ticksSinceLastExplosion = 0
    this._holdTheBallNextProgressTick = 0
    this._holdTheBallReturnTick = -1
    this._koHStates = []
    this.carryable = null
    this.ctf = null
    this._pinsReseted = false
    this.carryableTeam0 = null
    this.carryableTeam1 = null
    this.isRanked = false
    this.rankedId = 0
    this.round = 0
    this._rankedRestartIssued = false
    this.isEnding = false
    this.endTick = 0
    this.currentRound = 0
    this.roundWinners = [-1, -1, -1]
    this.roundEndTick = -1
    this.roundEndTickBlock = -1
    this.isRoundEnding = false
    this.roundStartTime = 0
    this.roundTicks = 0
    this.toGoalTeam = -1
    this.goalTicks = 0
    this.goalResetTicks = 0
    this.goalPlayersReset = false
    this.canReset = true
    this.tmpBrawlballTick = 0
    this.roundResetTicks = 0
    this.tScore = [0, 0]
    this.goalPauseEndTick = 0
    this.resetCarryableState = false
    this._fiveTeamsSpawnCounters = null
    this._logicPathFinder = null
    this.id = 0
  }

  getPathFinder () {
    if (this._logicPathFinder == null) {
      const LogicPathFinder = require('./Level/LogicPathFinder')
      this._logicPathFinder = new LogicPathFinder(this.getTileMap(), true)
    }
    return this._logicPathFinder
  }

  setPlayerMap (map) {
    this.battlePlayerMap = map
    this.tileMap = TileMapFactory.createPlayerMap(map.mapData != null ? map.mapData.data : null)
    this.playArea = new Rect(0, 0, this.tileMap.logicWidth, this.tileMap.logicHeight)
    this.gameModeVariation = map.gmv
    this.playersCountWithGameModeVariation = GamePlayUtil.getPlayerCountWithGameModeVariation(map.gmv)
  }

  static getShowdownTrophiesTable (brawlerTrophies) {
    if (brawlerTrophies <= 99) return [20, 16, 14, 12, 8, 4, 4, 2, 0, 0]
    if (brawlerTrophies <= 199) return [20, 16, 14, 12, 6, 4, 4, 0, -1, -2]
    if (brawlerTrophies <= 299) return [20, 16, 14, 12, 6, 2, 0, -1, -2, -2]
    if (brawlerTrophies <= 399) return [20, 16, 12, 10, 6, 2, 0, -2, -3, -3]
    if (brawlerTrophies <= 499) return [20, 16, 12, 10, 4, 0, 0, -3, -4, -4]
    if (brawlerTrophies <= 599) return [20, 16, 12, 10, 4, -1, -2, -3, -5, -5]
    if (brawlerTrophies <= 899) return [20, 16, 12, 8, 4, -1, -2, -5, -6, -6]
    if (brawlerTrophies <= 999) return [20, 16, 12, 8, 2, -2, -2, -5, -7, -8]
    if (brawlerTrophies <= 1049) return [20, 16, 12, 8, 2, -3, -4, -5, -8, -9]
    if (brawlerTrophies <= 1099) return [18, 14, 10, 4, 0, -3, -4, -7, -9, -10]
    if (brawlerTrophies <= 1149) return [16, 12, 8, 2, -1, -3, -6, -8, -10, -11]
    if (brawlerTrophies <= 1199) return [12, 10, 6, 2, -2, -5, -6, -9, -11, -12]
    if (brawlerTrophies <= 1249) return [10, 8, 2, 0, -2, -6, -7, -10, -12, -13]
    return [10, 6, 0, -1, -2, -6, -8, -11, -12, -13]
  }

  static getDuoShowdownTrophiesTable (brawlerTrophies) {
    if (brawlerTrophies <= 99) return [18, 16, 14, 12, 0]
    if (brawlerTrophies <= 199) return [18, 16, 14, 12, -2]
    if (brawlerTrophies <= 299) return [18, 16, 14, 10, -2]
    if (brawlerTrophies <= 399) return [18, 16, 12, 8, -3]
    if (brawlerTrophies <= 499) return [18, 16, 10, 6, -4]
    if (brawlerTrophies <= 599) return [18, 14, 10, 4, -5]
    if (brawlerTrophies <= 899) return [18, 14, 8, 2, -6]
    if (brawlerTrophies <= 999) return [18, 12, 6, 0, -7]
    if (brawlerTrophies <= 1049) return [18, 12, 6, -1, -8]
    if (brawlerTrophies <= 1099) return [18, 10, 4, -2, -9]
    if (brawlerTrophies <= 1149) return [16, 8, 2, -3, -10]
    if (brawlerTrophies <= 1199) return [12, 6, 2, -4, -11]
    if (brawlerTrophies <= 1249) return [10, 4, 0, -5, -12]
    return [10, 2, 0, -5, -13]
  }

  static getTrioTrophiesTable (brawlerTrophies) {
    if (brawlerTrophies <= 49) return [16, 0, 2]
    if (brawlerTrophies <= 99) return [16, -1, 2]
    if (brawlerTrophies <= 199) return [16, -2, 2]
    if (brawlerTrophies <= 299) return [16, -3, 0]
    if (brawlerTrophies <= 399) return [16, -4, 0]
    if (brawlerTrophies <= 599) return [16, -5, 0]
    if (brawlerTrophies <= 899) return [16, -6, 0]
    if (brawlerTrophies <= 999) return [16, -7, 0]
    if (brawlerTrophies <= 1049) return [14, -7, 0]
    if (brawlerTrophies <= 1099) return [12, -8, 0]
    if (brawlerTrophies <= 1149) return [10, -9, 0]
    if (brawlerTrophies <= 1199) return [8, -10, 0]
    if (brawlerTrophies <= 1249) return [6, -12, 0]
    return [6, -13, -1]
  }

  getZoneByUID (a1) {
    const state = this._koHStates[a1]
    return state != null ? state : null
  }

  getKOHZoneCount () {
    return this._koHStates.length
  }

  hasEventModifier (m) {
    return this.eventModifiers.includes(m)
  }

  setEventModifiers (ms) {
    this.eventModifiers = ms.slice()
  }

  getGemGrabCountdown () {
    return this.gemGrabCountdown
  }

  getLogicRandom () {
    return this.random
  }

  getGameObjectManager () {
    return this.gameObjectManager
  }

  getPlayersAliveCountForBattleRoyale () {
    return this.playersAlive
  }

  addWinInLaserBall (teamIndex) {
    const plr = this.players.find(p => p.playerIndex === teamIndex)
    if (plr != null) {
      plr.addScore(1)
    }
  }

  setGoalLaserBall (team) {
    this.toGoalTeam = team
    this.goalTicks = (this.gameModeVariation === 5 ? 4 : 3) * 20
    this.goalResetTicks = 3 * 20
    this.goalPlayersReset = false
    this.goalPauseEndTick = this.getTicksGone() + this.goalTicks
  }

  registerBrawlBallGoal (scorerPlayerIndex, scoringTeam) {
    if (this.gameModeVariation !== 5 || this.toGoalTeam !== -1 || this._setStopTicks) return
    const scorer = this.players.find(player => player != null && player.playerIndex === scorerPlayerIndex && player.teamIndex === scoringTeam)
    if (scorer == null) return
    scorer.addScore(1)
    this.setGoalLaserBall(scoringTeam)
    this.resetCarryable()
  }

  registerBasketBrawlGoal (scorerPlayerIndex, scoringTeam, points) {
    if (this.gameModeVariation !== 22 || this.toGoalTeam !== -1 || this._setStopTicks || this.carryable == null || points < 2) return
    const scorer = this.players.find(player => player != null && player.playerIndex === scorerPlayerIndex && player.teamIndex === scoringTeam)
    if (scorer == null) return
    scorer.addScore(points)
    this.toGoalTeam = scoringTeam
    this.goalTicks = 60
    this.goalResetTicks = 20
    this.goalPlayersReset = false
    this.goalPauseEndTick = this.getTicksGone() + this.goalTicks
    this.carryable.carringCharacter = null
    this.carryable.stopKicking()
    this.carryable.setPosition(Math.trunc(this.tileMap.logicWidth / 2), Math.trunc(this.tileMap.logicHeight / 2), 0)
    this.carryable.carryablePickTicks = this.goalTicks
    this.carryable.lastPickupPlayerIndex = -1
    this.carryable.lastPickupPlayerIndexTOCHNO = -1
  }

  onHoldTheBallPickedUp () {
    if (this.gameModeVariation !== 21) return
    this._holdTheBallReturnTick = -1
    if (this.carryable != null) this.carryable.carryablePickTicks = 0
    this._holdTheBallNextProgressTick = this.getTicksGone() + BattleMode.HOLD_THE_BALL_PROGRESS_INTERVAL_TICKS
  }

  onHoldTheBallDropped () {
    if (this.gameModeVariation !== 21) return
    this._holdTheBallReturnTick = this.getTicksGone() + BattleMode.HOLD_THE_BALL_RETURN_TICKS
    if (this.carryable != null) this.carryable.carryablePickTicks = BattleMode.HOLD_THE_BALL_RETURN_TICKS
    this._holdTheBallNextProgressTick = this.getTicksGone() + BattleMode.HOLD_THE_BALL_PROGRESS_INTERVAL_TICKS
  }

  createCenteredBall (ballData) {
    const Character = getCharacterClass()
    const ball = new Character(ballData)
    ball.setPosition(Math.trunc(this.tileMap.logicWidth / 2), Math.trunc(this.tileMap.logicHeight / 2), 0)
    ball.setIndex(0)
    ball.lastPickupPlayerIndex = -1
    ball.lastPickupPlayerIndexTOCHNO = -1
    return ball
  }

  respawnHoldTheBall () {
    if (this.carryable != null) {
      this.carryable.carringCharacter = null
      this.carryable.stopKicking()
      this.gameObjectManager.removeGameObject(this.carryable)
    }
    const ballData = DataTables.getCharacterByName('HoldingBall')
    if (ballData == null) {
      this.carryable = null
      return
    }
    const ball = this.createCenteredBall(ballData)
    ball.setForcedVisible()
    this.gameObjectManager.addGameObject(ball)
    this.carryable = ball
    this._holdTheBallReturnTick = -1
    this._holdTheBallNextProgressTick = this.getTicksGone() + BattleMode.HOLD_THE_BALL_PROGRESS_INTERVAL_TICKS
  }

  tickHoldTheBall () {
    if (this.gameModeVariation !== 21) return
    if (this.carryable == null || !this.carryable.isAlive()) {
      this.respawnHoldTheBall()
      return
    }
    let carrier = this.carryable.carringCharacter
    if (carrier != null && !carrier.isAlive()) {
      this.carryable.carringCharacter = null
      this.onHoldTheBallDropped()
      carrier = null
    }
    if (carrier != null) {
      const player = carrier.getPlayer()
      if (player != null && player.teamIndex >= 0 && player.teamIndex <= 1 &&
        this.getTeamScore(player.teamIndex) < 100 && this.getTicksGone() >= this._holdTheBallNextProgressTick) {
        player.addScore(1)
        this._holdTheBallNextProgressTick = this.getTicksGone() + BattleMode.HOLD_THE_BALL_PROGRESS_INTERVAL_TICKS
      }
      this._holdTheBallReturnTick = -1
      return
    }
    if (this._holdTheBallReturnTick >= 0 && this.getTicksGone() >= this._holdTheBallReturnTick) {
      this.carryable.stopKicking()
      this.carryable.setPosition(Math.trunc(this.tileMap.logicWidth / 2), Math.trunc(this.tileMap.logicHeight / 2), 0)
      this.carryable.carryablePickTicks = 0
      this._holdTheBallReturnTick = -1
      this._holdTheBallNextProgressTick = this.getTicksGone() + BattleMode.HOLD_THE_BALL_PROGRESS_INTERVAL_TICKS
    }
  }

  resetBasketBallAfterGoal () {
    if (this.carryable == null || !this.carryable.isAlive()) {
      const ballData = DataTables.getCharacterByName('BasketBall')
      if (ballData == null) return
      const ball = this.createCenteredBall(ballData)
      ball.carryablePickTicks = this.goalTicks
      ball.setForcedVisible()
      this.gameObjectManager.addGameObject(ball)
      this.carryable = ball
    } else {
      this.carryable.carringCharacter = null
      this.carryable.stopKicking()
      this.carryable.setPosition(Math.trunc(this.tileMap.logicWidth / 2), Math.trunc(this.tileMap.logicHeight / 2), 0)
      this.carryable.carryablePickTicks = this.goalTicks
      this.carryable.lastPickupPlayerIndex = -1
      this.carryable.lastPickupPlayerIndexTOCHNO = -1
      this.carryable.setForcedVisible()
    }
  }

  getGoalTeam () {
    return this.toGoalTeam
  }

  resetRoundLaserBall (ballr, isResettedByServerError = false) {
    if (!this.canReset && ballr) return
    if (this._setStopTicks) return
    this.carryable = null
    for (const character of this.gameObjectManager.getCharacters()) this.gameObjectManager.removeGameObject(character)
    for (const player of this.players.slice()) {
      if (player != null) this.instantRespawn(player)
    }
    for (const item of this.gameObjectManager.getItems()) this.gameObjectManager.removeGameObject(item)
    for (const area of this.gameObjectManager.getAreaEffects()) this.gameObjectManager.removeGameObject(area)
    for (const projectile of this.gameObjectManager.getProjectiles()) this.gameObjectManager.removeGameObject(projectile)
    this.gameObjectManager.petrols.length = 0

    const Character = getCharacterClass()
    if (this.gameModeVariation === 5) {
      const ball = new Character(DataTables.getCharacterByName('LaserBall'))
      ball.setPosition(Math.trunc(this.getTileMap().logicWidth / 2), Math.trunc(this.getTileMap().logicHeight / 2), 0)
      ball.setIndex(0)
      this.gameObjectManager.addGameObject(ball)
      this.carryable = ball
    } else {
      const volleyball = new Character(DataTables.getCharacterByName('VolleyBall'))
      volleyball.setPosition(3150, 4950, 0)
      volleyball.setIndex(1)
      this.gameObjectManager.addGameObject(volleyball)
    }
  }

  resetCarryable () {
    if (this.carryable == null) return
    const carryable = this.carryable
    this.carryable = null
    carryable.carringCharacter = null
    carryable.stopKicking()
    this.gameObjectManager.removeGameObject(carryable)
    for (const character of this.gameObjectManager.getCharacters()) character.carryablePersonImunTicks = 0
  }

  instantRespawn (player) {
    for (const character of this.gameObjectManager.getCharacters()) {
      const owner = character.getPlayer()
      if (owner != null && owner.playerIndex === player.playerIndex) this.gameObjectManager.removeGameObject(character)
    }
    const character = this.spawnHero(player.characterData, player.heroPowerLevel, player.teamIndex * 16 + player.playerIndex, 0, false)
    const spawnPoint = player.getSpawnPoint()
    character.triggerBlink(spawnPoint.x, spawnPoint.y, null, null, 0, 0)
    character.setBot(player.isBot())
    character.spawnTick = this.getTicksGone()
    if (this.gameModeVariation === 5 || this.gameModeVariation === 23) character.isInvincible = false
    player.ownObjectId = character.getGlobalID()
    player.isAlive = true
  }

  getLaserBallRespawnTile (player, randomindex) {
    const tiles = player.teamIndex === 0 ? this.tileMap.laserBallInstantRespawnTileTeam1 : player.teamIndex === 1 ? this.tileMap.laserBallInstantRespawnTileTeam2 : null
    if (tiles == null || tiles.length === 0) return null
    return tiles[randomindex % tiles.length]
  }

  tickSpawnHeroes () {
    if (this.gameModeVariation !== 9) {
      for (const player of this.players) {
        if (player.isAlive) continue
        if (this.gameModeVariation === 6) return
        const spawnPoint = player.getSpawnPoint()
        if (player.characterData.name === 'WeaponThrower') player.chargeUlti(4000, false, false)
        let randomindex = 0
        if (this.gameModeVariation === 5 || this.gameModeVariation === 23) {
          randomindex = player.playerIndex % 3
        }
        const respawnTick = player.deathTick + 20 * GameModeUtil.getRespawnSeconds(this.gameModeVariation)
        const laserBallTile = (this.gameModeVariation === 5 || this.gameModeVariation === 23) ? this.getLaserBallRespawnTile(player, randomindex) : null

        if (this.getTicksGone() === respawnTick) {
          if (player.deathTick !== 1) {
            const v90 = GameObjectFactory.createGameObjectByData(DataTables.getAreaEffectByName('HeroSpawn'))
            if (v90 != null) {
              if (laserBallTile != null) {
                v90.setPosition(laserBallTile.x + 150, laserBallTile.y + 150, 0)
              } else {
                v90.setPosition(spawnPoint.x, spawnPoint.y, 0)
              }
              v90.setIndex(player.teamIndex * 16 + player.playerIndex)
              this.gameObjectManager.addGameObject(v90)
              v90.trigger()
            }
          }
        }

        if (this.getTicksGone() === respawnTick + 40) {
          const character = this.spawnHero(player.characterData, player.heroPowerLevel, player.teamIndex * 16 + player.playerIndex, 0, false)
          if (laserBallTile != null) {
            character.setPosition(laserBallTile.x + 150, laserBallTile.y + 150, 0)
          } else {
            character.setPosition(spawnPoint.x, spawnPoint.y, 0)
          }
          character.setBot(player.isBot())
          character.spawnTick = this.getTicksGone()
          character.isInvincible = true
          player.ownObjectId = character.getGlobalID()
          player.isAlive = true
        }
      }
    } else {
      for (const player of this.players) {
        if (player.isAlive) continue
        const aliveTeammates = this.getAliveCharactersByTeam(player.teamIndex)
        const hasAliveTeammate = aliveTeammates.length > 0
        if (!hasAliveTeammate && !player.respawnStarted) continue
        if (player.characterData.name === 'WeaponThrower') player.chargeUlti(4000, false, false)
        const respawnBaseTick = player.deathTick + 20 * GameModeUtil.getRespawnSeconds(this.gameModeVariation)
        if (!player.respawnStarted && this.getTicksGone() === respawnBaseTick) {
          if (player.deathTick !== 1) {
            if (aliveTeammates.length === 0) continue
            const anchor = aliveTeammates[0]
            player.respawnX = anchor.getX()
            player.respawnY = anchor.getY()
            player.respawnStarted = true
            const v90 = GameObjectFactory.createGameObjectByData(DataTables.getAreaEffectByName('HeroSpawn'))
            if (v90 != null) {
              v90.setPosition(player.respawnX, player.respawnY, 0)
              v90.setIndex(player.teamIndex * 16 + player.playerIndex)
              this.gameObjectManager.addGameObject(v90)
              v90.trigger()
            }
          }
        }
        if (player.respawnStarted && this.getTicksGone() === respawnBaseTick + 40) {
          const character = this.spawnHero(player.characterData, player.heroPowerLevel, player.teamIndex * 16 + player.playerIndex, 0, false)
          character.setPosition(player.respawnX, player.respawnY, 0)
          character.setBot(player.isBot())
          character.spawnTick = this.getTicksGone()
          character.isInvincible = true
          player.ownObjectId = character.getGlobalID()
          player.isAlive = true
          player.respawnStarted = false
        }
      }
    }
  }

  spawnHero (a2, a3, a4, a5, a6) {
    const Character = getCharacterClass()
    const v9 = new Character(a2)
    this.gameObjectManager.addGameObject(v9)
    if (a2.areaEffect != null && a2.areaEffect !== '') {
      v9.addAreaEffect(0, 0, null, 1, false)
    }
    v9.setIndex(a4)
    v9.setUpgrades(a3)
    return v9
  }

  getHomeModeFor (player) {
    const listener = LogicServerListener.instance
    if (listener == null) return null
    try {
      return listener.getHomeMode(player.accountId)
    } catch (e) {
      return null
    }
  }

  updateQuests (player, isVictory, rank) {
    const homeMode = this.getHomeModeFor(player)
    if (homeMode == null || homeMode.home == null || homeMode.home.quests == null) return null
    return homeMode.home.quests.updateQuestsProgress(this.gameModeVariation, player.characterId, player.kills, player.damage, player.heals, homeMode.home, isVictory, rank)
  }

  static updateHighestTrophies (avatar) {
    if (avatar.trophies > avatar.highestTrophies) {
      avatar.highestTrophies = avatar.trophies
    }
  }

  createBattleEndMessage (player, players) {
    const message = new BattleEndMessage()
    message.players = players
    message.pp = players
    message.ownPlayer = player
    return message
  }

  playerDied (player) {
    if (this.gameModeVariation === 9) {
      if (player.isBot() === 2) return
      player.isAlive = false
      player.deathTick = this.getTicksGone()
      player.respawnStarted = false
      const teamHasAlive = this.getAliveCharactersByTeam(player.teamIndex).length > 0
      const teamHasRespawn = this.hasRespawningPlayersOnTeam(player.teamIndex)
      if (!teamHasAlive && !teamHasRespawn) {
        const rank = this.getAliveTeamsCountForDuo() + 1
        for (const teammate of this.players) {
          if (teammate.teamIndex !== player.teamIndex) continue
          if (teammate.battleEndSent) continue
          if (teammate.battleRoyaleRank === -1) teammate.battleRoyaleRank = rank
          teammate.respawnStarted = false
          teammate.isAlive = false
          this.sendBattleEndToPlayer(teammate)
        }
      }
      return
    }

    if (this.gameModeVariation === 6) {
      if (player.isBot() !== 0) {
        this.playersAlive--
        player.isAlive = false
        player.battleRoyaleRank = this.playersAlive + 1
        return
      }
      const rank = LogicMath.clamp(this.playersAlive, 1, 10)
      this.playersAlive--
      player.isAlive = false
      player.battleRoyaleRank = rank
      if (player.battleEndSent) return
      const message = this.createBattleEndMessage(player, this.players)
      message.gameMode = 2
      message.isPvP = true
      message.result = player.battleRoyaleRank
      if (this.battleWithTrophies) {
        const quests = this.updateQuests(player, false, player.battleRoyaleRank)
        if (quests != null) message.progressiveQuests = quests
      }
      if (player.avatar == null) return
      player.avatar.battleId = -1
      if (player.gameListener == null) return
      const hero = player.avatar.getHero(player.characterId)
      if (hero == null) return
      const trophies = BattleMode.getShowdownTrophiesTable(hero.trophies)
      if (this.battleWithTrophies) {
        const premiumTrophies = 0
        const trophiesReward = trophies[rank - 1] + premiumTrophies
        const tokensReward = SHOWDOWN_TOKENS_REWARDS[rank - 1]
        const experienceResult = SHOWDOWN_EXPERIENCE_REWARDS[rank - 1]
        message.experienceReward = experienceResult
        message.tokensReward = tokensReward
        message.trophiesReward = trophiesReward
        message.underdogTrophies = premiumTrophies
        player.home.experience += experienceResult
        message.experience = player.home.experience
        if (rank === 1) player.avatar.soloWins++
        player.avatar.addTokens(tokensReward)
        hero.addTrophies(trophiesReward)
        player.home.tokenReward += tokensReward
        player.home.trophiesReward += trophiesReward
      }
      BattleMode.updateHighestTrophies(player.avatar)
      player.battleEndSent = true
      player.gameListener.sendTCPMessage(message)
      return
    }

    if (this.gameModeVariation === 0) {
      player.resetScore()
    }
    player.ownObjectId = 0
  }

  getPlayerWithObject (globalId) {
    const gameObject = this.gameObjectManager.getGameObjectByID(globalId)
    if (gameObject == null) return null
    return gameObject.getPlayer()
  }

  getTileMap () {
    return this.tileMap
  }

  start () {
    if (this.updateTimer != null) return
    this.updateTimer = setInterval(() => this.update(), Math.trunc(1000 / 20))
  }

  disposeTimer () {
    if (this.updateTimer != null) {
      clearInterval(this.updateTimer)
      this.updateTimer = null
    }
  }

  update () {
    this.executeOneTick()
  }

  getPlayer (globalId) {
    const gameObject = this.gameObjectManager.getGameObjectByID(globalId)
    if (gameObject == null) return null
    return gameObject.getPlayer()
  }

  addSpectator (sessionId, gameListener) {
    if (this.spectators.has(sessionId)) {
      this.spectators.delete(sessionId)
    }
    if (gameListener != null) this.spectators.set(sessionId, gameListener)
  }

  addPetrol (a2, a3, a4, a5, a6, a7) {
    const v32 = new Petrol(a2, a3, a4, a5, a6, a7)
    this.gameObjectManager.petrols.push(v32)
    return v32
  }

  changePlayerSessionId (old, newId) {
    if (this.playersBySessionId.has(old)) {
      const player = this.playersBySessionId.get(old)
      player.lastHandledInput = 0
      this.playersBySessionId.delete(old)
      this.playersBySessionId.set(newId, player)
      player.sessionId = newId
    }
  }

  getPlayerBySessionId (sessionId) {
    const player = this.playersBySessionId.get(sessionId)
    return player != null ? player : null
  }

  addPlayer (player, sessionId) {
    if (Debugger.doAssert(player != null, 'LogicBattle::AddPlayer - player is NULL!')) {
      player.sessionId = sessionId
      if (this.gameModeVariation === 5 || this.gameModeVariation === 16 || this.gameModeVariation === 21 || this.gameModeVariation === 22) {
        if (player.accessoryDatas != null) player.accessoryDatas.fill(null)
        if (player.accessoryCardDatas != null) player.accessoryCardDatas.fill(null)
        player.accessory = null
      }
      this.players.push(player)
      if (sessionId > 0) {
        this.playersBySessionId.set(sessionId, player)
      }
      if (player.avatar != null) {
        player.avatar.battleId = this.id
        player.avatar.teamIndex = player.teamIndex
        player.avatar.ownIndex = player.playerIndex
      }
      if (this.hasEventModifier(13) || player.isAdmin) player.addUltiCharge(4000)
    }
  }

  removePlayer (player) {
    if (Debugger.doAssert(player != null, 'LogicBattle::RemovePlayer - player is NULL!')) {
      player.gameListener = null
      this.playersBySessionId.delete(player.sessionId)
      if (player.avatar != null) {
        player.avatar.battleId = -1
      }
    }
  }

  static setTilePosition (character, player, x, y) {
    character.setPosition(x, y, 0)
    player.setSpawnPoint(x, y)
  }

  addGameObjects () {
    const Character = getCharacterClass()
    const tileMap = this.tileMap
    this.playersAlive = this.players.length
    let team1Indexer = 0
    let team2Indexer = 0

    if (this.gameModeVariation === 19) {
      this.playerIndexesForTeam1 = this.getPlayerIndexesByTeam(0)
      this.playerIndexesForTeam2 = this.getPlayerIndexesByTeam(1)
      if (this.playerIndexesForTeam1.length > 0) this.team1King = this.playerIndexesForTeam1[Math.floor(Math.random() * this.playerIndexesForTeam1.length)]
      if (this.playerIndexesForTeam2.length > 0) this.team2King = this.playerIndexesForTeam2[Math.floor(Math.random() * this.playerIndexesForTeam2.length)]
    }

    for (const player of this.players) {
      const character = this.spawnHero(player.characterData, player.heroPowerLevel, player.teamIndex * 16 + player.playerIndex, 0, false)
      if (player.characterData.name === 'WeaponThrower') player.chargeUlti(4000, false, false)
      player.isAlive = true
      character.setBot(player.isBot())

      if (GameModeUtil.hasTwoTeams(this.gameModeVariation)) {
        let spawns = player.teamIndex === 0 ? tileMap.spawnPointsTeam1 : tileMap.spawnPointsTeam2
        let useTeam1Indexer = player.teamIndex === 0
        if (spawns.length === 0) {
          spawns = player.teamIndex === 0 ? tileMap.spawnPointsTeam2 : tileMap.spawnPointsTeam1
          useTeam1Indexer = !useTeam1Indexer
        }
        const tile = spawns.length > 0 ? spawns[(useTeam1Indexer ? team1Indexer++ : team2Indexer++) % spawns.length] : null
        if (tile != null) BattleMode.setTilePosition(character, player, tile.x + 150, tile.y + 150)
      } else if (this.gameModeVariation === 9) {
        const spawns = tileMap.spawnPointsTeam1
        if (spawns.length > 0) {
          const spawnPointIndex = player.teamIndex % 5
          let safeIndex = spawnPointIndex * 2
          if (safeIndex >= spawns.length) safeIndex = safeIndex % spawns.length
          const baseTile = spawns[safeIndex]
          const positionInTeam = player.playerIndex % 2
          const offsetX = positionInTeam === 0 ? -300 : 300
          const offsetY = 0
          BattleMode.setTilePosition(character, player, baseTile.x + 150 + offsetX, baseTile.y + 150 + offsetY)
        }
      } else if (GameModeUtil.hasFiveTeams(this.gameModeVariation)) {
        if (this._fiveTeamsSpawnCounters == null) {
          this._fiveTeamsSpawnCounters = [0, 0, 0, 0, 0]
        }
        const spawns = tileMap.spawnPointsTeam1
        const spawnPointIndex = player.teamIndex % 5
        if (spawns.length > 0) {
          const baseTile = spawns[(spawnPointIndex * 2) % spawns.length]
          const positionInTeam = this._fiveTeamsSpawnCounters[spawnPointIndex] % 2
          this._fiveTeamsSpawnCounters[spawnPointIndex]++
          const offsetX = positionInTeam * 600 * 2
          const offsetY = 0
          BattleMode.setTilePosition(character, player, baseTile.x + 150 + offsetX, baseTile.y + 150 + offsetY)
        }
      } else {
        const spawns = tileMap.spawnPointsTeam1
        if (spawns.length > 0) {
          const tile = spawns[team1Indexer++ % spawns.length]
          BattleMode.setTilePosition(character, player, tile.x + 150, tile.y + 150)
        }
      }

      player.ownObjectId = character.getGlobalID()
      character.setHeroLevel(player.heroPowerLevel - 1)
      if (this.gameModeVariation === 19) {
        if (player.playerIndex === this.team2King) character.setKing()
        if (player.playerIndex === this.team1King) character.setKing()
      }
    }

    if (this.gameModeVariation === 0) {
      const itemData = DataTables.getItemByName('OrbSpawner')
      if (itemData != null) {
        const Item = getItemClass()
        const item = new Item(itemData)
        item.setPosition(3150, 4950, 0)
        item.setIndex(16)
        this.gameObjectManager.addGameObject(item)
      }
    }

    if (this.gameModeVariation === 3) {
      const itemData = DataTables.getItemByName('Money')
      if (itemData != null) {
        const Item = getItemClass()
        const item = new Item(itemData)
        item.setPosition(3150, 4950, 0)
        this.gameObjectManager.addGameObject(item)
      }
    }

    if (this.gameModeVariation === 6 || this.gameModeVariation === 9) {
      const data = DataTables.getCharacterByName('LootBox')
      if (data != null) {
        for (let i = 0; i < tileMap.height; i++) {
          for (let j = 0; j < tileMap.width; j++) {
            const tile = tileMap.getTile(j, i, true)
            if (tile != null && tile.code === '4') {
              const sh = this.getRandomInt(0, 120) < 80
              if (sh) {
                const box = new Character(data)
                box.setPosition(tile.x + 150, tile.y + 150, 0)
                box.setIndex(170)
                box.hitpoints = 4300
                box.maxHitpoints = 4300
                this.gameObjectManager.addGameObject(box)
              }
            }
          }
        }
      }
    }

    if (this.gameModeVariation === 5) {
      const ball = new Character(DataTables.getCharacterByName('LaserBall'))
      ball.setPosition(Math.trunc(this.getTileMap().logicWidth / 2), Math.trunc(this.getTileMap().logicHeight / 2), 0)
      ball.setIndex(0)
      this.gameObjectManager.addGameObject(ball)
      this.carryable = ball
    }

    if (this.gameModeVariation === 21) {
      const ballData = DataTables.getCharacterByName('HoldingBall')
      if (ballData != null) {
        const ball = this.createCenteredBall(ballData)
        ball.setForcedVisible()
        this.gameObjectManager.addGameObject(ball)
        this.carryable = ball
        this._holdTheBallReturnTick = -1
        this._holdTheBallNextProgressTick = this.getTicksGone() + BattleMode.HOLD_THE_BALL_PROGRESS_INTERVAL_TICKS
      }
    }

    if (this.gameModeVariation === 22) {
      const ballData = DataTables.getCharacterByName('BasketBall')
      if (ballData != null) {
        const ball = this.createCenteredBall(ballData)
        ball.setForcedVisible()
        this.gameObjectManager.addGameObject(ball)
        this.carryable = ball
      }
      const hoopData = DataTables.getItemByName('BasketBrawlHoop')
      if (hoopData != null) {
        const Item = getItemClass()
        const hoop0 = new Item(hoopData)
        hoop0.setPosition(300, Math.trunc(this.getTileMap().logicHeight / 2), 0)
        hoop0.setIndex(0)
        hoop0.setForcedVisible()
        this.gameObjectManager.addGameObject(hoop0)
        const hoop1 = new Item(hoopData)
        hoop1.setPosition(this.getTileMap().logicWidth - 300, Math.trunc(this.getTileMap().logicHeight / 2), 0)
        hoop1.setIndex(16)
        hoop1.setForcedVisible()
        this.gameObjectManager.addGameObject(hoop1)
      }
    }

    if (this.gameModeVariation === 10) {
      const bossData = DataTables.getCharacterByName('RaidBoss')
      if (bossData != null && tileMap.raidBossSpawn != null) {
        const raidBoss = new Character(bossData)
        raidBoss.setPosition(tileMap.raidBossSpawn.x + 150, tileMap.raidBossSpawn.y + 150, 0)
        raidBoss.setIndex(16)
        this.gameObjectManager.addGameObject(raidBoss)
      }
    }

    if (this.gameModeVariation === 2 || this.gameModeVariation === 11) {
      const b = DataTables.getCharacterByName(this.gameModeVariation === 2 ? 'Safe' : 'RoboWarsBase')
      if (b != null && tileMap.spawnPointsBases.length >= 2) {
        const base1 = new Character(b)
        base1.setPosition(tileMap.spawnPointsBases[0].x + 150, tileMap.spawnPointsBases[0].y + 150, 0)
        base1.setIndex(22)
        base1.teamIndex = 1
        this.gameObjectManager.addGameObject(base1)
        const base2 = new Character(b)
        base2.setPosition(tileMap.spawnPointsBases[1].x + 150, tileMap.spawnPointsBases[1].y + 150, 0)
        base2.setIndex(6)
        base2.teamIndex = 0
        this.gameObjectManager.addGameObject(base2)
      }
    }

    if (this.gameModeVariation === 13) {
      let trainingDummyIndex = 24
      const spawnTrainingDummy = (dataName, spawner) => {
        if (spawner == null) return
        const dummyData = DataTables.getCharacterByName(dataName)
        if (dummyData == null) return
        const dummy = new Character(dummyData)
        dummy.setPosition(spawner.x + 150, spawner.y + 150, 0)
        dummy.setIndex(trainingDummyIndex++)
        dummy.teamIndex = 1
        this.gameObjectManager.addGameObject(dummy)
      }
      for (const spawner of tileMap.trainingDummyBigSpawners) spawnTrainingDummy('TrainingDummyBig', spawner)
      for (const spawner of tileMap.trainingDummySmallSpawners) spawnTrainingDummy('TrainingDummySmall', spawner)
      for (const spawner of tileMap.trainingDummyShooting) spawnTrainingDummy('TrainingDummyShooting', spawner)
      for (const spawner of tileMap.trainingDummyMediumSpawners) spawnTrainingDummy('TrainingDummyMedium', spawner)
    }

    if (this.gameModeVariation === 16) {
      if (this.ctf == null) this.ctf = new CtfState(this)
      this.ctf.initialize()
    }

    if (this.gameModeVariation === 17) {
      const areaData = DataTables.getAreaEffectByName('KingOfHillArea')
      if (areaData != null) {
        const AreaEffect = getAreaEffectClass()
        for (let i = 0; i < tileMap.zonesSpawnPoints.length; i++) {
          const area = new AreaEffect(areaData)
          area.setPosition(tileMap.zonesSpawnPoints[i].x + 150, tileMap.zonesSpawnPoints[i].y + 150, 0)
          area.setIndex(16)
          area.kohUID = i
          this._koHStates.push(new KingOfHillState(i))
          this.gameObjectManager.addGameObject(area)
          area.trigger()
        }
      }
    }

    if (this.gameModeVariation === 23) {
      const volleyData = DataTables.getCharacterByName('VolleyBall')
      if (volleyData != null) {
        const volley = new Character(volleyData)
        volley.setPosition(3150, 4950, 0)
        this.gameObjectManager.addGameObject(volley)
        volley.setIndex(16)
      }
    }

    const spawnTileItems = (tiles, itemName) => {
      const d = DataTables.getItemByName(itemName)
      if (d == null) return
      const Item = getItemClass()
      for (const tile of tiles) {
        const it = new Item(d)
        it.setPosition(tile.x + 150, tile.y + 150, 0)
        it.setIndex(16)
        it.setForcedVisible()
        this.gameObjectManager.addGameObject(it)
      }
    }
    spawnTileItems(tileMap.healTiles, 'Healing')
    spawnTileItems(tileMap.damageTiles, 'IntervalDamage')
    spawnTileItems(tileMap.tramplineTilesUp, 'SpringBoardUp')
    spawnTileItems(tileMap.tramplineTilesDown, 'SpringBoardDown')
    spawnTileItems(tileMap.tramplineTilesLeft, 'SpringBoardLeft')
    spawnTileItems(tileMap.tramplineTilesRight, 'SpringBoardRight')
    spawnTileItems(tileMap.tramplineTilesUpRight, 'SpringBoardUpRight')
    spawnTileItems(tileMap.tramplineTilesUpLeft, 'SpringBoardUpLeft')
    spawnTileItems(tileMap.tramplineTilesDownRight, 'SpringBoardDownRight')
    spawnTileItems(tileMap.tramplineTilesDownLeft, 'SpringBoardDownLeft')
  }

  respawnCTFCarryable (carryable) {
    const flagData = DataTables.getCharacterByName('CaptureFlag')
    if (carryable === this.carryableTeam0 && this.carryableTeam0 != null) {
      this.carryableTeam0.causeDamage(null, 99999, 99999, false, null, false)
      this.carryableTeam0.carringCharacter = null
      if (flagData != null && this.tileMap.ctfBaseSpawn.length > 0) {
        const flag = this.spawnHero(flagData, 11, -16, 0, false)
        flag.setPosition(this.tileMap.ctfBaseSpawn[0].x + 150, this.tileMap.ctfBaseSpawn[0].y + 150, 0)
        this.carryableTeam0 = flag
      }
    }
    if (carryable === this.carryableTeam1 && this.carryableTeam1 != null) {
      this.carryableTeam1.causeDamage(null, 99999, 99999, false, null, false)
      this.carryableTeam1.carringCharacter = null
      if (flagData != null && this.tileMap.ctfBaseSpawn.length > 1) {
        const flag = this.spawnHero(flagData, 11, 0, 0, false)
        flag.setPosition(this.tileMap.ctfBaseSpawn[1].x + 150, this.tileMap.ctfBaseSpawn[1].y + 150, 0)
        this.carryableTeam1 = flag
      }
    }
  }

  removeSpectator (id) {
    this.spectators.delete(id)
  }

  isInPlayArea (x, y) {
    return this.playArea.isInside(x + 150, y + 150)
  }

  getTeamPlayersCount (teamIndex) {
    let result = 0
    for (const player of this.getPlayers()) {
      if (player.teamIndex === teamIndex) result++
    }
    return result
  }

  addClientInput (input, sessionId) {
    if (!this.playersBySessionId.has(sessionId) || input == null) return
    input.ownerSessionId = sessionId
    this.inputQueue.push(input)
  }

  handleSpectatorInput (input, sessionId) {
    if (input == null) return
    if (!this.spectators.has(sessionId)) return
    this.spectators.get(sessionId).handledInputs = input.index
  }

  getCharacterByID (globalId) {
    const gameObject = this.gameObjectManager.getGameObjectByID(globalId)
    if (gameObject == null || gameObject.getObjectType() !== 0) return null
    return gameObject
  }

  handleClientInput (input) {
    if (input == null) return
    const player = this.getPlayerBySessionId(input.ownerSessionId)
    if (player == null) return
    if (player.lastHandledInput >= input.index) return
    player.lastHandledInput = input.index
    const character1 = this.getCharacterByID(player.ownObjectId)
    if ((character1 == null || !character1.isAlive()) && input.type !== 4 && input.type !== 9) return
    if (character1 != null && character1.viusalChargeType > 0 && input.type >= 2 && input.type <= 8) return

    switch (input.type) {
      case 0: {
        const character = character1
        const skill = character.getWeaponSkill()
        if (skill == null) return
        character.ultiDisabled()
        if (input.autoAttack) {
          this.applyAutoAttackTarget(character, input)
          character.activateSkill(0, input.x, input.y)
          break
        } else if (skill.skillData.isPositionalTargeted()) {
          character.activateSkill(0, input.x, input.y)
        } else {
          let aimX = input.x
          let aimY = input.y
          if (this.isPlayFieldMirroredForPlayer(player.teamIndex)) {
            aimX = -aimX
            aimY = -aimY
          }
          const targetX = aimX + character.getX()
          const targetY = aimY + character.getY()
          character.activateSkill(0, targetX, targetY)
          if (skill.skillData.buttonExportName === 'rapid_fire_button') {
            character.isRapidFireHeld = true
            character.rapidFireRepeatX = targetX
            character.rapidFireRepeatY = targetY
            character.rapidFireRepeatTick = this.getTicksGone()
          }
        }
        const counter = character1.getFadeCounter()
        character1.incrementFadeCounter()
        character.setFadeCounter(counter)
        character1.resetAFKTicks()
        break
      }
      case 1: {
        const character = character1
        if (character.skills[1] != null) character.skills[1].seemToBeActive = false
        if (character.displayUltiTmp) return
        const skill = character.getUltimateSkill()
        if (skill == null) return
        character.ultiDisabled()
        if (!player.hasUlti()) return
        character.ultiEnabled()
        skill.isFromAutoAttack = input.autoAttack
        if (input.autoAttack) {
          this.applyAutoAttackTarget(character, input)
          character.activateSkill(1, input.x, input.y)
          break
        } else if (skill.skillData.isPositionalTargeted()) {
          character.activateSkill(1, input.x, input.y)
        } else {
          let aimX = input.x
          let aimY = input.y
          if (this.isPlayFieldMirroredForPlayer(player.teamIndex)) {
            aimX = -aimX
            aimY = -aimY
          }
          character.activateSkill(1, aimX + character.getX(), aimY + character.getY())
        }
        const counter = character1.getFadeCounter()
        character1.incrementFadeCounter()
        character.setFadeCounter(counter)
        character1.resetAFKTicks()
        break
      }
      case 2: {
        const character = character1
        if (character.slippery) {
          const dx = input.x - character.getX()
          const dy = input.y - character.getY()
          const distSq = dx * dx + dy * dy
          let dist = distSq > 0 ? LogicMath.sqrt(distSq) : 0
          if (dist < 60) {
            character.moveTo(0, input.x, input.y, 0, 0, 0, 0)
            break
          }
          let targetAngle = dist > 0 ? LogicMath.getAngle(dx, dy) : character.moveAngle
          let angleDiff = (targetAngle - character.moveAngle) % 360
          if (angleDiff > 180) angleDiff -= 360
          if (angleDiff < -180) angleDiff += 360
          const maxTurn = 20
          if (angleDiff > maxTurn) targetAngle = character.moveAngle + maxTurn
          else if (angleDiff < -maxTurn) targetAngle = character.moveAngle - maxTurn
          targetAngle = LogicMath.normalizeAngle360(targetAngle)
          if (dist < 40) dist = 40
          input.x = character.getX() + LogicMath.getRotatedX(dist, 0, targetAngle)
          input.y = character.getY() + LogicMath.getRotatedY(dist, 0, targetAngle)
        }
        character.moveTo(0, input.x, input.y, 0, 0, 0, 0)
        character1.resetAFKTicks()
        break
      }
      case 4: {
        if (this.gameModeVariation === 13) {
          this.sendBattleEndToPlayer(player)
          this.removePlayer(player)
          return
        }
        break
      }
      case 5: {
        character1.ultiEnabled()
        character1.resetAFKTicks()
        break
      }
      case 6: {
        character1.ultiDisabled()
        character1.resetAFKTicks()
        break
      }
      case 8: {
        if (character1.isControlled) return
        const accessory = player.accessory
        if (accessory != null) accessory.triggerAccessory(character1, input.x, input.y)
        break
      }
      case 9: {
        if (player.lastPinUseTicks + 200 < this.getTicksGone()) player.usePin(input.emoteIndex, this.getTicksGone())
        break
      }
      case 10: {
        if (character1.isSteerMovementActive()) {
          if ((input.x | input.y) < 0) {
            character1.steerAngle = -1
          } else {
            character1.steerAngle = LogicMath.getAngle(-input.x + character1.getX(), -input.y + character1.getY())
          }
          return
        }
        const projectile = character1.getControlledProjectile()
        if (projectile == null) return
        let v26
        if ((input.x | input.y) < 0) {
          v26 = -1
        } else {
          v26 = LogicMath.getAngle(input.x - projectile.getX(), input.y - projectile.getY())
        }
        projectile.steerAngle = v26
        character1.resetAFKTicks()
        break
      }
      case 13: {
        input.x = Math.trunc(input.x * 150 / 100)
        const weaponSkill = character1.skills[0]
        const holdsSkill = weaponSkill != null && weaponSkill.skillData.attackPattern === 13
        if (character1.getSkillHoldedTicks() <= 0) {
          character1.holdSkillStarted()
          if (holdsSkill) break
          const areaEffect = GameObjectFactory.createGameObjectByData(DataTables.getAreaEffectByName('Tara005UltiSuck'))
          if (areaEffect != null) {
            areaEffect.setIndex(character1.getIndex())
            areaEffect.setPosition(character1.getX(), character1.getY(), 0)
            this.gameObjectManager.addGameObject(areaEffect)
          }
        }
        if (holdsSkill) break
        character1.setForcedAngle(LogicMath.normalizeAngle360(LogicMath.getAngle(input.x, input.y) - Math.trunc(character1.getIndex() / 16) * 180))
        character1.setVisionOverride(input.x + character1.getX(), input.y + character1.getY(), 2)
        character1.stopMovement()
        character1.setForcedVisible()
        character1.blockHealthRegen()
        if (character1.skills[1] != null) character1.skills[1].seemToBeActive = true
        character1.resetAFKTicks()
        break
      }
      default:
        if (input.type !== 7) Debugger.warning('Input is unhandled: ' + input.type)
        break
    }
  }

  applyAutoAttackTarget (character, input) {
    let target = this.getCharacterByID(input.autoAttackTarget)
    if (target == null) {
      target = character.getClosestVisibleEnemy()
    }
    if (target != null) {
      input.x = target.getX()
      input.y = target.getY()
    }
  }

  isTileOnPoisonArea (xTile, yTile) {
    if (this.gameModeVariation !== 6 && this.gameModeVariation !== 9) return false
    const tick = this.getTicksGone()
    if (tick > 500) {
      const poisons = Math.trunc((tick - 500) / 100)
      if (xTile <= poisons || xTile >= 59 - poisons || yTile <= poisons || yTile >= 59 - poisons) {
        return true
      }
    }
    return false
  }

  handleIncomingInputMessages () {
    while (this.inputQueue.length > 0) {
      this.handleClientInput(this.inputQueue.shift())
    }
  }

  executeOneTick () {
    if (this.isGameOver) {
      this.disposeTimer()
      return
    }
    try {
      const tick = this.time.getTick()
      if (!this.isEnding && tick >= 110 && this.calculateIsGameOver()) {
        this.isEnding = true
        this.endTick = tick
        this.gameOver()
        for (const player of this.getPlayers()) {
          player.resetUsingPin()
        }
      }

      if (this.isEnding) {
        this.handleIncomingInputMessages()
        if (tick >= this.endTick + BattleMode.GAME_OVER_TICKS) {
          this.disposeTimer()
          this.isGameOver = true
          return
        }
        this.gameObjectManager.preTick()
        try {
          this.sendVisionUpdateToPlayers()
        } catch (e) { }
        this.tick()
        this.time.increaseTick()
        return
      }

      this.handleIncomingInputMessages()
      for (const player of this.getPlayers()) {
        player.killList.length = 0
      }
      this.gameObjectManager.preTick()
      try {
        this.sendVisionUpdateToPlayers()
      } catch (e) { }
      this.tick()
      this.time.increaseTick()
    } catch (e) {
      const trace = '[' + new Date().toISOString() + '] Battle crashed! Mode=' + this.gameModeVariation + ' Tick=' + (this.time != null ? this.time.getTick() : 0) + ' Players=' + this.players.length + '\nMessage: ' + e.message + '\nTrace: ' + e.stack + '\n'
      Debugger.error(trace)
      try {
        fs.appendFileSync('crash-logs.txt', trace)
      } catch (err) { }
      this.disposeTimer()
      this.isGameOver = true
      for (const player of this.players.slice()) {
        try {
          if (player != null && player.gameListener != null) {
            const serverErrorMessage = new AuthenticationFailedMessage()
            serverErrorMessage.errorCode = 5
            serverErrorMessage.message = 'The battle crashed due to an unknown error!'
            player.gameListener.sendTCPMessage(serverErrorMessage)
          }
        } catch (err) { }
      }
    }
  }

  tickSpawnEventStuffDelayed () {
  }

  gameOver () {
    this.sendBattleEndToPlayers()
  }

  sendEndRoundRanked (r) {
    for (const player of this.players) {
      if (player.avatar == null || player.gameListener == null) continue
      const message = this.createBattleEndMessage(player, this.players)
      message.rankedMatch = true
      message.gameMode = 1
      message.result = (this.winnerTeam === player.teamIndex) ? 0 : 1
      message.blueTeamWins = r.blueWins
      message.redTeamWins = r.redWins
      message.round = r.currentRound
      message.solo = r.isSoloMatch
      player.gameListener.sendTCPMessage(message)
    }
    setTimeout(() => this.disposeTimer(), 5000)
  }

  sendBattleEndRanked (r) {
    const randomRange = (min, max) => min + Math.floor(Math.random() * (max - min))
    const isSolo = r.isSoloMatch
    for (const player of this.players) {
      if (player.avatar == null || player.home == null) continue
      const home = player.home
      const isVictory = (this.winnerTeam === player.teamIndex)
      const oldProgress = (isSolo ? home.rankedSoloProgress : home.rankedTrioProgress) | 0
      const currentRank = Math.trunc(oldProgress / 1000) + 1
      let delta = BattleMode.calculateRankedDelta(currentRank, isVictory)
      if (!isVictory && delta > 0) delta = -delta
      if (player.avatar.premiumLevel > 0 && home.premiumEndTime > Date.now()) {
        const vipBonus = isVictory ? randomRange(25, 50) : randomRange(10, 20)
        delta += vipBonus
      }
      let newProgress = oldProgress + delta
      if (newProgress < 1000) newProgress = 1000
      let newRank = Math.trunc(newProgress / 1000) + 1
      if (newRank > 19) newRank = 19
      if (isSolo) {
        home.rankedSoloProgress = newProgress
        home.rankedSoloRank = newRank
        home.rankedSoloMaxProgress = Math.max(home.rankedSoloMaxProgress | 0, newProgress)
        home.rankedSoloMaxRank = Math.max(home.rankedSoloMaxRank | 0, newRank)
      } else {
        home.rankedTrioProgress = newProgress
        home.rankedTrioRank = newRank
        home.rankedTrioMaxProgress = Math.max(home.rankedTrioMaxProgress | 0, newProgress)
        home.rankedTrioMaxRank = Math.max(home.rankedTrioMaxRank | 0, newRank)
      }
      const message = this.createBattleEndMessage(player, this.players)
      message.rankedMatch = true
      message.gameMode = 1
      message.result = isVictory ? 0 : 1
      message.blueTeamWins = r.blueWins
      message.redTeamWins = r.redWins
      message.round = 0
      message.solo = isSolo
      message.elo = oldProgress
      message.newElo = newProgress
      message.add = delta
      message.rank = currentRank
      message.upRank = newRank
      message.tokensReward = isVictory ? 40 : 15
      player.avatar.addTokens(message.tokensReward)
      if (player.isBot() === 0 && player.gameListener != null) {
        player.gameListener.sendTCPMessage(message)
        player.avatar.rankedRank = newRank
      }
      Debugger.print('[Ranked End] ' + player.avatar.name + ' | Delta: ' + delta + ' | Rank: ' + newRank)
    }
    r.stop()
    setTimeout(() => {
      this.isGameOver = true
      this.disposeTimer()
    }, 4000)
  }

  static calculateRankedDelta (rank, isVictory) {
    if (isVictory) return 10000
    if (rank >= 19) return 150
    if (rank <= 3) return 70
    if (rank <= 6) return 90
    if (rank <= 12) return 120
    if (rank <= 18) return 160
    return 0
  }

  sendBattleEndToPlayers () {
    if (this.isRanked) {
      const listener = LogicServerListener.instance
      const ranked = listener != null && typeof listener.getRankedMatch === 'function' ? listener.getRankedMatch(this.rankedId) : null
      if (ranked != null) {
        ranked.onRoundFinished(this.winnerTeam)
        if (ranked.blueWins >= 2 || ranked.redWins >= 2) {
          this.sendBattleEndRanked(ranked)
        } else {
          this.sendEndRoundRanked(ranked)
        }
      }
      return
    }

    for (const player of this.players) {
      try {
        if (player == null || player.sessionId < 0) continue
        if (player.battleEndSent) continue
        if (player.battleRoyaleRank === -1) player.battleRoyaleRank = 1
        if (player.avatar == null) continue
        const rank = player.battleRoyaleRank
        player.avatar.battleId = -1
        const isVictory = this.winnerTeam === player.teamIndex
        const message = this.createBattleEndMessage(player, this.players)
        const hero = player.avatar.getHero(player.characterId)
        if (player.isBot() !== 2 && this.battleWithTrophies) {
          const homeMode = this.getHomeModeFor(player)
          if (homeMode != null && homeMode.home != null) {
            homeMode.home.lastGameModeVariation = this.gameModeVariation
            homeMode.home.lastCharacterId = player.characterId
            if (homeMode.home.quests != null) {
              message.progressiveQuests = homeMode.home.quests.updateQuestsProgress(this.gameModeVariation, player.characterId, player.kills, player.damage, player.heals, homeMode.home, isVictory, rank)
            }
          }
        }

        if (this.gameModeVariation !== 6 && this.gameModeVariation !== 9) {
          message.gameMode = 1
          message.isPvP = this.battleWithTrophies
          const experienceRewards = [8, 4, 6]
          const tokensRewards = [14, 7, 10]
          const trophiesRewards = BattleMode.getTrioTrophiesTable(hero != null ? hero.trophies : 0)
          let experienceResult = 0
          let trophiesResult = 0
          let tokensResult = 0
          let premiumTrophies = 0
          if (this.winnerTeam === -1) {
            message.result = 2
            experienceResult = experienceRewards[message.result]
            trophiesResult = trophiesRewards[message.result]
            tokensResult = tokensRewards[message.result]
            message.experienceReward = experienceResult
            message.tokensReward = tokensResult
            message.trophiesReward = trophiesResult
            if (this.battleWithTrophies && hero != null) {
              hero.addTrophies(trophiesResult)
              player.avatar.addTokens(tokensResult)
              player.home.experience += experienceResult
              player.home.tokenReward += tokensResult
              player.home.trophiesReward += trophiesResult
              BattleMode.updateHighestTrophies(player.avatar)
            }
          } else if (isVictory) {
            message.result = 0
            experienceResult = experienceRewards[message.result]
            trophiesResult = trophiesRewards[message.result]
            tokensResult = tokensRewards[message.result]
            if (this.battleWithTrophies && hero != null) {
              if (player.avatar.premiumLevel === 1) {
                premiumTrophies = trophiesResult
              }
              hero.addTrophies(trophiesResult + premiumTrophies)
              player.avatar.addTokens(tokensResult)
              player.home.experience += experienceResult
              player.avatar.trioWins++
              message.experienceReward = experienceResult
              message.tokensReward = tokensResult
              message.trophiesReward = trophiesResult
              message.underdogTrophies = premiumTrophies
              player.home.tokenReward += tokensResult
              player.home.trophiesReward = LogicMath.max(player.home.trophiesReward + trophiesResult + premiumTrophies, 0)
              BattleMode.updateHighestTrophies(player.avatar)
            }
          } else {
            message.result = 1
            experienceResult = experienceRewards[message.result]
            trophiesResult = trophiesRewards[message.result]
            tokensResult = tokensRewards[message.result]
            if (hero != null && hero.trophies < -trophiesResult) trophiesResult = -hero.trophies
            message.trophiesReward = trophiesResult
            message.experienceReward = experienceResult
            message.tokensReward = tokensResult
            if (this.battleWithTrophies && hero != null) {
              hero.addTrophies(trophiesResult)
              player.avatar.addTokens(tokensResult)
              player.home.experience += experienceResult
              player.home.tokenReward += tokensResult
              player.home.trophiesReward = LogicMath.max(player.home.trophiesReward + trophiesResult, 0)
              BattleMode.updateHighestTrophies(player.avatar)
            }
          }
          message.experience = player.home != null ? player.home.experience : 0
        } else if (this.gameModeVariation === 6) {
          message.isPvP = true
          message.gameMode = 2
          const soloRank = LogicMath.clamp(rank, 1, 10)
          message.result = soloRank
          if (this.battleWithTrophies && hero != null) {
            const trophies = BattleMode.getShowdownTrophiesTable(hero.trophies)
            const premiumTrophies = 0
            const trophiesReward = trophies[soloRank - 1]
            const tokensReward = SHOWDOWN_TOKENS_REWARDS[soloRank - 1]
            message.tokensReward = tokensReward
            message.trophiesReward = trophiesReward
            message.underdogTrophies = premiumTrophies
            if (soloRank === 1) player.avatar.soloWins++
            player.avatar.addTokens(tokensReward)
            hero.addTrophies(trophiesReward)
            player.home.tokenReward += tokensReward
            player.home.trophiesReward += trophiesReward
          }
          BattleMode.updateHighestTrophies(player.avatar)
        } else if (this.gameModeVariation === 9) {
          message.isPvP = this.battleWithTrophies
          message.gameMode = 5
          const players = [player]
          message.players = players
          message.pp = players
          const rank1 = this.getAliveTeamsCountForDuo() + 1
          for (const teammate of this.players) {
            if (teammate.teamIndex !== player.teamIndex) continue
            if (teammate.battleRoyaleRank !== -1) continue
            teammate.battleRoyaleRank = rank1
            teammate.respawnStarted = false
            teammate.isAlive = false
            players.push(teammate)
          }
          const duoTeamRank = LogicMath.clamp(rank, 1, 5)
          message.result = duoTeamRank
          if (this.battleWithTrophies && hero != null) {
            const trophies = BattleMode.getDuoShowdownTrophiesTable(hero.trophies)
            const premiumTrophies = 0
            const trophiesReward = trophies[duoTeamRank - 1]
            const tokensReward = SHOWDOWN_TOKENS_REWARDS[duoTeamRank - 1]
            message.tokensReward = tokensReward
            message.trophiesReward = trophiesReward
            message.underdogTrophies = premiumTrophies
            if (rank === 1) player.avatar.duoWins++
            player.avatar.addTokens(tokensReward)
            hero.addTrophies(trophiesReward)
            player.home.tokenReward += tokensReward
            player.home.trophiesReward += trophiesReward
          }
          BattleMode.updateHighestTrophies(player.avatar)
        }

        if (player.gameListener == null) continue
        player.gameListener.sendTCPMessage(message)
        player.battleEndSent = true
      } catch (ex) {
        Debugger.error('BattleEnd processing failed for ' + (player != null ? player.accountId : null) + ': ' + (ex && ex.stack ? ex.stack : ex))
        if (player == null || player.gameListener == null || player.battleEndSent) continue
        try {
          const fallback = this.createBattleEndMessage(player, this.players)
          fallback.gameMode = this.gameModeVariation === 6 ? 2 : this.gameModeVariation === 9 ? 5 : 1
          fallback.isPvP = this.battleWithTrophies
          fallback.result = this.gameModeVariation === 6 || this.gameModeVariation === 9
            ? Math.max(1, player.battleRoyaleRank)
            : this.winnerTeam === -1 ? 2 : this.winnerTeam === player.teamIndex ? 0 : 1
          player.gameListener.sendTCPMessage(fallback)
          player.battleEndSent = true
        } catch (fallbackError) {
          Debugger.error('BattleEnd fallback failed for ' + (player != null ? player.accountId : null) + ': ' + fallbackError)
        }
      }
    }
  }

  sendBattleEndToPlayer (player) {
    if (player.battleEndSent) return

    if (this.gameModeVariation === 13) {
      if (player.avatar == null) return
      if (player.gameListener == null) return
      player.avatar.battleId = -1
      const msg13 = this.createBattleEndMessage(player, [player])
      msg13.isPvP = false
      player.gameListener.sendTCPMessage(msg13)
      player.battleEndSent = true
      return
    }

    if (this.gameModeVariation === 6) {
      const rank = LogicMath.clamp(player.isAlive || player.battleRoyaleRank === -1 ? this.playersAlive : player.battleRoyaleRank, 1, 10)
      if (player.isAlive) this.playersAlive--
      player.isAlive = false
      player.battleRoyaleRank = rank
      const message = this.createBattleEndMessage(player, [player])
      message.gameMode = 2
      message.isPvP = true
      message.result = rank
      if (player.isBot() !== 2) {
        const quests = this.updateQuests(player, false, player.battleRoyaleRank)
        if (quests != null) message.progressiveQuests = quests
      }
      if (player.avatar == null) return
      player.avatar.battleId = -1
      if (player.gameListener == null) return
      const hero = player.avatar.getHero(player.characterId)
      if (this.battleWithTrophies && hero != null) {
        const trophies = BattleMode.getShowdownTrophiesTable(hero.trophies)
        const premiumTrophies = 0
        const trophiesReward = trophies[rank - 1]
        const tokensReward = SHOWDOWN_TOKENS_REWARDS[rank - 1]
        message.tokensReward = tokensReward
        message.trophiesReward = trophiesReward
        message.underdogTrophies = premiumTrophies
        if (rank === 1) player.avatar.soloWins++
        player.avatar.addTokens(tokensReward)
        hero.addTrophies(trophiesReward)
        player.home.tokenReward += tokensReward
        player.home.trophiesReward += trophiesReward
      }
      BattleMode.updateHighestTrophies(player.avatar)
      player.gameListener.sendTCPMessage(message)
      player.battleEndSent = true
      return
    }

    if (this.gameModeVariation === 9) {
      const players = [player]
      const message = this.createBattleEndMessage(player, players)
      message.gameMode = 5
      message.isPvP = this.battleWithTrophies
      const teamHasAlive = this.getAliveCharactersByTeam(player.teamIndex).length > 0
      const teamHasRespawn = this.hasRespawningPlayersOnTeam(player.teamIndex)
      if (!teamHasAlive && !teamHasRespawn) {
        const rank = this.getAliveTeamsCountForDuo() + 1
        for (const teammate of this.players) {
          if (teammate.teamIndex !== player.teamIndex) continue
          if (teammate.battleRoyaleRank !== -1) continue
          teammate.battleRoyaleRank = rank
          teammate.respawnStarted = false
          teammate.isAlive = false
          if (teammate !== player) players.push(teammate)
        }
      }
      if (player.battleRoyaleRank === -1) player.battleRoyaleRank = this.getAliveTeamsCountForDuo() + 1
      const duoTeamRank = LogicMath.clamp(player.battleRoyaleRank, 1, 5)
      message.result = duoTeamRank
      if (player.avatar == null) return
      player.avatar.battleId = -1
      if (player.gameListener == null) return
      const hero = player.avatar.getHero(player.characterId)
      if (this.battleWithTrophies && hero != null) {
        const trophies = BattleMode.getDuoShowdownTrophiesTable(hero.trophies)
        const premiumTrophies = 0
        const trophiesReward = trophies[duoTeamRank - 1]
        const tokensReward = SHOWDOWN_TOKENS_REWARDS[duoTeamRank - 1]
        message.tokensReward = tokensReward
        message.trophiesReward = trophiesReward
        message.underdogTrophies = premiumTrophies
        if (duoTeamRank === 1) player.avatar.duoWins++
        player.avatar.addTokens(tokensReward)
        hero.addTrophies(trophiesReward)
        player.home.tokenReward += tokensReward
        player.home.trophiesReward += trophiesReward
      }
      BattleMode.updateHighestTrophies(player.avatar)
      player.gameListener.sendTCPMessage(message)
      player.battleEndSent = true
      this.removePlayer(player)
    }
  }

  getTeamScore (team) {
    let score = 0
    for (const player of this.players) {
      if (player.teamIndex === team) score += player.getScore()
    }
    return score
  }

  stopAllAI () {
    for (const character of this.gameObjectManager.getCharacters()) {
      if (character != null) character.stopAI = true
    }
  }

  scheduleStop (delay) {
    if (!this._setStopTicks || this._stopTicks === 0) this._stopTicks = this.getTicksGone() + delay
    this._setStopTicks = true
    return this.getTicksGone() >= this._stopTicks
  }

  getBaseHitpoints () {
    let base1Alive = 0
    let base2Alive = 0
    for (const character of this.gameObjectManager.getCharacters()) {
      if (character.characterData.isBase()) {
        if (Math.trunc(character.getIndex() / 16) === 0) base1Alive = character.getHitpointPercentage()
        else base2Alive = character.getHitpointPercentage()
      }
    }
    return [base1Alive, base2Alive]
  }

  getKingHitpoints () {
    let base1Alive = 0
    let base2Alive = 0
    for (const character of this.gameObjectManager.getCharacters()) {
      if (!character.characterData.isHero()) continue
      if (!character.isAlive()) continue
      const owner = character.getPlayer()
      if (owner != null && owner.playerIndex === this.getTeam1King()) base1Alive = character.getHitpointPercentage()
      if (owner != null && owner.playerIndex === this.getTeam2King()) base2Alive = character.getHitpointPercentage()
    }
    return [base1Alive, base2Alive]
  }

  calculateIsGameOver () {
    switch (this.gameModeVariation) {
      case 16:
        if (this.getTeamScore(0) >= 2 || this.getTeamScore(1) >= 2) {
          this.winnerTeam = this.getTeamScore(0) >= 2 ? 0 : 1
          this.stopAllAI()
          const stop = this.scheduleStop(65)
          if (!this._pinsReseted) {
            for (const player of this.players) {
              if (player != null) player.lastPinUseTicks = -999
            }
            this._pinsReseted = true
          }
          if (stop) return true
        }
        break
      case 21:
      case 22: {
        const targetScore = this.gameModeVariation === 21 ? 100 : 6
        if (this.getTeamScore(0) >= targetScore || this.getTeamScore(1) >= targetScore) {
          this.winnerTeam = this.getTeamScore(0) >= targetScore ? 0 : 1
          this.stopAllAI()
          if (this.scheduleStop(65)) return true
        }
        break
      }
      case 0: {
        const score0 = this.getTeamScore(0)
        const score1 = this.getTeamScore(1)
        if ((score0 > score1 && score0 >= 10) || (score0 < score1 && score1 >= 10)) {
          if (this.gemGrabCountdown === 0) {
            this.gemGrabCountdown = this.getTicksGone() + 20 * 17
          } else if (this.getTicksGone() > this.gemGrabCountdown) {
            this.winnerTeam = score0 > score1 ? 0 : 1
            this.stopAllAI()
            if (this.scheduleStop(10)) return true
          }
        } else {
          this.gemGrabCountdown = 0
        }
        break
      }
      case 3:
      case 25: {
        const target = this.gameModeVariation === 3 ? 20 : 10
        if (this.getTeamScore(0) >= target || this.getTeamScore(1) >= target) {
          this.winnerTeam = this.getTeamScore(0) >= target ? 0 : 1
          this.stopAllAI()
          if (this.scheduleStop(10)) return true
        }
        break
      }
      case 5:
        if (this.getTeamScore(0) >= 2 || this.getTeamScore(1) >= 2) {
          if (this.goalTicks > 0) return false
          this.canReset = false
          this.winnerTeam = this.getTeamScore(0) >= 2 ? 0 : 1
          this.stopAllAI()
          if (this.scheduleStop(0)) return true
        }
        break
      case 23:
        if (this.getTeamScore(0) >= 3 || this.getTeamScore(1) >= 3) {
          this.canReset = false
          this.winnerTeam = this.getTeamScore(0) >= 3 ? 0 : 1
          this.stopAllAI()
          if (this.scheduleStop(10)) return true
        }
        break
      case 9:
        if (this.getAliveTeams() <= 1) {
          const aliveTeams = this.getAliveTeamsList()
          this.winnerTeam = aliveTeams.length === 1 ? aliveTeams[0] : -1
          if (this.winnerTeam >= 0) {
            for (const player of this.players) {
              if (player.teamIndex === this.winnerTeam && player.battleRoyaleRank === -1) {
                player.battleRoyaleRank = 1
              }
            }
          }
          this.stopAllAI()
          if (this.scheduleStop(10)) return true
        } else {
          const anyRealPlayerAlive = this.players.some(p => p.isBot() === 0 && p.isAlive)
          if (!anyRealPlayerAlive) {
            this.stopAllAI()
            if (this.scheduleStop(20 * 5)) return true
          }
        }
        break
      case 17:
        if (this.zone1Score >= 100 || this.zone2Score >= 100) {
          this.winnerTeam = this.zone1Score >= 100 ? 0 : 1
          this.stopAllAI()
          if (this.scheduleStop(10)) return true
        }
        break
      case 6:
        if (this.playersAlive <= 1) {
          this.winnerTeam = 1
          if (this.scheduleStop(10)) return true
        } else {
          const anyRealPlayerAlive = this.players.some(p => p.isBot() === 0 && p.isAlive)
          if (!anyRealPlayerAlive) {
            this.winnerTeam = 1
            if (this.scheduleStop(20 * 5)) return true
          }
        }
        break
      case 19: {
        const [base1Alive, base2Alive] = this.getKingHitpoints()
        if (base1Alive <= 0 || base2Alive <= 0) {
          if (base1Alive <= 0) {
            this.winnerTeam = 1
          } else if (base2Alive <= 0) {
            this.winnerTeam = 0
          }
          this.stopAllAI()
          if (this.scheduleStop(0)) return true
        }
        break
      }
    }

    if (this.gameModeVariation === 20) {
      let team0Wins = 0
      let team1Wins = 0
      for (let i = 0; i < 3; i++) {
        if (this.roundWinners[i] === 0) team0Wins++
        else if (this.roundWinners[i] === 1) team1Wins++
      }
      if (team0Wins >= 2 || team1Wins >= 2) {
        this.winnerTeam = (team0Wins > team1Wins) ? 0 : 1
        return true
      }
      if (this.currentRound >= 2 && this.isRoundEnding && this.getTicksGone() >= this.roundEndTick) {
        if (team0Wins === team1Wins) this.winnerTeam = -1
        else this.winnerTeam = (team0Wins > team1Wins) ? 0 : 1
        return true
      }
      return false
    }

    if (GameModeUtil.hasTwoBases(this.gameModeVariation)) {
      const [base1Alive, base2Alive] = this.getBaseHitpoints()
      if (base1Alive <= 0 || base2Alive <= 0) {
        if (base1Alive <= 0) {
          this.winnerTeam = 1
        } else if (base2Alive <= 0) {
          this.winnerTeam = 0
        }
        this.stopAllAI()
        if (this.scheduleStop(10)) return true
      }
    }

    if (this.getTicksGone() >= GameModeUtil.getBattleTicks(this.gameModeVariation) - 1) {
      if (!this._setStopTicks) {
        if (GameModeUtil.hasTwoBases(this.gameModeVariation)) {
          const [base1Alive, base2Alive] = this.getBaseHitpoints()
          if (base1Alive > base2Alive) this.winnerTeam = 0
          else if (base1Alive < base2Alive) this.winnerTeam = 1
          else this.winnerTeam = -1
        } else if (this.gameModeVariation === 19) {
          const [base1Alive, base2Alive] = this.getKingHitpoints()
          if (base1Alive > base2Alive) this.winnerTeam = 0
          else if (base1Alive < base2Alive) this.winnerTeam = 1
          else this.winnerTeam = -1
        }
      }
      this.stopAllAI()
      if (this.scheduleStop(10)) return true
    }

    return false
  }

  hasRespawningPlayersOnTeam (teamIndex) {
    for (const player of this.players) {
      if (player.teamIndex === teamIndex && !player.isAlive && player.respawnStarted) return true
    }
    return false
  }

  isTeamAliveOrRespawning (teamIndex) {
    const alive = this.getAliveCharactersByTeam(teamIndex)
    if (alive != null && alive.length > 0) return true
    return this.gameModeVariation === 9 && this.hasRespawningPlayersOnTeam(teamIndex)
  }

  getAliveTeamsCountForDuo () {
    return this.getAliveTeamsList().length
  }

  getAliveTeams () {
    return this.getAliveTeamsList().length
  }

  getAliveTeamsList () {
    const teams = []
    for (let i = 0; i < 5; i++) {
      if (this.isTeamAliveOrRespawning(i)) teams.push(i)
    }
    return teams
  }

  getAliveCharactersByTeam (teamIndex) {
    if (this.gameObjectManager == null) return []
    const teamCharacters = []
    for (const character of this.gameObjectManager.getCharacters()) {
      const player = character.getPlayer()
      if (player != null && player.teamIndex === teamIndex && player.ownObjectId === character.getGlobalID()) {
        if (player.isAlive) teamCharacters.push(character)
      }
    }
    return teamCharacters
  }

  getPlayerIndexesByTeam (teamIndex) {
    const indexes = []
    for (const player of this.players) {
      if (player != null && player.teamIndex === teamIndex) {
        indexes.push(player.playerIndex)
      }
    }
    return indexes
  }

  getCharactersByTeam (teamIndex) {
    if (this.gameObjectManager == null) return []
    const teamCharacters = []
    for (const character of this.gameObjectManager.getCharacters()) {
      const player = character.getPlayer()
      if (player != null && player.teamIndex === teamIndex) {
        teamCharacters.push(character)
      }
    }
    return teamCharacters
  }

  tickTimers () {
    if (this.gameModeVariation === 9) this._playersAliveForDuo = this.getAliveTeams()
    if (this.tmpBrawlballTick > 1) this.tmpBrawlballTick--
    if (this.tmpBrawlballTick === 1) {
      this.tmpBrawlballTick = 0
      this.resetCarryable()
    }
    if ((this.gameModeVariation === 5 || this.gameModeVariation === 22 || this.gameModeVariation === 23) && this.goalTicks > 0) {
      this.goalTicks--
      if (this.goalResetTicks > 0) this.goalResetTicks--
      if (this.goalResetTicks === 0 && !this.goalPlayersReset) {
        if (this.gameModeVariation === 22) this.resetBasketBallAfterGoal()
        else this.resetRoundLaserBall(true)
        this.goalPlayersReset = true
      }
      if (this.goalTicks === 0) {
        this.toGoalTeam = -1
        this.goalResetTicks = 0
        this.goalPlayersReset = false
        this.goalPauseEndTick = 0
      }
    }
  }

  tick () {
    this.gameObjectManager.tick()
    if (this.gameModeVariation === 16) {
      if (this.ctf == null) this.ctf = new CtfState(this)
      this.ctf.tick()
    }
    this.tileMap.tick(this.gameObjectManager)
    this.tickSpawnEventStuffDelayed()
    if (this.gameModeVariation !== 20) this.tickSpawnHeroes()
    this.updatePlayerStatus()
    this.tickPetrols()
    this.tickTimers()
    if (this.gameModeVariation === 20) this.tickKnockout()
    if (this.gameModeVariation === 21) this.tickHoldTheBall()
  }

  tickKnockout () {
    if (this.roundWinners == null || this.roundWinners.length === 0 || this.players == null) return
    if (this.currentRound < 0 || this.currentRound >= this.roundWinners.length) {
      const wins0 = countWhere(this.roundWinners, w => w === 0)
      const wins1 = countWhere(this.roundWinners, w => w === 1)
      this.winnerTeam = wins0 === wins1 ? -1 : wins0 > wins1 ? 0 : 1
      this.isRoundEnding = true
      this.roundEndTick = this.getTicksGone()
      return
    }
    if (this.isRoundEnding) {
      if (this.getTicksGone() >= this.roundEndTick) {
        this.isRoundEnding = false
        if (this.roundWinners[this.currentRound] === -1) {
          this.roundWinners[this.currentRound] = 2
          this.restartKnockoutRound()
          return
        }
        if (countWhere(this.roundWinners, w => w === 0) >= 2 || countWhere(this.roundWinners, w => w === 1) >= 2) return
        this.currentRound++
        this.restartKnockoutRound()
      }
      return
    }
    this.roundTicks = this.getTicksGone() - this.roundStartTime
    const alive0 = countWhere(this.players, p => p.teamIndex === 0 && p.isAlive)
    const alive1 = countWhere(this.players, p => p.teamIndex === 1 && p.isAlive)
    if (alive0 === 0 || alive1 === 0) {
      this.roundWinners[this.currentRound] = alive0 > alive1 ? 0 : alive1 > alive0 ? 1 : -1
      this.isRoundEnding = true
      this.roundEndTick = this.getTicksGone() + 70
      this.roundEndTickBlock = this.getTicksGone() + 180
    } else if (this.roundTicks >= 20 * 60 * 3) {
      this.roundWinners[this.currentRound] = -1
      this.isRoundEnding = true
      this.roundEndTick = this.getTicksGone() + 70
      this.roundEndTickBlock = this.getTicksGone() + 180
    }
  }

  restartKnockoutRound () {
    for (const obj of this.gameObjectManager.getGameObjects()) {
      if (obj != null) this.gameObjectManager.removeGameObject(obj)
    }
    this.roundStartTime = this.getTicksGone()
    this.roundTicks = 0
    for (const player of this.players.slice()) {
      if (player != null) this.spawnHeroAtSpawnPoint(player)
    }
  }

  spawnHeroAtSpawnPoint (player) {
    if (player == null || player.characterData == null) return
    const spawnPoint = player.getSpawnPoint()
    if (spawnPoint == null) return
    const character = this.spawnHero(player.characterData, player.heroPowerLevel, player.teamIndex * 16 + player.playerIndex, 0, false)
    if (character == null) return
    character.triggerBlink(spawnPoint.x, spawnPoint.y, null, null, 0, 0)
    character.setBot(player.isBot())
    character.spawnTick = this.getTicksGone()
    character.isInvincible = true
    player.ownObjectId = character.getGlobalID()
    player.isAlive = true
  }

  getKnockoutRoundWinners (teamIndex) {
    const winners = [0, 0, 0]
    for (let i = 0; i < 3; i++) {
      winners[i] = this.roundWinners[i]
    }
    return winners
  }

  tickPetrols () {
    const petrols = this.gameObjectManager.petrols
    const toRemove = []
    for (const v5 of petrols.slice()) {
      if (v5.tick(this.gameObjectManager)) {
        toRemove.push(v5)
        for (const v9 of petrols) {
          if (v9.teamIndex === v5.teamIndex && LogicMath.abs(v9.x - v5.x) <= 1 && LogicMath.abs(v9.y - v5.y) <= 1) v9.ignite(this.gameObjectManager, v5.damage)
        }
      }
    }
    for (const v1 of toRemove) {
      const index = petrols.indexOf(v1)
      if (index !== -1) petrols.splice(index, 1)
    }
  }

  updatePlayerStatus () {
    for (const player of this.players) {
      if (this.gameObjectManager.getGameObjectByID(player.ownObjectId) == null && player.isAlive) {
        player.isAlive = false
        player.deathTick = this.getTicksGone()
      }
      const character = this.getCharacterByID(player.ownObjectId)
      if (character != null) {
        const v9 = player.accessory
        if (v9 != null) v9.updateAccessory(character)
      }
    }
  }

  getZone1Score () {
    return this.zone1Score
  }

  addScoreTo1Zone () {
    this.zone1Score++
  }

  addScoreTo2Zone () {
    this.zone2Score++
  }

  getZone2Score () {
    return this.zone2Score
  }

  getTeam1King () {
    return this.team1King
  }

  getTeam2King () {
    return this.team2King
  }

  sendVisionUpdateToPlayers () {
    for (const player of this.players) {
      if (player.gameListener == null) continue
      try {
        const visionBitStream = new BitStream(1024)
        this.gameObjectManager.encode(visionBitStream, this.tileMap, player.ownObjectId, player.playerIndex, player.teamIndex)
        const visionUpdate = new VisionUpdateMessage()
        visionUpdate.tick = this.getTicksGone()
        visionUpdate.handledInputs = player.lastHandledInput
        visionUpdate.viewers = this.spectators.size
        visionUpdate.visionBitStream = visionBitStream
        player.gameListener.sendMessage(visionUpdate)
      } catch (e) {
        Debugger.error('VisionUpdate failed: ' + (e && e.stack ? e.stack : e))
      }
    }

    if (this.spectators.size === 0) return

    const spectateStream = new BitStream(64)
    this.gameObjectManager.encode(spectateStream, this.tileMap, 0, -1, -1)
    for (const gameListener of Array.from(this.spectators.values())) {
      const visionUpdate = new VisionUpdateMessage()
      visionUpdate.tick = this.getTicksGone()
      visionUpdate.handledInputs = gameListener.handledInputs | 0
      visionUpdate.viewers = this.spectators.size
      visionUpdate.visionBitStream = spectateStream
      gameListener.sendMessage(visionUpdate)
    }
  }

  getPlayers () {
    return this.players.slice()
  }

  getRandomInt (min, max) {
    if (max === undefined) return this.random.rand(min)
    return this.random.rand(max - min) + min
  }

  getTicksGone () {
    return this.time.getTick()
  }

  getGameModeVariation () {
    return this.gameModeVariation
  }

  getPlayersCountWithGameModeVariation () {
    return this.playersCountWithGameModeVariation
  }

  getRandomSeed () {
    return this.randomSeed
  }

  isPlayFieldMirroredForPlayer (teamIndex) {
    return teamIndex > 0 && GameModeUtil.hasTwoTeams(this.gameModeVariation)
  }

  get location () {
    if (this.locationId == null) return null
    const table = DataTables.get(DataType.Location)
    if (table == null) return null
    const data = table.getDataByGlobalId(this.locationId)
    return data != null ? data : null
  }
}

module.exports = BattleMode
