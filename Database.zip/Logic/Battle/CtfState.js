const DataTables = require('../Data/DataTables')
const LogicMath = require('../../Titan/Math/LogicMath')

class CtfState {
  constructor (battle) {
    this.battle = battle
    this.initialized = false
  }

  initialize () {
    if (this.initialized) return
    const battle = this.battle
    const tileMap = battle.getTileMap()
    const flagData = DataTables.getCharacterByName('CaptureFlag')
    if (flagData == null || tileMap.ctfBaseSpawn.length < 2) return

    const flag0 = battle.spawnHero(flagData, 11, -16, 0, false)
    flag0.setPosition(tileMap.ctfBaseSpawn[0].x + 150, tileMap.ctfBaseSpawn[0].y + 150, 0)
    battle.carryableTeam0 = flag0

    const flag1 = battle.spawnHero(flagData, 11, 0, 0, false)
    flag1.setPosition(tileMap.ctfBaseSpawn[1].x + 150, tileMap.ctfBaseSpawn[1].y + 150, 0)
    battle.carryableTeam1 = flag1

    this.initialized = true
  }

  getFlags () {
    return [this.battle.carryableTeam0, this.battle.carryableTeam1]
  }

  getCarriedFlagObject (character) {
    for (const flag of this.getFlags()) {
      if (flag != null && flag.carringCharacter === character) return flag
    }
    return null
  }

  tryThrow (character, angle) {
    const flag = this.getCarriedFlagObject(character)
    if (flag == null) return false
    flag.carringCharacter = null
    flag.setPosition(character.getX() + LogicMath.getRotatedX(300, 0, angle), character.getY() + LogicMath.getRotatedY(300, 0, angle), 0)
    flag.setForcedVisible()
    return true
  }

  tick () {
    if (!this.initialized) {
      this.initialize()
      return
    }

    const battle = this.battle
    const tileMap = battle.getTileMap()
    const flags = this.getFlags()

    for (let flagTeam = 0; flagTeam < 2; flagTeam++) {
      const flag = flags[flagTeam]
      if (flag == null) continue
      const carrier = flag.carringCharacter
      if (carrier == null) continue

      if (!carrier.isAlive()) {
        flag.carringCharacter = null
        continue
      }

      flag.setPosition(carrier.getX(), carrier.getY(), 0)

      const player = carrier.getPlayer()
      if (player == null || player.teamIndex === flagTeam) continue
      const base = tileMap.ctfBaseSpawn[player.teamIndex]
      if (base == null) continue
      const dx = carrier.getX() - (base.x + 150)
      const dy = carrier.getY() - (base.y + 150)
      if (dx * dx + dy * dy > 300 * 300) continue

      player.addScore(1)
      flag.carringCharacter = null
      battle.respawnCTFCarryable(flag)
    }
  }
}

module.exports = CtfState
