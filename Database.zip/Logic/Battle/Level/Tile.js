const DataTables = require('../../Data/DataTables')
const DataType = require('../../Data/DataType')

class Tile {
  static tileCodeToInstanceId (code) {
    switch (code) {
      default:
        return -1
    }
  }

  static findTileData (code) {
    const table = DataTables.get(DataType.Tile)
    for (const tileData of table.getDatas()) {
      if (tileData == null) continue
      if (tileData.tileCode != null && tileData.tileCode[0] === code) {
        return tileData
      }
    }

    return table.getData(0)
  }

  static createDynamic (dynamicCode, x, y) {
    const tile = new Tile('-', x, y)
    const table = DataTables.get(DataType.Tile)
    for (const tileData of table.getDatas()) {
      if (tileData != null && tileData.dynamicCode === dynamicCode) {
        tile.data = tileData
        break
      }
    }
    return tile
  }

  constructor (code, x, y) {
    this.code = code
    this.x = x
    this.y = y
    this.tileX = Math.trunc(x / 300)
    this.tileY = Math.trunc(y / 300)
    this.placerIndex = -1
    this.respawnTicks = 0
    this.replacement = null

    this.data = Tile.findTileData(code)

    this.destructed = false
  }

  destruct () {
    this.destructed = true
    this.respawnTicks = 0
  }

  isDestructed () {
    return this.destructed
  }

  getCheckSum () {
    return 0
  }
}

module.exports = Tile
