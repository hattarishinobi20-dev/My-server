const Tile = require('./Tile')
const GamePlayUtil = require('../../Util/GamePlayUtil')
const LogicMath = require('../../../Titan/Math/LogicMath')

class TileMap {
  constructor (width, height, data) {
    this.width = width
    this.height = height

    this.spawnPoints = []
    this.spawnPointsTeam1 = []
    this.spawnPointsTeam2 = []
    this.spawnPointsBases = []
    this.ctfBaseSpawn = []
    this.zonesSpawnPoints = []
    this.laserBallInstantRespawnTileTeam1 = []
    this.laserBallInstantRespawnTileTeam2 = []
    this.raidBossSpawn = null
    this.trainingDummyBigSpawners = []
    this.trainingDummySmallSpawners = []
    this.trainingDummyShooting = []
    this.trainingDummyMediumSpawners = []
    this.healTiles = []
    this.damageTiles = []
    this.tramplineTilesUp = []
    this.tramplineTilesDown = []
    this.tramplineTilesLeft = []
    this.tramplineTilesRight = []
    this.tramplineTilesUpRight = []
    this.tramplineTilesUpLeft = []
    this.tramplineTilesDownRight = []
    this.tramplineTilesDownLeft = []
    this.newTiles = []

    const chars = String(data)
    let idx = 0
    let bossTile = null

    this.tiles = new Array(this.height)

    for (let i = 0; i < this.height; i++) {
      this.tiles[i] = new Array(this.width)
      for (let j = 0; j < this.width; j++) {
        const code = idx < chars.length ? chars[idx] : '.'
        const tile = new Tile(code, 300 * j, 300 * i)
        this.tiles[i][j] = tile

        switch (code) {
          case '1':
            this.spawnPoints.push(tile)
            this.spawnPointsTeam1.push(tile)
            break
          case '2':
            this.spawnPoints.push(tile)
            this.spawnPointsTeam2.push(tile)
            break
          case '0':
            this.trainingDummySmallSpawners.push(tile)
            break
          case '3':
            this.trainingDummyBigSpawners.push(tile)
            break
          case '4':
            this.trainingDummyShooting.push(tile)
            break
          case '5':
            if (bossTile == null) bossTile = tile
            break
          case '6':
            this.laserBallInstantRespawnTileTeam1.push(tile)
            break
          case '7':
            this.laserBallInstantRespawnTileTeam2.push(tile)
            break
          case '8':
            this.spawnPointsBases.push(tile)
            this.ctfBaseSpawn.push(tile)
            this.zonesSpawnPoints.push(tile)
            break
          case 'K':
            this.tramplineTilesUp.push(tile)
            break
          case 'L':
            this.tramplineTilesDown.push(tile)
            break
          case 'G':
            this.tramplineTilesLeft.push(tile)
            break
          case 'H':
            this.tramplineTilesRight.push(tile)
            break
          case 'U':
            this.tramplineTilesUpRight.push(tile)
            break
          case 'Z':
            this.tramplineTilesUpLeft.push(tile)
            break
          case 'P':
            this.tramplineTilesDownRight.push(tile)
            break
          case 'O':
            this.tramplineTilesDownLeft.push(tile)
            break
        }

        idx++
      }
    }

    if (bossTile == null && this.spawnPointsTeam2.length > 0) bossTile = this.spawnPointsTeam2[0]
    this.raidBossSpawn = bossTile
  }

  get logicWidth () {
    return TileMap.tileToLogic(this.width)
  }

  get logicHeight () {
    return TileMap.tileToLogic(this.height)
  }

  getTile (x, y, isTile = false) {
    if (!isTile) {
      x = TileMap.logicToTile(x)
      y = TileMap.logicToTile(y)
    }

    if (x >= 0 && x < this.width && y >= 0 && y < this.height) {
      return this.tiles[y][x]
    }

    return null
  }

  static logicToTile (logicValue) {
    return Math.trunc(logicValue / 300)
  }

  static tileToLogic (tile) {
    return 300 * tile + 150
  }

  getTiles () {
    return this.tiles
  }

  tick (gameObjectManager) {
    for (let i = 0; i < this.height; i++) {
      for (let j = 0; j < this.width; j++) {
        const tile = this.tiles[i][j]
        if (!tile.destructed || tile.replacement != null || tile.data == null || !(tile.data.respawnSeconds > 0)) continue
        tile.respawnTicks++
        if (tile.respawnTicks < tile.data.respawnSeconds * 20) continue
        if (gameObjectManager != null && this.isTileOccupied(gameObjectManager, j, i)) continue
        tile.destructed = false
        tile.respawnTicks = 0
      }
    }
  }

  isTileOccupied (gameObjectManager, tileX, tileY) {
    for (const character of gameObjectManager.getCharacters()) {
      if (character == null || !character.isAlive()) continue
      if (TileMap.logicToTile(character.getX()) === tileX && TileMap.logicToTile(character.getY()) === tileY) return true
    }
    return false
  }

  isPassable (type, tileX, tileY, a4, a5, canWalkOverWater = false) {
    const tile = this.getTile(tileX, tileY, true)
    if (tile == null) return false
    if (tile.replacement != null) {
      const replacementData = tile.replacement.data
      if (replacementData == null || !replacementData.blocksMovement) return true
      return canWalkOverWater && !replacementData.blocksProjectiles && !replacementData.isDestructible
    }
    if (tile.destructed) return true
    const data = tile.data
    if (data == null) return true
    if (!data.blocksMovement) return true
    if (canWalkOverWater && !data.blocksProjectiles && !data.isDestructible) return true
    return false
  }

  isOnHealTile (x, y) {
    const tile = this.getTile(x, y)
    if (tile == null) return false
    return this.healTiles.includes(tile)
  }

  destroyEnvironment (x, y, radius, onlyNonBlocking) {
    const tileX = TileMap.logicToTile(x)
    const tileY = TileMap.logicToTile(y)
    const tileRadius = Math.trunc(radius / 300) + 1
    const minX = LogicMath.clamp(tileX - tileRadius, 0, this.width - 1)
    const minY = LogicMath.clamp(tileY - tileRadius, 0, this.height - 1)
    const maxX = LogicMath.clamp(tileX + tileRadius, 0, this.width - 1)
    const maxY = LogicMath.clamp(tileY + tileRadius, 0, this.height - 1)
    let destroyed = false

    for (let i = minX; i <= maxX; i++) {
      for (let j = minY; j <= maxY; j++) {
        const tile = this.tiles[j][i]
        if (tile.destructed || tile.data == null || !tile.data.isDestructible) continue
        if (onlyNonBlocking && tile.data.blocksMovement) continue
        if (GamePlayUtil.getDistanceSquaredBetween(tile.x + 150, tile.y + 150, x, y) > radius * radius) continue
        tile.destruct()
        destroyed = true
      }
    }

    return destroyed
  }

  placeNewTile (tileX, tileY, dynamicCode, placerIndex) {
    const tile = this.getTile(tileX, tileY, true)
    if (tile == null) return null
    const newTile = Tile.createDynamic(dynamicCode, tileX * 300, tileY * 300)
    newTile.placerIndex = placerIndex
    tile.destruct()
    const index = this.newTiles.indexOf(tile.replacement)
    if (index !== -1) this.newTiles.splice(index, 1)
    tile.replacement = newTile
    this.newTiles.push(newTile)
    return newTile
  }

  calculateLOSWithCollision (startX, startY, endX, endY, width) {
    const dx = endX - startX
    const dy = endY - startY
    const distance = LogicMath.sqrt(dx * dx + dy * dy)
    const steps = Math.max(1, Math.trunc(distance / 100))

    for (let i = 1; i < steps; i++) {
      const x = startX + Math.trunc(dx * i / steps)
      const y = startY + Math.trunc(dy * i / steps)
      const tile = this.getTile(x, y)
      if (tile == null) return false
      if (tile.replacement != null) {
        if (tile.replacement.data != null && tile.replacement.data.blocksProjectiles) return false
        continue
      }
      if (!tile.destructed && tile.data != null && tile.data.blocksProjectiles) return false
    }

    return true
  }

  static getTeleportPairLocation (teleportId, gameObjectManager, ownGlobalId) {
    for (const item of gameObjectManager.getItems()) {
      if (item == null) continue
      if (item.getGlobalID() === ownGlobalId) continue
      if (item.teleportIternalId === teleportId) return item
    }
    return null
  }
}

module.exports = TileMap
