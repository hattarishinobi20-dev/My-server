const LogicVector2 = require('../../../Titan/Math/LogicVector2')

const STRAIGHT_COST = 10
const DIAGONAL_COST = 14
const MAX_EXPANSIONS = 4096

class LogicPathFinder {
  constructor (tileMap, allowDiagonals = true, canWalkOverWater = false) {
    this.tileMap = tileMap
    this.allowDiagonals = allowDiagonals
    this.canWalkOverWater = canWalkOverWater
    this.width = tileMap.width
    this.height = tileMap.height
    this.gScore = new Int32Array(this.width * this.height)
    this.parent = new Int32Array(this.width * this.height)
    this.visit = new Int32Array(this.width * this.height)
    this.closed = new Int32Array(this.width * this.height)
    this.generation = 0
  }

  isPassable (x, y) {
    if (x < 0 || y < 0 || x >= this.width || y >= this.height) return false
    return this.tileMap.isPassable(1, x, y, 0, 0, this.canWalkOverWater)
  }

  static toTile (value) {
    return Math.trunc(value / 300)
  }

  static heuristic (x1, y1, x2, y2) {
    const dx = Math.abs(x1 - x2)
    const dy = Math.abs(y1 - y2)
    return STRAIGHT_COST * (dx + dy) + (DIAGONAL_COST - 2 * STRAIGHT_COST) * Math.min(dx, dy)
  }

  findPath (start, end) {
    const width = this.width
    const height = this.height
    if (width <= 0 || height <= 0) return null
    const sx = Math.min(width - 1, Math.max(0, LogicPathFinder.toTile(start.x)))
    const sy = Math.min(height - 1, Math.max(0, LogicPathFinder.toTile(start.y)))
    const ex = Math.min(width - 1, Math.max(0, LogicPathFinder.toTile(end.x)))
    const ey = Math.min(height - 1, Math.max(0, LogicPathFinder.toTile(end.y)))
    const startIndex = sy * width + sx
    const endIndex = ey * width + ex
    if (startIndex === endIndex) return [this.tileCenter(startIndex)]

    this.generation++
    if (this.generation >= 0x7fffffff) {
      this.generation = 1
      this.visit.fill(0)
      this.closed.fill(0)
    }
    const generation = this.generation
    const heap = []
    const push = (index, f) => {
      heap.push([f, index])
      let i = heap.length - 1
      while (i > 0) {
        const p = (i - 1) >> 1
        if (heap[p][0] <= heap[i][0]) break
        const tmp = heap[p]
        heap[p] = heap[i]
        heap[i] = tmp
        i = p
      }
    }
    const pop = () => {
      const top = heap[0]
      const last = heap.pop()
      if (heap.length > 0) {
        heap[0] = last
        let i = 0
        while (true) {
          const l = 2 * i + 1
          const r = l + 1
          let m = i
          if (l < heap.length && heap[l][0] < heap[m][0]) m = l
          if (r < heap.length && heap[r][0] < heap[m][0]) m = r
          if (m === i) break
          const tmp = heap[m]
          heap[m] = heap[i]
          heap[i] = tmp
          i = m
        }
      }
      return top
    }

    this.visit[startIndex] = generation
    this.gScore[startIndex] = 0
    this.parent[startIndex] = -1
    push(startIndex, LogicPathFinder.heuristic(sx, sy, ex, ey))

    let bestIndex = startIndex
    let bestH = LogicPathFinder.heuristic(sx, sy, ex, ey)
    let expansions = 0
    let found = false
    while (heap.length > 0 && expansions < MAX_EXPANSIONS) {
      const current = pop()[1]
      if (this.closed[current] === generation) continue
      this.closed[current] = generation
      expansions++
      if (current === endIndex) {
        found = true
        break
      }
      const cx = current % width
      const cy = Math.trunc(current / width)
      const h = LogicPathFinder.heuristic(cx, cy, ex, ey)
      if (h < bestH) {
        bestH = h
        bestIndex = current
      }
      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          if (dx === 0 && dy === 0) continue
          const diagonal = dx !== 0 && dy !== 0
          if (diagonal && !this.allowDiagonals) continue
          const nx = cx + dx
          const ny = cy + dy
          const neighborIndex = ny * width + nx
          if (!this.isPassable(nx, ny)) continue
          if (diagonal && (!this.isPassable(cx + dx, cy) || !this.isPassable(cx, cy + dy))) continue
          if (this.closed[neighborIndex] === generation) continue
          const g = this.gScore[current] + (diagonal ? DIAGONAL_COST : STRAIGHT_COST)
          if (this.visit[neighborIndex] !== generation || g < this.gScore[neighborIndex]) {
            this.visit[neighborIndex] = generation
            this.gScore[neighborIndex] = g
            this.parent[neighborIndex] = current
            push(neighborIndex, g + LogicPathFinder.heuristic(nx, ny, ex, ey))
          }
        }
      }
    }

    let index = found ? endIndex : bestIndex
    if (index === startIndex) return [this.tileCenter(startIndex)]
    const path = []
    while (index !== -1) {
      path.push(this.tileCenter(index))
      if (index === startIndex) break
      index = this.parent[index]
    }
    path.reverse()
    return path
  }

  tileCenter (index) {
    const x = index % this.width
    const y = Math.trunc(index / this.width)
    return new LogicVector2(x * 300 + 150, y * 300 + 150)
  }
}

module.exports = LogicPathFinder
