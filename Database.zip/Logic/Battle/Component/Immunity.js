class Immunity {
  constructor (targetIndex, targetData, ticks, immunityPercent = 0) {
    this.targetIndex = targetIndex
    this.targetData = targetData
    this.ticks = ticks
    this.immunityPercent = immunityPercent
  }

  getImmunityPercentage () {
    return this.immunityPercent
  }

  tick (a2) {
    this.ticks -= a2
    return this.ticks < 1
  }

  destruct () {
    this.ticks = 0
  }
}

module.exports = Immunity
