class Poison {
  constructor (damage, normalDMG, isUlti, source, sourceIndex, type, slowDown = false) {
    this.type = type
    this.timer = 20
    this.source = source
    this.sourceIndex = sourceIndex
    this.damage = damage
    this.normalDMG = normalDMG
    this.isUlti = isUlti
    this.tickCount = Poison.getTickCount(type)
    this.slowDown = slowDown
  }

  hasSlowDownEffect () {
    return this.slowDown
  }

  allowStacking () {
    return false
  }

  refreshPosion (damage, normalDMG, isUlti, type) {
    this.tickCount = Poison.getTickCount(type)
    this.damage = damage
    this.normalDMG = normalDMG
    this.isUlti = isUlti
    this.type = type
  }

  refreshPoison (source, damage, tickCount) {
    this.tickCount = tickCount
    this.source = source
    this.damage = tickCount > 0 ? Math.trunc(damage / tickCount) : damage
  }

  tick (character) {
    const v3 = this.timer
    this.timer = v3 - 1
    if (v3 > 1) return false

    let v4 = true
    character.causeDamage(this.source, this.damage, this.normalDMG, this.isUlti, null, true)

    const v5 = this.tickCount
    this.timer = 20
    this.tickCount = v5 - 1
    if (v5 >= 2) v4 = false
    return v4
  }

  destruct () {
    this.timer = -1
    this.type = -1
    this.damage = 0
    this.normalDMG = 0
    this.tickCount = 0

    this.source = null
  }

  getPoisonType () {
    return this.type
  }

  static getTickCount (a1) {
    let v1 = 4
    if (a1 === 4) v1 = 2

    return v1
  }
}

module.exports = Poison
