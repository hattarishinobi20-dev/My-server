const DataTables = require('../../Data/DataTables')
const GamePlayUtil = require('../../Util/GamePlayUtil')
const LogicMath = require('../../../Titan/Math/LogicMath')
const LogicVector2 = require('../../../Titan/Math/LogicVector2')

const DEFAULT_USES = 3

function teamOf (index) {
  return Math.trunc(index / 16)
}

class Accessory {
  constructor (accessoryData) {
    this.accessoryData = accessoryData
    this.isActive = false
    this.ticksActive = 0
    this.ticksSinceActivation = 0
    this.usesLeft = accessoryData != null && accessoryData.chargeCount > 0 ? accessoryData.chargeCount : DEFAULT_USES
    this.coolDown = 0
    this.activationDelay = 0
    this.targetX = 0
    this.targetY = 0
    this.rewindHP = 0
    this.savedSeeInvisibilityDistance = 0
  }

  get type () {
    return this.accessoryData.type
  }

  getOwnPet (character) {
    const gameObjectManager = character.getGameObjectManager()
    if (gameObjectManager == null) return null
    for (const object of gameObjectManager.getGameObjects()) {
      if (object.getObjectType() !== 0 || object === character) continue
      if (object.getIndex() !== character.getIndex()) continue
      if (object.characterData.isHero() || !object.isAlive()) continue
      return object
    }
    return null
  }

  getOwnMinions (character) {
    const gameObjectManager = character.getGameObjectManager()
    if (gameObjectManager == null) return []
    return gameObjectManager.getGameObjects().filter(object => object.getObjectType() === 0 && object !== character && object.getIndex() === character.getIndex() && !object.characterData.isHero() && object.isAlive())
  }

  canTrigger (character) {
    const data = this.accessoryData
    if (data == null || character == null || !character.isAlive()) return false
    if (this.usesLeft <= 0 || this.coolDown > 0 || this.isActive || this.activationDelay > 0) return false
    if (character.stunTicks > 0 && !data.allowStunActivation) return false
    if (character.getZ() > 0) return false
    if (character.isPlayerControlRemoved()) return false
    if (data.requirePet && this.getOwnPet(character) == null) return false
    if (data.requireEnemyDistance > 0 && character.getClosestEnemy(data.requireEnemyDistance, 0, false, false, null, false, false, false) == null) return false
    if (data.consumesAmmo) {
      const weapon = character.getWeaponSkill()
      if (weapon == null || weapon.charge < 1000) return false
    }
    switch (data.type) {
      case 'consume_bush':
        return character.isInBush()
      case 'teleport_to_pet':
        return this.getOwnPet(character) != null
      case 'kill_projectile':
        return character.getControlledProjectile() != null
      case 'promote_minion':
        return this.getOwnMinions(character).length > 0
      case 'throw_opponent':
        return this.getClosestEnemyInRange(character, data.customValue1 > 0 ? data.customValue1 : 300) != null
      case 'spawn':
        return data.customObject == null || this.getSpawnData(data.customObject) != null
    }
    return true
  }

  getSpawnData (name) {
    return DataTables.getCharacterByName(name) || DataTables.getItemByName(name) || DataTables.getAreaEffectByName(name)
  }

  getClosestEnemyInRange (character, range) {
    let closest = null
    let distance = range
    for (const object of character.getGameObjectManager().getGameObjects()) {
      if (object.getObjectType() !== 0) continue
      if (teamOf(object.getIndex()) === teamOf(character.getIndex())) continue
      if (!object.isAlive() || object.characterData.isCarryable() || object.isInvincible) continue
      const d = character.getPosition().getDistance(object.getPosition())
      if (d <= distance) {
        closest = object
        distance = d
      }
    }
    return closest
  }

  triggerAccessory (character, x, y) {
    if (!this.canTrigger(character)) return false
    const data = this.accessoryData
    if (data.consumesAmmo) character.getWeaponSkill().charge -= 1000
    this.usesLeft--
    this.coolDown = data.cooldown
    this.targetX = x
    this.targetY = y
    if (data.setAttackAngle) character.attackAngle = LogicMath.getAngle(x - character.getX(), y - character.getY())
    if (data.stopMovement) character.stopMovement()
    if (data.activationDelay > 0) {
      this.activationDelay = data.activationDelay
      return true
    }
    this.activate(character)
    return true
  }

  activate (character) {
    const data = this.accessoryData
    this.isActive = true
    this.ticksActive = data.activeTicks > 0 ? data.activeTicks : 0
    this.ticksSinceActivation = 0
    this.rewindHP = 0
    if (data.interruptsAction) character.interruptAllSkills(true)
    if (data.shieldPercent > 0) character.addShield(data.shieldTicks, data.shieldPercent)
    if (data.areaEffect != null && data.type !== 'repeat_area' && data.type !== 'spin_shoot') this.spawnArea(character, data.areaEffect, character.getX(), character.getY())
    if (data.petAreaEffect != null) {
      const pet = this.getOwnPet(character)
      if (pet != null) this.spawnArea(character, data.petAreaEffect, pet.getX(), pet.getY())
    }
    if (data.destroyPet) {
      const pet = this.getOwnPet(character)
      if (pet != null) pet.causeDamage(null, pet.hitpoints, 0, false, null, false, true)
    }
    this.onActivate(character)
    if (this.ticksActive <= 0) this.endAccessoryActivation(character)
  }

  spawnArea (character, name, x, y, bonusDamage = 0) {
    const area = DataTables.getAreaEffectByName(name)
    if (area == null) return null
    return character.triggerAreaEffect(area, x, y, bonusDamage, 3)
  }

  getAimVector (character, distance) {
    let dx = this.targetX - character.getX()
    let dy = this.targetY - character.getY()
    if (dx === 0 && dy === 0) {
      dx = LogicMath.cos(character.moveAngle)
      dy = LogicMath.sin(character.moveAngle)
    }
    const length = LogicMath.max(1, LogicMath.sqrt(dx * dx + dy * dy))
    return new LogicVector2(character.getX() + Math.trunc(dx * distance / length), character.getY() + Math.trunc(dy * distance / length))
  }

  onActivate (character) {
    const data = this.accessoryData
    switch (data.type) {
      case 'consume_bush': {
        character.heal(character.getIndex(), data.customValue1, true, null)
        break
      }
      case 'jump': {
        const target = this.getAimVector(character, 1000)
        character.triggerCharge(target.x, target.y, 2000, 9, data.customValue1, 0, false)
        break
      }
      case 'dash': {
        const target = this.getAimVector(character, data.customValue1 > 0 ? data.customValue1 : 900)
        character.triggerCharge(target.x, target.y, data.customValue2 > 0 ? data.customValue2 : 2000, 4, 0, 0, false)
        break
      }
      case 'heal':
        if (data.customValue1 === 1) {
          const amount = data.customValue2 > 0 ? data.customValue2 : character.maxHitpoints
          character.heal(character.getIndex(), amount, true, null)
        }
        break
      case 'speed':
        character.giveSpeedFasterBuff(data.customValue1, data.customValue2, true)
        break
      case 'teleport_to_pet': {
        const pet = this.getOwnPet(character)
        if (pet != null) {
          character.stopMovement()
          character.setPosition(pet.getX(), pet.getY(), 0)
          if (data.customObject != null) this.spawnArea(character, data.customObject, pet.getX(), pet.getY())
        }
        break
      }
      case 'cc_immunity':
        character.addCcImmunity(data.customValue1 > 0 ? data.customValue1 : this.ticksActive)
        break
      case 'spawn':
        this.spawnObject(character)
        break
      case 'throw_opponent': {
        const enemy = this.getClosestEnemyInRange(character, data.customValue1 > 0 ? data.customValue1 : 300)
        if (enemy != null) {
          const dx = character.getX() - enemy.getX()
          const dy = character.getY() - enemy.getY()
          enemy.triggerPushback(enemy.getX() - dx * 2, enemy.getY() - dy * 2, 600, true, 0, false, false, false, false, false, false, false, 0)
        }
        break
      }
      case 'vision':
        this.savedSeeInvisibilityDistance = character.seeInvisibilityDistance
        character.seeInvisibilityDistance = 99999
        break
      case 'promote_minion':
        for (const minion of this.getOwnMinions(character)) {
          minion.maxHitpoints += Math.trunc(minion.maxHitpoints * (data.customValue1 - 100) / 100)
          minion.hitpoints = minion.maxHitpoints
        }
        break
      case 'reload': {
        const weapon = character.getWeaponSkill()
        if (weapon != null) weapon.addCharge(character, data.customValue1 * 10)
        break
      }
      case 'kill_projectile': {
        const projectile = character.getControlledProjectile()
        if (projectile != null) projectile.targetReached(5)
        break
      }
      case 'auto_super_load_boost':
        break
    }
    this.onActiveTick(character)
  }

  spawnObject (character) {
    const data = this.accessoryData
    if (data.customObject == null) return
    const spawnData = this.getSpawnData(data.customObject)
    if (spawnData == null) return
    const count = data.customValue1 > 0 ? data.customValue1 : 1
    const gameObjectManager = character.getGameObjectManager()
    const GameObjectFactory = require('../Objects/GameObjectFactory')
    for (let i = 0; i < count; i++) {
      const object = GameObjectFactory.createGameObjectByData(spawnData)
      if (object == null) continue
      const spot = new LogicVector2(character.getX(), character.getY())
      GamePlayUtil.getClosestPassableSpot(0, character.getX(), character.getY(), 3, character.getBattle().getTileMap(), spot, false)
      object.setPosition(spot.x, spot.y, 0)
      object.setIndex(character.getIndex())
      if (object.getObjectType() === 2) {
        object.damage = spawnData.damage
        object.normalDMG = 0
        object.setSource(character, 3)
        gameObjectManager.addGameObject(object)
        object.trigger()
        continue
      }
      if (object.getObjectType() === 0 && data.customValue2 > 0) {
        object.maxHitpoints = data.customValue2
        object.hitpoints = data.customValue2
      }
      if (object.owner !== undefined) object.owner = character
      gameObjectManager.addGameObject(object)
    }
  }

  onActiveTick (character) {
    const data = this.accessoryData
    const elapsed = this.ticksSinceActivation
    switch (data.type) {
      case 'repeat_area': {
        const interval = data.customValue1 > 0 ? data.customValue1 : 10
        if (elapsed % interval === 0 && data.areaEffect != null) this.spawnArea(character, data.areaEffect, character.getX(), character.getY())
        break
      }
      case 'trail':
        if (elapsed % 3 === 0 && data.customObject != null) this.spawnArea(character, data.customObject, character.getX(), character.getY())
        break
      case 'heal':
        if (data.customValue1 === 2 && elapsed % 20 === 0) character.heal(character.getIndex(), data.customValue2, true, null)
        break
      case 'spin_shoot':
        this.tickSpinShoot(character, elapsed)
        break
      case 'repeat_shot':
        this.tickRepeatShot(character, elapsed)
        break
    }
  }

  tickSpinShoot (character, elapsed) {
    const data = this.accessoryData
    if (data.areaEffect != null && elapsed === 0) this.spawnArea(character, data.areaEffect, character.getX(), character.getY())
    if (data.customObject == null) return
    const projectileData = DataTables.getProjectileByName(data.customObject)
    if (projectileData == null) return
    const Projectile = require('../Objects/Projectile')
    const bullets = LogicMath.max(1, data.customValue1)
    const total = LogicMath.max(1, data.activeTicks)
    const range = data.customValue3 > 0 ? data.customValue3 : 700
    const weapon = character.weaponSkillData
    const damage = weapon != null ? Math.trunc(weapon.damage * (data.customValue2 > 0 ? data.customValue2 : 100) / 100) : 0
    const baseAngle = Math.trunc(360 * elapsed / total) + character.attackAngle
    for (let i = 0; i < bullets; i++) {
      const angle = LogicMath.normalizeAngle360(baseAngle + Math.trunc(360 * i / bullets))
      const tx = character.getX() + ((LogicMath.cos(angle) * range) >> 10)
      const ty = character.getY() + ((LogicMath.sin(angle) * range) >> 10)
      const projectile = Projectile.shootProjectile(-1, -1, character, character, projectileData, tx, ty, damage, damage, 0, false, 0, character.getBattle(), i, 4)
      if (projectile != null) projectile.runEarlyTicks()
    }
  }

  tickRepeatShot (character, elapsed) {
    const data = this.accessoryData
    if (data.customObject == null) return
    const projectileData = DataTables.getProjectileByName(data.customObject)
    if (projectileData == null) return
    const shots = LogicMath.max(1, data.customValue1)
    const total = LogicMath.max(1, data.activeTicks)
    const interval = LogicMath.max(1, Math.trunc(total / shots))
    if (elapsed % interval !== 0 || Math.trunc(elapsed / interval) >= shots) return
    const Projectile = require('../Objects/Projectile')
    const enemy = character.getClosestEnemy(10, 0, false, false, null, false, false, false)
    const tx = enemy != null ? enemy.getX() : this.targetX
    const ty = enemy != null ? enemy.getY() : this.targetY
    const weapon = character.weaponSkillData
    const damage = weapon != null ? Math.trunc(weapon.damage * (data.customValue2 > 0 ? data.customValue2 : 100) / 100) : 0
    character.attackAngle = LogicMath.getAngle(tx - character.getX(), ty - character.getY())
    const projectile = Projectile.shootProjectile(-1, -1, character, character, projectileData, tx, ty, damage, damage, 0, false, 0, character.getBattle(), elapsed, 4)
    if (projectile != null) projectile.runEarlyTicks()
  }

  updateAccessory (character) {
    if (this.coolDown > 0) this.coolDown--
    if (this.activationDelay > 0) {
      this.activationDelay--
      if (this.activationDelay === 0) {
        if (character.isAlive()) this.activate(character)
      }
      return
    }
    if (!this.isActive) return
    if (!character.isAlive()) {
      this.endAccessoryActivation(character)
      return
    }
    this.ticksSinceActivation++
    this.onActiveTick(character)
    this.ticksActive--
    if (this.ticksActive <= 0) this.endAccessoryActivation(character)
  }

  interrupt (ignoreAccessory, character) {
    if (ignoreAccessory) return
    this.activationDelay = 0
    if (this.isActive && this.accessoryData.interruptsAction) this.endAccessoryActivation(character)
  }

  endAccessoryActivation (character = null) {
    if (this.accessoryData != null && this.accessoryData.type === 'vision' && character != null && this.isActive) {
      character.seeInvisibilityDistance = this.savedSeeInvisibilityDistance
    }
    this.isActive = false
    this.ticksActive = 0
  }

  encode (bitStream, isOwnObject) {
    bitStream.writeBoolean(this.isActive)
    if (isOwnObject) bitStream.writePositiveIntMax3(LogicMath.clamp(this.usesLeft, 0, 3))
  }

  static getClosestTile (x, y, tileMap) {
    const spot = new LogicVector2()
    if (!GamePlayUtil.getClosestPassableSpot(0, x, y, 2, tileMap, spot, false)) return null
    return tileMap.getTile(spot.x, spot.y)
  }
}

module.exports = Accessory
