const PlayerDisplayData = require('../../Avatar/Structures/PlayerDisplayData')
const PlayerKillEntry = require('./PlayerKillEntry')
const TickDamage = require('./TickDamage')
const DataTables = require('../../Data/DataTables')
const DataType = require('../../Data/DataType')
const GlobalId = require('../../Data/Helper/GlobalId')
const ByteStreamHelper = require('../../Helper/ByteStreamHelper')
const LogicVector2 = require('../../../Titan/Math/LogicVector2')
const LogicMath = require('../../../Titan/Math/LogicMath')

const DEFAULT_EMOTE = 137 - 3

function createAccessory (accessoryData) {
  if (accessoryData == null) return null
  let Accessory = null
  try {
    Accessory = require('./Accessory')
  } catch (e) {
    return null
  }
  return new Accessory(accessoryData)
}

class BattlePlayer {
  constructor (home, avatar) {
    this.accountId = 0
    this.playerIndex = 0
    this.teamIndex = 0
    this.emotes = new Map()
    this.spray = new Map()
    this.teamId = -1
    this.heroIndex = 0
    this.heroIndexMax = 0
    this.displayData = new PlayerDisplayData()
    this.sessionId = 0
    this.gameListener = null
    this.characterIds = [0, 0, 0]
    this.skinIds = [0, 0, 0]
    this.ownObjectId = 0
    this.previousObjectId = 0
    this.controlTicksLeft = 0
    this.lastHandledInput = 0
    this.trophies = 0
    this.highestTrophies = 0
    this.heroPowerLevel = 0
    this.score = 0
    this.spawnPoint = new LogicVector2()
    this.respawnStarted = false
    this.respawnX = 0
    this.respawnY = 0
    this.startUsingPinTicks = -9999
    this.lastPinUseTicks = -9999
    this.pinIndex = 0
    this.sprayIndex = 0
    this.accessoryCardDatas = null
    this.accessoryDatas = null
    this.starPowerDatas = null
    this.accessory = null
    this.characterDatas = null
    this.overChargeDatas = null
    this.powerLevel = 0
    this.bot = 0
    this.isAdmin = false
    this.ultiCharge = 0
    this.overCharge = 0
    this.overCharging = false
    this.overChargeActivated = false
    this.overChargeStarted = false
    this.overChargeEnded = false
    this.isAlive = false
    this.battleRoyaleRank = -1
    this.killList = []
    this.kills = 0
    this.damage = 0
    this.heals = 0
    this.deathTick = 1
    this.deaths = 0
    this.damageHistory = []
    this.boMines = []
    this.hasStar = false
    this.eventCollectTokens = 0
    this.temporaryTeamOverride = 0
    this.battleEndSent = false
    this.isStarplayer = false
    this.powerPlayScore = 0

    this.home = home != null ? home : null
    this.avatar = avatar != null ? avatar : null
  }

  get characterId () {
    return this.characterIds[this.heroIndex] | 0
  }

  get skinId () {
    return this.skinIds[this.heroIndex] | 0
  }

  get skinData () {
    if (this.skinId === 0) return null
    return DataTables.get(DataType.Skin).getDataByGlobalId(this.skinId)
  }

  get skinConfData () {
    const skinData = this.skinData
    if (skinData == null) return null
    return DataTables.get(DataType.SkinConf).getData(skinData.conf)
  }

  get accessoryCardData () {
    return this.accessoryCardDatas != null ? this.accessoryCardDatas[this.heroIndex] || null : null
  }

  get accessoryData () {
    return this.accessoryDatas != null ? this.accessoryDatas[this.heroIndex] || null : null
  }

  get starPowerData () {
    return this.starPowerDatas != null ? this.starPowerDatas[this.heroIndex] || null : null
  }

  get characterData () {
    return this.characterDatas != null ? this.characterDatas[this.heroIndex] || null : null
  }

  get overChargeData () {
    return this.overChargeDatas != null ? this.overChargeDatas[this.heroIndex] || null : null
  }

  healed (heals) {
    this.heals += heals
  }

  getDps () {
    return this.damageHistory.reduce((sum, entry) => sum + entry.damage, 0)
  }

  damageDealed (damage, currentTick = 0) {
    this.damage += damage
    if (damage > 0) {
      this.damageHistory.push(new TickDamage(currentTick, damage))
    }
  }

  getSprayIDBySprayIndex (i) {
    return this.spray.has(i) ? this.spray.get(i) : 0
  }

  killedPlayer (index, bountyStars) {
    this.killList.push(new PlayerKillEntry(index, bountyStars))
    this.kills++
  }

  hasUlti () {
    return this.ultiCharge >= 4000
  }

  overChargeReady () {
    return this.overCharge >= 4000
  }

  getUltiCharge () {
    return this.ultiCharge
  }

  getOverCharge () {
    return this.overCharge
  }

  getCardValueForPassive (type, index) {
    const starPowerData = this.starPowerData
    if (starPowerData == null || starPowerData.type !== type) return -1
    if (index === 2) return starPowerData.value3
    return index > 0 ? starPowerData.value : starPowerData.value2
  }

  addUltiCharge (amount) {
    this.ultiCharge = LogicMath.clamp(this.ultiCharge + amount, 0, 4000)
  }

  getGearBoost (logicType) {
    return 0
  }

  chargeUlti (amount, a3, a4) {
    this.ultiCharge = LogicMath.clamp(this.ultiCharge + amount, 0, 4000)
  }

  useUlti () {
    this.ultiCharge = 0
  }

  isBot () {
    return this.bot
  }

  addScore (a) {
    this.score += a
  }

  resetScore () {
    this.score = 0
  }

  usePin (index, ticks) {
    this.startUsingPinTicks = ticks
    this.pinIndex = index
    this.lastPinUseTicks = ticks
  }

  isUsingPin (ticks) {
    return ticks - this.startUsingPinTicks < 80
  }

  resetUsingPin () {
    this.startUsingPinTicks = -1
    this.lastPinUseTicks = -1
  }

  setHeroIndex (index) {
    this.heroIndex = index
    this.accessory = createAccessory(this.accessoryDatas != null ? this.accessoryDatas[index] : null)
  }

  getScore () {
    return this.score
  }

  setSpawnPoint (x, y) {
    if (x instanceof LogicVector2) {
      this.spawnPoint = x
      return
    }
    this.spawnPoint.set(x, y)
  }

  getSpawnPoint () {
    return this.spawnPoint.clone()
  }

  hasOverCharge () {
    return this.overChargeData != null
  }

  decode (stream) {
    this.characterIds[0] = ByteStreamHelper.readDataReference(stream)
    this.skinIds[0] = ByteStreamHelper.readDataReference(stream)
    this.teamIndex = stream.readVInt()
    this.bot = stream.readBoolean() ? 0 : 1
    this.displayData.name = stream.readString(9000000)
  }

  encode (stream) {
    stream.writeLong(this.accountId)
    stream.writeVInt(this.playerIndex)
    stream.writeVInt(this.teamIndex)
    stream.writeVInt(0)
    stream.writeInt(0)

    ByteStreamHelper.writeDataReference(stream, this.characterId)
    ByteStreamHelper.writeDataReference(stream, this.skinIds[0])

    stream.writeBoolean(true)
    stream.writeVInt(this.heroPowerLevel)
    ByteStreamHelper.writeDataReference(stream, this.starPowerDatas != null ? this.starPowerDatas[0] : null)
    ByteStreamHelper.writeDataReference(stream, this.accessoryCardDatas != null ? this.accessoryCardDatas[0] : null)

    stream.writeBoolean(true)
    stream.writeVInt(5)
    for (let i = 1; i <= 5; i++) {
      const emote = this.emotes.has(i) ? this.emotes.get(i) : DEFAULT_EMOTE
      ByteStreamHelper.writeDataReference(stream, GlobalId.createGlobalId(52, emote))
    }

    this.displayData.encode(stream)
    stream.writeBoolean(false)
  }

  static getSelectedStarPowerCard (avatar, hero) {
    if (hero == null || !hero.hasStarpower) return null
    const characterData = DataTables.get(DataType.Character).getDataByGlobalId(hero.characterId)
    if (characterData == null) return null
    const cards = DataTables.get(DataType.Card)
    const candidates = [cards.getData(characterData.name + '_unique'), cards.getData(characterData.name + '_unique_2')]
      .filter(card => card != null)
    return candidates.find(card => avatar.selectedStarpowers.includes(card.getGlobalId())) ||
      candidates.find(card => avatar.starpowers.includes(card.getGlobalId())) ||
      null
  }

  static getSelectedGadgetCard (avatar, hero) {
    if (hero == null || hero.powerLevel <= 5) return null
    const HomeMode = require('../../Home/HomeMode')
    const characterData = DataTables.get(DataType.Character).getDataByGlobalId(hero.characterId)
    for (const card of HomeMode.getGadgetCards(characterData)) {
      if (avatar.starpowers.includes(card.getGlobalId())) return card
    }
    return null
  }

  static create (home, avatar, playerIndex, teamIndex, eventData = null, characterid = -1, enableGadget = false) {
    const player = new BattlePlayer(home, avatar)
    player.displayData.name = avatar.name
    player.displayData.thumbnailId = home.thumbnailId
    player.displayData.nameColorId = home.nameColorId
    if (String(avatar.name).startsWith('<c')) {
      player.displayData.highNameColorId = -1
    } else {
      player.displayData.highNameColorId = home.hasPremiumPass || home.nameColorId === 43000012 ? home.nameColorId : 0
    }

    player.accessoryCardDatas = [null, null, null]
    player.accessoryDatas = [null, null, null]
    player.starPowerDatas = [null, null, null]
    player.characterDatas = [null, null, null]
    player.overChargeDatas = [null, null, null]

    player.accountId = avatar.accountId

    const selectedCharacterId = characterid === -1 ? home.characterId : characterid
    const hero = avatar.getHero(selectedCharacterId)

    player.characterIds[0] = selectedCharacterId

    const skinInstanceId = home.selectedSkins != null ? home.selectedSkins[GlobalId.getInstanceId(selectedCharacterId)] | 0 : 0
    if (hero != null && skinInstanceId > 0) {
      player.skinIds[0] = GlobalId.createGlobalId(DataType.Skin, skinInstanceId)
    }

    const gadgetCard = BattlePlayer.getSelectedGadgetCard(avatar, hero)
    player.accessoryCardDatas[0] = gadgetCard
    player.accessoryDatas[0] = gadgetCard != null ? DataTables.get(DataType.Accessory).getData(gadgetCard.name) : null

    player.starPowerDatas[0] = BattlePlayer.getSelectedStarPowerCard(avatar, hero)
    player.characterDatas[0] = DataTables.get(DataType.Character).getDataByGlobalId(selectedCharacterId)

    player.accessory = createAccessory(player.accessoryData)

    player.playerIndex = playerIndex
    player.teamIndex = teamIndex

    if (hero != null) {
      player.trophies = hero.trophies
      player.highestTrophies = hero.highestTrophies
      player.heroPowerLevel = hero.powerLevel
    }

    return player
  }

  static createBotInfo (name, playerIndex, teamIndex, character = 16000000) {
    const player = new BattlePlayer()
    player.accessoryCardDatas = [null, null, null]
    player.accessoryDatas = [null, null, null]
    player.starPowerDatas = [null, null, null]
    player.characterDatas = [null, null, null]
    player.overChargeDatas = [null, null, null]

    const selectedCharacter = DataTables.get(DataType.Character).getDataByGlobalId(character)
    if (selectedCharacter != null && selectedCharacter.name != null) {
      player.displayData.name = String(selectedCharacter.name).toUpperCase()
    } else if (name != null) {
      player.displayData.name = String(name).toUpperCase()
    } else {
      player.displayData.name = 'BOT'
    }
    player.displayData.thumbnailId = GlobalId.createGlobalId(28, 0)
    player.displayData.nameColorId = GlobalId.createGlobalId(43, 0)
    player.displayData.highNameColorId = GlobalId.createGlobalId(46, 0)
    player.accountId = 100000 + playerIndex
    player.characterIds[0] = character
    player.playerIndex = playerIndex
    player.teamIndex = teamIndex
    player.sessionId = -1
    player.bot = 1
    player.characterDatas[0] = selectedCharacter
    player.skinIds[0] = 0
    player.heroPowerLevel = 5 + Math.floor(Math.random() * 4)
    player.heroIndexMax = 0
    return player
  }
}

module.exports = BattlePlayer
