class PlayerKillEntry {
  constructor (playerIndex = 0, bountyStarsEarned = 0) {
    this.playerIndex = playerIndex
    this.bountyStarsEarned = bountyStarsEarned
  }
}

module.exports = PlayerKillEntry
