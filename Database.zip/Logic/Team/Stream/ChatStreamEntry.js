const TeamStreamEntry = require('./TeamStreamEntry')

class ChatStreamEntry extends TeamStreamEntry {
  constructor () {
    super()
    this.message = null
  }

  encode (encoder) {
    super.encode(encoder)
    encoder.writeString(this.message)
  }

  getStreamEntryType () {
    return 2
  }
}

module.exports = ChatStreamEntry
