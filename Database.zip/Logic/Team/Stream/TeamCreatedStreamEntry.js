const TeamStreamEntry = require('./TeamStreamEntry')

class TeamCreatedStreamEntry extends TeamStreamEntry {
  constructor () {
    super()
    this.teamId = 0
  }

  encode (encoder) {
    super.encode(encoder)
    encoder.writeLong(this.teamId)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
  }

  getStreamEntryType () {
    return 77
  }
}

module.exports = TeamCreatedStreamEntry
