class TeamStreamEntry {
  constructor () {
    this.id = 0
    this.accountId = 0
    this.name = null
  }

  encode (encoder) {
    encoder.writeVInt(this.getStreamEntryType())
    encoder.writeVLong(this.id)
    encoder.writeVLong(this.accountId)
    encoder.writeString(this.name)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
  }

  getStreamEntryType () {
    return 0
  }
}

module.exports = TeamStreamEntry
