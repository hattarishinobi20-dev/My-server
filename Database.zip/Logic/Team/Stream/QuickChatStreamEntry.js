const TeamStreamEntry = require('./TeamStreamEntry')
const ByteStreamHelper = require('../../Helper/ByteStreamHelper')

class QuickChatStreamEntry extends TeamStreamEntry {
  constructor () {
    super()
    this.messageDataId = 0
    this.targetId = 0
    this.targetPlayerName = null
    this.unknown1 = 0
    this.unknown2 = 0
  }

  encode (encoder) {
    super.encode(encoder)
    ByteStreamHelper.writeDataReference(encoder, this.messageDataId)
    if (encoder.writeBoolean(this.targetId > 0)) {
      encoder.writeLong(this.targetId)
    }
    encoder.writeString(this.targetPlayerName)
    encoder.writeVInt(this.unknown1)
    encoder.writeVInt(this.unknown2)
  }

  getStreamEntryType () {
    return 8
  }
}

module.exports = QuickChatStreamEntry
