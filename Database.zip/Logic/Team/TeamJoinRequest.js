class TeamJoinRequest {
  encode (stream) {
    throw new Error('TeamJoinRequest::encode is not implemented')
  }
}

module.exports = TeamJoinRequest
