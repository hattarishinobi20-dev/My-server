const ByteStreamHelper = require('../Helper/ByteStreamHelper')

class TeamMember {
  constructor () {
    this.isOwner = false
    this.accountId = 0
    this.characterId = 0
    this.skinId = 0
    this.heroTrophies = 0
    this.heroHighestTrophies = 0
    this.heroLevel = 0
    this.state = 0
    this.isReady = false
    this.starpower = 0
    this.gadget = 0
    this.teamIndex = 0
    this.displayData = null
  }

  encode (stream) {
    stream.writeBoolean(this.isOwner)
    stream.writeLong(this.accountId)
    ByteStreamHelper.writeDataReference(stream, this.characterId)
    ByteStreamHelper.writeDataReference(stream, this.skinId)
    stream.writeVInt(0)
    stream.writeVInt(this.heroTrophies)
    stream.writeVInt(this.heroHighestTrophies)
    stream.writeVInt(this.heroLevel + 1)
    stream.writeVInt(this.state)
    stream.writeBoolean(this.isReady)
    stream.writeVInt(this.teamIndex)
    stream.writeVInt(0)
    stream.writeVInt(0)
    stream.writeVInt(0)
    stream.writeVInt(0)
    stream.writeVInt(0)
    this.displayData.encode(stream)
    ByteStreamHelper.writeDataReference(stream, this.starpower)
    ByteStreamHelper.writeDataReference(stream, this.gadget)
    stream.writeVInt(0)
  }
}

module.exports = TeamMember
