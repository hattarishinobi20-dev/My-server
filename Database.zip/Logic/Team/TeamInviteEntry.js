class TeamInviteEntry {
  constructor () {
    this.inviterId = 0
    this.id = 0
    this.name = null
    this.slot = 0
  }

  encode (stream) {
    stream.writeLong(this.inviterId)
    stream.writeLong(this.id)
    stream.writeString(this.name)
    stream.writeVInt(1)
    stream.writeVInt(this.slot)
  }
}

module.exports = TeamInviteEntry
