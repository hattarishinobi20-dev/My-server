const Command = require('../Command')

class LogicClearShopTickersCommand extends Command {
  constructor () {
    super()
  }

  decode (stream) {
    super.decode(stream)
  }

  execute (homeMode) {
    for (const bundle of homeMode.home.offerBundles.slice()) {
      bundle.state = 2
    }
    return 0
  }

  getCommandType () {
    return 515
  }
}

module.exports = LogicClearShopTickersCommand
