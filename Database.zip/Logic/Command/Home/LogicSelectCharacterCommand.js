const Command = require('../Command')
const GlobalId = require('../../Data/Helper/GlobalId')

class LogicSelectCharacterCommand extends Command {
  constructor () {
    super()
    this.characterInstanceId = 0
  }

  decode (stream) {
    super.decode(stream)
    stream.readVInt()
    this.characterInstanceId = stream.readVInt()
  }

  execute (homeMode) {
    const globalId = GlobalId.createGlobalId(16, this.characterInstanceId)
    if (homeMode.avatar.hasHero(globalId)) {
      homeMode.home.characterId = globalId
      homeMode.onCharacterChanged(globalId)
      return 0
    }
    return -1
  }

  getCommandType () {
    return 525
  }
}

module.exports = LogicSelectCharacterCommand
