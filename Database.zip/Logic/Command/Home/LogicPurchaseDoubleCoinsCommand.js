const Command = require('../Command')

class LogicPurchaseDoubleCoinsCommand extends Command {
  constructor () {
    super()
  }

  decode (stream) {
    super.decode(stream)
  }

  execute (homeMode) {
    return 0
  }

  getCommandType () {
    return 509
  }
}

module.exports = LogicPurchaseDoubleCoinsCommand
