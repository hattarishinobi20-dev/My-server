const Command = require('../Command')

class LogicDeleteNotificationCommand extends Command {
  constructor () {
    super()
    this.notificationIndex = 0
  }

  decode (stream) {
    super.decode(stream)
    this.notificationIndex = stream.readVInt()
  }

  execute (homeMode) {
    return 0
  }

  getCommandType () {
    return 514
  }
}

module.exports = LogicDeleteNotificationCommand
