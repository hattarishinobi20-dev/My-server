const Command = require('../Command')

class LogicInviteBlockingChangedCommand extends Command {
  constructor () {
    super()
    this.state = false
  }

  encode (stream) {
    stream.writeBoolean(this.state)
    super.encode(stream)
  }

  execute (homeMode) {
    return 0
  }

  getCommandType () {
    return 213
  }
}

module.exports = LogicInviteBlockingChangedCommand
