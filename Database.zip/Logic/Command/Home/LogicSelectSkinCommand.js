const Command = require('../Command')

class LogicSelectSkinCommand extends Command {
  constructor () {
    super()
    this.skinId = 0
  }

  decode (stream) {
    super.decode(stream)
    stream.readVInt()
    this.skinId = stream.readVInt()
  }

  execute (homeMode) {
    return 0
  }

  getCommandType () {
    return 506
  }
}

module.exports = LogicSelectSkinCommand
