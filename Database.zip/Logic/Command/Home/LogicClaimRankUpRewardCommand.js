const Command = require('../Command')
const ByteStreamHelper = require('../../Helper/ByteStreamHelper')
const DataTables = require('../../Data/DataTables')
const DataType = require('../../Data/DataType')
const GlobalId = require('../../Data/Helper/GlobalId')
const LogicBitHelper = require('../../Util/LogicBitHelper')
const DeliveryUnit = require('../../Home/Gatcha/DeliveryUnit')
const GatchaDrop = require('../../Home/Gatcha/GatchaDrop')
const Debugger = require('../../../Titan/Debug/Debugger')

class LogicClaimRankUpRewardCommand extends Command {
  constructor () {
    super()
    this.milestoneId = 0
    this.unknownDataId = 0
    this.unk2 = 0
    this.unk3 = 0
    this.requieredMilestone = 0
  }

  decode (stream) {
    super.decode(stream)
    this.milestoneId = stream.readVInt()
    this.unknownDataId = ByteStreamHelper.readDataReference(stream)
    this.unk2 = stream.readVInt()
    this.requieredMilestone = stream.readVInt()
  }

  execute (homeMode) {
    Debugger.print(`Claim rankup reward: milestone: ${this.milestoneId}, data: ${this.unknownDataId}, unk2: ${this.unk2}, unk3: ${this.unk3}`)

    const home = homeMode.home

    if (this.milestoneId === 6) {
      const name = `goal_6_${home.trophyRoadProgress - 1}`
      const milestoneData = DataTables.get(DataType.Milestone).getData(name)
      if (milestoneData == null) {
        Debugger.error(`Milestone data is NULL - ${name}`)
        return -111
      }

      if (homeMode.avatar.highestTrophies < milestoneData.progress + milestoneData.progressStart) {
        Debugger.warning(`current progress: ${homeMode.avatar.highestTrophies}, required progress: ${milestoneData.progress + milestoneData.progressStart}`)
        return -2
      }

      if (this.processReward(homeMode, milestoneData, false, 6, home.trophyRoadProgress + 1, false) !== 0) return -3
      home.trophyRoadProgress++
    } else if (this.milestoneId === 9 || this.milestoneId === 10) {
      if (this.milestoneId === 9 && !home.hasPremiumPass) {
        return -5
      }

      const name = `Goal_${this.milestoneId}_8_${this.requieredMilestone}`
      const milestoneData = DataTables.get(DataType.Milestone).getData(name)
      if (milestoneData == null) {
        Debugger.error(`Milestone data is NULL - ${name}`)
        return -111
      }

      if (home.brawlPassTokens < milestoneData.progress + milestoneData.progressStart) {
        Debugger.warning(`current progress: ${home.brawlPassTokens}, required progress: ${milestoneData.progress + milestoneData.progressStart}`)
        return -2
      }

      const bit = this.requieredMilestone + 2
      if (this.milestoneId === 9 && LogicBitHelper.get(home.premiumPassProgress, bit)) return -4
      if (this.milestoneId === 10 && LogicBitHelper.get(home.brawlPassProgress, bit)) return -4

      if (this.processReward(homeMode, milestoneData, false, this.milestoneId, bit, true) !== 0) return -3

      if (this.milestoneId === 9) {
        home.premiumPassProgress = LogicBitHelper.set(home.premiumPassProgress, bit, true)
      } else {
        home.brawlPassProgress = LogicBitHelper.set(home.brawlPassProgress, bit, true)
      }
    } else {
      return -1
    }

    return 0
  }

  sendDelivery (homeMode, unit, track, idx, isBp) {
    const LogicGiveDeliveryItemsCommand = require('./LogicGiveDeliveryItemsCommand')
    const AvailableServerCommandMessage = require('../../../Protocol/Messages/Server/AvailableServerCommandMessage')

    const command = new LogicGiveDeliveryItemsCommand()
    command.deliveryUnits.push(unit)
    command.rewardTrackType = track
    command.rewardForRank = idx
    if (isBp) {
      command.brawlPassSeason = 8
    }
    command.execute(homeMode)

    const message = new AvailableServerCommandMessage()
    message.command = command
    if (homeMode.gameListener != null) homeMode.gameListener.sendMessage(message)
  }

  singleDrop (type, count) {
    const unit = new DeliveryUnit(100)
    const drop = new GatchaDrop(type)
    drop.count = count
    unit.addDrop(drop)
    return { unit, drop }
  }

  processReward (homeMode, milestoneData, useSecondaryReward, track, idx, isBp) {
    const type = useSecondaryReward ? milestoneData.secondaryLvlUpRewardType : milestoneData.primaryLvlUpRewardType
    const data = useSecondaryReward ? milestoneData.secondaryLvlUpRewardData : milestoneData.primaryLvlUpRewardData
    const count = useSecondaryReward ? milestoneData.secondaryLvlUpRewardCount : milestoneData.primaryLvlUpRewardCount
    const fallback = () => useSecondaryReward ? -3 : this.processReward(homeMode, milestoneData, true, track, idx, isBp)

    switch (type) {
      case 1: {
        const { unit } = this.singleDrop(7, count)
        this.sendDelivery(homeMode, unit, track, idx, isBp)
        break
      }
      case 3: {
        const character = DataTables.get(DataType.Character).getData(data)
        if (character == null || homeMode.avatar.hasHero(character.getGlobalId())) {
          return fallback()
        }
        const { unit, drop } = this.singleDrop(1, 1)
        drop.dataGlobalId = character.getGlobalId()
        this.sendDelivery(homeMode, unit, track, idx, isBp)
        break
      }
      case 6:
      case 10:
      case 14: {
        const unit = new DeliveryUnit(type === 6 ? 10 : (type === 10 ? 11 : 12))
        homeMode.simulateGatcha(unit)
        this.sendDelivery(homeMode, unit, track, idx, isBp)
        break
      }
      case 9: {
        const { unit } = this.singleDrop(2, count)
        this.sendDelivery(homeMode, unit, track, idx, isBp)
        break
      }
      case 4:
      case 24: {
        const skin = DataTables.get(DataType.Skin).getData(data)
        if (skin == null || homeMode.home.unlockedSkins.includes(skin.getGlobalId())) {
          return fallback()
        }
        const { unit, drop } = this.singleDrop(9, 1)
        drop.skinGlobalId = skin.getGlobalId()
        this.sendDelivery(homeMode, unit, track, idx, isBp)
        break
      }
      case 12: {
        if (this.unknownDataId < GlobalId.createGlobalId(16, 0)) {
          return fallback()
        }
        const character = DataTables.get(DataType.Character).getDataByGlobalId(this.unknownDataId)
        if (character == null || !homeMode.avatar.hasHero(character.getGlobalId())) {
          return fallback()
        }
        const { unit, drop } = this.singleDrop(6, count)
        drop.dataGlobalId = character.getGlobalId()
        this.sendDelivery(homeMode, unit, track, idx, isBp)
        break
      }
      case 13:
        break
      case 16: {
        const { unit } = this.singleDrop(8, count)
        this.sendDelivery(homeMode, unit, track, idx, isBp)
        break
      }
      case 18: {
        const Quests = require('../../Home/Quest/Quests')
        const LogicHeroWinQuestsChangedCommand = require('./LogicHeroWinQuestsChangedCommand')
        const AvailableServerCommandMessage = require('../../../Protocol/Messages/Server/AvailableServerCommandMessage')

        homeMode.home.quests = new Quests()
        homeMode.home.quests.addRandomQuests(homeMode.avatar.heroes, 8)

        const cmd = new LogicHeroWinQuestsChangedCommand()
        cmd.quests = homeMode.home.quests
        const message = new AvailableServerCommandMessage()
        message.command = cmd
        if (homeMode.gameListener != null) homeMode.gameListener.sendMessage(message)
        break
      }
      case 19: {
        const emote = DataTables.get(DataType.Emote).getData(data)
        if (emote == null || homeMode.home.unlockedEmotes.includes(emote.getGlobalId())) {
          return fallback()
        }
        const { unit, drop } = this.singleDrop(11, 1)
        drop.pinGlobalId = emote.getGlobalId()
        this.sendDelivery(homeMode, unit, track, idx, isBp)
        break
      }
      default:
        Debugger.error('Unknown reward type: ' + type)
        return fallback()
    }

    return 0
  }

  getCommandType () {
    return 517
  }
}

module.exports = LogicClaimRankUpRewardCommand
