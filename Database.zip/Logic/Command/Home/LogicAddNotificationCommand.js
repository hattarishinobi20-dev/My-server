const Command = require('../Command')

class LogicAddNotificationCommand extends Command {
  constructor () {
    super()
    this.notification = null
  }

  encode (stream) {
    if (stream.writeBoolean(this.notification != null)) {
      this.notification.encode(stream)
    }
    stream.writeVInt(0)
    super.encode(stream)
  }

  execute (homeMode) {
    return 0
  }

  getCommandType () {
    return 206
  }
}

module.exports = LogicAddNotificationCommand
