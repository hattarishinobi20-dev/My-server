const Command = require('../Command')

class LogicPurchaseBrawlPassProgressCommand extends Command {
  constructor () {
    super()
    this.unknown = 0
  }

  decode (stream) {
    super.decode(stream)
    this.unknown = stream.readVInt()
  }

  execute (homeMode) {
    return -1
  }

  getCommandType () {
    return 536
  }
}

module.exports = LogicPurchaseBrawlPassProgressCommand
