const Command = require('../Command')
const ForcedDrops = require('../../Home/Gatcha/ForcedDrops')

class LogicGiveDeliveryItemsCommand extends Command {
  constructor () {
    super()
    this.deliveryUnits = []
    this.forcedDrops = new ForcedDrops()
    this.rewardTrackType = 0
    this.rewardForRank = 0
    this.rewardMilestoneIdx = 0
    this.brawlPassSeason = 0
  }

  encode (stream) {
    stream.writeVInt(0)
    stream.writeVInt(this.deliveryUnits.length)
    for (const unit of this.deliveryUnits) {
      unit.encode(stream)
    }
    this.forcedDrops.encode(stream)
    stream.writeVInt(this.rewardTrackType)
    stream.writeVInt(this.rewardForRank)
    stream.writeVInt(this.brawlPassSeason)
    stream.writeBoolean(false)
    stream.writeBoolean(false)
    super.encode(stream)
  }

  execute (homeMode) {
    for (const unit of this.deliveryUnits) {
      for (const drop of unit.getDrops()) {
        if (!drop.isExecuted) {
          drop.doDrop(homeMode)
          drop.isExecuted = true
        }
      }
    }
    return 0
  }

  getCommandType () {
    return 203
  }
}

module.exports = LogicGiveDeliveryItemsCommand
