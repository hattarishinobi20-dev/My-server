const Command = require('../Command')
const DeliveryUnit = require('../../Home/Gatcha/DeliveryUnit')
const Debugger = require('../../../Titan/Debug/Debugger')

const BOXES = Object.freeze({
  3: { currency: 'diamonds', cost: 80, type: 11 },
  1: { currency: 'diamonds', cost: 30, type: 12 },
  4: { currency: 'starTokens', cost: 10, type: 12 },
  5: { currency: 'tokens', cost: 100, type: 10 }
})

class LogicGatchaCommand extends Command {
  constructor () {
    super()
    this.boxIndex = 0
  }

  decode (stream) {
    super.decode(stream)
    this.boxIndex = stream.readVInt()
  }

  execute (homeMode) {
    const LogicGiveDeliveryItemsCommand = require('./LogicGiveDeliveryItemsCommand')
    const AvailableServerCommandMessage = require('../../../Protocol/Messages/Server/AvailableServerCommandMessage')

    const box = BOXES[this.boxIndex]
    if (box == null) {
      Debugger.warning('Gatcha: Unknown box index: ' + this.boxIndex)
      return 0
    }

    const avatar = homeMode.avatar
    let paid = false
    if (box.currency === 'diamonds') paid = avatar.useDiamonds(box.cost)
    else if (box.currency === 'starTokens') paid = avatar.useStarTokens(box.cost)
    else if (box.currency === 'tokens') paid = avatar.useTokens(box.cost)
    if (!paid) return -1

    const command = new LogicGiveDeliveryItemsCommand()
    const unit = new DeliveryUnit(box.type)
    homeMode.simulateGatcha(unit)
    command.deliveryUnits.push(unit)
    command.execute(homeMode)

    const message = new AvailableServerCommandMessage()
    message.command = command
    if (homeMode.gameListener != null) homeMode.gameListener.sendMessage(message)
    return 0
  }

  getCommandType () {
    return 500
  }
}

module.exports = LogicGatchaCommand
