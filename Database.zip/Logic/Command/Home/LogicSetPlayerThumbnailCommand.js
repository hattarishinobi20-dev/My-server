const Command = require('../Command')
const DataTables = require('../../Data/DataTables')
const DataType = require('../../Data/DataType')
const GlobalId = require('../../Data/Helper/GlobalId')
const Friend = require('../../Friends/Friend')

class LogicSetPlayerThumbnailCommand extends Command {
  constructor () {
    super()
    this.thumbnailInstanceId = 0
  }

  decode (stream) {
    super.decode(stream)
    stream.readVInt()
    this.thumbnailInstanceId = stream.readVInt()
  }

  execute (homeMode) {
    if (this.thumbnailInstanceId < 0) return 1
    if (this.thumbnailInstanceId >= DataTables.get(DataType.PlayerThumbnail).count) return 2
    homeMode.home.thumbnailId = GlobalId.createGlobalId(28, this.thumbnailInstanceId)
    Friend.updateDisplayData(homeMode)
    return 0
  }

  getCommandType () {
    return 505
  }
}

module.exports = LogicSetPlayerThumbnailCommand
