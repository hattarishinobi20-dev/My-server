const Command = require('../Command')
const ByteStreamHelper = require('../../Helper/ByteStreamHelper')

class LogicPurchaseOfferCommand extends Command {
  constructor () {
    super()
    this.offerIndex = 0
    this.unknown = 0
  }

  decode (stream) {
    super.decode(stream)
    this.offerIndex = stream.readVInt()
    this.unknown = ByteStreamHelper.readDataReference(stream)
  }

  execute (homeMode) {
    if (!this.canExecute(homeMode)) return -1
    homeMode.home.purchaseOffer(this.offerIndex)
    return 0
  }

  getCommandType () {
    return 519
  }
}

module.exports = LogicPurchaseOfferCommand
