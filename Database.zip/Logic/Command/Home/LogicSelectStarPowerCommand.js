const Command = require('../Command')

class LogicSelectStarPowerCommand extends Command {
  constructor () {
    super()
    this.starpowerInstanceId = 0
  }

  decode (stream) {
    super.decode(stream)
    stream.readVInt()
    this.starpowerInstanceId = stream.readVInt()
  }

  execute (homeMode) {
    return 0
  }

  getCommandType () {
    return 529
  }
}

module.exports = LogicSelectStarPowerCommand
