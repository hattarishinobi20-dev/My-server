const Command = require('../Command')

class LogicSetPlayerNameColorCommand extends Command {
  constructor () {
    super()
    this.nameColorInstanceId = 0
  }

  decode (stream) {
    super.decode(stream)
    stream.readVInt()
    this.nameColorInstanceId = stream.readVInt()
  }

  execute (homeMode) {
    return 0
  }

  getCommandType () {
    return 527
  }
}

module.exports = LogicSetPlayerNameColorCommand
