class Command {
  encode (stream) {
    stream.writeVInt(1)
    stream.writeVInt(1)
    stream.writeVInt(0)
    stream.writeVInt(0)
  }

  decode (stream) {
    stream.readVInt()
    stream.readVInt()
    stream.readVInt()
    stream.readVInt()
  }

  canExecute (homeMode) {
    return true
  }

  execute (homeMode) {
    throw new Error('Command::execute is abstract')
  }

  getCommandType () {
    throw new Error('Command::getCommandType is abstract')
  }
}

module.exports = Command
