const ByteStreamHelper = require('../Helper/ByteStreamHelper')
const GlobalId = require('../Data/Helper/GlobalId')
const DataTables = require('../Data/DataTables')
const DataType = require('../Data/DataType')
const OfferBundle = require('./Items/OfferBundle')
const Offer = require('./Items/Offer')
const ShopItem = require('./Items/ShopItem')
const NotificationFactory = require('./Items/NotificationFactory')
const Quests = require('./Quest/Quests')
const DeliveryUnit = require('./Gatcha/DeliveryUnit')
const GatchaDrop = require('./Gatcha/GatchaDrop')
const PlayerMap = require('./Structures/PlayerMap')

const SIMPLE_FIELDS = [
  'homeId', 'thumbnailId', 'nameColorId', 'characterId', 'trophiesReward', 'tokenReward', 'starTokenReward',
  'starPointsGained', 'powerPlayTrophiesReward', 'brawlPassTokens', 'hasPremiumPass', 'unlockedEmotes', 'experience',
  'tokenDoublers', 'trophyRoadProgress', 'unlockedSkins', 'selectedSkins', 'powerPlayGamesPlayed', 'powerPlayScore',
  'powerPlayHighestScore', 'battleTokens', 'battleTokensRefreshStart', 'premiumEndTime', 'chatBanEndTime', 'banEndTime',
  'reportsIds', 'blockFriendRequests', 'ipAddress', 'device', 'lastVisitHomeTime', 'lastRotateDate'
]

const DAILY_SKINS = Object.freeze([
  'Witch', 'Rockstar', 'Beach', 'Pink', 'Panda', 'White', 'Hair', 'Gold', 'Rudo', 'Bandita', 'Rey', 'Knight', 'Caveman',
  'Dragon', 'Summer', 'Summertime', 'Pheonix', 'Greaser', 'GirlPrereg', 'Box', 'Santa', 'Chef', 'Boombox', 'Wizard',
  'Reindeer', 'GalElf', 'Hat', 'Footbull', 'Popcorn', 'Hanbok', 'Cny', 'Valentine', 'WarsBox', 'Nightwitch', 'Cart',
  'Shiba', 'GalBunny', 'Ms', 'GirlHotrod', 'Maple', 'RR', 'Mecha', 'MechaWhite', 'MechaNight', 'FootbullBlue', 'Outlaw',
  'Hogrider', 'BoosterDefault', 'Shark', 'HoleBlue', 'BoxMoonFestival', 'WizardRed', 'Pirate', 'GirlWitch', 'KnightDark',
  'DragonDark', 'DJ', 'Wolf', 'Brown', 'Total', 'Sally', 'Leonard', 'SantaRope', 'Gift', 'GT', 'SniperDefaultAddonBee',
  'SniperLadyBug', 'SniperLadyBugAddonBee', 'Virus', 'BoosterVirus', 'HoleStreetNinja', 'Gamer', 'Valentines', 'Koala',
  'BearKoala', 'TurretDefault', 'AgentP', 'Football', 'Arena', 'Tanuki', 'Horus', 'ArenaPSG', 'DarkBunny', 'College',
  'TurretTanuki', 'TotemDefault', 'Bazaar', 'RedDragon', 'Constructor', 'Hawaii', 'Barbking', 'Trader', 'StationSummer',
  'Silver', 'SniperMonster', 'BombMonster', 'SniperMonsterAddonBee', 'Bank', 'Retro', 'Ranger', 'Tracksuit', 'Knight'
])

const EXCLUDED_DAILY_SKINS = Object.freeze(['RocketGirlRanger', 'PowerLevelerKnight', 'BlowerTrader'])

const SELECTED_SKINS_COUNT = 53
const BATTLE_TOKENS_REFRESH_MS = 30 * 60 * 1000

function nextInt (min, max) {
  if (max <= min) return min
  return min + Math.floor(Math.random() * (max - min))
}

function utcDate (time) {
  const date = new Date(time)
  return Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate())
}

function tomorrowAtEight () {
  return utcDate(Date.now()) + 86400000 + 8 * 3600000
}

function pickDistinct (list, count) {
  const pool = Array.from(new Set(list))
  const result = []
  const amount = Math.min(pool.length, count)
  for (let i = 0; i < amount; i++) {
    const index = nextInt(0, pool.length)
    result.push(pool[index])
    pool.splice(index, 1)
  }
  return result
}

function toBigInt (value, fallback) {
  try {
    if (typeof value === 'bigint') return value
    if (value != null) return BigInt(value)
  } catch (e) { }
  return fallback
}

class ClientHome {
  static DAILYOFFERS_COUNT = 6
  static GoldPacksPrice = Object.freeze([20, 50, 140, 280])
  static GoldPacksAmount = Object.freeze([150, 400, 1200, 2600])
  static BRAWL_PASS_SEASON = 8
  static BRAWL_PASS_PRICE = 169
  static BRAWL_PASS_BUNDLE_PRICE = 249
  static BRAWL_PASS_BUNDLE_TIERS = 10
  static BRAWL_PASS_TIER_PRICE = 30

  static getBrawlPassTierEnd (tokens) {
    const milestones = DataTables.get(DataType.Milestone)
    for (let i = 1; ; i++) {
      const milestoneData = milestones.getData(`Goal_10_${ClientHome.BRAWL_PASS_SEASON}_${i}`)
      if (milestoneData == null) return null
      const end = milestoneData.progressStart + milestoneData.progress
      if (milestoneData.progressStart <= tokens && end > tokens) return end
    }
  }

  addBrawlPassTiers (count) {
    let added = 0
    for (let i = 0; i < count; i++) {
      const end = ClientHome.getBrawlPassTierEnd(this.brawlPassTokens)
      if (end == null) break
      this.brawlPassTokens = end
      added++
    }
    return added
  }

  constructor () {
    this.homeMode = null
    this.homeId = 0

    this.thumbnailId = GlobalId.createGlobalId(28, 0)
    this.nameColorId = GlobalId.createGlobalId(43, 0)
    this.characterId = GlobalId.createGlobalId(16, 0)

    this.offerBundles = []

    this.trophiesReward = 0
    this.tokenReward = 0
    this.starTokenReward = 0
    this.starPointsGained = 0
    this.powerPlayTrophiesReward = 0

    this.brawlPassProgress = 1n
    this.premiumPassProgress = 1n
    this.brawlPassTokens = 0
    this.hasPremiumPass = false

    this.unlockedEmotes = []
    this.experience = 0
    this.tokenDoublers = 0
    this.trophyRoadProgress = 1

    this.quests = null
    this.notificationFactory = new NotificationFactory()
    this.playerMaps = []

    this.unlockedSkins = []
    this.selectedSkins = new Array(SELECTED_SKINS_COUNT).fill(0)

    this.powerPlayGamesPlayed = 0
    this.powerPlayScore = 0
    this.powerPlayHighestScore = 0

    this.battleTokens = 200
    this.battleTokensRefreshStart = 0

    this.premiumEndTime = 0
    this.chatBanEndTime = 0
    this.banEndTime = 0

    this.reportsIds = []
    this.blockFriendRequests = false

    this.ipAddress = null
    this.device = null

    this.events = []

    this.lastVisitHomeTime = 0
    this.lastRotateDate = 0
    this.shouldUpdateDay = false
  }

  get thumbnail () {
    return DataTables.get(DataType.PlayerThumbnail).getDataByGlobalId(this.thumbnailId)
  }

  get nameColor () {
    return DataTables.get(DataType.NameColor).getDataByGlobalId(this.nameColorId)
  }

  get character () {
    return DataTables.get(DataType.Character).getDataByGlobalId(this.characterId)
  }

  homeVisited () {
    this.rotateShopContent(Date.now(), this.offerBundles.length === 0, false)
    this.lastVisitHomeTime = Date.now()

    if (this.quests == null && this.trophyRoadProgress >= 11) {
      this.quests = new Quests()
      this.quests.addRandomQuests(this.homeMode.avatar.heroes, 6)
    }
  }

  tick (notify = true) {
    this.lastVisitHomeTime = Date.now()

    while (this.shouldAddTokens()) {
      this.battleTokensRefreshStart += BATTLE_TOKENS_REFRESH_MS
      this.battleTokens = Math.min(200, this.battleTokens + 30)
      if (this.battleTokens === 200) {
        this.battleTokensRefreshStart = 0
        break
      }
    }

    this.rotateShopContent(Date.now(), this.offerBundles.length === 0, notify)
  }

  getbattleTokensRefreshSeconds () {
    if (this.battleTokensRefreshStart === 0) {
      return -1
    }
    return Math.trunc((this.battleTokensRefreshStart + BATTLE_TOKENS_REFRESH_MS - Date.now()) / 1000)
  }

  shouldAddTokens () {
    if (this.battleTokensRefreshStart === 0) {
      return false
    }
    return this.getbattleTokensRefreshSeconds() < 1
  }

  purchaseOffer (index) {
    const LogicGiveDeliveryItemsCommand = require('../Command/Home/LogicGiveDeliveryItemsCommand')
    const AvailableServerCommandMessage = require('../../Protocol/Messages/Server/AvailableServerCommandMessage')

    if (!Number.isInteger(index) || index < 0 || index >= this.offerBundles.length) return false
    const bundle = this.offerBundles[index]
    if (bundle.purchased) return false

    const avatar = this.homeMode.avatar
    if (bundle.currency === 0) {
      if (!avatar.useDiamonds(bundle.cost)) return false
    } else if (bundle.currency === 1) {
      if (!avatar.useGold(bundle.cost)) return false
    } else if (bundle.currency === 3) {
      if (!avatar.useStarPoints(bundle.cost)) return false
    } else {
      return false
    }

    bundle.purchased = true

    const command = new LogicGiveDeliveryItemsCommand()

    const addBoxes = (offer, type) => {
      for (let x = 0; x < offer.count; x++) {
        const unit = new DeliveryUnit(type)
        this.homeMode.simulateGatcha(unit)
        if (x + 1 !== offer.count) {
          command.execute(this.homeMode)
        }
        command.deliveryUnits.push(unit)
      }
    }

    const addSingle = (drop) => {
      const unit = new DeliveryUnit(100)
      unit.addDrop(drop)
      command.deliveryUnits.push(unit)
    }

    for (const offer of bundle.items) {
      if (offer.type === ShopItem.BrawlBox || offer.type === ShopItem.FreeBox) {
        addBoxes(offer, 10)
      } else if (offer.type === ShopItem.HeroPower) {
        const reward = new GatchaDrop(6)
        reward.dataGlobalId = offer.itemDataId
        reward.count = offer.count
        addSingle(reward)
      } else if (offer.type === ShopItem.BigBox) {
        addBoxes(offer, 12)
      } else if (offer.type === ShopItem.MegaBox) {
        addBoxes(offer, 11)
      } else if (offer.type === ShopItem.Skin) {
        const reward = new GatchaDrop(9)
        reward.skinGlobalId = GlobalId.createGlobalId(29, offer.skinDataId)
        addSingle(reward)
      } else if (offer.type === ShopItem.Gems) {
        const reward = new GatchaDrop(8)
        reward.count = offer.count
        addSingle(reward)
      } else if (offer.type === ShopItem.Coin) {
        const reward = new GatchaDrop(7)
        reward.count = offer.count
        addSingle(reward)
      } else if (offer.type === ShopItem.CoinDoubler) {
        const reward = new GatchaDrop(2)
        reward.count = offer.count
        addSingle(reward)
      }

      command.execute(this.homeMode)
    }

    const message = new AvailableServerCommandMessage()
    message.command = command
    this.sendMessage(message)
    return true
  }

  sendMessage (message) {
    if (this.homeMode != null && this.homeMode.gameListener != null) {
      this.homeMode.gameListener.sendMessage(message)
    }
  }

  rotateShopContent (time, isNewAcc, notify = true) {
    let isUpdated = false
    const offLen = this.offerBundles.length
    this.offerBundles = this.offerBundles.filter(offer => offer.endTime > time)

    isUpdated = this.offerBundles.length !== offLen

    const now = new Date()
    if (isNewAcc || now.getUTCHours() >= 8) {
      const today = utcDate(now.getTime())
      if (this.lastRotateDate < today) {
        isUpdated = true
        this.offerBundles = this.offerBundles.filter(offer => !offer.isDailyDeals)
        this.lastRotateDate = today
        this.updateDailyOfferBundles()
        this.updateDailySkins()
        this.powerPlayGamesPlayed = 0
        this.reportsIds = []

        if (this.quests != null) {
          this.quests.questList = this.quests.questList.filter(quest => !quest.isDailyQuest)
          this.quests.addRandomQuests(this.homeMode.avatar.heroes, this.quests.questList.length >= 18 ? 8 : 10)
        }
      }
    }

    if (this.offerBundles == null || this.offerBundles.length === 0) {
      this.updateDailyOfferBundles()
      isUpdated = true
    }

    if (isUpdated && notify) {
      const LogicDayChangedCommand = require('../Command/Home/LogicDayChangedCommand')
      const AvailableServerCommandMessage = require('../../Protocol/Messages/Server/AvailableServerCommandMessage')

      const newday = new LogicDayChangedCommand()
      newday.home = this
      const eventupdated = new AvailableServerCommandMessage()
      eventupdated.command = newday
      this.sendMessage(eventupdated)
    }
  }

  updateDailySkins () {
    const skinTable = DataTables.get(DataType.Skin)
    const skis = []
    const starss = []

    for (const h of this.homeMode.avatar.heroes) {
      const c = DataTables.get(DataType.Character).getDataByGlobalId(h.characterId)
      if (c == null) continue
      const cn = c.name

      for (const name of DAILY_SKINS) {
        const s = skinTable.getData(cn + name)
        if (s == null) continue
        if (this.unlockedSkins.includes(s.getGlobalId())) continue
        if (EXCLUDED_DAILY_SKINS.includes(s.name)) continue

        if (s.costStarPoints > 1) {
          starss.push(s.getGlobalId())
          continue
        }

        if (!s.name.endsWith('Gold')) {
          skis.push(s.getGlobalId())
        } else {
          const sc = skinTable.getData(s.name.replace('Gold', 'Silver'))
          if (sc == null) {
            skis.push(s.getGlobalId())
            continue
          }
          if (this.unlockedSkins.includes(sc.getGlobalId())) {
            skis.push(s.getGlobalId())
          }
        }
      }
    }

    for (const id of pickDistinct(skis, 8)) {
      const skin = skinTable.getDataByGlobalId(id)
      if (skin == null) continue

      const bundle = new OfferBundle()
      bundle.isDailyDeals = false
      bundle.endTime = tomorrowAtEight()

      if (skin.costGems > 0) {
        bundle.currency = 0
        bundle.cost = skin.costGems - 1
      } else if (skin.costCoins > 0) {
        bundle.currency = 1
        bundle.cost = skin.costCoins
      } else {
        continue
      }

      bundle.items.push(new Offer(ShopItem.Skin, 1, 0, GlobalId.getInstanceId(id)))
      this.offerBundles.push(bundle)
    }

    for (const id of pickDistinct(starss, 3)) {
      const skin = skinTable.getDataByGlobalId(id)
      if (skin == null) continue

      const bundle = new OfferBundle()
      bundle.currency = 3
      bundle.isDailyDeals = false
      bundle.endTime = tomorrowAtEight()
      bundle.cost = skin.costStarPoints
      bundle.items.push(new Offer(ShopItem.Skin, 1, 0, GlobalId.getInstanceId(id)))
      this.offerBundles.push(bundle)
    }
  }

  updateDailyOfferBundles () {
    this.offerBundles = []
    this.offerBundles.push(this.generateDailyGift())

    const possibleHeroes = []
    for (const h of this.homeMode.avatar.heroes) {
      if (h.powerLevel === 8) continue
      if (h.powerPoints >= 1410) continue
      possibleHeroes.push(h)
    }

    let shouldPowerPoints = true
    let hasMG = false
    let offcount = 0

    for (let i = 1; i < ClientHome.DAILYOFFERS_COUNT; i++) {
      if (possibleHeroes.length === 0) break
      offcount++

      if (!hasMG && nextInt(0, 100) > 33) {
        i++
        offcount++
        hasMG = true
        const a = this.generateDailyOffer(false, null)
        if (a != null) {
          this.offerBundles.push(a)
        }
      }

      const inds = nextInt(0, possibleHeroes.length)
      const brawler = possibleHeroes[inds]
      possibleHeroes.splice(inds, 1)

      const dailyOffer = this.generateDailyOffer(shouldPowerPoints, brawler)
      if (dailyOffer != null) {
        if (!shouldPowerPoints) shouldPowerPoints = dailyOffer.items[0].type !== ShopItem.HeroPower
        this.offerBundles.push(dailyOffer)
      }
    }

    if (offcount < 5 && !hasMG) {
      const dailyOffer = this.generateDailyOffer(false, null)
      if (dailyOffer != null) {
        this.offerBundles.push(dailyOffer)
      }
    }
  }

  generateDailyGift () {
    const bundle = new OfferBundle()
    bundle.isDailyDeals = true
    bundle.endTime = tomorrowAtEight()
    bundle.cost = 0
    bundle.items.push(new Offer(ShopItem.FreeBox, 1))
    return bundle
  }

  generateDailyOffer (shouldPowerPoints, brawler) {
    const bundle = new OfferBundle()
    bundle.isDailyDeals = true
    bundle.endTime = tomorrowAtEight()

    if (shouldPowerPoints && brawler != null) {
      const count = nextInt(15, 100) + 1
      bundle.items.push(new Offer(ShopItem.HeroPower, count, brawler.characterId))
      bundle.cost = count * 2
      bundle.currency = 1
    } else {
      bundle.items.push(new Offer(ShopItem.MegaBox, 1))
      bundle.cost = 40
      bundle.oldCost = 80
      bundle.currency = 0
    }

    return bundle
  }

  getDayOfYear (date) {
    const start = Date.UTC(date.getUTCFullYear(), 0, 1)
    const today = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate())
    return Math.floor((today - start) / 86400000) + 1
  }

  logicDailyData (encoder, utcNow) {
    const avatar = this.homeMode.avatar

    encoder.writeVInt(utcNow.getUTCFullYear() * 1000 + this.getDayOfYear(utcNow))
    encoder.writeVInt(utcNow.getUTCHours() * 3600 + utcNow.getUTCMinutes() * 60 + utcNow.getUTCSeconds())
    encoder.writeVInt(avatar.trophies)
    encoder.writeVInt(avatar.highestTrophies)
    encoder.writeVInt(avatar.highestTrophies)
    encoder.writeVInt(this.trophyRoadProgress)
    encoder.writeVInt(this.experience + 1909)

    ByteStreamHelper.writeDataReference(encoder, this.thumbnail)
    ByteStreamHelper.writeDataReference(encoder, this.nameColorId)

    encoder.writeVInt(18)
    for (let i = 0; i < 18; i++) {
      encoder.writeVInt(i)
    }

    encoder.writeVInt(SELECTED_SKINS_COUNT)
    for (let i = 0; i < SELECTED_SKINS_COUNT; i++) {
      encoder.writeVInt(29)
      encoder.writeVInt(this.selectedSkins[i] | 0)
    }

    encoder.writeVInt(this.unlockedSkins.length)
    for (const s of this.unlockedSkins) {
      ByteStreamHelper.writeDataReference(encoder, s)
    }

    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(avatar.highestTrophies)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeBoolean(true)
    encoder.writeVInt(this.tokenDoublers)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeBoolean(false)
    encoder.writeBoolean(false)
    encoder.writeBoolean(false)
    encoder.writeVInt(2)
    encoder.writeVInt(2)
    encoder.writeVInt(2)
    encoder.writeVInt(0)
    encoder.writeVInt(0)

    encoder.writeVInt(0)

    encoder.writeVInt(0)
    encoder.writeVInt(this.battleTokens)
    encoder.writeVInt(this.getbattleTokensRefreshSeconds())
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    ByteStreamHelper.writeDataReference(encoder, this.character)
    encoder.writeString(null)
    encoder.writeString(null)
    encoder.writeVInt(0)

    this.tokenReward = 0
    this.trophiesReward = 0
    this.starTokenReward = 0
    this.starPointsGained = 0
    this.powerPlayTrophiesReward = 0

    encoder.writeVInt(0)
    encoder.writeVInt(1)
    encoder.writeVInt(8)
    encoder.writeVInt(this.brawlPassTokens)
    encoder.writeBoolean(this.hasPremiumPass)
    encoder.writeVInt(0)
    encoder.writeBoolean(false)
    if (encoder.writeBoolean(true)) {
      encoder.writeLongLong128(toBigInt(this.premiumPassProgress, 1n))
    }
    if (encoder.writeBoolean(true)) {
      encoder.writeLongLong128(toBigInt(this.brawlPassProgress, 1n))
    }

    encoder.writeVInt(1)
    encoder.writeVInt(2)
    encoder.writeVInt(this.powerPlayScore)

    encoder.writeBoolean(true)
    encoder.writeVInt(0)
    encoder.writeBoolean(true)
    encoder.writeVInt(0)
    encoder.writeBoolean(false)
    encoder.writeInt(0)
  }

  logicConfData (encoder, utcNow) {
    encoder.writeVInt(0)
    encoder.writeVInt(9)
    for (let i = 1; i <= 9; i++) {
      encoder.writeVInt(i)
    }

    const events = this.events || []
    encoder.writeVInt(events.length)
    for (const data of events) {
      data.isSecondary = false
      data.encode(encoder)
    }

    encoder.writeVInt(0)
    encoder.writeVInt(0)

    ByteStreamHelper.writeIntList(encoder, ClientHome.GoldPacksPrice)
    ByteStreamHelper.writeIntList(encoder, ClientHome.GoldPacksAmount)

    encoder.writeBoolean(true)
    encoder.writeVInt(0)
    encoder.writeVInt(1)
    encoder.writeInt(1)
    encoder.writeInt(41000034)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
  }

  encode (encoder) {
    const utcNow = new Date()
    this.logicDailyData(encoder, utcNow)
    this.logicConfData(encoder, utcNow)

    encoder.writeLong(this.homeId)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(0)

    encoder.writeBoolean(false)
    encoder.writeVInt(0)
  }

  toJSON () {
    const data = {}
    for (const field of SIMPLE_FIELDS) data[field] = this[field]
    data.offerBundles = this.offerBundles
    data.brawlPassProgress = toBigInt(this.brawlPassProgress, 1n).toString()
    data.premiumPassProgress = toBigInt(this.premiumPassProgress, 1n).toString()
    data.quests = this.quests
    data.notificationFactory = this.notificationFactory
    data.playerMaps = this.playerMaps
    return data
  }

  static fromJSON (data) {
    const home = new ClientHome()
    for (const field of SIMPLE_FIELDS) {
      if (data[field] !== undefined && data[field] !== null) home[field] = data[field]
    }
    if (Array.isArray(data.offerBundles)) home.offerBundles = data.offerBundles.map(bundle => OfferBundle.fromJSON(bundle))
    home.brawlPassProgress = toBigInt(data.brawlPassProgress, 1n)
    home.premiumPassProgress = toBigInt(data.premiumPassProgress, 1n)
    home.quests = data.quests != null ? Quests.fromJSON(data.quests) : null
    home.notificationFactory = NotificationFactory.fromJSON(data.notificationFactory)
    home.playerMaps = Array.isArray(data.playerMaps) ? data.playerMaps.map(map => PlayerMap.fromJSON(map)) : []
    if (!Array.isArray(home.selectedSkins)) home.selectedSkins = new Array(SELECTED_SKINS_COUNT).fill(0)
    while (home.selectedSkins.length < SELECTED_SKINS_COUNT) home.selectedSkins.push(0)
    return home
  }
}

module.exports = ClientHome
