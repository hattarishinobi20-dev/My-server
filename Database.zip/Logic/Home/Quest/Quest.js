const ByteStreamHelper = require('../../Helper/ByteStreamHelper')

const JSON_FIELDS = ['missionType', 'currentGoal', 'questGoal', 'gameModeVariation', 'isDailyQuest', 'brawlPassExclusive', 'questSeen', 'characterId', 'reward', 'progress']

class Quest {
  constructor () {
    this.missionType = 0
    this.currentGoal = 0
    this.questGoal = 0
    this.gameModeVariation = 0
    this.isDailyQuest = false
    this.brawlPassExclusive = false
    this.questSeen = false
    this.characterId = 0
    this.reward = 0
    this.progress = 0
  }

  clone () {
    return Quest.fromJSON(this.toJSON())
  }

  encode (encoder) {
    encoder.writeVInt(0)
    encoder.writeVInt(1)
    encoder.writeVInt(this.missionType)
    encoder.writeVInt(this.currentGoal)
    encoder.writeVInt(this.questGoal)
    encoder.writeVInt(this.reward)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeVInt(this.isDailyQuest ? 1 : -1)
    encoder.writeBoolean(this.brawlPassExclusive)
    encoder.writeBoolean(this.questSeen)
    ByteStreamHelper.writeDataReference(encoder, this.characterId)
    encoder.writeVInt(this.gameModeVariation)
    encoder.writeVInt(this.progress)
    encoder.writeVInt(0)
  }

  toJSON () {
    const data = {}
    for (const field of JSON_FIELDS) data[field] = this[field]
    return data
  }

  static fromJSON (data) {
    const quest = new Quest()
    for (const field of JSON_FIELDS) {
      if (data[field] !== undefined) quest[field] = data[field]
    }
    return quest
  }
}

module.exports = Quest
