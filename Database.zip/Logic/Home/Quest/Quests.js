const Quest = require('./Quest')

const ALLOWED_MODES = Object.freeze([0, 2, 5, 6, 9, 11])

function nextInt (min, max) {
  if (max <= min) return min
  return min + Math.floor(Math.random() * (max - min))
}

class Quests {
  static GOAL_TABLE = Object.freeze([40000, 50000, 60000, 80000, 100000])
  static WIN_TABLE = Object.freeze([6, 10])

  constructor () {
    this.questList = []
  }

  addRandomQuests (unlockedHeroes, count) {
    const characters = unlockedHeroes.map(x => x.characterId)
    this.addQuest(characters, false, 3, 100, true)
    this.addQuest(characters, false, 3, 100, true)
    this.addQuest(characters, false, 6, 250, false)
    this.addQuest(characters, false, 6, 250, false)
    this.addQuest(characters, false, 10, 500, false)
    this.addQuest(characters, true, 10, 500, false)
  }

  addQuest (characters, isPremium, goal, reward, isDaily) {
    const quest = new Quest()
    quest.missionType = 1
    const forCharacter = nextInt(0, 120) > 40
    if (forCharacter && characters.length > 0) {
      quest.characterId = characters[nextInt(0, characters.length)]
      quest.gameModeVariation = -1
    } else {
      quest.gameModeVariation = ALLOWED_MODES[nextInt(0, ALLOWED_MODES.length)]
    }
    quest.questGoal = goal
    quest.reward = reward
    quest.brawlPassExclusive = isPremium
    quest.isDailyQuest = isDaily
    this.questList.push(quest)
  }

  updateQuestsProgress (gameModeVariation, characterId, kills, damage, heals, home) {
    const completed = []
    const progressive = []
    if (this.questList == null) {
      return progressive
    }

    for (const quest of this.questList.slice()) {
      if ((quest.gameModeVariation === gameModeVariation || quest.gameModeVariation === -1) &&
        (quest.characterId === characterId || quest.characterId === 0)) {
        if (quest.brawlPassExclusive && !home.hasPremiumPass) continue

        let amount = null
        if (quest.missionType === 1) amount = 1
        else if (quest.missionType === 2) amount = kills
        else if (quest.missionType === 3) amount = damage
        else if (quest.missionType === 4) amount = heals
        if (amount == null) continue

        const progress = quest.clone()
        progress.progress = amount
        if (quest.missionType === 4 && progress.currentGoal + progress.progress > progress.questGoal) {
          progress.progress = progress.questGoal - progress.currentGoal
        }
        quest.currentGoal += amount
        if (quest.currentGoal >= quest.questGoal) {
          completed.push(quest)
        }
        progressive.push(progress)
      }
    }

    for (const quest of completed) {
      const index = this.questList.indexOf(quest)
      if (index !== -1) this.questList.splice(index, 1)
      home.tokenReward += quest.reward
      home.brawlPassTokens += quest.reward
    }

    return progressive
  }

  encode (encoder) {
    encoder.writeVInt(this.questList.length)
    for (const quest of this.questList.slice()) {
      quest.encode(encoder)
    }
  }

  toJSON () {
    return { quest_list: this.questList }
  }

  static fromJSON (data) {
    const quests = new Quests()
    if (data != null && Array.isArray(data.quest_list)) {
      quests.questList = data.quest_list.map(quest => Quest.fromJSON(quest))
    }
    return quests
  }
}

module.exports = Quests
