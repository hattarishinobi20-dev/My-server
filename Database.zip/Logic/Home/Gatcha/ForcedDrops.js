class ForcedDrops {
  encode (stream) {
    stream.writeBoolean(false)
  }
}

module.exports = ForcedDrops
