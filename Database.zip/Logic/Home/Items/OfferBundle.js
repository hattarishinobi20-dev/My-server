const Offer = require('./Offer')

const JSON_FIELDS = ['currency', 'cost', 'isDailyDeals', 'purchased', 'endTime', 'oldCost', 'title', 'backgroundExportName', 'state']

class OfferBundle {
  constructor () {
    this.items = []
    this.currency = 0
    this.cost = 0
    this.isDailyDeals = false
    this.purchased = false
    this.endTime = 0
    this.oldCost = 0
    this.title = null
    this.backgroundExportName = null
    this.state = 0
  }

  encode (stream) {
    stream.writeVInt(this.items.length)
    for (const offer of this.items) {
      offer.encode(stream)
    }
    stream.writeVInt(this.currency)
    stream.writeVInt(this.cost)
    stream.writeVInt(Math.trunc((this.endTime - Date.now()) / 1000))
    stream.writeVInt(this.state)
    stream.writeVInt(0)
    stream.writeBoolean(this.purchased)
    stream.writeVInt(0)
    stream.writeBoolean(this.isDailyDeals)
    stream.writeVInt(this.oldCost)
    stream.writeInt(0)
    stream.writeString(this.title)
    stream.writeBoolean(false)
    stream.writeString(this.backgroundExportName)
    stream.writeVInt(0)
    stream.writeBoolean(false)
    stream.writeVInt(2)
    stream.writeVInt(0)
  }

  toJSON () {
    const data = { items: this.items }
    for (const field of JSON_FIELDS) data[field] = this[field]
    return data
  }

  static fromJSON (data) {
    const bundle = new OfferBundle()
    for (const field of JSON_FIELDS) {
      if (data[field] !== undefined) bundle[field] = data[field]
    }
    bundle.items = Array.isArray(data.items) ? data.items.map(item => Offer.fromJSON(item)) : []
    return bundle
  }
}

module.exports = OfferBundle
