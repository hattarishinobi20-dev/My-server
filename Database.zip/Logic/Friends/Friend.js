const LogicServerListener = require('../Listener/LogicServerListener')
const PlayerDisplayData = require('../Avatar/Structures/PlayerDisplayData')

class Friend {
  constructor () {
    this.accountId = 0
    this.trophies = 0
    this.displayData = null
    this.friendState = 0
    this.friendReason = 0
  }

  get avatar () {
    return LogicServerListener.instance.getAvatar(this.accountId)
  }

  encode (stream) {
    const avatar = this.avatar
    const isOnline = LogicServerListener.instance.isPlayerOnline(this.accountId)

    stream.writeLong(this.accountId)
    stream.writeString(null)
    stream.writeString(null)
    stream.writeString(null)
    stream.writeString(null)
    stream.writeString(null)
    stream.writeString(null)
    stream.writeInt(avatar != null ? avatar.trophies : this.trophies)
    stream.writeInt(this.friendState)
    stream.writeInt(this.friendReason)
    stream.writeInt(0)
    stream.writeInt(0)
    stream.writeBoolean(false)
    stream.writeString(null)
    stream.writeInt(isOnline || avatar == null ? 0 : Math.trunc((Date.now() - avatar.lastOnline) / 1000))
    if (stream.writeBoolean(this.displayData != null)) {
      if (avatar != null) this.displayData.name = avatar.name
      this.displayData.encode(stream)
    }
  }

  static updateDisplayData (homeMode) {
    const avatar = homeMode.avatar
    const home = homeMode.home
    for (const friend of avatar.friends) {
      const friendAvatar = friend.avatar
      if (friendAvatar == null) continue
      const entry = friendAvatar.friends.find(x => x.accountId === avatar.accountId)
      if (entry == null) continue
      entry.displayData = new PlayerDisplayData(home.hasPremiumPass, home.thumbnailId, home.nameColorId, avatar.name)
    }
  }

  toJSON () {
    return {
      accountId: this.accountId,
      trophies: this.trophies,
      displayData: this.displayData,
      friendState: this.friendState,
      friendReason: this.friendReason
    }
  }

  static fromJSON (data) {
    const friend = new Friend()
    if (data.accountId != null) friend.accountId = data.accountId
    if (data.trophies != null) friend.trophies = data.trophies
    if (data.displayData != null) friend.displayData = PlayerDisplayData.fromJSON(data.displayData)
    if (data.friendState != null) friend.friendState = data.friendState
    if (data.friendReason != null) friend.friendReason = data.friendReason
    return friend
  }
}

module.exports = Friend
