class LogicBitHelper {
  static get (value, index) {
    return ((BigInt(value) >> BigInt(index)) & 1n) === 1n
  }

  static set (value, index, data) {
    value = BigInt(value)
    value &= ~(1n << BigInt(index))

    if (data) {
      value |= (1n << BigInt(index))
    }

    return value
  }
}

module.exports = LogicBitHelper
