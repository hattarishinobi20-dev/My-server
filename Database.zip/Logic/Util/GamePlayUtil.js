const LogicVector2 = require('../../Titan/Math/LogicVector2')
const LogicMath = require('../../Titan/Math/LogicMath')

class GamePlayUtil {
  static isJumpCharge (chargeType) {
    const v1 = (chargeType - 2) >>> 0

    if (v1 <= 9) {
      return ((0x293 >>> v1) & 1) !== 0
    }

    return false
  }

  static getPlayerCountWithGameModeVariation (gameMode) {
    switch (gameMode) {
      case 0:
      case 2:
      case 3:
      case 5:
        return 6
      case 6:
        return 10
      case 7:
        return 6
      case 8:
        return 3
      case 9:
        return 10
      case 10:
        return 3
      case 11:
        return 6
      case 12:
      case 13:
        return 1
      case 14:
      case 15:
        return 10
      case 16:
      case 17:
        return 6
      case 18:
        return 3
      case 19:
      case 20:
      case 21:
      case 22:
      case 23:
        return 6
      case 24:
        return 2
      case 25:
      case 26:
      case 27:
        return 6
    }

    return -1
  }

  static getDistanceSquaredBetween (x1, y1, x2, y2) {
    const dx = x1 - x2
    const dy = y1 - y2
    return dx * dx + dy * dy
  }

  static getDistanceBetween (x1, y1, x2, y2) {
    return LogicMath.sqrt(GamePlayUtil.getDistanceSquaredBetween(x1, y1, x2, y2))
  }

  static lineSegmentIntersectsRectangle (x1, y1, x2, y2, left, top, right, bottom, out) {
    if (x1 >= left && x1 <= right && y1 >= top && y1 <= bottom) {
      const distances = [[y1 - top, 1], [right - x1, 2], [x1 - left, 3], [bottom - y1, 4]]
      let best = distances[0]
      for (const entry of distances) {
        if (entry[0] < best[0]) best = entry
      }
      out.x = x1
      out.y = y1
      return best[1]
    }

    const dx = x2 - x1
    const dy = y2 - y1
    const checks = [[-dx, x1 - left, 3], [dx, right - x1, 2], [-dy, y1 - top, 1], [dy, bottom - y1, 4]]
    let enter = 0
    let exit = 1
    let side = 0

    for (const [p, q, s] of checks) {
      if (p === 0) {
        if (q < 0) return 0
        continue
      }

      const t = q / p

      if (p < 0) {
        if (t > exit) return 0
        if (t > enter) {
          enter = t
          side = s
        }
      } else {
        if (t < enter) return 0
        if (t < exit) exit = t
      }
    }

    if (side === 0) return 0

    out.x = x1 + Math.trunc(dx * enter)
    out.y = y1 + Math.trunc(dy * enter)
    return side
  }

  static calculatePercentDamage (percent, damage, isCharge, damageBuff, damageDebuff, minDamage, target) {
    if (target == null) return damage

    let result = LogicMath.max(Math.trunc(target.hitpoints * percent / 100), minDamage)

    if (damageBuff > 0) result += Math.trunc(result * damageBuff / 100)
    if (damageDebuff > 0) result -= Math.trunc(result * damageDebuff / 100)

    return LogicMath.max(0, result)
  }

  static getClosestPassableSpot (type, x, y, maxTileRadius, tileMap, outVector, canWalkOverWater) {
    const tileX = Math.trunc(x / 300)
    const tileY = Math.trunc(y / 300)

    for (let r = 0; r <= maxTileRadius; r++) {
      let bestDistance = -1
      let bestX = 0
      let bestY = 0

      for (let i = tileX - r; i <= tileX + r; i++) {
        for (let j = tileY - r; j <= tileY + r; j++) {
          if (LogicMath.max(LogicMath.abs(i - tileX), LogicMath.abs(j - tileY)) !== r) continue
          if (!tileMap.isPassable(type, i, j, 0, 0, canWalkOverWater)) continue
          const centerX = i * 300 + 150
          const centerY = j * 300 + 150
          const distance = GamePlayUtil.getDistanceSquaredBetween(centerX, centerY, x, y)
          if (bestDistance === -1 || distance < bestDistance) {
            bestDistance = distance
            bestX = centerX
            bestY = centerY
          }
        }
      }

      if (bestDistance !== -1) {
        outVector.set(bestX, bestY)
        return true
      }
    }

    return false
  }

  static getClosestLevelBorderCollision (x1, y1, x2, y2, tileMap, margin, out) {
    const minX = margin
    const minY = margin
    const maxX = tileMap.logicWidth - margin
    const maxY = tileMap.logicHeight - margin
    if (x2 >= minX && x2 <= maxX && y2 >= minY && y2 <= maxY) return false
    const dx = x2 - x1
    const dy = y2 - y1
    let t = 1
    if (x2 < minX && dx !== 0) t = Math.min(t, (minX - x1) / dx)
    if (x2 > maxX && dx !== 0) t = Math.min(t, (maxX - x1) / dx)
    if (y2 < minY && dy !== 0) t = Math.min(t, (minY - y1) / dy)
    if (y2 > maxY && dy !== 0) t = Math.min(t, (maxY - y1) / dy)
    t = Math.max(0, t)
    out.x = LogicMath.clamp(x1 + Math.trunc(dx * t), minX, maxX)
    out.y = LogicMath.clamp(y1 + Math.trunc(dy * t), minY, maxY)
    return true
  }

  static getClosestAnyCollision (x1, y1, x2, y2, tileMap, out, a7, a8, a9, a10) {
    const dx = x2 - x1
    const dy = y2 - y1
    const distance = LogicMath.sqrt(dx * dx + dy * dy)
    const steps = Math.max(1, Math.trunc(distance / 25))
    let prevTileX = Math.trunc(x1 / 300)
    let prevTileY = Math.trunc(y1 / 300)
    for (let i = 1; i <= steps; i++) {
      const x = x1 + Math.trunc(dx * i / steps)
      const y = y1 + Math.trunc(dy * i / steps)
      const outside = x < 0 || y < 0 || x >= tileMap.logicWidth || y >= tileMap.logicHeight
      const tileX = Math.trunc(x / 300)
      const tileY = Math.trunc(y / 300)
      if (outside || ((tileX !== prevTileX || tileY !== prevTileY) && !tileMap.isPassable(0, tileX, tileY, 0, 0, false))) {
        out.x = x1 + Math.trunc(dx * (i - 1) / steps)
        out.y = y1 + Math.trunc(dy * (i - 1) / steps)
        return true
      }
      prevTileX = tileX
      prevTileY = tileY
    }
    return false
  }

  static findSafeDropPosition (tileMap, x, y, minRadius, maxRadius, out) {
    const spot = new LogicVector2()
    if (!GamePlayUtil.getClosestPassableSpot(0, LogicMath.clamp(x, 1, tileMap.logicWidth - 2), LogicMath.clamp(y, 1, tileMap.logicHeight - 2), Math.max(1, Math.trunc(maxRadius / 300) + 1), tileMap, spot, false)) return false
    out.x = LogicMath.clamp(spot.x, 1, tileMap.logicWidth - 2)
    out.y = LogicMath.clamp(spot.y, 1, tileMap.logicHeight - 2)
    return true
  }

  static losCleared (x1, y1, x2, y2, tileMap) {
    return tileMap.calculateLOSWithCollision(x1, y1, x2, y2, 0)
  }

  static weaponSpreadToAngleRad (spread) {
    return Math.fround(Math.atan(spread / 450) * 2)
  }

  static radToDeg (rad) {
    return Math.fround(rad * 180 / Math.PI)
  }
}

module.exports = GamePlayUtil
