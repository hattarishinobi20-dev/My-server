const Debugger = require('../../Titan/Debug/Debugger')

class GameModeUtil {
  static playersCollectPowerCubes (variation) {
    const v1 = variation - 6

    if (v1 >= 0 && v1 <= 8) {
      return ((0x119 >> v1) & 1) !== 0
    }

    return false
  }

  static getRespawnSeconds (variation) {
    switch (variation) {
      case 0:
      case 2:
        return 3
      case 3:
        return 1
      default:
        return 5
    }
  }

  static playersCollectBountyStars (variation) {
    return variation === 3 || variation === 15
  }

  static hasTwoTeams (variation) {
    return variation !== 6 && variation !== 9
  }

  static hasTwoBases (variation) {
    return variation === 2 || variation === 11
  }

  static hasFiveTeams (variation) {
    return variation === 9
  }

  static modeHasCarryables (variation) {
    return variation === 5 || variation === 16 || variation === 21 || variation === 22 || variation === 23
  }

  static getBattleTicks (variation) {
    switch (variation) {
      case 6:
      case 8:
      case 9:
      case 10:
      case 12:
      case 13:
        return 16000
      default:
        return 3180
    }
  }

  static getGameModeVariation (mode) {
    switch (mode) {
      case 'CoinRush':
        return 0
      case 'AttackDefend':
        return 2
      case 'BossFight':
        return 7
      case 'BountyHunter':
        return 3
      case 'Artifact':
        return 4
      case 'LaserBall':
        return 5
      case 'BattleRoyale':
        return 6
      case 'BattleRoyaleTeam':
        return 9
      case 'Survival':
        return 8
      case 'Raid':
        return 10
      case 'RoboWars':
        return 11
      case 'Tutorial':
        return 12
      case 'Training':
        return 13
      default:
        Debugger.error('Wrong game mode!')
        return -1
    }
  }
}

module.exports = GameModeUtil
