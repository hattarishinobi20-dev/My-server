const ByteStream = require('../../Titan/DataStream/ByteStream')

class GameMessage extends ByteStream {
  constructor (bytes, client) {
    super(Buffer.isBuffer(bytes) ? bytes : 10)
    this.id = 0
    this.version = 0
    this.client = client != null ? client : null
  }

  encode () {

  }

  decode () {

  }

  process () {
    this.client.connection.messaging.readNewMessage(this)
  }

  send () {
    this.client.connection.send(this)
  }

  getMessageType () {
    return this.id
  }

  getServiceNodeType () {
    return 0
  }

  setVersion (version) {
    this.version = version
  }

  getVersion () {
    return this.version
  }

  getByteStream () {
    return this
  }

  getMessageBytes () {
    return this.buffer.subarray(0, this.offset)
  }

  getEncodingLength () {
    return this.offset
  }
}

module.exports = GameMessage
