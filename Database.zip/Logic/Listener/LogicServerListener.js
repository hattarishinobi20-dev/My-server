class LogicServerListener {
  static instance = null

  getAvatar (id) {
    throw new Error('LogicServerListener::getAvatar is abstract')
  }

  getGameListener (id) {
    throw new Error('LogicServerListener::getGameListener is abstract')
  }

  getHomeMode (id) {
    throw new Error('LogicServerListener::getHomeMode is abstract')
  }

  isPlayerOnline (id) {
    throw new Error('LogicServerListener::isPlayerOnline is abstract')
  }
}

module.exports = LogicServerListener
