const LogicData = require('./Helper/LogicData')

class CampaignData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

CampaignData.columns = [
  ['name', 'Name', 'string'],
  ['tid', 'TID', 'string'],
  ['location', 'Location', 'string'],
  ['allowedHeroes', 'AllowedHeroes', 'string'],
  ['reward', 'Reward', 'string'],
  ['levelGenerationSeed', 'LevelGenerationSeed', 'int'],
  ['map', 'Map', 'string'],
  ['enemies', 'Enemies', 'string'],
  ['enemyLevel', 'EnemyLevel', 'int'],
  ['boss', 'Boss', 'string'],
  ['bossLevel', 'BossLevel', 'int'],
  ['base', 'Base', 'string'],
  ['numBases', 'NumBases', 'int'],
  ['baseLevel', 'BaseLevel', 'int'],
  ['tower', 'Tower', 'string'],
  ['numTowers', 'NumTowers', 'int'],
  ['towerLevel', 'TowerLevel', 'int'],
  ['requiredStars', 'RequiredStars', 'int']
]

module.exports = CampaignData
