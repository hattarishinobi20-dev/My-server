const fs = require('fs')
const Column = require('./Column')
const CSVReader = require('./CSVReader')

class Table {
  constructor (path) {
    const Row = require('./Row')

    this.rows = []
    this.headers = []
    this.types = []
    this.columns = []

    const reader = new CSVReader(fs.readFileSync(path, 'utf8'))

    const columns = reader.readFields() || []

    for (const column of columns) {
      this.headers.push(column)
      this.columns.push(new Column())
    }

    const types = reader.readFields() || []

    for (const type of types) {
      this.types.push(type)
    }

    while (!reader.isEndOfData()) {
      const values = reader.readFields()

      if (values[0]) {
        this.addRow(new Row(this))
      }

      for (let i = 0; i < this.headers.length; i++) {
        this.columns[i].add(i < values.length ? values[i] : '')
      }
    }
  }

  addRow (row) {
    this.rows.push(row)
  }

  getArraySizeAt (row, columnIndex) {
    const index = row.index

    if (this.rows[index] !== row) {
      return 0
    }

    let nextOffset

    if (index + 1 >= this.rows.length) {
      nextOffset = this.columns[columnIndex].getSize()
    } else {
      nextOffset = this.rows[index + 1].getOffset()
    }

    return Column.getArraySize(row.getOffset(), nextOffset)
  }

  getColumnIndexByName (name) {
    return this.headers.indexOf(name)
  }

  getColumnName (index) {
    return this.headers[index]
  }

  getColumnRowCount () {
    return this.columns.length > 0 ? this.columns[0].getSize() : 0
  }

  getRowAt (index) {
    return this.rows[index]
  }

  getRowCount () {
    return this.rows.length
  }

  getValue (name, level) {
    const index = this.headers.indexOf(name)
    return this.getValueAt(index, level)
  }

  getValueAt (column, row) {
    if (column < 0 || column >= this.columns.length) {
      return null
    }

    const value = this.columns[column].get(row)
    return value !== undefined ? value : null
  }
}

module.exports = Table
