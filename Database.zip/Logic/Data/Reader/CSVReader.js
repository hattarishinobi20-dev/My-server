const WHITESPACE = /^[\s\u0000]+|[\s\u0000]+$/g

class CSVReader {
  constructor (text) {
    this.lines = text.replace(/^\uFEFF/, '').split(/\r\n|\n|\r/)
    this.index = 0
  }

  isEndOfData () {
    this.skipEmptyLines()
    return this.index >= this.lines.length
  }

  skipEmptyLines () {
    while (this.index < this.lines.length && this.lines[this.index].trim().length === 0) {
      this.index++
    }
  }

  readFields () {
    if (this.isEndOfData()) {
      return null
    }

    const fields = []
    let line = this.lines[this.index++]
    let position = 0

    while (true) {
      while (position < line.length && (line[position] === ' ' || line[position] === '\t')) {
        position++
      }

      if (line[position] === '"') {
        let value = ''
        position++

        while (true) {
          const quote = line.indexOf('"', position)

          if (quote === -1) {
            value += line.substring(position)

            if (this.index >= this.lines.length) {
              throw new Error(`CSVReader: unterminated quoted field at line ${this.index}`)
            }

            value += '\n'
            line = this.lines[this.index++]
            position = 0
            continue
          }

          value += line.substring(position, quote)
          position = quote + 1

          if (line[position] === '"') {
            value += '"'
            position++
            continue
          }

          break
        }

        while (position < line.length && (line[position] === ' ' || line[position] === '\t')) {
          position++
        }

        if (position < line.length && line[position] !== ',') {
          throw new Error(`CSVReader: malformed line ${this.index}`)
        }

        fields.push(value.replace(WHITESPACE, ''))
      } else {
        const comma = line.indexOf(',', position)
        const end = comma === -1 ? line.length : comma
        fields.push(line.substring(position, end).replace(WHITESPACE, ''))
        position = end
      }

      if (position >= line.length) {
        break
      }

      position++

      if (position >= line.length) {
        fields.push('')
        break
      }
    }

    return fields
  }
}

module.exports = CSVReader
