const INT_PATTERN = /^[\s\u0000]*[+-]?\d+[\s\u0000]*$/
const BOOL_PATTERN = /^[\s\u0000]*(true|false)[\s\u0000]*$/i

class Row {
  constructor (table) {
    this.table = table
    this.rowStart = table.getColumnRowCount()
    this.index = table.getRowCount()
  }

  getOffset () {
    return this.rowStart
  }

  static parseInt (value) {
    if (value == null || !INT_PATTERN.test(value)) {
      return null
    }

    const number = Number(value.replace(/[\s\u0000]/g, ''))

    if (number > 2147483647 || number < -2147483648) {
      return null
    }

    return number
  }

  static parseBoolean (value) {
    if (value == null) {
      return null
    }

    const match = BOOL_PATTERN.exec(value)

    if (match == null) {
      return null
    }

    return match[1].toLowerCase() === 'true'
  }

  loadData (data) {
    const columns = data.constructor.columns || []

    for (const [field, name, type] of columns) {
      switch (type) {
        case 'int[]':
          data[field] = this.loadIntArray(name)
          break
        case 'bool[]':
          data[field] = this.loadBoolArray(name)
          break
        case 'string[]':
          data[field] = this.loadStringArray(name)
          break
        default: {
          const value = this.getValue(name, 0)

          if (value) {
            if (type === 'int') {
              const number = Row.parseInt(value)
              if (number != null) data[field] = number
            } else if (type === 'bool') {
              const boolean = Row.parseBoolean(value)
              if (boolean != null) data[field] = boolean
            } else {
              data[field] = value
            }
          }
        }
      }
    }
  }

  getArraySize (name) {
    const index = this.table.getColumnIndexByName(name)
    return index !== -1 ? this.table.getArraySizeAt(this, index) : 0
  }

  getName () {
    return this.table.getValueAt(0, this.rowStart)
  }

  getValue (name, level) {
    return this.table.getValue(name, level + this.rowStart)
  }

  loadBoolArray (column) {
    const array = new Array(this.getArraySize(column)).fill(false)

    for (let i = 0; i < array.length; i++) {
      const boolean = Row.parseBoolean(this.getValue(column, i))
      if (boolean != null) array[i] = boolean
    }

    return array
  }

  loadIntArray (column) {
    const array = new Array(this.getArraySize(column)).fill(0)

    for (let i = 0; i < array.length; i++) {
      const number = Row.parseInt(this.getValue(column, i))
      if (number != null) array[i] = number
    }

    return array
  }

  loadStringArray (column) {
    const array = new Array(this.getArraySize(column))

    for (let i = 0; i < array.length; i++) {
      array[i] = this.getValue(column, i)
    }

    return array
  }
}

module.exports = Row
