const LogicData = require('./Helper/LogicData')

class ThemeData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

ThemeData.columns = [
  ['name', 'Name', 'string'],
  ['fileName', 'FileName', 'string'],
  ['exportName', 'ExportName', 'string'],
  ['particleFileName', 'ParticleFileName', 'string'],
  ['particleExportName', 'ParticleExportName', 'string'],
  ['particleStyle', 'ParticleStyle', 'string'],
  ['particleVariations', 'ParticleVariations', 'int'],
  ['themeMusic', 'ThemeMusic', 'string'],
  ['useInLevelSelection', 'UseInLevelSelection', 'bool']
]

module.exports = ThemeData
