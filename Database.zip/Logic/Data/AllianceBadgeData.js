const LogicData = require('./Helper/LogicData')

class AllianceBadgeData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

AllianceBadgeData.columns = [
  ['name', 'Name', 'string'],
  ['iconSWF', 'IconSWF', 'string'],
  ['iconExportName', 'IconExportName', 'string'],
  ['category', 'Category', 'string']
]

module.exports = AllianceBadgeData
