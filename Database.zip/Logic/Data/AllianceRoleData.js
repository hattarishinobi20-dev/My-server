const LogicData = require('./Helper/LogicData')

class AllianceRoleData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

AllianceRoleData.columns = [
  ['name', 'Name', 'string'],
  ['level', 'Level', 'int'],
  ['tid', 'TID', 'string'],
  ['canInvite', 'CanInvite', 'bool'],
  ['canSendMail', 'CanSendMail', 'bool'],
  ['canChangeAllianceSettings', 'CanChangeAllianceSettings', 'bool'],
  ['canAcceptJoinRequest', 'CanAcceptJoinRequest', 'bool'],
  ['canKick', 'CanKick', 'bool'],
  ['canBePromotedToLeader', 'CanBePromotedToLeader', 'bool'],
  ['promoteSkill', 'PromoteSkill', 'int']
]

module.exports = AllianceRoleData
