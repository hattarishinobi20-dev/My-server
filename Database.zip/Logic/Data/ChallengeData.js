const LogicData = require('./Helper/LogicData')

class ChallengeData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

ChallengeData.columns = [
  ['name', 'Name', 'string'],
  ['challengeId', 'ChallengeId', 'int'],
  ['fileName', 'FileName', 'string'],
  ['locale', 'Locale', 'string[]'],
  ['logoAsset', 'LogoAsset', 'string[]'],
  ['eventAsset', 'EventAsset', 'string'],
  ['bannerSWF', 'BannerSWF', 'string'],
  ['eventBanner', 'EventBanner', 'string'],
  ['rewardItem', 'RewardItem', 'string'],
  ['rewardUnlockedItem', 'RewardUnlockedItem', 'string'],
  ['headerFrame', 'HeaderFrame', 'string'],
  ['tid', 'TID', 'string'],
  ['stageTID', 'StageTID', 'string'],
  ['rewardTID', 'RewardTID', 'string'],
  ['completedTID', 'CompletedTID', 'string'],
  ['rewardPopupTID', 'RewardPopupTID', 'string'],
  ['battleEndHeaderTID', 'BattleEndHeaderTID', 'string'],
  ['battleEndWinLabelTID', 'BattleEndWinLabelTID', 'string'],
  ['battleEndWinTID', 'BattleEndWinTID', 'string'],
  ['startNotification', 'StartNotification', 'string'],
  ['reminderNotification', 'ReminderNotification', 'string'],
  ['teaserTitleTID', 'TeaserTitleTID', 'string'],
  ['teaserInfoTID', 'TeaserInfoTID', 'string']
]

module.exports = ChallengeData
