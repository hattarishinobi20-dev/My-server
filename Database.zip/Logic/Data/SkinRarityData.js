const LogicData = require('./Helper/LogicData')

class SkinRarityData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

SkinRarityData.columns = [
  ['name', 'Name', 'string'],
  ['price', 'Price', 'int'],
  ['rarity', 'Rarity', 'int']
]

module.exports = SkinRarityData
