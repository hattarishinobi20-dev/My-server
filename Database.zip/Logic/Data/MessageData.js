const LogicData = require('./Helper/LogicData')

class MessageData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

MessageData.columns = [
  ['name', 'Name', 'string'],
  ['tid', 'TID', 'string'],
  ['bubbleOverrideTID', 'BubbleOverrideTID', 'string'],
  ['disabled', 'Disabled', 'bool'],
  ['messageType', 'MessageType', 'int'],
  ['fileName', 'FileName', 'string'],
  ['exportName', 'ExportName', 'string'],
  ['quickEmojiType', 'QuickEmojiType', 'int'],
  ['sortPriority', 'SortPriority', 'int'],
  ['ageGated', 'AgeGated', 'bool']
]

module.exports = MessageData
