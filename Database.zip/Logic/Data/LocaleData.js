const LogicData = require('./Helper/LogicData')

class LocaleData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

LocaleData.columns = [
  ['name', 'Name', 'string'],
  ['iconSWF', 'IconSWF', 'string'],
  ['iconExportName', 'IconExportName', 'string'],
  ['localizedName', 'LocalizedName', 'string'],
  ['sortOrder', 'SortOrder', 'int'],
  ['enabled', 'Enabled', 'bool'],
  ['fileName', 'FileName', 'string'],
  ['testLanguage', 'TestLanguage', 'bool'],
  ['usedSystemFont', 'UsedSystemFont', 'string'],
  ['preferedFallbackFont', 'PreferedFallbackFont', 'string'],
  ['forcedFontFullName', 'ForcedFontFullName', 'string'],
  ['helpshiftSDKLanguage', 'HelpshiftSDKLanguage', 'string'],
  ['helpshiftSDKLanguageAndroid', 'HelpshiftSDKLanguageAndroid', 'string'],
  ['testExcludes', 'TestExcludes', 'string'],
  ['loadAllLanguages', 'LoadAllLanguages', 'bool'],
  ['championshipRegisterUrl', 'ChampionshipRegisterUrl', 'string'],
  ['championshipRegisterUrl_cn', 'ChampionshipRegisterUrl_cn', 'string'],
  ['termsAndServiceUrl', 'TermsAndServiceUrl', 'string'],
  ['parentsGuideUrl', 'ParentsGuideUrl', 'string'],
  ['privacyPolicyUrl', 'PrivacyPolicyUrl', 'string'],
  ['laserboxUrl', 'LaserboxUrl', 'string'],
  ['laserboxUrlCN', 'LaserboxUrlCN', 'string'],
  ['laserboxStagingUrl', 'LaserboxStagingUrl', 'string'],
  ['laserboxStagingUrlCN', 'LaserboxStagingUrlCN', 'string'],
  ['laserboxCommunityUrl', 'LaserboxCommunityUrl', 'string'],
  ['laserboxCommunityUrlCN', 'LaserboxCommunityUrlCN', 'string'],
  ['laserboxCommunityStagingUrl', 'LaserboxCommunityStagingUrl', 'string'],
  ['laserboxCommunityStagingUrlCN', 'LaserboxCommunityStagingUrlCN', 'string'],
  ['laserboxLangCode', 'LaserboxLangCode', 'string'],
  ['faqUrl_ios', 'FaqUrl_ios', 'string'],
  ['faqUrl_ios_cn', 'FaqUrl_ios_cn', 'string'],
  ['faqUrl_android', 'FaqUrl_android', 'string'],
  ['faqUrl_android_cn', 'FaqUrl_android_cn', 'string'],
  ['contactUsUrl_ios', 'ContactUsUrl_ios', 'string'],
  ['contactUsUrl_ios_cn', 'ContactUsUrl_ios_cn', 'string'],
  ['contactUsUrl_android', 'ContactUsUrl_android', 'string'],
  ['contactUsUrl_android_cn', 'ContactUsUrl_android_cn', 'string'],
  ['laserboxEnabled', 'LaserboxEnabled', 'bool'],
  ['isRTL', 'IsRTL', 'bool'],
  ['isNounAdj', 'isNounAdj', 'bool'],
  ['separateThousandsWithSpaces', 'SeparateThousandsWithSpaces', 'bool'],
  ['selfHelpUrl', 'SelfHelpUrl', 'string'],
  ['fallbackToHelpshift', 'FallbackToHelpshift', 'bool'],
  ['fallbackToHelpshiftCN', 'FallbackToHelpshiftCN', 'bool']
]

module.exports = LocaleData
