const LogicData = require('./Helper/LogicData')

class PlayerThumbnailData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

PlayerThumbnailData.columns = [
  ['name', 'Name', 'string'],
  ['requiredExpLevel', 'RequiredExpLevel', 'int'],
  ['requiredTotalTrophies', 'RequiredTotalTrophies', 'int'],
  ['requiredSeasonPoints', 'RequiredSeasonPoints', 'int'],
  ['requiredHero', 'RequiredHero', 'string'],
  ['iconSWF', 'IconSWF', 'string'],
  ['iconExportName', 'IconExportName', 'string'],
  ['sortOrder', 'SortOrder', 'int']
]

module.exports = PlayerThumbnailData
