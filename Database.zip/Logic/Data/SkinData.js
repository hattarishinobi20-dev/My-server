const LogicData = require('./Helper/LogicData')

class SkinData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

SkinData.columns = [
  ['name', 'Name', 'string'],
  ['conf', 'Conf', 'string'],
  ['disabled', 'Disabled', 'bool'],
  ['campaigns', 'Campaigns', 'int'],
  ['iconOverride', 'IconOverride', 'string'],
  ['skinGroupId', 'SkinGroupId', 'int'],
  ['obtainType', 'ObtainType', 'int'],
  ['obtainTypeCN', 'ObtainTypeCN', 'int'],
  ['lastChance', 'LastChance', 'bool'],
  ['masterSkin', 'MasterSkin', 'string'],
  ['petSkin', 'PetSkin', 'string'],
  ['petSkin2', 'PetSkin2', 'string'],
  ['costClubCoins', 'CostClubCoins', 'int'],
  ['costStarPoints', 'CostStarPoints', 'int'],
  ['costGems', 'CostGems', 'int'],
  ['costCoins', 'CostCoins', 'int'],
  ['tid', 'TID', 'string'],
  ['shopTID', 'ShopTID', 'string'],
  ['features', 'Features', 'string'],
  ['communityCredit', 'CommunityCredit', 'string'],
  ['materialsFile', 'MaterialsFile', 'string'],
  ['blueTexture', 'BlueTexture', 'string'],
  ['redTexture', 'RedTexture', 'string'],
  ['blueSpecular', 'BlueSpecular', 'string'],
  ['redSpecular', 'RedSpecular', 'string'],
  ['outlineShader', 'OutlineShader', 'string']
]

module.exports = SkinData
