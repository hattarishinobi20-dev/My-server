const LogicData = require('./Helper/LogicData')

class PinData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

PinData.columns = [
  ['name', 'Name', 'string'],
  ['pinType', 'PinType', 'int'],
  ['rarity', 'Rarity', 'int'],
  ['index', 'Index', 'int'],
  ['bonus', 'Bonus', 'int'],
  ['craftCost', 'CraftCost', 'int']
]

module.exports = PinData
