const LogicData = require('./Helper/LogicData')

class RegionData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

RegionData.columns = [
  ['name', 'Name', 'string'],
  ['tid', 'TID', 'string'],
  ['displayName', 'DisplayName', 'string'],
  ['isCountry', 'IsCountry', 'bool']
]

module.exports = RegionData
