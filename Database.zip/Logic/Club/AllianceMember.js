const LogicServerListener = require('../Listener/LogicServerListener')
const PlayerDisplayData = require('../Avatar/Structures/PlayerDisplayData')
const AllianceRole = require('../Avatar/AllianceRole')

class AllianceMember {
  constructor (avatar) {
    this.displayData = null
    this.accountId = 0
    this.trophies = 0
    this.doNotDisturb = false
    this.role = AllianceRole.None

    if (avatar != null) {
      const home = avatar.homeMode.home
      this.displayData = new PlayerDisplayData(home.hasPremiumPass, home.thumbnailId, home.nameColorId, avatar.name)
      this.accountId = avatar.accountId
      this.trophies = avatar.trophies
      this.role = avatar.allianceRole
      this.doNotDisturb = avatar.doNotDisturb
    }
  }

  get avatar () {
    return LogicServerListener.instance.getAvatar(this.accountId)
  }

  get isOnline () {
    return LogicServerListener.instance.isPlayerOnline(this.accountId)
  }

  encode (stream) {
    const avatar = this.avatar
    const isOnline = this.isOnline

    stream.writeLong(this.accountId)
    stream.writeVInt(this.role)
    stream.writeVInt(avatar != null ? avatar.trophies : this.trophies)
    stream.writeVInt(isOnline && avatar != null ? avatar.playerStatus : 0)
    stream.writeVInt(isOnline || avatar == null ? -1 : Math.trunc((Date.now() - avatar.lastOnline) / 1000))
    stream.writeVInt(0)
    stream.writeVInt(0)
    stream.writeVInt(0)
    stream.writeBoolean(this.doNotDisturb)
    if (this.displayData != null) {
      this.displayData.encode(stream)
    } else {
      new PlayerDisplayData().encode(stream)
    }
    stream.writeVInt(0)
    stream.writeBoolean(false)
  }

  toJSON () {
    return {
      displayData: this.displayData,
      accountId: this.accountId,
      trophies: this.trophies,
      DoNotDisturb: this.doNotDisturb,
      role: this.role
    }
  }

  static fromJSON (data) {
    const member = new AllianceMember()
    if (data.displayData != null) member.displayData = PlayerDisplayData.fromJSON(data.displayData)
    if (data.accountId != null) member.accountId = data.accountId
    if (data.trophies != null) member.trophies = data.trophies
    if (data.DoNotDisturb != null) member.doNotDisturb = data.DoNotDisturb
    if (data.role != null) member.role = data.role
    return member
  }
}

module.exports = AllianceMember
