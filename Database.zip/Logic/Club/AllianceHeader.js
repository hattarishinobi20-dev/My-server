const ByteStreamHelper = require('../Helper/ByteStreamHelper')

class AllianceHeader {
  constructor (id, name, badge, playersCount, trophies, requiredTrophies, type) {
    this.id = id
    this.name = name
    this.badge = badge
    this.playersCount = playersCount
    this.trophies = trophies
    this.requiredTrophies = requiredTrophies
    this.type = type
  }

  encode (stream) {
    stream.writeLong(this.id)
    stream.writeString(this.name)
    ByteStreamHelper.writeDataReference(stream, this.badge)
    stream.writeVInt(this.type)
    stream.writeVInt(this.playersCount)
    stream.writeVInt(this.trophies)
    stream.writeVInt(this.requiredTrophies)
    ByteStreamHelper.writeDataReference(stream, null)
    stream.writeString('RU')
    stream.writeVInt(0)
    stream.writeVInt(0)
  }
}

module.exports = AllianceHeader
