const LogicServerListener = require('../Listener/LogicServerListener')
const GlobalId = require('../Data/Helper/GlobalId')
const AllianceRole = require('../Avatar/AllianceRole')
const AllianceStream = require('../Stream/AllianceStream')
const AllianceMember = require('./AllianceMember')
const AllianceHeader = require('./AllianceHeader')
const AllianceStreamEntryMessage = require('../../Protocol/Messages/Server/AllianceStreamEntryMessage')

class Alliance {
  constructor () {
    this.id = 0
    this.name = 'Alliance'
    this.description = ''
    this.members = []
    this.allianceBadgeId = GlobalId.createGlobalId(8, 0)
    this.requiredTrophies = 0
    this.type = 1
    this.stream = new AllianceStream()
  }

  get onlinePlayers () {
    let result = 0
    for (const entry of this.members) {
      if (LogicServerListener.instance.isPlayerOnline(entry.accountId)) result++
    }
    return result
  }

  sendToAlliance (message) {
    for (const member of this.members.slice()) {
      if (LogicServerListener.instance.isPlayerOnline(member.accountId)) {
        const listener = LogicServerListener.instance.getGameListener(member.accountId)
        if (listener != null) listener.sendTCPMessage(message)
      }
    }
  }

  getRoleVector (v1, v2) {
    return (v1 === AllianceRole.Member && v2 === AllianceRole.Elder) ||
      (v1 === AllianceRole.Elder && v2 === AllianceRole.CoLeader) ||
      (v1 === AllianceRole.CoLeader && v2 === AllianceRole.Leader)
  }

  static getRoleRank (role) {
    switch (role) {
      case AllianceRole.Member: return 1
      case AllianceRole.Elder: return 2
      case AllianceRole.CoLeader: return 3
      case AllianceRole.Leader: return 4
      default: return 0
    }
  }

  getNextRoleMember () {
    const coleader = this.members.find(member => member.role === AllianceRole.CoLeader)
    if (coleader != null) return coleader

    const elder = this.members.find(member => member.role === AllianceRole.Elder)
    if (elder != null) return elder

    const member = this.members.find(member => member.role === AllianceRole.Member)
    if (member != null) return member

    return null
  }

  addStreamEntry (entry) {
    this.stream.addEntry(entry)
    this.sendAllianceStreamEntryToAll(entry)
  }

  sendChatMessage (id, message) {
    const member = this.getMemberById(id)
    if (member == null) return

    const entry = this.stream.sendChatMessage(member, message)
    this.sendAllianceStreamEntryToAll(entry)
  }

  sendAllianceStreamEntryToAll (entry) {
    const message = new AllianceStreamEntryMessage()
    message.entry = entry

    for (const member of this.members.slice()) {
      if (LogicServerListener.instance.isPlayerOnline(member.accountId)) {
        const listener = LogicServerListener.instance.getGameListener(member.accountId)
        if (listener != null) listener.sendTCPMessage(message)
      }
    }
  }

  getMemberById (id) {
    return this.members.find(member => member.accountId === id) || null
  }

  removeMemberById (id) {
    const index = this.members.findIndex(member => member.accountId === id)
    if (index !== -1) this.members.splice(index, 1)
  }

  get trophies () {
    let result = 0
    for (const member of this.members) {
      const avatar = member.avatar
      result += avatar != null ? avatar.trophies : member.trophies
    }
    return result
  }

  get header () {
    return new AllianceHeader(this.id, this.name, this.allianceBadgeId, this.members.length, this.trophies, this.requiredTrophies, this.type)
  }

  encode (stream) {
    this.header.encode(stream)
    stream.writeString(this.description)

    const members = this.members.slice()
    stream.writeVInt(members.length)
    for (const member of members) {
      member.encode(stream)
    }
  }

  toJSON () {
    return {
      id: this.id,
      name: this.name,
      desc: this.description,
      members: this.members,
      badge: this.allianceBadgeId,
      required_trophies: this.requiredTrophies,
      type: this.type,
      stream: this.stream
    }
  }

  static fromJSON (data) {
    const alliance = new Alliance()
    if (data.id != null) alliance.id = data.id
    if (data.name != null) alliance.name = data.name
    if (data.desc != null) alliance.description = data.desc
    if (Array.isArray(data.members)) alliance.members = data.members.map(member => AllianceMember.fromJSON(member))
    if (data.badge != null) alliance.allianceBadgeId = data.badge
    if (data.required_trophies != null) alliance.requiredTrophies = data.required_trophies
    if (data.type != null) alliance.type = data.type
    if (data.stream != null) alliance.stream = AllianceStream.fromJSON(data.stream)
    return alliance
  }
}

module.exports = Alliance
