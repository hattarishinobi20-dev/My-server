const readline = require('readline')
const Logger = require('../Logger')
const DataTables = require('../../Logic/Data/DataTables')
const HomeMode = require('../../Logic/Home/HomeMode')
const LogicLongCodeGenerator = require('../../Logic/Util/LogicLongCodeGenerator')
const AuthenticationFailedMessage = require('../../Protocol/Messages/Server/AuthenticationFailedMessage')
const Accounts = require('../Database/Accounts')
const Sessions = require('../Networking/Session/Sessions')

class CmdHandler {
  static rl = null
  static pendingLine = null

  static isInteractive () {
    return this.rl != null && process.stdin.isTTY === true
  }

  static onNextLine (callback) {
    this.pendingLine = callback
  }

  static start () {
    if (this.rl != null) return
    this.rl = readline.createInterface({ input: process.stdin, terminal: false })
    this.rl.on('line', line => {
      if (this.pendingLine != null) {
        const callback = this.pendingLine
        this.pendingLine = null
        callback()
        return
      }
      try {
        this.execute(line)
      } catch (e) {
        Logger.error('CmdHandler: ' + (e.stack || e))
      }
    })
    this.rl.on('close', () => {
      this.rl = null
    })
  }

  static execute (cmd) {
    if (cmd == null) return
    cmd = cmd.trim()
    if (!cmd.startsWith('/')) return
    cmd = cmd.substring(1)
    const args = cmd.split(' ').filter(arg => arg.length > 0)
    if (args.length < 1) return
    switch (args[0]) {
      case 'premium':
        this.executeGivePremiumToAccount(args)
        break
      case 'ban':
        this.executeBanAccount(args)
        break
      case 'unban':
        this.executeUnbanAccount(args)
        break
      case 'changename':
        this.executeChangeNameForAccount(args)
        break
      case 'getvalue':
        this.executeGetFieldValue(args)
        break
      case 'changevalue':
        this.executeChangeValueForAccount(args)
        break
      case 'unlockall':
        this.executeUnlockAllForAccount(args)
        break
      case 'maintenance':
        console.log('Starting maintenance...')
        this.executeShutdown()
        console.log('Maintenance started!')
        break
    }
  }

  static loadAccount (tag) {
    const id = LogicLongCodeGenerator.toId(tag).toNumber()
    if (!(id > 0)) return null
    return Accounts.load(id)
  }

  static accountUpdated (account) {
    Accounts.save(account)
    const id = account.accountId
    if (Sessions.isSessionActive(id)) {
      const session = Sessions.getSession(id)
      const message = new AuthenticationFailedMessage()
      message.message = 'Your account updated!'
      session.connection.send(message)
      Sessions.remove(id)
    }
  }

  static executeUnlockAllForAccount (args) {
    if (args.length !== 2) {
      console.log('Usage: /unlockall [TAG]')
      return
    }

    const account = this.loadAccount(args[1])
    if (account == null) {
      console.log('Fail: account not found!')
      return
    }

    const characters = DataTables.get(16)
    const cards = DataTables.get(23)
    for (let i = 0; i < HomeMode.UNLOCKABLE_HEROES_COUNT; i++) {
      if (account.avatar.hasHero(16000000 + i)) continue
      const character = characters.getDataWithId(i)
      if (character == null) continue
      const card = cards.getData(character.name + '_unlock')
      if (card == null) continue
      account.avatar.unlockHero(character.getGlobalId(), card.getGlobalId())
    }

    Logger.print(`Successfully unlocked all brawlers for account 0-${account.accountId} (${args[1]})`)

    this.accountUpdated(account)
  }

  static executeGivePremiumToAccount (args) {
    if (args.length !== 2) {
      console.log('Usage: /premium [TAG]')
      return
    }

    const account = this.loadAccount(args[1])
    if (account == null) {
      console.log('Fail: account not found!')
      return
    }

    account.avatar.isPremium = true
    this.accountUpdated(account)
  }

  static executeUnbanAccount (args) {
    if (args.length !== 2) {
      console.log('Usage: /unban [TAG]')
      return
    }

    const account = this.loadAccount(args[1])
    if (account == null) {
      console.log('Fail: account not found!')
      return
    }

    account.avatar.banned = false
    account.home.banEndTime = 0
    this.accountUpdated(account)
  }

  static executeBanAccount (args) {
    if (args.length !== 2) {
      console.log('Usage: /ban [TAG]')
      return
    }

    const account = this.loadAccount(args[1])
    if (account == null) {
      console.log('Fail: account not found!')
      return
    }

    account.avatar.banned = true
    account.avatar.resetTrophies()
    account.avatar.name = 'Brawler'
    this.accountUpdated(account)
  }

  static executeChangeNameForAccount (args) {
    if (args.length !== 3) {
      console.log('Usage: /changename [TAG] [NewName]')
      return
    }

    const account = this.loadAccount(args[1])
    if (account == null) {
      console.log('Fail: account not found!')
      return
    }

    account.avatar.name = args[2]
    this.accountUpdated(account)
  }

  static resolveField (avatar, name) {
    if (name == null || name.length === 0) return null
    for (const field of [name, name[0].toLowerCase() + name.substring(1)]) {
      if (!Object.prototype.hasOwnProperty.call(avatar, field)) continue
      const value = avatar[field]
      if (value !== null && typeof value === 'object') continue
      if (typeof value === 'function') continue
      return field
    }
    return null
  }

  static executeGetFieldValue (args) {
    if (args.length !== 3) {
      console.log('Usage: /getvalue [TAG] [FieldName]')
      return
    }

    const account = this.loadAccount(args[1])
    if (account == null) {
      console.log('Fail: account not found!')
      return
    }

    const field = this.resolveField(account.avatar, args[2])
    if (field == null) {
      console.log(`Fail: LogicClientAvatar::${args[2]} not found!`)
      return
    }

    console.log(`LogicClientAvatar::${args[2]} = ${account.avatar[field]}`)
  }

  static executeChangeValueForAccount (args) {
    if (args.length !== 4) {
      console.log('Usage: /changevalue [TAG] [FieldName] [Value]')
      return
    }

    const account = this.loadAccount(args[1])
    if (account == null) {
      console.log('Fail: account not found!')
      return
    }

    const field = this.resolveField(account.avatar, args[2])
    if (field == null) {
      console.log(`Fail: LogicClientAvatar::${args[2]} not found!`)
      return
    }

    const current = account.avatar[field]
    let value = args[3]
    if (typeof current === 'number') {
      if (!/^-?\d+$/.test(value)) {
        console.log(`Fail: LogicClientAvatar::${args[2]} is a number!`)
        return
      }
      value = parseInt(value, 10)
    } else if (typeof current === 'boolean') {
      if (value !== 'true' && value !== 'false') {
        console.log(`Fail: LogicClientAvatar::${args[2]} is a boolean!`)
        return
      }
      value = value === 'true'
    }

    account.avatar[field] = value
    this.accountUpdated(account)
  }

  static executeShutdown () {
    const ExitHandler = require('./ExitHandler')
    ExitHandler.shutdown()
  }
}

module.exports = CmdHandler
