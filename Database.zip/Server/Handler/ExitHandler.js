const Logger = require('../Logger')
const Accounts = require('../Database/Accounts')
const Alliances = require('../Database/Alliances')
const AccountCache = require('../Database/Cache/AccountCache')
const AllianceCache = require('../Database/Cache/AllianceCache')
const Sessions = require('../Networking/Session/Sessions')

class ExitHandler {
  static exiting = false
  static waitingForKey = false

  static saveAll () {
    for (const id of Array.from(Sessions.activeSessions.keys())) {
      Accounts.save(Accounts.load(id))
    }
    AccountCache.saveAll()
    AllianceCache.saveAll()
    Accounts.flush()
    Alliances.flush()
  }

  static shutdown () {
    Sessions.startShutdown()
    this.saveAll()

    AccountCache.started = false
    AllianceCache.started = false
  }

  static finish () {
    try {
      const Events = require('../Logic/Game/Events')
      Events.stop()
      this.saveAll()
    } catch (e) {
      Logger.error('Failed to save databases on exit: ' + (e.stack || e))
    }
    process.exit(0)
  }

  static exit (interactive) {
    if (this.waitingForKey) {
      this.finish()
      return
    }
    if (this.exiting) return
    this.exiting = true

    try {
      this.shutdown()
      Logger.print('Shutting down...')
    } catch (e) {
      Logger.error('Failed to save databases on exit: ' + (e.stack || e))
    }

    const CmdHandler = require('./CmdHandler')
    if (!interactive || !CmdHandler.isInteractive()) {
      this.finish()
      return
    }

    this.waitingForKey = true
    console.log('Server is now in maintenance mode, press any key to shutdown')
    CmdHandler.onNextLine(() => this.finish())
  }

  static init () {
    process.on('SIGINT', () => this.exit(true))
    process.on('SIGTERM', () => this.exit(false))
    process.on('SIGHUP', () => this.exit(false))
    if (process.platform === 'win32') process.on('SIGBREAK', () => this.exit(false))
  }
}

module.exports = ExitHandler
