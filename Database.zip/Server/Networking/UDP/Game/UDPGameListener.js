const LogicGameListener = require('../../../../Logic/Listener/LogicGameListener')

class UDPGameListener extends LogicGameListener {
  constructor (socket, connection) {
    super()
    this.socket = socket
    this.tcpConnection = connection
  }

  sendMessage (message) {
    this.socket.sendMessage(message)
  }

  sendTCPMessage (message) {
    try {
      this.tcpConnection.send(message)
    } catch (e) { }
  }
}

module.exports = UDPGameListener
