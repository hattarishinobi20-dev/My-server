const dgram = require('dgram')
const ByteStream = require('../../../Titan/DataStream/ByteStream')
const Logger = require('../../Logger')

class UDPGateway {
  static socket = null
  static sessionCounter = 0
  static sockets = new Map()
  static messageFactory = null

  static init (host, port) {
    const MessageFactory = require('../../../Protocol/MessageFactory')

    this.sockets = new Map()
    this.messageFactory = new MessageFactory()

    this.socket = dgram.createSocket('udp4')
    this.socket.on('message', (buffer, remote) => this.receive(buffer, remote))
    this.socket.on('error', (e) => Logger.error(`UDP: ${e.message}`))
    this.socket.bind(port, host, () => {
      Logger.print(`UDP Server started at ${host}:${port}`)
    })
  }

  static receive (buffer, remoteEndPoint) {
    if (buffer.length < 10) return

    try {
      const UDPGameListener = require('./Game/UDPGameListener')

      const stream = new ByteStream(buffer, buffer.length)
      const sessionId = stream.readLong().toNumber()
      stream.readShort()

      const client = this.sockets.get(sessionId)
      if (client == null) return

      if (!client.isConnected) {
        client.setEndPoint(remoteEndPoint)

        if (client.battle == null) return

        if (!client.isSpectator) {
          const player = client.battle.getPlayerBySessionId(client.sessionId)
          if (player != null) {
            player.gameListener = new UDPGameListener(client, client.tcpConnection)
          }
        }
      }

      client.processReceive(stream)
    } catch (e) {
      Logger.error(`UDP EXCEPTION: ${e.message}`)
    }
  }

  static createSocket () {
    const UDPSocket = require('./UDPSocket')
    const socket = new UDPSocket(++this.sessionCounter)
    this.sockets.set(socket.sessionId, socket)
    return socket
  }

  static removeSocket (sessionId) {
    this.sockets.delete(sessionId)
  }

  static sendTo (data, startIndex, count, remoteEndPoint) {
    if (remoteEndPoint == null || this.socket == null) return
    try {
      this.socket.send(data, startIndex, count, remoteEndPoint.port, remoteEndPoint.address)
    } catch (e) { }
  }
}

module.exports = UDPGateway
