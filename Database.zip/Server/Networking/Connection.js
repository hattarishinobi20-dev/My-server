const Messaging = require('./Messaging')
const MessageManager = require('../Message/MessageManager')

class Connection {
  constructor (socket) {
    this.socket = socket
    this.ping = 0
    this.isOpen = true
    this.matchmakeSlot = -1
    this.matchmakingEntry = null
    this.udpSessionId = -1
    this.messaging = new Messaging(this)
    this.messageManager = new MessageManager(this)
  }

  get home () {
    if (this.messageManager.homeMode != null) {
      return this.messageManager.homeMode.home
    }
    return null
  }

  get avatar () {
    if (this.messageManager.homeMode != null) {
      return this.messageManager.homeMode.avatar
    }
    return null
  }

  get remoteEndPoint () {
    const address = String(this.socket.remoteAddress || '').replace(/^::ffff:/, '')
    return `${address}:${this.socket.remotePort}`
  }

  pingUpdated (value) {
    this.ping = value
  }

  send (message) {
    this.messaging.send(message)
  }

  close () {
    this.isOpen = false
    try {
      this.socket.destroy()
    } catch (e) { }
  }

  write (stream) {
    if (!this.isOpen || this.socket.destroyed || !this.socket.writable) return
    try {
      this.socket.write(stream)
    } catch (e) { }
  }

  onDisconnect () {
    const Connections = require('./Connections')
    const Sessions = require('./Session/Sessions')

    Connections.removeConnection(this)
    if (this.messageManager.homeMode != null) {
      Sessions.remove(this.avatar.accountId, this)
    }
    this.close()
  }
}

module.exports = Connection
