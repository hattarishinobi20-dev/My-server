const fs = require('fs')
const Debugger = require('../Titan/Debug/Debugger')

const CYAN = '\x1b[36m'
const RESET = '\x1b[0m'

class DebuggerListener {
  error (message) {
    console.log(`${CYAN}[LOGIC] Error: ${message}${RESET}`)
  }

  print (message) {
    console.log(`${CYAN}[LOGIC] Info: ${message}${RESET}`)
  }

  warning (message) {
    console.log(`${CYAN}[LOGIC] Warning: ${message}${RESET}`)
  }
}

class Logger {
  static init () {
    Debugger.setListener(new DebuggerListener())
  }

  static print (log) {
    console.log(`${CYAN}[DEBUG] ${log}${RESET}`)
  }

  static warning (log) {
    console.log(`${CYAN}[WARNING] ${log}${RESET}`)
  }

  static error (log) {
    console.log(`${CYAN}[ERROR] ${log}${RESET}`)
  }

  static timestamp () {
    return new Date().toLocaleString()
  }

  static appendFile (file, line) {
    try {
      fs.appendFileSync(file, line + '\n')
    } catch (e) {
      Logger.error(`Failed to write ${file}: ${e.message}`)
    }
  }

  static log (log) {
    Logger.appendFile('./log.txt', `[${Logger.timestamp()}][WARN!!] ${log}`)
  }

  static bLog (log) {
    Logger.appendFile('./battles.txt', `[${Logger.timestamp()}] ${log}`)
  }

  static handleReport (log) {
    Logger.appendFile('./chatreports.txt', `[${Logger.timestamp()}] ${log}`)
  }
}

module.exports = Logger
