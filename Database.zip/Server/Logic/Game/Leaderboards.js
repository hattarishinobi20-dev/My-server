const Accounts = require('../../Database/Accounts')
const Alliances = require('../../Database/Alliances')

class Leaderboards {
  static REFRESH_MS = 10 * 1000

  static accounts = []
  static alliances = []
  static brawlers = new Map()
  static lastUpdate = 0

  static init () {
    this.accounts = []
    this.alliances = []
    this.brawlers = new Map()
    this.lastUpdate = 0
  }

  static getAvatarRankingList () {
    this.update()
    return this.accounts.slice()
  }

  static getBrawlersRankingList () {
    this.update()
    return this.brawlers
  }

  static getAllianceRankingList () {
    this.update()
    return this.alliances.slice()
  }

  static update () {
    if (Date.now() - this.lastUpdate < this.REFRESH_MS) return
    this.accounts = Accounts.getRankingList()
    this.alliances = Alliances.getRankingList()
    this.brawlers = Accounts.getBrawlersRankingList()
    this.lastUpdate = Date.now()
  }
}

module.exports = Leaderboards
