const DataTables = require('../../../Logic/Data/DataTables')
const DataType = require('../../../Logic/Data/DataType')
const GameModeUtil = require('../../../Logic/Util/GameModeUtil')
const GamePlayUtil = require('../../../Logic/Util/GamePlayUtil')
const BattlePlayer = require('../../../Logic/Battle/Structures/BattlePlayer')
const MatchMakingStatusMessage = require('../../../Protocol/Messages/Server/MatchMakingStatusMessage')
const MatchMakingCancelledMessage = require('../../../Protocol/Messages/Server/MatchMakingCancelledMessage')
const StartLoadingMessage = require('../../../Protocol/Messages/Server/StartLoadingMessage')
const Sessions = require('../../Networking/Session/Sessions')
const Events = require('./Events')
const Battles = require('./Battles')
const Logger = require('../../Logger')

function getEventGameModeVariation (e) {
  if (e.battlePlayerMap != null) return e.battlePlayerMap.gmv
  const location = e.location
  if (location != null) return GameModeUtil.getGameModeVariation(location.gameMode)
  return null
}

function loadBattleMode () {
  try {
    return require('../../../Logic/Battle/BattleMode')
  } catch (e) {
    return null
  }
}

class MatchmakingEntry {
  constructor (connection) {
    this.connection = connection
    this.player = null
    this.playerTeamId = -1
    this.prefferedTeam = -1
  }
}

class MatchmakingSlot {
  static SEARCH_TIMEOUT = 7
  static botBrawlers = null

  constructor (eventData, playersRequired) {
    this.playersRequired = playersRequired
    this.eventData = eventData
    this.queue = []
    this.requestQueue = []
    this.removeQueue = []
    this.secondsLeft = MatchmakingSlot.SEARCH_TIMEOUT
    this.turns = 0
    this.lastStartSucceeded = false
  }

  get isRanked () {
    const slot = this.eventData.slot
    return slot === 14 || slot === 15 || slot === 16
  }

  updateEventData (eventData, playersRequired) {
    this.eventData = eventData
    this.playersRequired = playersRequired
  }

  update () {
    if (Sessions.maintenance) return

    if (this.isRanked) {
      const gameModeVariation = getEventGameModeVariation(this.eventData) || 0
      if (Matchmaking.isBannedRankedMode(gameModeVariation)) return
      this.playersRequired = GamePlayUtil.getPlayerCountWithGameModeVariation(gameModeVariation)
    }

    for (const entry of this.queue) {
      if (!entry.connection.isOpen) this.remove(entry)
    }

    while (this.removeQueue.length > 0) {
      const removedEntry = this.removeQueue.shift()
      const index = this.queue.indexOf(removedEntry)
      if (index !== -1) this.queue.splice(index, 1)
    }

    while (this.requestQueue.length > 0) {
      const entry = this.requestQueue.shift()
      if (this.queue.some(x => x.connection === entry.connection)) continue
      this.queue.push(entry)
    }

    if (this.queue.length === 0) {
      this.turns = 0
      this.secondsLeft = MatchmakingSlot.SEARCH_TIMEOUT
      return
    }

    if (!(this.playersRequired > 0)) return

    while (this.queue.length >= this.playersRequired) {
      const batch = this.queue.slice(0, this.playersRequired)
      this.queue.splice(0, batch.length)
      this.tryStartGame(batch)
    }

    if (this.queue.length > 0 && this.queue.length < this.playersRequired && this.secondsLeft <= 0) {
      this.secondsLeft = MatchmakingSlot.SEARCH_TIMEOUT
      const batch = this.queue.slice()
      this.queue = []
      this.tryStartGame(batch)
    }

    if (this.queue.length > 0) {
      this.turns++
      if (this.turns >= 4) {
        this.turns = 0
        this.secondsLeft--
      }
    } else {
      this.turns = 0
      this.secondsLeft = MatchmakingSlot.SEARCH_TIMEOUT
    }

    if (this.queue.length > 0) {
      for (const entry of this.queue) {
        const message = new MatchMakingStatusMessage()
        message.seconds = this.secondsLeft
        message.found = this.queue.length
        message.max = this.playersRequired
        message.showTips = true
        entry.connection.send(message)
      }
    }
  }

  remove (entry) {
    if (entry != null) this.removeQueue.push(entry)
  }

  add (entry) {
    this.requestQueue.push(entry)
  }

  static getBotBrawlers () {
    if (MatchmakingSlot.botBrawlers == null) {
      const table = DataTables.get(DataType.Character)
      const ids = []
      for (let i = 0; i < table.getCount(); i++) {
        const cd = table.getDataWithId(i)
        if (cd == null) continue
        if (cd.type !== 'Hero') continue
        ids.push(i)
      }
      MatchmakingSlot.botBrawlers = ids
    }
    return MatchmakingSlot.botBrawlers
  }

  static randomBotCharacter () {
    const brawlers = MatchmakingSlot.getBotBrawlers()
    return 16000000 + brawlers[Math.floor(Math.random() * brawlers.length)]
  }

  tryStartGame (entries) {
    this.lastStartSucceeded = false
    try {
      this.startGame(entries)
    } catch (e) {
      this.lastStartSucceeded = false
      Logger.error(`Matchmaking battle start failed: ${e.message}`)
    }
    const pendingBattle = this.pendingBattle
    this.pendingBattle = null
    if (!this.lastStartSucceeded) {
      if (pendingBattle != null) this.abortBattle(pendingBattle, entries)
      for (const entry of entries) {
        if (entry != null && entry.connection != null && entry.connection.isOpen) {
          entry.connection.matchmakeSlot = -1
          entry.connection.send(new MatchMakingCancelledMessage())
        }
      }
    }
    return this.lastStartSucceeded
  }

  abortBattle (battle, entries) {
    battle.isGameOver = true
    if (typeof battle.disposeTimer === 'function') battle.disposeTimer()
    const UDPGateway = require('../../Networking/UDP/UDPGateway')
    for (const entry of entries) {
      if (entry == null || entry.connection == null) continue
      if (entry.connection.avatar != null && entry.connection.avatar.battleId === battle.id) entry.connection.avatar.battleId = 0
      if (entry.connection.udpSessionId > 0) {
        UDPGateway.removeSocket(entry.connection.udpSessionId)
        entry.connection.udpSessionId = -1
      }
    }
  }

  startRankedMatch (entries) {
    Logger.warning(`Ranked matchmaking is not available (slot ${this.eventData.slot})`)
  }

  createBot (battle, index, teamIndex, botCharacter) {
    const data = DataTables.get(DataType.Character).getDataByGlobalId(botCharacter)
    const name = data != null && data.itemName != null ? String(data.itemName).toUpperCase() : null
    const bot = BattlePlayer.createBotInfo(name, index, teamIndex, botCharacter)
    battle.addPlayer(bot, -1)
  }

  addConnectionPlayer (battle, entry, index, teamIndex) {
    const UDPGateway = require('../../Networking/UDP/UDPGateway')
    const socket = UDPGateway.createSocket()
    socket.tcpConnection = entry.connection
    socket.battle = battle
    entry.connection.udpSessionId = socket.sessionId

    const player = BattlePlayer.create(entry.connection.home, entry.connection.avatar, index, teamIndex, null, -1, battle.getGameModeVariation() === 13)
    player.teamId = entry.playerTeamId
    entry.player = player
    battle.addPlayer(player, entry.connection.udpSessionId)
  }

  startGame (entries) {
    this.lastStartSucceeded = false

    if (this.isRanked) {
      this.startRankedMatch(entries)
      return
    }

    const BattleMode = loadBattleMode()
    if (BattleMode == null) return

    entries = entries.filter(entry => entry.connection.isOpen && entry.connection.home != null && entry.connection.avatar != null)
    if (entries.length === 0) return

    let battle
    if (this.eventData.battlePlayerMap != null) {
      battle = new BattleMode(this.eventData.battlePlayerMap)
      battle.setPlayerMap(this.eventData.battlePlayerMap)
    } else {
      battle = new BattleMode(this.eventData.locationId)
      if (battle.location == null) {
        Logger.warning(`Matchmaking: location is null for ${this.eventData.locationId}, slot ${this.eventData.slot}`)
        return
      }
    }
    battle.id = Battles.add(battle)
    this.pendingBattle = battle

    let sortedEntries = []
    const gameModeVariation = battle.getGameModeVariation()

    if (GameModeUtil.hasTwoTeams(gameModeVariation)) {
      const teamEntries = new Map()
      for (const entry of entries.filter(e => e.playerTeamId > 0)) {
        if (!teamEntries.has(entry.playerTeamId)) teamEntries.set(entry.playerTeamId, [])
        teamEntries.get(entry.playerTeamId).push(entry)
      }

      let teamNumber = 0
      for (const teamedEntries of teamEntries.values()) {
        for (const entry of teamedEntries) {
          entry.prefferedTeam = teamNumber
          sortedEntries.push(entry)
        }
        teamNumber++
      }
      for (const entry of entries.filter(e => !(e.playerTeamId > 0))) {
        sortedEntries.push(entry)
      }

      for (let i = 0; i < sortedEntries.length; i++) {
        let teamIndex = i % 2
        if (sortedEntries[i].prefferedTeam !== -1) {
          teamIndex = sortedEntries[i].prefferedTeam % 2
        }
        if (battle.getTeamPlayersCount(teamIndex) >= 3) {
          teamIndex = teamIndex === 1 ? 0 : 1
        }
        this.addConnectionPlayer(battle, sortedEntries[i], i, teamIndex)
      }

      const team1BotsCharacters = []
      const team2BotsCharacters = []

      for (let i = sortedEntries.length; i < battle.getPlayersCountWithGameModeVariation(); i++) {
        let teamIndex = i % 2
        if (battle.getTeamPlayersCount(teamIndex) >= 3) {
          teamIndex = teamIndex === 1 ? 0 : 1
        }

        const used = teamIndex === 0 ? team1BotsCharacters : team2BotsCharacters
        let botCharacter = MatchmakingSlot.randomBotCharacter()
        for (let attempt = 0; attempt < 50 && used.includes(botCharacter); attempt++) {
          botCharacter = MatchmakingSlot.randomBotCharacter()
        }
        used.push(botCharacter)

        this.createBot(battle, i, teamIndex, botCharacter)
      }
    } else {
      if (gameModeVariation === 9) {
        const grouped = new Map()
        for (const entry of entries.filter(e => e.playerTeamId > 0)) {
          if (!grouped.has(entry.playerTeamId)) grouped.set(entry.playerTeamId, [])
          grouped.get(entry.playerTeamId).push(entry)
        }
        for (const group of grouped.values()) sortedEntries.push(...group)
        sortedEntries.push(...entries.filter(e => !(e.playerTeamId > 0)))
      } else {
        sortedEntries = entries
      }

      for (let i = 0; i < sortedEntries.length; i++) {
        const teamIndex = gameModeVariation === 9 ? Math.floor(i / 2) : i
        this.addConnectionPlayer(battle, sortedEntries[i], i, teamIndex)
      }

      for (let i = sortedEntries.length; i < battle.getPlayersCountWithGameModeVariation(); i++) {
        const teamIndex = gameModeVariation === 9 ? Math.floor(i / 2) : i
        this.createBot(battle, i, teamIndex, MatchmakingSlot.randomBotCharacter())
      }
    }

    battle.addGameObjects()

    for (const entry of sortedEntries) {
      const startLoading = new StartLoadingMessage()
      startLoading.locationId = battle.location.getGlobalId()
      startLoading.teamIndex = entry.player.teamIndex
      startLoading.ownIndex = entry.player.playerIndex
      startLoading.gameMode = gameModeVariation === 6 ? 6 : gameModeVariation === 9 ? 9 : 1

      const avatar = entry.connection.avatar
      avatar.udpSessionId = entry.connection.udpSessionId
      avatar.battleId = battle.id
      avatar.teamIndex = entry.player.teamIndex
      avatar.ownIndex = entry.player.playerIndex
      startLoading.players.push(...battle.getPlayers())
      entry.connection.matchmakeSlot = -1
      entry.connection.send(startLoading)
      battle.battleWithTrophies = true
    }

    battle.start()
    this.lastStartSucceeded = true
  }
}

class Matchmaking {
  static slots = new Map()
  static timer = null

  static updateSlot (e) {
    if (e == null) return
    const mode = getEventGameModeVariation(e)
    if (mode == null) return
    const playersRequired = GamePlayUtil.getPlayerCountWithGameModeVariation(mode)
    const existing = this.slots.get(e.slot)
    if (existing != null) {
      existing.updateEventData(e, playersRequired)
    } else {
      this.slots.set(e.slot, new MatchmakingSlot(e, playersRequired))
    }
  }

  static init () {
    this.slots = new Map()

    for (const e of Events.getEvents()) {
      this.updateSlot(e)
    }

    if (this.timer != null) clearInterval(this.timer)
    this.timer = setInterval(() => this.update(), 250)
  }

  static update () {
    try {
      for (const e of Events.getEvents()) {
        this.updateSlot(e)
      }
    } catch (e) {
      Logger.error(`Matchmaking slots refresh failed: ${e.message}`)
    }

    for (const slot of this.slots.values()) {
      try {
        slot.update()
      } catch (e) {
        Logger.error(`Matchmaking slot update failed: ${e.message}`)
      }
    }
  }

  static isBannedRankedMode (gameModeVariation) {
    return gameModeVariation === 300
  }

  static requestMatchmake (connection, slot, team = -1) {
    const matchmakingSlot = this.slots.get(slot)
    if (matchmakingSlot == null) return

    if (connection.matchmakeSlot !== -1 && connection.matchmakeSlot !== slot) {
      const previous = this.slots.get(connection.matchmakeSlot)
      if (previous != null) previous.remove(connection.matchmakingEntry)
    }

    connection.matchmakeSlot = slot
    const entry = new MatchmakingEntry(connection)
    entry.playerTeamId = team
    connection.matchmakingEntry = entry
    matchmakingSlot.add(entry)
  }

  static cancelMatchmake (connection) {
    const Teams = require('./Teams')

    const matchmakingSlot = this.slots.get(connection.matchmakeSlot)
    if (matchmakingSlot == null) return

    connection.matchmakeSlot = -1
    const entry = connection.matchmakingEntry
    if (entry == null) return
    matchmakingSlot.remove(entry)

    if (entry.playerTeamId > 0) {
      const team = Teams.get(entry.playerTeamId)
      entry.playerTeamId = -1
      if (team == null) return

      for (const member of team.members.slice()) {
        member.isReady = false
        const session = Sessions.getSession(member.accountId)
        if (session == null || session.connection === connection) continue
        if (session.connection.matchmakingEntry != null) {
          session.connection.matchmakingEntry.playerTeamId = -1
        }
        this.cancelMatchmake(session.connection)
        session.connection.send(new MatchMakingCancelledMessage())
      }

      team.teamUpdated()
    }
  }
}

Matchmaking.MatchmakingSlot = MatchmakingSlot
Matchmaking.MatchmakingEntry = MatchmakingEntry

module.exports = Matchmaking
