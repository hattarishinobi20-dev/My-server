const fs = require('fs')
const path = require('path')
const Logger = require('../Logger')

class JsonTable {
  constructor (file) {
    this.file = file
    this.rows = new Map()
    this.flushTimer = null
  }

  load () {
    this.rows = new Map()

    fs.mkdirSync(path.dirname(this.file), { recursive: true })

    if (!fs.existsSync(this.file)) return

    const text = fs.readFileSync(this.file, 'utf8').replace(/^\uFEFF/, '')
    if (text.trim().length === 0) return

    const rows = JSON.parse(text)
    for (const row of rows) {
      this.rows.set(row.Id, row)
    }
  }

  getMaxId () {
    let result = 0
    for (const id of this.rows.keys()) {
      if (id > result) result = id
    }
    return result
  }

  getIds () {
    return Array.from(this.rows.keys())
  }

  select (id) {
    return this.rows.get(id) || null
  }

  selectAll () {
    return Array.from(this.rows.values())
  }

  insert (row) {
    if (this.rows.has(row.Id)) {
      throw new Error(`JsonTable: duplicate entry ${row.Id} in ${path.basename(this.file)}`)
    }
    this.rows.set(row.Id, row)
    this.scheduleFlush()
  }

  update (id, values) {
    const row = this.rows.get(id)
    if (row == null) return false
    Object.assign(row, values)
    this.scheduleFlush()
    return true
  }

  delete (id) {
    if (this.rows.delete(id)) this.scheduleFlush()
  }

  scheduleFlush () {
    if (this.flushTimer != null) return
    this.flushTimer = setTimeout(() => {
      this.flushTimer = null
      this.flush()
    }, 1000)
  }

  flush () {
    if (this.flushTimer != null) {
      clearTimeout(this.flushTimer)
      this.flushTimer = null
    }

    const temp = `${this.file}.tmp`
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true })
      fs.writeFileSync(temp, JSON.stringify(Array.from(this.rows.values())))
      fs.renameSync(temp, this.file)
    } catch (e) {
      Logger.error(`Failed to write ${this.file}: ${e.stack || e}`)
    }
  }
}

module.exports = JsonTable
