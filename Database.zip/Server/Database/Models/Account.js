const ClientAvatar = require('../../../Logic/Avatar/ClientAvatar')
const ClientHome = require('../../../Logic/Home/ClientHome')

class Account {
  constructor () {
    this.accountId = 0
    this.passToken = null

    this.home = new ClientHome()
    this.avatar = new ClientAvatar()
  }

  toJSON () {
    return {
      accountId: this.accountId,
      passToken: this.passToken,
      home: this.home,
      avatar: this.avatar
    }
  }

  static fromJSON (data) {
    const account = new Account()

    if (data.accountId != null) account.accountId = data.accountId
    if (data.passToken != null) account.passToken = data.passToken
    if (data.home != null) account.home = ClientHome.fromJSON(data.home)
    if (data.avatar != null) account.avatar = ClientAvatar.fromJSON(data.avatar)

    return account
  }
}

module.exports = Account
