const fs = require('fs')

class Configuration {
  static instance = null

  constructor (data = {}) {
    this.udpHost = data.udp_host != null ? String(data.udp_host) : ''
    this.udpPort = Number.isInteger(data.udp_port) ? data.udp_port : 9339
    this.databaseName = data.database_name != null && String(data.database_name).length > 0 ? String(data.database_name) : 'database'
    this.apiAuthPass = data.api_auth_pass != null ? String(data.api_auth_pass) : ''
  }

  static loadFromFile (filename) {
    const text = fs.readFileSync(filename, 'utf8').replace(/^\uFEFF/, '')
    return new Configuration(JSON.parse(text))
  }
}

module.exports = Configuration
