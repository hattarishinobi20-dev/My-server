const fs = require('fs')
const path = require('path')
const LogicJSONParser = require('../../Titan/Json/LogicJSONParser')
const Logger = require('../Logger')

class Fingerprint {
  static sha = null
  static fullDump = null
  static version = null

  static load () {
    const json = fs.readFileSync(path.join(__dirname, '../../Assets/fingerprint.json'), 'utf8').replace(/^\uFEFF/, '')

    const jsonObject = LogicJSONParser.parseObject(json)

    if (jsonObject == null) {
      throw new Error('fingerprint.json is invalid')
    }

    const sha = jsonObject.getJSONString('sha')
    const version = jsonObject.getJSONString('version')

    Fingerprint.sha = sha != null ? sha.getStringValue() : null
    Fingerprint.version = version != null ? version.getStringValue() : null
    Fingerprint.fullDump = json

    Logger.print(`Loaded fingerprint.json v${Fingerprint.version}`)
  }
}

module.exports = Fingerprint
