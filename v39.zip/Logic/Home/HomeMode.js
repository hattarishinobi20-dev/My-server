const GlobalId = require('../Data/Helper/GlobalId')
const DataTables = require('../Data/DataTables')
const DataType = require('../Data/DataType')
const GatchaDrop = require('./Gatcha/GatchaDrop')

const GATCHA_BRAWLERS = Object.freeze([4, 5, 6, 10, 11, 12, 13, 15, 16, 17, 18, 19, 20, 21, 23, 24, 25, 26, 28, 29, 31, 32, 34, 35, 36, 37])
const RANDOM_BRAWLERS = Object.freeze([4, 5, 6, 10, 11, 12, 13, 15, 16, 17, 18, 19, 20, 21, 23, 24, 25, 26, 28, 29, 31, 32, 34, 36, 37, 38])

const DIAMONDS_REWARD = Object.freeze([3, 5, 7, 12])

const BOX_SETTINGS = Object.freeze({
  10: { name: 'box', doublers: [200], tickets: [1, 2, 3], bonusChances: [6, 4, 2], characterChance: 5, starpowerChance: 11, bonusChance: 10, pp: [25, 75, 5, 45, 2] },
  12: { name: 'big', doublers: [200, 400], tickets: [1, 2, 3, 5], bonusChances: [6, 4, 2], characterChance: 10, starpowerChance: 22, bonusChance: 20, coins: [50, 200], pp: [15, 125, 3] },
  11: { name: 'mega', doublers: [200, 400, 600], tickets: [1, 2, 3, 5], bonusChances: [7, 5, 3], characterChance: 15, starpowerChance: 33, bonusChance: 30, coins: [175, 750], pp: [25, 250, 5] }
})

function nextInt (min, max) {
  if (max <= min) return min
  return min + Math.floor(Math.random() * (max - min))
}

class HomeMode {
  static UNLOCKABLE_HEROES_COUNT = 38

  static getGadgetCards (characterData) {
    if (characterData == null) return []
    return DataTables.get(DataType.Card).getDatas()
      .filter(card => card != null && card.metaType === 5 && card.target === characterData.name)
  }

  constructor (home, avatar, gameListener) {
    this.home = home
    this.avatar = avatar

    this.home.homeMode = this
    this.avatar.homeMode = this

    this.gameListener = gameListener
    this.characterChanged = []
  }

  static loadHomeState (gameListener, home, avatar, events) {
    home.events = events

    const homeMode = new HomeMode(home, avatar, gameListener)
    homeMode.enter(Date.now())

    return homeMode
  }

  onCharacterChanged (characterId) {
    for (const handler of this.characterChanged.slice()) {
      handler(characterId)
    }
  }

  getRandomBrawlerForGatcha (unit) {
    const unlockedBrawlers = this.avatar.heroes.map(hero => GlobalId.getInstanceId(hero.characterId))
    const unlockableBrawlers = RANDOM_BRAWLERS.filter(x => !unlockedBrawlers.includes(x))
    if (unlockableBrawlers.length === 0) return false

    const brawler = GlobalId.createGlobalId(16, unlockableBrawlers[nextInt(0, unlockableBrawlers.length)])
    const character = DataTables.get(DataType.Character).getDataByGlobalId(brawler)
    if (character == null) return false

    const drop = new GatchaDrop(1)
    drop.dataGlobalId = character.getGlobalId()
    drop.count = 1
    unit.addDrop(drop)
    return true
  }

  procChance (chance, type, forcedDrops) {
    const v1 = Math.floor(nextInt(0, 1000) / 10)
    switch (type) {
      case 'bonus':
        chance += forcedDrops * 2
        break
      case 'starpower':
        chance += forcedDrops * 1.25
        break
      case 'character':
        chance += forcedDrops * 0.5
        break
    }
    return v1 < chance
  }

  getMultByRarity (rarity) {
    switch (rarity) {
      case 'bonus': return 0.5
      case 'character': return 2
      case 'card_notchar': return 4
      case 'rare': return 2
      case 'super_rare': return 3
      case 'epic': return 5
      case 'super_epic': return 7
      case 'legendary': return 10
    }
    return 0
  }

  calcForcedDrop (proc, rarity, type, forcedDrops, box) {
    let v1 = 0
    let v2 = 0
    let v3 = 0
    let v4 = 0
    let v5 = 0
    let v6 = 0
    const v7 = this.getMultByRarity(rarity)
    let v8 = forcedDrops

    switch (box) {
      case 'mega':
        v1 = 0.66
        v2 = 0.33
        v3 = 0.125
        v4 = v5 = v6 = 0.66 * v7
        break
      case 'big':
        v1 = 0.33
        v2 = 0.125
        v3 = 0.065
        v4 = v5 = v6 = 0.55 * v7
        break
      case 'box':
        v1 = 0.22
        v2 = 0.10
        v3 = 0.045
        v4 = v5 = v6 = 0.44 * v7
        break
    }

    if (!proc) {
      switch (type) {
        case 'bonus':
          v8 += v3
          break
        case 'character':
          v8 += v1
          break
        case 'starpower':
          v8 += v2
          break
      }
    } else {
      switch (type) {
        case 'bonus':
          v8 = Math.max(0, v8 - v6)
          break
        case 'character':
          v8 = Math.max(0, v8 - v4)
          break
        case 'starpower':
          v8 = Math.max(0, v8 - v5)
          break
      }
    }

    return v8 > 10 ? 10 : v8
  }

  getUnlockableBrawlers () {
    const unlockedBrawlers = this.avatar.heroes.map(hero => GlobalId.getInstanceId(hero.characterId))
    return {
      unlocked: unlockedBrawlers,
      unlockable: GATCHA_BRAWLERS.filter(x => !unlockedBrawlers.includes(x))
    }
  }

  getBonusChance (unlockedCount, chances) {
    if (unlockedCount < 3) return chances[0]
    if (unlockedCount < 5) return chances[1]
    if (unlockedCount < 7) return chances[2]
    return 0
  }

  canDropStarpower () {
    return this.avatar.heroes.some(hero => hero.powerLevel >= 6)
  }

  collectStarpowerCandidates () {
    const cards = DataTables.get(DataType.Card)
    const sps = []
    const add = (id) => {
      if (!sps.includes(id)) sps.push(id)
    }

    for (const hero of this.avatar.heroes) {
      const cd = DataTables.get(DataType.Character).getDataByGlobalId(hero.characterId)
      if (cd == null) continue

      if (hero.powerLevel === 8) {
        let card3 = cards.getData(cd.name + '_unique_3')
        if (card3 != null && card3.lockedForChronos) card3 = null

        const candidates = [cards.getData(cd.name + '_unique'), cards.getData(cd.name + '_unique_2'), card3]
          .filter(card => card != null)
          .map(card => card.getGlobalId())
          .filter(id => !this.avatar.starpowers.includes(id))

        if (candidates.length > 0) {
          add(candidates[nextInt(0, candidates.length)])
        }
      }

      if (hero.powerLevel > 5) {
        for (const wildCard of HomeMode.getGadgetCards(cd)) {
          if (!this.avatar.starpowers.includes(wildCard.getGlobalId())) {
            add(wildCard.getGlobalId())
          }
        }
      }
    }

    return sps
  }

  dropStarpower (unit, sps, box) {
    const index = nextInt(0, sps.length)
    const sp = sps[index]
    sps.splice(index, 1)

    const drop = new GatchaDrop(4)
    drop.cardGlobalId = sp
    drop.count = 1
    unit.addDrop(drop)

    const card = DataTables.get(DataType.Card).getDataByGlobalId(sp)
    if (card != null) {
      const heroData = DataTables.get(DataType.Character).getData(card.name.split('_')[0])
      if (heroData != null) {
        const h = this.avatar.getHero(heroData.getGlobalId())
        if (h != null) h.hasStarpower = true
      }
    }

    this.avatar.forcedDrops = this.calcForcedDrop(true, 'card_notchar', 'starpower', this.avatar.forcedDrops, box)
  }

  dropCharacter (unit, unlockable, box) {
    const index = nextInt(0, unlockable.length)
    const brawler = GlobalId.createGlobalId(16, unlockable[index])
    unlockable.splice(index, 1)

    const character = DataTables.get(DataType.Character).getDataByGlobalId(brawler)
    if (character == null) return

    let card = DataTables.get(DataType.Card).getData(character.name + '_unlock')
    if (card == null && character.name === 'Duplicator') card = DataTables.get(DataType.Card).getDataByGlobalId(23000427)

    const drop = new GatchaDrop(1)
    drop.dataGlobalId = character.getGlobalId()
    drop.count = 1
    unit.addDrop(drop)

    this.avatar.forcedDrops = this.calcForcedDrop(true, card != null ? card.rarity : 'character', 'starpower', this.avatar.forcedDrops, box)
  }

  addPowerPoints (unit, maxHeroes, min, max) {
    const canHavePowerPoints = this.avatar.heroes.filter(hero => hero.powerLevel !== 8 && hero.powerPoints < 1410)
    const count = canHavePowerPoints.length
    const avards = []

    for (let x = 0; Math.min(count, maxHeroes) > x; x++) {
      const index = nextInt(0, canHavePowerPoints.length)
      const brawler = canHavePowerPoints[index]
      canHavePowerPoints.splice(index, 1)

      const oldpp = brawler.powerPoints
      let powerPoints = nextInt(min, max)
      if (oldpp + powerPoints > 1410) {
        powerPoints = 1410 - oldpp
      }
      avards.push({ characterId: brawler.characterId, count: powerPoints })
    }

    avards.sort((a, b) => a.count - b.count)

    for (const avard of avards) {
      const drop = new GatchaDrop(6)
      drop.count = avard.count
      drop.dataGlobalId = avard.characterId
      unit.addDrop(drop)
    }
  }

  addBonuses (unit, settings) {
    const possibleBonuses = [0, 1]

    while (this.procChance(settings.bonusChance, 'bonus', this.avatar.forcedDrops) && possibleBonuses.length > 0) {
      this.avatar.forcedDrops = this.calcForcedDrop(true, 'bonus', 'bonus', this.avatar.forcedDrops, settings.name)
      const bonusIndex = nextInt(0, possibleBonuses.length)
      const bonusType = possibleBonuses[bonusIndex]

      switch (bonusType) {
        case 0: {
          const gems = new GatchaDrop(8)
          gems.count = DIAMONDS_REWARD[nextInt(0, DIAMONDS_REWARD.length)]
          unit.addDrop(gems)
          break
        }
        case 1: {
          const tokens = new GatchaDrop(2)
          tokens.count = settings.doublers[nextInt(0, settings.doublers.length)]
          unit.addDrop(tokens)
          break
        }
        case 2: {
          const tickets = new GatchaDrop(3)
          tickets.count = settings.tickets[nextInt(0, settings.tickets.length)]
          unit.addDrop(tickets)
          break
        }
      }

      possibleBonuses.splice(bonusIndex, 1)
    }

    if (possibleBonuses.length === 2) {
      this.avatar.forcedDrops = this.calcForcedDrop(false, 'bonus', 'bonus', this.avatar.forcedDrops, settings.name)
    }
  }

  simulateGatcha (unit) {
    const settings = BOX_SETTINGS[unit.type]
    if (settings == null) return

    const { unlocked, unlockable } = this.getUnlockableBrawlers()
    this.avatar.rollsSinceGoodDrop++

    const bonusChance = this.getBonusChance(unlocked.length, settings.bonusChances)

    if (unit.type === 10) {
      let isBr = false
      let canDropSp

      if (unlockable.length > 0) {
        this.avatar.forcedDrops = this.calcForcedDrop(false, 'character', 'starpower', this.avatar.forcedDrops, settings.name)
      }

      canDropSp = this.canDropStarpower()

      if (this.procChance(settings.characterChance + bonusChance, 'character', this.avatar.forcedDrops) && unlockable.length > 0) {
        isBr = true
        this.dropCharacter(unit, unlockable, settings.name)
      }

      if (!isBr && canDropSp) {
        const sps = this.collectStarpowerCandidates()
        if (this.procChance(settings.starpowerChance, 'starpower', this.avatar.forcedDrops) && sps.length > 0) {
          this.dropStarpower(unit, sps, settings.name)
        } else {
          this.avatar.forcedDrops = this.calcForcedDrop(false, 'card_notchar', 'starpower', this.avatar.forcedDrops, settings.name)
          canDropSp = false
        }
      }

      if (!canDropSp && !isBr) {
        const coins = new GatchaDrop(7)
        coins.count = nextInt(settings.pp[0], settings.pp[1])
        unit.addDrop(coins)

        this.addPowerPoints(unit, settings.pp[4], settings.pp[2], settings.pp[3])
        this.addBonuses(unit, settings)
      }
      return
    }

    const coins = new GatchaDrop(7)
    coins.count = nextInt(settings.coins[0], settings.coins[1])
    unit.addDrop(coins)

    this.addPowerPoints(unit, settings.pp[2], settings.pp[0], settings.pp[1])

    let isBr = false
    while (this.procChance(settings.characterChance + bonusChance, 'character', this.avatar.forcedDrops) && unlockable.length > 0) {
      isBr = true
      this.dropCharacter(unit, unlockable, settings.name)
    }

    if (unlockable.length > 0 && !isBr) {
      this.avatar.forcedDrops = this.calcForcedDrop(false, 'character', 'starpower', this.avatar.forcedDrops, settings.name)
    }

    const canDropSp = this.canDropStarpower()
    if (canDropSp) {
      const sps = this.collectStarpowerCandidates()
      if (sps.length > 0) {
        let spdrop = false
        while (this.procChance(settings.starpowerChance, 'starpower', this.avatar.forcedDrops) && sps.length > 0) {
          spdrop = true
          this.dropStarpower(unit, sps, settings.name)
        }

        if (sps.length > 0 && !spdrop) {
          this.avatar.forcedDrops = this.calcForcedDrop(false, 'card_notchar', 'starpower', this.avatar.forcedDrops, settings.name)
        }
      }
    }

    this.addBonuses(unit, settings)
  }

  enter (dateTime) {
    this.home.homeVisited()
    this.home.tick(false)
  }

  clientTurnReceived (tick, checksum, commands) {
    this.home.tick()
  }
}

module.exports = HomeMode
