const LogicServerListener = require('../Listener/LogicServerListener')
const ByteStreamHelper = require('../Helper/ByteStreamHelper')
const TeamMessage = require('../../Protocol/Messages/Server/TeamMessage')
const TeamStreamMessage = require('../../Protocol/Messages/Server/TeamStreamMessage')

class TeamEntry {
  static CAPACITY = 3

  constructor () {
    this.id = 0
    this.type = 0
    this.locationId = 0
    this.members = []
    this.invites = []
    this.joinRequests = []
    this.disabledBots = []
    this.battlePlayerMap = null
    this.eventSlot = 1
    this.entryCounter = 0
    this.stream = []
  }

  sendToMembers (message) {
    for (const member of this.members.slice()) {
      if (LogicServerListener.instance.isPlayerOnline(member.accountId)) {
        const listener = LogicServerListener.instance.getGameListener(member.accountId)
        if (listener != null) listener.sendTCPMessage(message)
      }
    }
  }

  addStreamEntry (entry) {
    if (entry == null) return
    entry.id = ++this.entryCounter
    this.stream.push(entry)

    const message = new TeamStreamMessage()
    message.teamId = this.id
    message.entries = [entry]
    this.sendToMembers(message)
  }

  streamUpdated () {
  }

  getMember (id) {
    return this.members.find(member => member.accountId === id) || null
  }

  getInviteById (id) {
    return this.invites.find(invite => invite.id === id) || null
  }

  isEveryoneReady () {
    for (const member of this.members) {
      if (!member.isReady) return false
    }
    return true
  }

  teamUpdated () {
    const message = new TeamMessage()
    message.team = this
    this.sendToMembers(message)
  }

  encode (stream) {
    stream.writeVInt(this.type)
    stream.writeBoolean(this.type === 1)
    stream.writeVInt(TeamEntry.CAPACITY)
    stream.writeLong(this.id)
    stream.writeVInt(0)
    stream.writeBoolean(false)
    stream.writeBoolean(false)
    stream.writeVInt(0)
    stream.writeVInt(0)
    ByteStreamHelper.writeDataReference(stream, this.locationId)
    ByteStreamHelper.writeBattlePlayerMap(stream, this.battlePlayerMap)

    const members = this.members.slice()
    stream.writeVInt(members.length)
    for (const entry of members) {
      entry.encode(stream)
    }

    const invites = this.invites.slice()
    stream.writeVInt(invites.length)
    for (const entry of invites) {
      entry.encode(stream)
    }

    const joinRequests = this.joinRequests.slice()
    stream.writeVInt(joinRequests.length)
    for (const request of joinRequests) {
      request.encode(stream)
    }

    const disabledBots = this.disabledBots.slice()
    stream.writeVInt(disabledBots.length)
    for (const slot of disabledBots) {
      stream.writeVInt(slot)
    }
    stream.writeVInt(6)
  }

}

module.exports = TeamEntry
