const Command = require('../Command')

class LogicChangeAvatarNameCommand extends Command {
  constructor () {
    super()
    this.name = null
    this.changeNameCost = 0
  }

  encode (stream) {
    stream.writeString(this.name)
    stream.writeVInt(this.changeNameCost)
  }

  execute (homeMode) {
    homeMode.avatar.name = this.name
    homeMode.avatar.nameSetByUser = true
    return 0
  }

  getCommandType () {
    return 201
  }
}

module.exports = LogicChangeAvatarNameCommand
