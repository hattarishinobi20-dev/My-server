const path = require('path')
const JsonTable = require('./JsonTable')
const Account = require('./Models/Account')
const AccountCache = require('./Cache/AccountCache')
const Hero = require('../../Logic/Home/Structures/Hero')
const Helpers = require('../Utils/Helpers')
const Logger = require('../Logger')

class Accounts {
  static avatarIdCounter = 0
  static table = null

  static init (databaseName) {
    this.table = new JsonTable(path.join(__dirname, '../..', databaseName, 'accounts.json'))
    this.table.load()

    AccountCache.init()

    this.avatarIdCounter = this.getMaxAvatarId()
  }

  static serialize (account) {
    return JSON.parse(JSON.stringify(account))
  }

  static getMaxAvatarId () {
    return this.table.getMaxId()
  }

  static create () {
    const account = new Account()
    account.accountId = ++this.avatarIdCounter
    account.passToken = Helpers.randomString(40)

    account.avatar.accountId = account.accountId
    account.avatar.passToken = account.passToken

    account.home.homeId = account.accountId

    const hero = new Hero(16000000, 23000000)
    account.avatar.heroes.push(hero)

    this.table.insert({ Id: account.accountId, Trophies: account.avatar.trophies, Data: this.serialize(account) })

    AccountCache.cache(account)

    return account
  }

  static save (account) {
    if (account == null) return

    this.table.update(account.accountId, { Trophies: account.avatar.trophies, Data: this.serialize(account) })
  }

  static load (id) {
    if (AccountCache.isAccountCached(id)) {
      return AccountCache.getAccount(id)
    }

    const row = this.table.select(id)
    if (row != null) {
      const account = Account.fromJSON(row.Data)
      AccountCache.cache(account)
      return account
    }

    return null
  }

  static loadNoChache (id) {
    if (AccountCache.isAccountCached(id)) {
      return AccountCache.getAccount(id)
    }

    const row = this.table.select(id)
    if (row != null) {
      return Account.fromJSON(row.Data)
    }

    return null
  }

  static getRankingList () {
    const Alliances = require('./Alliances')
    const list = []

    try {
      const rows = this.table.selectAll().sort((a, b) => b.Trophies - a.Trophies).slice(0, 200)

      for (const row of rows) {
        const account = Account.fromJSON(row.Data)
        const allianceId = account.avatar.allianceId
        if (allianceId > 0) {
          const alliance = Alliances.load(allianceId)
          if (alliance != null) {
            account.avatar.allianceName = alliance.name
          }
        }

        list.push(account)
      }
    } catch (e) {
      Logger.error('Ranking list error: ' + (e.stack || e))
    }

    return list
  }

  static getBrawlersRankingList () {
    const Alliances = require('./Alliances')
    const list = new Map()

    for (const row of this.table.selectAll()) {
      try {
        const account = Account.fromJSON(row.Data)
        const allianceId = account.avatar.allianceId
        if (allianceId > 0) {
          const alliance = Alliances.load(allianceId)
          if (alliance != null) {
            account.avatar.allianceName = alliance.name
          }
        }

        for (const hero of account.avatar.heroes) {
          if (list.has(hero.characterId)) {
            list.get(hero.characterId).push(account)
          } else {
            list.set(hero.characterId, [account])
          }
        }
      } catch (e) {
        Logger.error('LB Error' + (e.stack || e))
      }
    }

    return list
  }

  static flush () {
    if (this.table != null) this.table.flush()
  }
}

module.exports = Accounts
