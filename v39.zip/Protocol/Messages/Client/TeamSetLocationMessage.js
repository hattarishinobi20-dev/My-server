const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamSetLocationMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14363
    this.version = 0
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamSetLocationMessage
